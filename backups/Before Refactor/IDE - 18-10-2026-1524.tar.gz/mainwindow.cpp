#include <QScrollArea>
#include "mainwindow.h"

#include "codeeditor.h"
#include "guidesigner.h"
#include "gamedesigner.h"
#include "gamemainownership.h"
#include "optionsdialog.h"
#include "findreplacedialog.h"
#include "projectsettingsdialog.h"
#include "ui_mainwindow.h"

#include <algorithm>
#include <cmath>
#include <QSet>
#include <QAction>
#include <QApplication>
#include <QClipboard>
#include <QCloseEvent>
#include <QColor>
#include <QCheckBox>
#include <QComboBox>
#include <QFormLayout>
#include <QGridLayout>
#include <QHeaderView>
#include <QGroupBox>
#include <QSignalBlocker>
#include <QSizePolicy>
#include <QSize>
#include <QSpinBox>
#include <QToolButton>
#include <QAbstractButton>
#include <QAbstractItemView>
#include <QCoreApplication>
#include <QDir>
#include <QDirIterator>
#include <QDateTime>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDrag>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QFile>
#include <QFileSystemWatcher>
#include <QFileDialog>
#include <QFileInfo>
#include <QFrame>
#include <QFontDatabase>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QCryptographicHash>
#include <QLockFile>
#include <QUuid>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QKeySequence>
#include <QLabel>
#include <QListWidget>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QTreeWidgetItemIterator>
#include <QLineEdit>
#include <QLayoutItem>
#include <QLocale>
#include <QMenu>
#include <QMessageBox>
#include <QMetaObject>
#include <QMouseEvent>
#include <QMimeData>
#include <QUrl>
#include <QPlainTextEdit>
#include <QPixmap>
#include <QGraphicsEffect>
#include <QPainter>
#include <QPushButton>
#include <QPoint>
#include <QProcess>
#include <QProgressBar>
#include <QPointer>
#include <QRegularExpression>
#include <QRunnable>
#include <QThreadPool>
#include <QSaveFile>
#include <QScrollBar>
#include <QSettings>
#include <QSplitter>
#include <QStatusBar>
#include <QTabWidget>
#include <QTabBar>
#include <QTemporaryDir>
#include <QTextCharFormat>
#include <QTextBlock>
#include <QTextBrowser>
#include <QTextCursor>
#include <QTextDocument>
#include <QTextStream>
#include <QTimer>
#include <QToolBar>
#include <QVBoxLayout>
#include <QVariant>
#include <QVector>
#include <QTextEdit>
#include <QStandardPaths>
#include <QStyle>
#include <functional>
#include <memory>
#include <limits>
#include <utility>
#include <zlib.h> // RFC 1952 gzip history snapshots

namespace {
// At the default ELF virtual base (0xD0010000), the 6 MiB SDRAM
// applet/music region ends 6080 KiB later at 0xD0600000.
constexpr int V2MaxAppletKiB = 6080;
constexpr int ProjectFileVersion = 2;

/*
 * Stage 35: On-save source history, stored with the project.
 *
 *   .history/src/main.c.20261013-234501-123.his
 *
 * Historical versions are not C source files, and are not added to the project.
 * A revision is captured BEFORE a changed file is overwritten. This is
 * intentionally different from the IDE's unsaved crash-recovery snapshots.
 */
constexpr int MaxFileHistoryRevisions = 40;
constexpr int FileHistoryRetentionDays = 30;
// Compressed snapshots are independent gzip revisions, NOT delta chains.
// Existing Stage 35 plaintext and Stage 37 Qt-compressed .his stay readable;
// incompressible revisions remain plain .his.
constexpr qsizetype MaxCompressedHistorySourceBytes = 128 * 1024 * 1024;
const QByteArray HistoryCompressionHeader = QByteArrayLiteral("CGHISTORY-ZLIB-v1\n");

bool isHistoryTextFile(const QString &path)
{
    const QString suffix = QFileInfo(path).suffix().toLower();
    return suffix == QStringLiteral("c") || suffix == QStringLiteral("h")
        || suffix == QStringLiteral("cc") || suffix == QStringLiteral("cpp")
        || suffix == QStringLiteral("hpp") || suffix == QStringLiteral("inc")
        || suffix == QStringLiteral("res") || suffix == QStringLiteral("txt")
        || suffix == QStringLiteral("md");
}

QString historyFolderForFile(const QString &projectRoot, const QString &filePath)
{
    if (projectRoot.isEmpty() || filePath.isEmpty() || !isHistoryTextFile(filePath))
        return {};

    // Canonical paths exclude symlinks that lead outside the project.
    const QString root = QFileInfo(projectRoot).canonicalFilePath();
    const QString target = QFileInfo(filePath).canonicalFilePath();
    if (root.isEmpty() || target.isEmpty()
        || !target.startsWith(root + QDir::separator()))
        return {};

    const QString relative = QDir(root).relativeFilePath(target);
    if (relative.startsWith(QStringLiteral(".history/"))
        || relative.startsWith(QStringLiteral("build/"))
        || relative.startsWith(QStringLiteral("buildv1/")))
        return {};

    const QString relativeDir = QFileInfo(relative).path();
    return QDir(root).filePath(
        relativeDir == QStringLiteral(".")
            ? QStringLiteral(".history")
            : QStringLiteral(".history/") + relativeDir);
}

// Stage 39: both legacy .his and independently recoverable .his.gz snapshots.
// Keep the timestamp parser shared by listing, pruning and the diff browser.
QString historyRevisionStamp(const QString &name, const QString &filename)
{
    const QString prefix = filename + QLatin1Char('.');
    if (!name.startsWith(prefix)) return {};
    int extensionSize = 0;
    if (name.endsWith(QStringLiteral(".his.gz"))) extensionSize = 7;
    else if (name.endsWith(QStringLiteral(".his"))) extensionSize = 4;
    else return {};
    const QString stamp = name.mid(prefix.size(), name.size()
                                  - prefix.size() - extensionSize);
    return QDateTime::fromString(stamp, QStringLiteral("yyyyMMdd-HHmmss-zzz"))
               .isValid() ? stamp : QString();
}

// Native gzip (RFC 1952), readable by gzip, 7-Zip and Ark. zlib's gzip
// wrapper provides CRC32 and ISIZE checksums. No external gzip command needed.
bool compressHistoryGzip(const QByteArray &source, QByteArray *result)
{
    if (!result || source.size() > MaxCompressedHistorySourceBytes) return false;
    z_stream stream{};
    if (deflateInit2(&stream, 6, Z_DEFLATED, MAX_WBITS + 16,
                     MAX_MEM_LEVEL, Z_DEFAULT_STRATEGY) != Z_OK)
        return false;
    const uLong bound = deflateBound(&stream, static_cast<uLong>(source.size()));
    if (bound > static_cast<uLong>(std::numeric_limits<int>::max())) {
        deflateEnd(&stream);
        return false;
    }
    QByteArray packed(static_cast<qsizetype>(bound), '\0');
    stream.next_in = reinterpret_cast<Bytef *>(const_cast<char *>(source.constData()));
    stream.avail_in = static_cast<uInt>(source.size());
    stream.next_out = reinterpret_cast<Bytef *>(packed.data());
    stream.avail_out = static_cast<uInt>(packed.size());
    const int rc = deflate(&stream, Z_FINISH);
    const bool ok = rc == Z_STREAM_END;
    if (ok) packed.resize(static_cast<qsizetype>(stream.total_out));
    deflateEnd(&stream);
    if (ok) *result = std::move(packed);
    return ok;
}

bool uncompressHistoryGzip(const QByteArray &packed, QByteArray *result,
                           QString *error)
{
    if (!result || packed.size() > MaxCompressedHistorySourceBytes + 1024 * 1024) {
        if (error) *error = QObject::tr("Compressed revision exceeds size limit.");
        return false;
    }
    z_stream stream{};
    if (inflateInit2(&stream, MAX_WBITS + 16) != Z_OK) {
        if (error) *error = QObject::tr("Cannot initialise gzip decoder.");
        return false;
    }
    stream.next_in = reinterpret_cast<Bytef *>(const_cast<char *>(packed.constData()));
    stream.avail_in = static_cast<uInt>(packed.size());
    QByteArray decoded;
    char chunk[65536];
    int status = Z_OK;
    do {
        stream.next_out = reinterpret_cast<Bytef *>(chunk);
        stream.avail_out = sizeof(chunk);
        status = inflate(&stream, Z_NO_FLUSH);
        if (status != Z_OK && status != Z_STREAM_END) break;
        const qsizetype count = sizeof(chunk) - stream.avail_out;
        if (count > MaxCompressedHistorySourceBytes - decoded.size()) {
            status = Z_MEM_ERROR;
            break;
        }
        decoded.append(chunk, count);
    } while (status != Z_STREAM_END);
    const bool ok = status == Z_STREAM_END && stream.avail_in == 0;
    inflateEnd(&stream);
    if (!ok) {
        if (error) *error = QObject::tr("Invalid, truncated or oversized gzip revision.");
        return false;
    }
    *result = std::move(decoded);
    return true;
}

QStringList historyRevisions(const QString &directory, const QString &filename)
{
    QStringList revisions;
    QDir folder(directory);
    if (!folder.exists()) return revisions;

    // Both gzip and older .his files share the same sortable timestamp.
    for (const QString &name : folder.entryList(QDir::Files | QDir::NoSymLinks,
                                                 QDir::Name)) {
        if (!historyRevisionStamp(name, filename).isEmpty())
            revisions.append(folder.filePath(name));
    }
    revisions.sort();
    return revisions;
}

// A rolling 30-day window and 40-version hard ceiling. Expiry is evaluated
// when history is opened AND on each new save (not only at IDE startup).
void pruneFileHistory(const QString &directory, const QString &filename)
{
    const QStringList revisions = historyRevisions(directory, filename);
    const QDateTime cutoff = QDateTime::currentDateTime().addDays(-FileHistoryRetentionDays);
    QStringList retained;
    for (const QString &path : revisions) {
        const QString name = QFileInfo(path).fileName();
        const QDateTime time = QDateTime::fromString(
            historyRevisionStamp(name, filename), QStringLiteral("yyyyMMdd-HHmmss-zzz"));
        if (time.isValid() && time < cutoff)
            QFile::remove(path);
        else
            retained.append(path);
    }
    for (int i = 0; i < retained.size() - MaxFileHistoryRevisions; ++i)
        QFile::remove(retained.at(i));
}

// The on-disk extension stays .his. The magic header distinguishes compressed
// revisions from Stage 35/36 plaintext revisions, preserving compatibility.
// Each snapshot is self-contained so damage/loss of one never breaks the others.
bool readFileHistorySnapshot(const QString &path, QString *text, QString *error)
{
    QFile snapshot(path);
    if (!snapshot.open(QIODevice::ReadOnly)) {
        if (error) *error = snapshot.errorString();
        return false;
    }
    QByteArray raw = snapshot.readAll();
    if (snapshot.error() != QFileDevice::NoError) {
        if (error) *error = QObject::tr("Cannot read revision completely.");
        return false;
    }
    if (path.endsWith(QStringLiteral(".his.gz"))) {
        QByteArray unpacked;
        if (!uncompressHistoryGzip(raw, &unpacked, error)) return false;
        raw = std::move(unpacked);
    } else if (raw.startsWith(HistoryCompressionHeader)) {
        const QByteArray payload = raw.mid(HistoryCompressionHeader.size());
        if (payload.size() < 6) {
            if (error) *error = QObject::tr("Truncated compressed revision.");
            return false;
        }
        // qCompress begins with a 32-bit big-endian original length. Check it
        // before allowing a damaged snapshot to allocate arbitrary memory.
        quint32 size = 0;
        for (int i = 0; i < 4; ++i)
            size = (size << 8) | static_cast<quint8>(payload.at(i));
        if (size > static_cast<quint32>(MaxCompressedHistorySourceBytes)) {
            if (error) *error = QObject::tr("Revision exceeds safe decompression limit.");
            return false;
        }
        raw = qUncompress(payload);
        if (raw.size() != static_cast<qsizetype>(size)) {
            if (error) *error = QObject::tr("Compressed revision is damaged.");
            return false;
        }
    }
    if (text) *text = QString::fromUtf8(raw);
    return true;
}

bool backupFileBeforeSave(const QString &projectRoot, const QString &filePath,
                          const QString &editorText, QString *error)
{
    const QString directory = historyFolderForFile(projectRoot, filePath);
    if (directory.isEmpty()) return true; // Not a project source file.

    QFile current(filePath);
    if (!current.open(QIODevice::ReadOnly)) {
        if (error) *error = QObject::tr("Cannot read the original file: %1")
                           .arg(current.errorString());
        return false;
    }
    const QByteArray original = current.readAll();
    if (current.error() != QFileDevice::NoError) {
        if (error) *error = QObject::tr("Cannot read the original file completely.");
        return false;
    }
    current.close();

    // Pressing Save on an unchanged file must not create fake revisions.
    if (QString::fromUtf8(original) == editorText) return true;

    if (!QDir().mkpath(directory)) {
        if (error) *error = QObject::tr("Cannot create history directory: %1")
                           .arg(QDir::toNativeSeparators(directory));
        return false;
    }

    // Project backups contain source code: keep permissions user-only.
    const QString historyRoot = QDir(QFileInfo(projectRoot).canonicalFilePath())
                                    .filePath(QStringLiteral(".history"));
    const QFileDevice::Permissions privateDir =
        QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner;
    QFile::setPermissions(historyRoot, privateDir);
    QFile::setPermissions(directory, privateDir);

    const QString baseName = QFileInfo(filePath).fileName();
    const QString stamp = QDateTime::currentDateTime()
                              .toString(QStringLiteral("yyyyMMdd-HHmmss-zzz"));
    QString destination = QDir(directory).filePath(
        baseName + QLatin1Char('.') + stamp + QStringLiteral(".his.gz"));
    // The same file may be saved twice within a millisecond. Never overwrite
    // a previous revision: wait until the clock produces a free timestamp.
    int suffix = 0;
    while (QFileInfo::exists(destination)
           || QFileInfo::exists(destination.left(destination.size() - 3))) {
        ++suffix;
        const QDateTime future = QDateTime::fromString(
             stamp, QStringLiteral("yyyyMMdd-HHmmss-zzz")).addMSecs(suffix);
        destination = QDir(directory).filePath(
            baseName + QLatin1Char('.')
            + future.toString(QStringLiteral("yyyyMMdd-HHmmss-zzz"))
            + QStringLiteral(".his.gz"));
    }

    // Standard gzip when smaller; otherwise store the raw source as .his.
    QByteArray stored = original;
    QByteArray packed;
    const bool compress = compressHistoryGzip(original, &packed)
                       && packed.size() < original.size();
    if (compress) stored = std::move(packed);
    else destination.chop(3); // .his.gz -> .his (plain text)

    QSaveFile copy(destination);
    if (!copy.open(QIODevice::WriteOnly)) {
        if (error) *error = QObject::tr("Cannot create snapshot: %1")
                           .arg(copy.errorString());
        return false;
    }
    if (copy.write(stored) != stored.size() || !copy.commit()) {
        if (error) *error = QObject::tr("Cannot finish writing history snapshot: %1")
                           .arg(copy.errorString());
        copy.cancelWriting();
        return false;
    }
    QFile::setPermissions(destination,
        QFileDevice::ReadOwner | QFileDevice::WriteOwner);

    // Prune only AFTER the new independent revision is safely written.
    pruneFileHistory(directory, baseName);
    return true;
}

// Shell single-quote a generated absolute path or filename without allowing
// project names with apostrophes, $, spaces etc. to become shell commands.
QString shellQuoted(QString input)
{
    input.replace(QLatin1Char('\''), QStringLiteral("'\\''"));
    return QLatin1Char('\'') + input + QLatin1Char('\'');
}

bool writeStandaloneLinuxBuildFiles(const QString &projectFile,
                                    const QString &sdkDirectory,
                                    const QString &appFileName,
                                    int appKb, int heapKb, int stackKb,
                                    const QString &linker, QString *error)
{
    const QFileInfo projectInfo(projectFile);
    const QString projectDir = projectInfo.absolutePath();
    const QString buildScriptPath = QDir(projectDir).filePath(QStringLiteral("build.sh"));
    const QString makefilePath = QDir(projectDir).filePath(QStringLiteral("Makefile"));
    const QString projectName = projectInfo.fileName();
    if (projectName.isEmpty()) {
        if (error) *error = QObject::tr("No saved project file.");
        return false;
    }

    // The project file is beside build.sh. SDK path is the IDE's currently
    // resolved idelibs location; SIDBOX_SDK may override it after a move.
    QString sh;
    sh += QStringLiteral("#!/usr/bin/env bash\n");
    sh += QStringLiteral("# Generated by CoderGirl - Standalone V2 build\n");
    sh += QStringLiteral("# Regenerate from the IDE if project settings change.\n");
    sh += QStringLiteral("set -euo pipefail\n");
    sh += QStringLiteral("PROJECT_DIR=\"$(cd -- \"$(dirname -- \"${BASH_SOURCE[0]}\")\" && pwd)\"\n");
    sh += QStringLiteral("SDK_DEFAULT=") + shellQuoted(sdkDirectory) + QLatin1Char('\n');
    sh += QStringLiteral("SDK=\"${SIDBOX_SDK:-$SDK_DEFAULT}\"\n");
    sh += QStringLiteral("BUILDER=\"$SDK/tools/bin/cgarm-build\"\n");
    sh += QStringLiteral("if [[ ! -x \"$BUILDER\" ]]; then\n");
    sh += QStringLiteral("  printf 'Cannot execute cgarm-build: %s\\nSet SIDBOX_SDK to the idelibs directory.\\n' \"$BUILDER\" >&2\n");
    sh += QStringLiteral("  exit 1\nfi\n");
    sh += QStringLiteral("cd -- \"$PROJECT_DIR\"\n");
    sh += QStringLiteral("exec \"$BUILDER\" \"$PROJECT_DIR\"/")
          + shellQuoted(projectName) + QStringLiteral(" \\\n");
    sh += QStringLiteral("  -o \"$PROJECT_DIR\"/") + shellQuoted(appFileName)
          + QStringLiteral(" \\\n");
    sh += QStringLiteral("  --sdk \"$SDK\" \\\n");
    sh += QStringLiteral("  --app-kb ") + QString::number(appKb) + QStringLiteral(" \\\n");
    sh += QStringLiteral("  --heap-kb ") + QString::number(heapKb) + QStringLiteral(" \\\n");
    sh += QStringLiteral("  --stack-kb ") + QString::number(stackKb) + QStringLiteral(" \\\n");
    sh += QStringLiteral("  --linker ") + shellQuoted(linker) + QStringLiteral(" \\\n");
    sh += QStringLiteral("  \"$@\"\n");

    const QString makefile = QStringLiteral(
        "# Generated by CoderGirl - V2 applet\n"
        "# This Makefile delegates to the same cgarm-build backend as the IDE.\n"
        ".PHONY: all clean rebuild\n"
        "all:\n"
        "\t@bash ./build.sh\n"
        "clean:\n"
        "\t@bash ./build.sh --clean\n"
        "rebuild:\n"
        "\t@bash ./build.sh --rebuild\n");

    // Each output is committed atomically with QSaveFile, so a failed write
    // cannot leave a truncated build script or Makefile.
    QSaveFile script(buildScriptPath);
    if (!script.open(QIODevice::WriteOnly | QIODevice::Text)
        || script.write(sh.toUtf8()) != sh.toUtf8().size() || !script.commit()) {
        if (error) *error = QObject::tr("Could not write build.sh: %1").arg(script.errorString());
        return false;
    }
    if (!QFile::setPermissions(buildScriptPath,
            QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner
            | QFileDevice::ReadGroup | QFileDevice::ExeGroup
            | QFileDevice::ReadOther | QFileDevice::ExeOther)) {
        if (error) *error = QObject::tr("Could not mark build.sh executable.");
        return false;
    }
    QSaveFile mk(makefilePath);
    if (!mk.open(QIODevice::WriteOnly | QIODevice::Text)
        || mk.write(makefile.toUtf8()) != makefile.toUtf8().size() || !mk.commit()) {
        if (error) *error = QObject::tr("Could not write Makefile: %1").arg(mk.errorString());
        return false;
    }
    return true;
}

// Stage 40: V1 GUI/Gaming standalone export mirrors the IDE's original GCC
// build instead of routing legacy fixed-address applets through CGARM V2.
// The linker script has already been written from gui.ld/gaming.ld (or chosen
// explicitly by the user) when the IDE saves its .proj.
struct StandaloneV1Options {
    QString projectFile;
    QString sdkDirectory;
    QString linkerScript;
    QString outputAppName;
    QStringList sources;
    QString optimisation;
    QString extraFlags;
    bool suppressWarnings = false;
    bool wall = false;
    bool wextra = false;
    bool functionSections = false;
    bool dataSections = false;
    bool stackUsage = false;
    bool gaming = false;
};

bool writeStandaloneV1LinuxBuildFiles(const StandaloneV1Options &opts,
                                      QString *error)
{
    const QFileInfo info(opts.projectFile);
    const QString root = info.absolutePath();
    const QDir projectDir(root);
    if (opts.sources.isEmpty()) {
        if (error) *error = QObject::tr("No V1 sources were found for standalone export.");
        return false;
    }
    if (!QFileInfo(opts.linkerScript).isFile()) {
        if (error) *error = QObject::tr("V1 linker script missing: %1").arg(opts.linkerScript);
        return false;
    }

    // Keep paths inside the project relative to the script, so moving the
    // project directory doesn't invalidate its C files and generated .ld.
    const auto projectShellPath = [&](const QString &absolute) -> QString {
        const QString relative = projectDir.relativeFilePath(QFileInfo(absolute).absoluteFilePath());
        return QStringLiteral("\"$PROJECT_DIR\"/") + shellQuoted(relative);
    };

    QString sh = QStringLiteral(
        "#!/usr/bin/env bash\n"
        "# Generated by CoderGirl - V1 fixed-address GUI/Gaming applet\n"
        "# Regenerate from the IDE when source files or build settings change.\n"
        "set -euo pipefail\n"
        "PROJECT_DIR=\"$(cd -- \"$(dirname -- \"${BASH_SOURCE[0]}\")\" && pwd)\"\n"
        "SDK_DEFAULT=");
    sh += shellQuoted(opts.sdkDirectory) + QLatin1Char('\n');
    sh += QStringLiteral(
        "SDK=\"${SIDBOX_SDK:-$SDK_DEFAULT}\"\n"
        "TOOLS=\"$SDK/tools/bin\"\n"
        "GCC=\"$TOOLS/arm-none-eabi-gcc\"\n"
        "OBJDUMP=\"$TOOLS/arm-none-eabi-objdump\"\n"
        "OBJCOPY=\"$TOOLS/arm-none-eabi-objcopy\"\n"
        "for exe in \"$GCC\" \"$OBJDUMP\" \"$OBJCOPY\"; do\n"
        "  if [[ ! -x \"$exe\" ]]; then\n"
        "    printf 'Missing executable: %s\\nOverride the SDK with SIDBOX_SDK=/path/to/idelibs\\n' \"$exe\" >&2\n"
        "    exit 1\n"
        "  fi\n"
        "done\n"
        "cd -- \"$PROJECT_DIR\"\n"
        "BUILD=\"$PROJECT_DIR/buildv1\"\n"
        "STEM=");
    sh += shellQuoted(info.completeBaseName()) + QLatin1Char('\n');
    sh += QStringLiteral("ELF=\"$BUILD/$STEM.elf\"\n"
                         "MAP=\"$BUILD/$STEM.map\"\n"
                         "ASM=\"$BUILD/$STEM.asm\"\n"
                         "APP=\"$PROJECT_DIR\"/");
    sh += shellQuoted(opts.outputAppName) + QLatin1Char('\n');
    sh += QStringLiteral("LINKER=") + projectShellPath(opts.linkerScript) + QLatin1Char('\n');
    sh += QStringLiteral(
        "case \"${1:-}\" in\n"
        "  --clean) rm -rf -- \"$BUILD\"; rm -f -- \"$APP\"; exit 0 ;;\n"
        "  --rebuild) rm -rf -- \"$BUILD\"; rm -f -- \"$APP\"; shift ;;\n"
        "  '') ;;\n"
        "  *) echo 'Usage: ./build.sh [--clean|--rebuild]' >&2; exit 2 ;;\n"
        "esac\n"
        "if [[ ! -f \"$LINKER\" ]]; then\n"
        "  printf 'Missing linker script: %s\\nRe-export from CoderGirl to generate its .ld file.\\n' \"$LINKER\" >&2\n"
        "  exit 1\n"
        "fi\n"
        "mkdir -p -- \"$BUILD\"\n"
        "# Compile from buildv1 so implicit GCC sidecars (for example .su)\n"
        "# never spill into the project root. All input/output paths are absolute.\n"
        "cd -- \"$BUILD\"\n"
        "SOURCES=(\n");
    for (const QString &source : opts.sources)
        sh += QStringLiteral("  ") + projectShellPath(source) + QLatin1Char('\n');
    sh += QStringLiteral(")\n"
        "# The IDE only compiles existing SDK API modules. Mirror that set.\n"
        "for api in applet.s apis.c syscalls.c crt/crt.c graphics/graphics.c audio/audio.c touch/touch.c; do\n"
        "  if [[ -f \"$SDK/api/$api\" ]]; then SOURCES+=(\"$SDK/api/$api\"); fi\n"
        "done\n"
        "LIBRARIES=()\n"
        "if [[ -d \"$SDK/libraries\" ]]; then\n"
        "  while IFS= read -r -d '' lib; do LIBRARIES+=(\"$lib\"); done < <(find \"$SDK/libraries\" -type f -name '*.a' -print0 | sort -z)\n"
        "fi\n"
        "FLAGS=(-mcpu=cortex-m7 -mthumb -mfpu=fpv5-d16 -mfloat-abi=hard\n"
        "  -std=gnu99 ");
    sh += shellQuoted(opts.optimisation) + QStringLiteral(
        " --specs=nano.specs -mno-unaligned-access\n"
        "  -DSIDBOX_STARTUP_HEADER_IN_ASM -I \"$SDK/api\" -I \"$SDK/libraries\")\n");
    if (opts.functionSections) sh += QStringLiteral("FLAGS+=(-ffunction-sections)\n");
    if (opts.dataSections) sh += QStringLiteral("FLAGS+=(-fdata-sections)\n");
    if (opts.stackUsage) sh += QStringLiteral("FLAGS+=(-fstack-usage)\n");
    if (opts.suppressWarnings) sh += QStringLiteral("FLAGS+=(-w)\n");
    else {
        if (opts.wall) sh += QStringLiteral("FLAGS+=(-Wall)\n");
        if (opts.wextra) sh += QStringLiteral("FLAGS+=(-Wextra)\n");
    }
    const QStringList extra = QProcess::splitCommand(opts.extraFlags);
    if (!extra.isEmpty()) {
        sh += QStringLiteral("FLAGS+=(");
        for (const QString &flag : extra) sh += QLatin1Char(' ') + shellQuoted(flag);
        sh += QStringLiteral(" )\n");
    }
    sh += QStringLiteral(
        "for source in \"${SOURCES[@]}\"; do\n"
        "  if [[ ! -f \"$source\" ]]; then printf 'Missing input: %s\\n' \"$source\" >&2; exit 1; fi\n"
        "done\n"
        "# .res is a resource C file; GCC cannot infer the language from .res.\n"
        "INPUTS=()\n"
        "for source in \"${SOURCES[@]}\"; do\n"
        "  case \"$source\" in\n"
        "    *.res) INPUTS+=(-x c \"$source\" -x none) ;;\n"
        "    *) INPUTS+=(\"$source\") ;;\n"
        "  esac\n"
        "done\n"
        "echo 'Building CoderGirl legacy V1 applet using SDK GCC...'\n"
        "\"$GCC\" \"${FLAGS[@]}\" \"${INPUTS[@]}\" \"${LIBRARIES[@]}\" \\\n"
        "  -T \"$LINKER\" -Wl,-Map=\"$MAP\" -Wl,--gc-sections -static --specs=nosys.specs \\\n"
        "  -Wl,--start-group -lc -lm -Wl,--end-group -o \"$ELF\"\n"
        "\"$OBJDUMP\" -d -S \"$ELF\" > \"$ASM\"\n"
        "\"$OBJCOPY\" -O binary \"$ELF\" \"$APP\"\n"
        "printf 'Built %s\\n' \"$APP\"\n");

    const QString makefile = QStringLiteral(
        "# Generated by CoderGirl - legacy V1 %1 applet\n"
        "# build.sh contains the exact saved IDE GCC and linker settings.\n"
        ".PHONY: all clean rebuild\n"
        "all:\n\t@bash ./build.sh\n"
        "clean:\n\t@bash ./build.sh --clean\n"
        "rebuild:\n\t@bash ./build.sh --rebuild\n")
        .arg(opts.gaming ? QStringLiteral("Gaming") : QStringLiteral("GUI"));

    // Match Stage 39's atomic writes and executable permissions.
    const QString buildScriptPath = projectDir.filePath(QStringLiteral("build.sh"));
    const QString makefilePath = projectDir.filePath(QStringLiteral("Makefile"));
    QSaveFile script(buildScriptPath);
    if (!script.open(QIODevice::WriteOnly | QIODevice::Text)
        || script.write(sh.toUtf8()) != sh.toUtf8().size() || !script.commit()) {
        if (error) *error = QObject::tr("Could not write V1 build.sh: %1").arg(script.errorString());
        return false;
    }
    if (!QFile::setPermissions(buildScriptPath,
            QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner
            | QFileDevice::ReadGroup | QFileDevice::ExeGroup
            | QFileDevice::ReadOther | QFileDevice::ExeOther)) {
        if (error) *error = QObject::tr("Could not mark V1 build.sh executable.");
        return false;
    }
    QSaveFile mk(makefilePath);
    if (!mk.open(QIODevice::WriteOnly | QIODevice::Text)
        || mk.write(makefile.toUtf8()) != makefile.toUtf8().size() || !mk.commit()) {
        if (error) *error = QObject::tr("Could not write V1 Makefile: %1").arg(mk.errorString());
        return false;
    }
    return true;
}

/*
 * Stage 36: A bounded, line-based Myers diff for CoderGirl's local history.
 * The limit keeps a completely rewritten large file from running an expensive
 * quadratic edit-distance trace on the GUI thread. Ordinary edits receive
 * exact alignment, including inserted/deleted blank rows.
 */
enum class HistoryDiffOp : quint8 { Same, Remove, Add };
struct HistoryDiffLine {
    QString text;
    int number = 0;    // 1-based source line; 0 is an alignment spacer.
    bool changed = false;
};
struct HistoryDiffResult {
    QVector<HistoryDiffLine> current;
    QVector<HistoryDiffLine> previous;
    QVector<int> hunkRows; // aligned zero-based row for each change block.
    bool simplified = false;
};

HistoryDiffResult makeHistoryDiff(const QString &newText, const QString &oldText)
{
    HistoryDiffResult result;
    const QStringList a = newText.split(QLatin1Char('\n'));
    const QStringList b = oldText.split(QLatin1Char('\n'));

    // Bound initial work when someone compares a very large generated file.
    if (a.size() > 30000 || b.size() > 30000) {
        result.simplified = true;
        // Preserve side-by-side reading but don't allocate a quadratic diff.
        for (int i = 0; i < a.size(); ++i)
            result.current.append({a.at(i), i + 1, false});
        for (int i = 0; i < b.size(); ++i)
            result.previous.append({b.at(i), i + 1, false});
        return result;
    }

    int prefix = 0;
    while (prefix < a.size() && prefix < b.size() && a.at(prefix) == b.at(prefix))
        ++prefix;
    int suffix = 0;
    while (suffix < a.size() - prefix && suffix < b.size() - prefix
           && a.at(a.size() - suffix - 1) == b.at(b.size() - suffix - 1))
        ++suffix;

    const int n = a.size() - prefix - suffix;
    const int m = b.size() - prefix - suffix;
    QVector<HistoryDiffOp> operations;
    operations.reserve(a.size() + b.size());
    for (int i = 0; i < prefix; ++i)
        operations.append(HistoryDiffOp::Same);

    if (n && m) {
        // Bounded shortest edit script. A normal change of a few lines is
        // extremely cheap even when the source files themselves are large.
        constexpr int MaxEditDistance = 1200;
        const int limit = qMin(n + m, MaxEditDistance);
        const int offset = limit + 1;
        QVector<int> frontier(2 * limit + 3, -1);
        QVector<QVector<int>> trace;
        trace.reserve(limit + 1);
        frontier[offset + 1] = 0;
        int solvedAt = -1;
        for (int d = 0; d <= limit && solvedAt < 0; ++d) {
            for (int k = -d; k <= d; k += 2) {
                const bool add = (k == -d)
                    || (k != d && frontier[offset + k - 1] < frontier[offset + k + 1]);
                int x = add ? frontier[offset + k + 1]
                            : frontier[offset + k - 1] + 1;
                int y = x - k;
                while (x < n && y < m && a.at(prefix + x) == b.at(prefix + y)) {
                    ++x;
                    ++y;
                }
                frontier[offset + k] = x;
                if (x >= n && y >= m) {
                    solvedAt = d;
                    break;
                }
            }
            trace.append(frontier);
        }

        if (solvedAt >= 0) {
            QVector<HistoryDiffOp> reverseMiddle;
            int x = n;
            int y = m;
            for (int d = solvedAt; d > 0; --d) {
                const QVector<int> &prev = trace.at(d - 1);
                const int k = x - y;
                const bool add = (k == -d)
                    || (k != d && prev.at(offset + k - 1) < prev.at(offset + k + 1));
                const int prevK = add ? k + 1 : k - 1;
                const int px = prev.at(offset + prevK);
                const int py = px - prevK;
                while (x > px && y > py) {
                    reverseMiddle.append(HistoryDiffOp::Same);
                    --x;
                    --y;
                }
                reverseMiddle.append(add ? HistoryDiffOp::Add : HistoryDiffOp::Remove);
                if (add) --y;
                else --x;
            }
            while (x > 0 && y > 0) {
                reverseMiddle.append(HistoryDiffOp::Same);
                --x;
                --y;
            }
            std::reverse(reverseMiddle.begin(), reverseMiddle.end());
            operations += reverseMiddle;
        } else {
            // Extreme rewrite: show the divergent middle as a single hunk,
            // retaining the equal beginning/end instead of freezing the IDE.
            result.simplified = true;
            for (int i = 0; i < n; ++i) operations.append(HistoryDiffOp::Remove);
            for (int i = 0; i < m; ++i) operations.append(HistoryDiffOp::Add);
        }
    } else {
        for (int i = 0; i < n; ++i) operations.append(HistoryDiffOp::Remove);
        for (int i = 0; i < m; ++i) operations.append(HistoryDiffOp::Add);
    }
    for (int i = 0; i < suffix; ++i)
        operations.append(HistoryDiffOp::Same);

    // Align changed groups row by row. Empty rows keep the panes vertically
    // synchronised even when one revision has extra lines.
    int ai = 0, bi = 0;
    for (int p = 0; p < operations.size();) {
        if (operations.at(p) == HistoryDiffOp::Same) {
            result.current.append({a.at(ai), ai + 1, false});
            result.previous.append({b.at(bi), bi + 1, false});
            ++ai; ++bi; ++p;
            continue;
        }
        result.hunkRows.append(result.current.size());
        QVector<int> removed, added;
        while (p < operations.size() && operations.at(p) != HistoryDiffOp::Same) {
            if (operations.at(p) == HistoryDiffOp::Remove) removed.append(ai++);
            else added.append(bi++);
            ++p;
        }
        const int count = qMax(removed.size(), added.size());
        for (int i = 0; i < count; ++i) {
            result.current.append(i < removed.size()
                ? HistoryDiffLine{a.at(removed.at(i)), removed.at(i) + 1, true}
                : HistoryDiffLine{});
            result.previous.append(i < added.size()
                ? HistoryDiffLine{b.at(added.at(i)), added.at(i) + 1, true}
                : HistoryDiffLine{});
        }
    }
    return result;
}

QString historyDiffText(const QVector<HistoryDiffLine> &rows)
{
    QString out;
    for (int i = 0; i < rows.size(); ++i) {
        if (i) out += QLatin1Char('\n');
        const HistoryDiffLine &line = rows.at(i);
        out += (line.number > 0 ? QString::number(line.number) : QString())
                   .rightJustified(6, QLatin1Char(' '));
        out += QStringLiteral("  |  ");
        out += line.text;
    }
    return out;
}

void showHistoryDiff(QPlainTextEdit *pane, const QVector<HistoryDiffLine> &rows,
                     const QColor &colour)
{
    pane->setPlainText(historyDiffText(rows));
    QList<QTextEdit::ExtraSelection> highlights;
    for (int i = 0; i < rows.size(); ++i) {
        if (!rows.at(i).changed) continue;
        QTextEdit::ExtraSelection selection;
        selection.cursor = QTextCursor(pane->document()->findBlockByNumber(i));
        selection.format.setBackground(colour);
        selection.format.setProperty(QTextFormat::FullWidthSelection, true);
        highlights.append(selection);
    }
    pane->setExtraSelections(highlights);
    pane->moveCursor(QTextCursor::Start);
}

bool chooseFileHistoryRevision(QWidget *parent, const QString &projectRoot,
                               const QString &sourcePath, const QString &currentText,
                               bool hasUnsavedEdits, QString *restoredText)
{
    if (!restoredText) return false;
    const QString folder = historyFolderForFile(projectRoot, sourcePath);
    if (folder.isEmpty()) {
        QMessageBox::information(parent, QObject::tr("File History"),
            QObject::tr("History is available for source files inside this project."));
        return false;
    }
    const QString filename = QFileInfo(sourcePath).fileName();
    pruneFileHistory(folder, filename);
    QStringList revisions = historyRevisions(folder, filename);
    if (revisions.isEmpty()) {
        QMessageBox::information(parent, QObject::tr("File History"),
            QObject::tr("No saved revisions for %1 yet.\n\n"
                        "A revision is stored whenever you save changes over an existing source file.")
                        .arg(filename));
        return false;
    }
    std::reverse(revisions.begin(), revisions.end());

    QDialog dialog(parent);
    dialog.setWindowTitle(QObject::tr("File History — %1").arg(filename));
    dialog.resize(1240, 670);
    auto *layout = new QVBoxLayout(&dialog);
    auto *hint = new QLabel(QObject::tr(
        "Compare the current file against a saved revision. "
        "Restoring loads the old version into the editor as an unsaved change."), &dialog);
    hint->setWordWrap(true);
    layout->addWidget(hint);

    auto *outerSplit = new QSplitter(Qt::Horizontal, &dialog);
    auto *versions = new QWidget(outerSplit);
    auto *versionLayout = new QVBoxLayout(versions);
    versionLayout->setContentsMargins(0, 0, 0, 0);
    versionLayout->addWidget(new QLabel(QObject::tr("Saved versions (newest first)"), versions));
    auto *list = new QListWidget(versions);
    list->setMinimumWidth(190);
    versionLayout->addWidget(list);

    auto *diffSplit = new QSplitter(Qt::Horizontal, outerSplit);
    auto makePane = [diffSplit](const QString &name) {
        auto *container = new QWidget(diffSplit);
        auto *column = new QVBoxLayout(container);
        column->setContentsMargins(1, 0, 1, 0);
        column->setSpacing(3);
        column->addWidget(new QLabel(name, container));
        auto *editor = new QPlainTextEdit(container);
        editor->setReadOnly(true);
        editor->setLineWrapMode(QPlainTextEdit::NoWrap);
        editor->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
        editor->setCenterOnScroll(false);
        column->addWidget(editor, 1);
        return editor;
    };
    auto *currentPane = makePane(hasUnsavedEdits
        ? QObject::tr("CURRENT — unsaved editor text") : QObject::tr("CURRENT — on disk"));
    auto *historyPane = makePane(QObject::tr("HISTORY — selected revision"));
    outerSplit->setChildrenCollapsible(false);
    diffSplit->setChildrenCollapsible(false);
    outerSplit->setSizes({235, 980});
    diffSplit->setSizes({480, 480});
    layout->addWidget(outerSplit, 1);

    // Both panes have identical numbers of display lines after alignment.
    // Do not block signals on the target scrollbar: QPlainTextEdit relies on
    // those valueChanged notifications to move its *text viewport*. Blocking
    // them moves the thumb but leaves the document visually in place.
    // Instead, stop only our own mirror callback from bouncing back.
    auto syncingHistoryScroll = std::make_shared<bool>(false);
    QObject::connect(currentPane->verticalScrollBar(), &QScrollBar::valueChanged,
                     historyPane, [historyPane, syncingHistoryScroll](int value) {
        if (*syncingHistoryScroll) return;
        *syncingHistoryScroll = true;
        historyPane->verticalScrollBar()->setValue(value);
        *syncingHistoryScroll = false;
    });
    QObject::connect(historyPane->verticalScrollBar(), &QScrollBar::valueChanged,
                     currentPane, [currentPane, syncingHistoryScroll](int value) {
        if (*syncingHistoryScroll) return;
        *syncingHistoryScroll = true;
        currentPane->verticalScrollBar()->setValue(value);
        *syncingHistoryScroll = false;
    });

    auto *navigation = new QHBoxLayout;
    auto *info = new QLabel(&dialog);
    navigation->addWidget(info, 1);
    auto *prev = new QPushButton(QObject::tr("Previous change"), &dialog);
    auto *next = new QPushButton(QObject::tr("Next change"), &dialog);
    navigation->addWidget(prev);
    navigation->addWidget(next);
    layout->addLayout(navigation);

    auto *buttons = new QDialogButtonBox(QDialogButtonBox::Cancel, &dialog);
    auto *restore = buttons->addButton(QObject::tr("Restore to Editor"),
                                       QDialogButtonBox::AcceptRole);
    layout->addWidget(buttons);
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    QObject::connect(restore, &QPushButton::clicked, &dialog, &QDialog::accept);

    const QColor base = dialog.palette().color(QPalette::Base);
    const auto mix = [&base](const QColor &accent) {
        return QColor((base.red() * 6 + accent.red() * 4) / 10,
                      (base.green() * 6 + accent.green() * 4) / 10,
                      (base.blue() * 6 + accent.blue() * 4) / 10);
    };
    const QColor removedColour = mix(QColor(202, 74, 75));
    const QColor addedColour = mix(QColor(55, 161, 104));
    QVector<int> changeRows;
    auto jump = [currentPane, historyPane](int line) {
        if (line < 0) return;
        // Position the cursor at the hunk, then align both views.
        const QTextBlock block = currentPane->document()->findBlockByNumber(line);
        if (!block.isValid()) return;
        QTextCursor cursor(block);
        currentPane->setTextCursor(cursor);
        currentPane->centerCursor();
        historyPane->verticalScrollBar()->setValue(
            currentPane->verticalScrollBar()->value());
    };
    QObject::connect(next, &QPushButton::clicked, &dialog,
        [&changeRows, currentPane, jump]() {
            const int current = currentPane->textCursor().blockNumber();
            for (int row : std::as_const(changeRows)) {
                if (row > current) { jump(row); return; }
            }
            if (!changeRows.isEmpty()) jump(changeRows.first());
        });
    QObject::connect(prev, &QPushButton::clicked, &dialog,
        [&changeRows, currentPane, jump]() {
            const int current = currentPane->textCursor().blockNumber();
            for (int i = changeRows.size() - 1; i >= 0; --i) {
                if (changeRows.at(i) < current) { jump(changeRows.at(i)); return; }
            }
            if (!changeRows.isEmpty()) jump(changeRows.last());
        });

    QString selectedContent;
    bool readable = false;
    for (const QString &revision : std::as_const(revisions)) {
        const QString storedName = QFileInfo(revision).fileName();
        const QString stamp = historyRevisionStamp(storedName, filename);
        const QDateTime date = QDateTime::fromString(
            stamp, QStringLiteral("yyyyMMdd-HHmmss-zzz"));
        auto *item = new QListWidgetItem(date.isValid()
            ? date.toString(QStringLiteral("dd MMM yyyy  HH:mm:ss.zzz")) : stamp, list);
        item->setToolTip(QDir::toNativeSeparators(revision));
    }
    QObject::connect(list, &QListWidget::currentRowChanged, &dialog,
        [&](int row) {
            selectedContent.clear();
            readable = false;
            changeRows.clear();
            restore->setEnabled(false);
            if (row < 0 || row >= revisions.size()) return;
            QString readError;
            if (!readFileHistorySnapshot(revisions.at(row), &selectedContent, &readError)) {
                info->setText(QObject::tr("Unable to read this revision: %1")
                                  .arg(readError));
                currentPane->clear();
                historyPane->clear();
                prev->setEnabled(false);
                next->setEnabled(false);
                return;
            }
            readable = true;
            restore->setEnabled(true);
            const HistoryDiffResult diff = makeHistoryDiff(currentText, selectedContent);
            showHistoryDiff(currentPane, diff.current, removedColour);
            showHistoryDiff(historyPane, diff.previous, addedColour);
            changeRows = diff.hunkRows;
            prev->setEnabled(!changeRows.isEmpty());
            next->setEnabled(!changeRows.isEmpty());
            if (!changeRows.isEmpty()) jump(changeRows.first());
            if (diff.simplified) {
                info->setText(QObject::tr("Large change/file: simplified comparison (no exact alignment)."));
            } else if (changeRows.isEmpty()) {
                info->setText(QObject::tr("No differences from the current file."));
            } else {
                info->setText(QObject::tr("%1 change block(s). Red: current only. Green: history only.")
                    .arg(changeRows.size()));
            }
        });
    list->setCurrentRow(0);

    if (dialog.exec() != QDialog::Accepted || !readable)
        return false;
    *restoredText = selectedContent;
    return true;
}

const QString GuiProjectType = QStringLiteral("gui");
const QString GameProjectType = QStringLiteral("game");

// CGARM tells us the *exact* number of bytes by which its linked RAM layout
// exceeds the selected allowance. LLVM's overflow diagnostics use different
// wording and continue through the existing LLVM sizing-probe path.
qint64 cgarmRamOverflowBytes(const QString &text)
{
    static const QRegularExpression overflowExpression(
        QStringLiteral(R"(Relocation preview exceeds CGARM RAM allowance by\s+(\d+)\s+bytes)"),
        QRegularExpression::CaseInsensitiveOption);
    const QRegularExpressionMatch match = overflowExpression.match(text);
    if (!match.hasMatch()) return 0;
    bool ok = false;
    const qint64 bytes = match.captured(1).toLongLong(&ok);
    return ok && bytes > 0 ? bytes : 0;
}

/*
 * Linker errors usually name a PIC object, not its original source line.
 * cgarm-build's v2_unit_N.d file (emitted by GCC -MMD) records the actual
 * original source, even for recursive project directories and SDK sources.
 * Never infer a source from N: order can differ across filesystems.
 */
QString cgarmSourceFromDependencyFile(const QString &objectFile)
{
    if (!objectFile.endsWith(QStringLiteral(".o")))
        return {};

    QFile deps(objectFile.left(objectFile.size() - 2) + QStringLiteral(".d"));
    if (!deps.open(QIODevice::ReadOnly) || deps.size() > 16 * 1024 * 1024)
        return {};

    const QByteArray bytes = deps.readAll();
    // GCC -MT writes ".../v2_unit_N.o: ..." as the first dependency rule.
    const qsizetype colon = bytes.indexOf(':');
    if (colon < 0 || colon + 1 >= bytes.size())
        return {};

    QByteArray source;
    bool started = false;
    for (qsizetype i = colon + 1; i < bytes.size(); ++i) {
        const char c = bytes.at(i);
        if (c == '\\' && i + 1 < bytes.size()) {
            if (bytes.at(i + 1) == '\n') {
                ++i;
                continue;
            }
            if (bytes.at(i + 1) == '\r' && i + 2 < bytes.size()
                && bytes.at(i + 2) == '\n') {
                i += 2;
                continue;
            }
            source.append(bytes.at(++i)); // e.g. GCC-escaped spaces
            started = true;
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
            if (started)
                break;
            continue;
        }
        source.append(c);
        started = true;
    }
    if (source.isEmpty())
        return {};

    const QString path = QFile::decodeName(source);
    const QFileInfo info(QDir::isAbsolutePath(path)
                             ? path
                             : QDir(QFileInfo(objectFile).absolutePath()).filePath(path));
    return info.isFile() ? info.canonicalFilePath() : QString();
}

/*
 * Find the *actual token* rather than matching the symbol inside comments,
 * #include strings or a longer identifier. Keep offsets identical to the
 * original source so we can report real line and column positions. This is a
 * best-effort source lookup, not a claim that the linker emitted DWARF lines.
 */
QList<int> cgarmSymbolOccurrences(const QString &source, const QString &symbol)
{
    if (symbol.isEmpty())
        return {};

    static const QRegularExpression cIdentifier(QStringLiteral(R"(^[A-Za-z_][A-Za-z_0-9]*$)"));
    if (!cIdentifier.match(symbol).hasMatch())
        return {};

    QString visible = source;
    enum class State { Code, LineComment, BlockComment, StringLiteral, CharacterLiteral };
    State state = State::Code;
    const auto blank = [&visible](qsizetype i) {
        if (visible.at(i) != QLatin1Char('\n') && visible.at(i) != QLatin1Char('\r'))
            visible[i] = QLatin1Char(' ');
    };
    for (qsizetype i = 0; i < source.size(); ++i) {
        const QChar c = source.at(i);
        const QChar next = (i + 1 < source.size()) ? source.at(i + 1) : QChar();
        if (state == State::Code) {
            if (c == QLatin1Char('/') && next == QLatin1Char('/')) {
                blank(i); blank(++i);
                state = State::LineComment;
            } else if (c == QLatin1Char('/') && next == QLatin1Char('*')) {
                blank(i); blank(++i);
                state = State::BlockComment;
            } else if (c == QLatin1Char('"')) {
                blank(i);
                state = State::StringLiteral;
            } else if (c == QLatin1Char('\'')) {
                blank(i);
                state = State::CharacterLiteral;
            }
        } else if (state == State::LineComment) {
            if (c == QLatin1Char('\n'))
                state = State::Code;
            else
                blank(i);
        } else if (state == State::BlockComment) {
            if (c == QLatin1Char('*') && next == QLatin1Char('/')) {
                blank(i); blank(++i);
                state = State::Code;
            } else {
                blank(i);
            }
        } else {
            blank(i);
            if (c == QLatin1Char('\\') && i + 1 < source.size()) {
                blank(++i);
            } else if ((state == State::StringLiteral && c == QLatin1Char('"'))
                       || (state == State::CharacterLiteral && c == QLatin1Char('\''))) {
                state = State::Code;
            }
        }
    }

    const QRegularExpression expression(
        QStringLiteral(R"((?<![A-Za-z_0-9])%1(?![A-Za-z_0-9]))")
            .arg(QRegularExpression::escape(symbol)));
    QList<int> positions;
    auto matches = expression.globalMatch(visible);
    while (matches.hasNext()) {
        const QRegularExpressionMatch match = matches.next();
        positions.append(match.capturedStart());
        if (positions.size() >= 64)
            break; // Avoid flooding the editor for a pathological source file.
    }
    return positions;
}

QString normalizedAppOutputName(const QString &name)
{
    QString clean = name.trimmed();
    if (clean.isEmpty()) {
        return {};
    }

    /*
     * This setting is a filename, not an output path. Keeping the generated
     * app beside the project makes builds predictable and prevents accidental
     * path traversal if a project file is edited by hand.
     */
    clean = QFileInfo(clean).fileName();

    if (clean.isEmpty()
        || clean == QStringLiteral(".")
        || clean == QStringLiteral("..")) {
        return {};
    }

    if (!clean.endsWith(QStringLiteral(".app"),
                        Qt::CaseInsensitive)) {
        clean += QStringLiteral(".app");
    }

    return clean;
}


bool isResourceSource(const QString &filePath)
{
    return QFileInfo(filePath).suffix().compare(
               QStringLiteral("res"), Qt::CaseInsensitive) == 0;
}

bool isCompilableSource(const QString &filePath)
{
    const QString suffix = QFileInfo(filePath).suffix().toLower();
    return suffix == QStringLiteral("c")
        || suffix == QStringLiteral("cc")
        || suffix == QStringLiteral("cpp")
        || suffix == QStringLiteral("res");
}

bool isProjectExplorerSuffix(const QString &suffix)
{
    const QString lower = suffix.toLower();
    return lower == QStringLiteral("c") || lower == QStringLiteral("h")
        || lower == QStringLiteral("cc") || lower == QStringLiteral("cpp")
        || lower == QStringLiteral("hpp")
        || lower == QStringLiteral("inc") || lower == QStringLiteral("txt")
        || lower == QStringLiteral("md") || lower == QStringLiteral("res")
        || lower == QStringLiteral("sbui") || lower == QStringLiteral("sbgm")
        || lower == QStringLiteral("uis")
        || lower == QStringLiteral("ppb") || lower == QStringLiteral("pal")
        || lower == QStringLiteral("act") || lower == QStringLiteral("png")
        || lower == QStringLiteral("bmp") || lower == QStringLiteral("jpg")
        || lower == QStringLiteral("jpeg") || lower == QStringLiteral("gif")
        || lower == QStringLiteral("wav") || lower == QStringLiteral("mod")
        || lower == QStringLiteral("s3m") || lower == QStringLiteral("xm")
        || lower == QStringLiteral("med") || lower == QStringLiteral("tfmx")
        || lower == QStringLiteral("sid") || lower == QStringLiteral("sba");
}

QIcon editorTabIconForFile(const QString &filePath,
                           int defaultType = 0)
{
    QString suffix = QFileInfo(filePath).suffix().toLower();

    /*
     * Untitled tabs have no file path yet, so use the same defaultType
     * convention as tabTitleForEditor():
     *   0 = C source, 1 = header, 2 = include.
     */
    if (suffix.isEmpty()) {
        if (defaultType == 1) {
            suffix = QStringLiteral("h");
        } else if (defaultType == 2) {
            suffix = QStringLiteral("inc");
        } else {
            suffix = QStringLiteral("c");
        }
    }

    if (suffix == QStringLiteral("c")
        || suffix == QStringLiteral("uis")
        || suffix == QStringLiteral("cc")
        || suffix == QStringLiteral("cpp")) {
        return QIcon(QStringLiteral(":/icons/tree_file_c.png"));
    }

    if (suffix == QStringLiteral("h")
        || suffix == QStringLiteral("hpp")) {
        return QIcon(QStringLiteral(":/icons/tree_file_h.png"));
    }

    if (suffix == QStringLiteral("inc")) {
        return QIcon(QStringLiteral(":/icons/tree_file_inc.png"));
    }

    if (suffix == QStringLiteral("res")) {
        return QIcon(QStringLiteral(":/icons/tree_file_res.png"));
    }

    if (suffix == QStringLiteral("txt")) {
        return QIcon(QStringLiteral(":/icons/tree_file_txt.png"));
    }

    if (suffix == QStringLiteral("sbui")) {
        return QIcon(QStringLiteral(":/icons/tree_guidesigner.png"));
    }

    if (suffix == QStringLiteral("sbgm")) {
        return QIcon(QStringLiteral(":/icons/toolbar_gamedesigner.png"));
    }

    if (suffix == QStringLiteral("md")) {
        return QIcon(QStringLiteral(":/icons/tree_file_md.png"));
    }

    return QIcon(QStringLiteral(":/icons/tree_file_unknown.png"));
}


QIcon projectFileIconWithErrorBadge(
    const QIcon &baseIcon,
    const QColor &errorColour)
{
    /*
     * Reuse the normal project-file icon and paint a small red diagnostic dot in
     * its lower-right corner. No extra resource image is needed.
     */
    constexpr int IconSize = 20;
    constexpr int BadgeSize = 8;

    QPixmap pixmap =
        baseIcon.pixmap(
            IconSize,
            IconSize);

    if (pixmap.isNull()) {
        pixmap =
            QPixmap(
                IconSize,
                IconSize);

        pixmap.fill(
            Qt::transparent);
    }

    QPainter painter(&pixmap);
    painter.setRenderHint(
        QPainter::Antialiasing,
        true);

    const QRect badgeRect(
        qMax(0, pixmap.width() - BadgeSize - 1),
        qMax(0, pixmap.height() - BadgeSize - 1),
        BadgeSize,
        BadgeSize);

    painter.setPen(
        QColor(
            20,
            20,
            20));

    painter.setBrush(
        errorColour);

    painter.drawEllipse(
        badgeRect);

    return QIcon(pixmap);
}


QString formattedFileSize(qint64 bytes)
{
    if (bytes < 0) {
        return QStringLiteral("0 B");
    }
    if (bytes < 1024) {
        return QStringLiteral("%1 B").arg(QLocale().toString(bytes));
    }

    const double kib = bytes / 1024.0;
    if (kib < 1024.0) {
        return QStringLiteral("%1 KB").arg(QLocale().toString(kib, 'f', 1));
    }

    return QStringLiteral("%1 MB").arg(QLocale().toString(kib / 1024.0, 'f', 1));
}

/*
bool canContainFunctionSignatures(const QString &filePath)
{
    const QString suffix = QFileInfo(filePath).suffix().toLower();
    return suffix == QStringLiteral("c") || suffix == QStringLiteral("h")
        || suffix == QStringLiteral("cc") || suffix == QStringLiteral("cpp")
        || suffix == QStringLiteral("hpp");
}
*/

bool canContainFunctionSignatures(const QString &filePath)
{
    // CRITICAL: Never feed arbitrary project resources to the C symbol parser.
    // .ppb/.mod/.med/.wav/.png can be megabytes of binary data; parsing them
    // as UTF-8 on the UI thread froze project open/save (Stage 53B).
    const QString suffix = QFileInfo(filePath).suffix().toLower();
    return suffix == QStringLiteral("c")
        || suffix == QStringLiteral("h")
        || suffix == QStringLiteral("inc")
        || suffix == QStringLiteral("cc")
        || suffix == QStringLiteral("cpp")
        || suffix == QStringLiteral("hpp");
}

bool canSearchProjectText(const QString &filePath)
{
    if (canContainFunctionSignatures(filePath)) return true;
    const QString suffix = QFileInfo(filePath).suffix().toLower();
    // Searchable text resources, not binary images/audio or serialized designs.
    return suffix == QStringLiteral("txt")
        || suffix == QStringLiteral("md")
        || suffix == QStringLiteral("uis");
}

bool isExcludedProjectDirectoryName(const QString &name)
{
    // Prune traversal at the directory itself, not AFTER iterating its files.
    // In particular, .history/ and buildv1/ can contain thousands of files.
    return name == QStringLiteral("build")
        || name == QStringLiteral("buildv1")
        || name == QStringLiteral(".history")
        || name == QStringLiteral(".git")
        || name == QStringLiteral(".svn")
        || name == QStringLiteral(".hg")
        || name == QStringLiteral("CMakeFiles");
}

bool isExcludedProjectRelativePath(const QString &relativePath)
{
    const QStringList components = QDir::fromNativeSeparators(relativePath)
        .split(QLatin1Char('/'), Qt::SkipEmptyParts);
    // Last component is the file name; only directories are excluded.
    for (int i = 0; i + 1 < components.size(); ++i) {
        if (isExcludedProjectDirectoryName(components.at(i))) return true;
    }
    return false;
}

QString normalizedProjectType(const QString &projectType)
{
    return projectType == GameProjectType ? GameProjectType : GuiProjectType;
}

QString projectTypeLabel(const QString &projectType)
{
    return normalizedProjectType(projectType) == GameProjectType
        ? QStringLiteral("Game")
        : QStringLiteral("GUI");
}

QString hexBytes(int kilobytes)
{
    return QStringLiteral("0x%1").arg(qMax(0, kilobytes) * 1024, 0, 16);
}

bool replaceLinkerAssignment(QString *text, const QString &symbol, const QString &value)
{
    const QRegularExpression expression(QStringLiteral("(^\\s*%1\\s*=\\s*)[^;]+(;)").arg(QRegularExpression::escape(symbol)),
        QRegularExpression::MultilineOption);
    const QRegularExpressionMatch match = expression.match(*text);
    if (!match.hasMatch()) {
        return false;
    }

    text->replace(expression, QStringLiteral("\\1%1\\2").arg(value));
    return true;
}

QStringList splitApiArgumentList(const QString &text)
{
    QStringList arguments;
    QString current;
    int depth = 0;
    for (const QChar ch : text) {
        if (ch == QLatin1Char('(') || ch == QLatin1Char('[')) {
            ++depth;
        } else if ((ch == QLatin1Char(')') || ch == QLatin1Char(']')) && depth > 0) {
            --depth;
        }
        if (ch == QLatin1Char(',') && depth == 0) {
            const QString argument = current.trimmed();
            if (!argument.isEmpty()) {
                arguments.append(argument);
            }
            current.clear();
            continue;
        }
        current.append(ch);
    }
    const QString argument = current.trimmed();
    if (!argument.isEmpty() && argument != QStringLiteral("void")) {
        arguments.append(argument);
    }
    return arguments;
}

QString readableApiArgumentName(const QString &rawArgument, int index)
{
    const QString argument = rawArgument.simplified();
    static const QRegularExpression functionPointerExpression(QStringLiteral("\\(\\s*\\*\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\)"));
    const QRegularExpressionMatch functionPointerMatch = functionPointerExpression.match(argument);
    if (functionPointerMatch.hasMatch()) {
        return functionPointerMatch.captured(1);
    }

    static const QRegularExpression identifierExpression(QStringLiteral("([A-Za-z_][A-Za-z0-9_]*)\\s*(?:\\[[^\\]]*\\])?\\s*$"));
    const QRegularExpressionMatch match = identifierExpression.match(argument);
    if (!match.hasMatch()) {
        return QStringLiteral("arg%1").arg(index + 1);
    }

    const QString name = match.captured(1);
    if (name == QStringLiteral("const") || name == QStringLiteral("volatile") || name == QStringLiteral("restrict")) {
        return QStringLiteral("arg%1").arg(index + 1);
    }

    const bool showPointer = argument.contains(QLatin1Char('*'))
        && !argument.contains(QRegularExpression(QStringLiteral("\\bchar\\s*\\*")));
    return showPointer ? QStringLiteral("*%1").arg(name) : name;
}

QString readableApiArguments(const QString &argumentText)
{
    const QStringList arguments = splitApiArgumentList(argumentText);
    QStringList names;
    for (int i = 0; i < arguments.count(); ++i) {
        names.append(readableApiArgumentName(arguments.at(i), i));
    }
    return names.join(QStringLiteral(", "));
}

QString uncommentedApiText(QString text)
{
    text.replace(QRegularExpression(QStringLiteral("/\\*.*?\\*/"), QRegularExpression::DotMatchesEverythingOption), QStringLiteral(" "));
    text.replace(QRegularExpression(QStringLiteral("//[^\\n]*")), QString());
    return text;
}

void collectApiFunctionPointers(const QString &text, QHash<QString, QString> *functionPointers)
{
    static const QRegularExpression pointerExpression(
        QStringLiteral("(?:^|[\\n;{])\\s*[^;{}]*?\\(\\s*\\*\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\)\\s*\\(([^;]*)\\)\\s*;"),
        QRegularExpression::MultilineOption);

    QRegularExpressionMatchIterator iterator = pointerExpression.globalMatch(text);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        functionPointers->insert(match.captured(1).trimmed(), readableApiArguments(match.captured(2)));
    }
}

void collectApiMacros(QString text, const QHash<QString, QString> &functionPointers, QHash<QString, QString> *tips, QStringList *signatures)
{
    text.replace(QRegularExpression(QStringLiteral(R"(\\\s*\r?\n)")), QStringLiteral(" "));
    static const QRegularExpression macroExpression(
        QStringLiteral("^\\s*#\\s*define\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(([^)]*)\\)\\s*([^\\n]*)"),
        QRegularExpression::MultilineOption);
    static const QRegularExpression targetExpression(QStringLiteral("->\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\("));

    QRegularExpressionMatchIterator iterator = macroExpression.globalMatch(text);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        const QString name = match.captured(1).trimmed();
        const QString macroArguments = match.captured(2).trimmed();
        const QString body = match.captured(3);

        QString targetName;
        QRegularExpressionMatchIterator targetIterator = targetExpression.globalMatch(body);
        while (targetIterator.hasNext()) {
            targetName = targetIterator.next().captured(1).trimmed();
        }

        QString displayArguments;
        if (macroArguments == QStringLiteral("...") && !targetName.isEmpty() && functionPointers.contains(targetName)) {
            displayArguments = functionPointers.value(targetName);
        } else {
            QStringList arguments = splitApiArgumentList(macroArguments);
            arguments.removeAll(QStringLiteral("void"));
            displayArguments = arguments.join(QStringLiteral(", "));
        }

        const QString signature = QStringLiteral("%1(%2)").arg(name, displayArguments);
        tips->insert(name, signature);
        signatures->append(signature);
    }
}

QString trimmedApiValue(QString value)
{
    value = value.simplified();
    if (value.length() > 120) {
        value = value.left(117) + QStringLiteral("...");
    }
    return value;
}

void collectApiDefines(QString text, QHash<QString, QString> *tips, QStringList *signatures)
{
    text.replace(QRegularExpression(QStringLiteral(R"(\\\s*\r?\n)")), QStringLiteral(" "));
    static const QRegularExpression defineExpression(
        QStringLiteral("^\\s*#\\s*define\\s+([A-Za-z_][A-Za-z0-9_]*)([^\\n]*)"),
        QRegularExpression::MultilineOption);

    QRegularExpressionMatchIterator iterator = defineExpression.globalMatch(text);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        const QString name = match.captured(1).trimmed();
        const QString rest = match.captured(2);
        if (name.isEmpty() || rest.startsWith(QLatin1Char('('))) {
            continue;
        }

        const QString value = trimmedApiValue(rest);
        if (value.isEmpty()) {
            continue;
        }
        tips->insert(name, QStringLiteral("#define %1 %2").arg(name, value));
        signatures->append(name);
    }
}

void collectApiTypes(const QString &text, QHash<QString, QString> *tips, QStringList *signatures)
{
    static const QRegularExpression callbackTypedefExpression(
        QStringLiteral("\\btypedef\\s+(.+?)\\(\\s*\\*\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\)\\s*\\(([^;]*)\\)\\s*;"),
        QRegularExpression::MultilineOption);
    QRegularExpressionMatchIterator callbackIterator = callbackTypedefExpression.globalMatch(text);
    while (callbackIterator.hasNext()) {
        const QRegularExpressionMatch match = callbackIterator.next();
        const QString returnType = match.captured(1).simplified();
        const QString name = match.captured(2).trimmed();
        const QString arguments = match.captured(3).simplified();
        if (!name.isEmpty()) {
            tips->insert(name, QStringLiteral("typedef %1 (*%2)(%3)").arg(returnType, name, arguments));
            signatures->append(name);
        }
    }

    static const QRegularExpression compoundTypedefExpression(
        QStringLiteral("\\btypedef\\s+(struct|enum)\\s*([A-Za-z_][A-Za-z0-9_]*)?\\s*\\{.*?\\}\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*;"),
        QRegularExpression::DotMatchesEverythingOption);
    QRegularExpressionMatchIterator compoundIterator = compoundTypedefExpression.globalMatch(text);
    while (compoundIterator.hasNext()) {
        const QRegularExpressionMatch match = compoundIterator.next();
        const QString kind = match.captured(1);
        const QString tagName = match.captured(2).trimmed();
        const QString aliasName = match.captured(3).trimmed();
        if (aliasName.isEmpty()) {
            continue;
        }

        const QString tip = tagName.isEmpty()
            ? QStringLiteral("typedef %1 { ... } %2").arg(kind, aliasName)
            : QStringLiteral("typedef %1 %2 { ... } %3").arg(kind, tagName, aliasName);
        tips->insert(aliasName, tip);
        signatures->append(aliasName);
        if (!tagName.isEmpty()) {
            tips->insert(tagName, tip);
            signatures->append(tagName);
        }
    }

    static const QRegularExpression simpleTypedefExpression(
        QStringLiteral("\\btypedef\\s+([^;{}()]+?)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*;"),
        QRegularExpression::MultilineOption);
    QRegularExpressionMatchIterator simpleIterator = simpleTypedefExpression.globalMatch(text);
    while (simpleIterator.hasNext()) {
        const QRegularExpressionMatch match = simpleIterator.next();
        const QString base = match.captured(1).simplified();
        const QString name = match.captured(2).trimmed();
        if (name.isEmpty() || base.startsWith(QStringLiteral("struct")) || base.startsWith(QStringLiteral("enum"))) {
            continue;
        }

        tips->insert(name, QStringLiteral("typedef %1 %2").arg(base, name));
        signatures->append(name);
    }

    static const QRegularExpression structExpression(
        QStringLiteral("\\b(struct|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\{"),
        QRegularExpression::MultilineOption);
    QRegularExpressionMatchIterator structIterator = structExpression.globalMatch(text);
    while (structIterator.hasNext()) {
        const QRegularExpressionMatch match = structIterator.next();
        const QString kind = match.captured(1);
        const QString name = match.captured(2).trimmed();
        if (!name.isEmpty() && !tips->contains(name)) {
            tips->insert(name, QStringLiteral("%1 %2 { ... }").arg(kind, name));
            signatures->append(name);
        }
    }
}

bool isApiIdentifierChar(QChar ch)
{
    return ch.isLetterOrNumber() || ch == QLatin1Char('_');
}

void collectApiLineSymbols(QString text, QHash<QString, QString> *tips, QStringList *signatures)
{
    text.replace(QRegularExpression(QStringLiteral(R"(\\\s*\r?\n)")), QStringLiteral(" "));

    for (const QString &rawLine : text.split(QLatin1Char('\n'))) {
        const QString line = rawLine.trimmed();
        if (line.startsWith(QStringLiteral("#define "))) {
            const QString rest = line.mid(8).trimmed();
            int nameEnd = 0;
            while (nameEnd < rest.length() && isApiIdentifierChar(rest.at(nameEnd))) {
                ++nameEnd;
            }

            const QString name = rest.left(nameEnd);
            const QString value = trimmedApiValue(rest.mid(nameEnd));
            if (name.isEmpty() || value.isEmpty()) {
                continue;
            }

            if (value.startsWith(QLatin1Char('('))) {
                const int closeIndex = value.indexOf(QLatin1Char(')'));
                if (closeIndex > 0 && !tips->contains(name)) {
                    const QString arguments = value.mid(1, closeIndex - 1).trimmed();
                    const QString signature = QStringLiteral("%1(%2)").arg(name, arguments);
                    tips->insert(name, signature);
                    signatures->append(signature);
                }
            } else if (!tips->contains(name)) {
                tips->insert(name, QStringLiteral("#define %1 %2").arg(name, value));
                signatures->append(name);
            }
            continue;
        }

        if (line.startsWith(QStringLiteral("typedef ")) && line.endsWith(QLatin1Char(';'))
            && !line.contains(QLatin1Char('{')) && !line.contains(QLatin1Char('('))) {
            QString declaration = line;
            declaration.chop(1);
            const int lastSpace = declaration.lastIndexOf(QLatin1Char(' '));
            if (lastSpace <= 8) {
                continue;
            }

            const QString name = declaration.mid(lastSpace + 1).trimmed();
            const QString base = declaration.mid(8, lastSpace - 8).simplified();
            if (!name.isEmpty() && !base.isEmpty() && !tips->contains(name)) {
                tips->insert(name, QStringLiteral("typedef %1 %2").arg(base, name));
                signatures->append(name);
            }
        }
    }
}

class ProjectTreeWidget : public QTreeWidget
{
public:
    explicit ProjectTreeWidget(QWidget *parent = nullptr)
        : QTreeWidget(parent)
    {
        setDragEnabled(true);
        setAcceptDrops(true);
        viewport()->setAcceptDrops(true);
        setDropIndicatorShown(true);
        setDragDropMode(QAbstractItemView::DragDrop);
        setDefaultDropAction(Qt::MoveAction);
    }

    std::function<void(const QString &, const QString &)> fileMoveRequested;

protected:
    QMimeData *mimeData(const QList<QTreeWidgetItem *> &items) const override
    {
        QMimeData *data = QTreeWidget::mimeData(items);
        QList<QUrl> urls;
        for (QTreeWidgetItem *item : items) {
            if (!item || item->data(0, Qt::UserRole + 1).toBool()) continue;
            const QString path = item->data(0, Qt::UserRole).toString();
            if (QFileInfo(path).isFile()) urls.append(QUrl::fromLocalFile(QFileInfo(path).absoluteFilePath()));
        }
        if (!urls.isEmpty()) data->setUrls(urls);
        return data;
    }
    void startDrag(Qt::DropActions supportedActions) override
    {
        Q_UNUSED(supportedActions);

        QTreeWidgetItem *item = currentItem();
        if (!item) {
            return;
        }

        const bool isFolder = item->data(0, Qt::UserRole + 1).toBool();
        const QString filePath = item->data(0, Qt::UserRole).toString();

        /* Folder items are drop targets only; they can never be dragged. */
        if (isFolder || filePath.isEmpty()) {
            return;
        }

        m_draggedFilePath = QFileInfo(filePath).absoluteFilePath();
        QTreeWidget::startDrag(Qt::CopyAction | Qt::MoveAction);
        m_draggedFilePath.clear();
    }

    void dropEvent(QDropEvent *event) override
    {
        if (m_draggedFilePath.isEmpty() || !fileMoveRequested) {
            event->ignore();
            return;
        }

        QString targetDirectory;
        QTreeWidgetItem *targetItem = itemAt(event->position().toPoint());

        if (targetItem) {
            const QString targetPath = targetItem->data(0, Qt::UserRole).toString();
            const bool targetIsFolder = targetItem->data(0, Qt::UserRole + 1).toBool();

            if (!targetPath.isEmpty()) {
                targetDirectory = targetIsFolder
                    ? QFileInfo(targetPath).absoluteFilePath()
                    : QFileInfo(targetPath).absolutePath();
            }
        }

        /*
         * Do not let QTreeWidget perform a cosmetic internal move. MainWindow
         * moves the real file on disk and then rebuilds the tree instead.
         */
        // Defer filesystem and tree changes until Qt has finished processing
        // this drop. A synchronous refreshProjectFiles() here would delete
        // QTreeWidgetItems still in use by QTreeWidget::dropEvent/startDrag.
        const QString sourcePath = m_draggedFilePath;
        const auto moveRequest = fileMoveRequested;
        QTimer::singleShot(0, this, [moveRequest, sourcePath, targetDirectory]() {
            if (moveRequest)
                moveRequest(sourcePath, targetDirectory);
        });
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }

private:
    QString m_draggedFilePath;
};



struct SourceVariableSymbol
{
    QString name;
    int line = -1;
    QString typeName;

    /*
     * Display-only array suffix, e.g. "[]", "[256]" or "[16][32]".
     * Keep this separate from name so Ctrl+Click/type/member lookup still uses
     * the real C identifier ("background", not "background[256]").
     */
    QString arraySuffix;

    /*
     * True for declarations such as:
     *
     *     extern const uint8_t background[];
     *
     * Ctrl+Click should prefer the real storage definition in another file
     * rather than stopping on this declaration.
     */
    bool externDeclaration = false;

    // MEMALIGN4/8/16/32: display metadata, not part of the C identifier.
    bool aligned = false;
};

struct SourceNamedSymbol
{
    QString name;
    int line = -1;
    QList<SourceVariableSymbol> members;
};

struct SourceFunctionSymbol
{
    QString signature;
    int line = -1;
    int endLine = -1;
    QList<SourceVariableSymbol> parameters;
    QList<SourceVariableSymbol> locals;
};

struct SourceSymbolTable
{
    QList<SourceNamedSymbol> defines;
    QList<SourceNamedSymbol> types;
    QList<SourceVariableSymbol> globals;
    QList<SourceFunctionSymbol> functions;
};


QVariantList structureNavigationLines(
    const SourceSymbolTable &symbols)
{
    QList<int> lines;

    for (const SourceNamedSymbol &type :
         symbols.types) {
        if (type.line >= 0) {
            lines.append(type.line);
        }
    }

    for (const SourceFunctionSymbol &function :
         symbols.functions) {
        if (function.line >= 0) {
            lines.append(function.line);
        }
    }

    std::sort(
        lines.begin(),
        lines.end());

    lines.erase(
        std::unique(
            lines.begin(),
            lines.end()),
        lines.end());

    QVariantList result;
    result.reserve(lines.size());

    for (int line : std::as_const(lines)) {
        result.append(line);
    }

    return result;
}


void populateSourceSymbolTree(
    QTreeWidget *tree,
    const SourceSymbolTable &symbols)
{
    if (!tree) {
        return;
    }

    tree->setUpdatesEnabled(false);

    const QIcon functionIcon(
        QStringLiteral(
            ":/icons/tree_scope_function.png"));

    const QIcon globalIcon(
        QStringLiteral(
            ":/icons/tree_scope_globals.png"));

    const QIcon typeIcon(
        QStringLiteral(
            ":/icons/tree_scope_types.png"));

    const QIcon defineIcon(
        QStringLiteral(
            ":/icons/tree_scope_defines.png"));

    const QIcon parameterIcon(
        QStringLiteral(
            ":/icons/tree_scope_params.png"));

    const QIcon localIcon(
        QStringLiteral(
            ":/icons/tree_scope_locals.png"));

    auto addNoneItem =
        [](QTreeWidgetItem *parent) {
            auto *noneItem =
                new QTreeWidgetItem(parent);

            noneItem->setText(
                0,
                QObject::tr("(none)"));

            noneItem->setFlags(
                noneItem->flags()
                & ~Qt::ItemIsSelectable);
        };

    auto *definesItem =
        new QTreeWidgetItem(tree);

    definesItem->setText(
        0,
        QObject::tr("Defines"));

    definesItem->setIcon(
        0,
        defineIcon);

    definesItem->setExpanded(false);

    if (symbols.defines.isEmpty()) {
        addNoneItem(definesItem);
    } else {
        for (const SourceNamedSymbol &define :
             symbols.defines) {
            auto *item =
                new QTreeWidgetItem(
                    definesItem);

            item->setText(
                0,
                define.name);

            item->setIcon(
                0,
                defineIcon);

            item->setData(
                0,
                Qt::UserRole,
                define.line);

            item->setToolTip(
                0,
                QObject::tr(
                    "#define — double-click to jump to line %1")
                    .arg(define.line + 1));
        }

        definesItem->setText(
            0,
            QStringLiteral("Defines (%1)")
                .arg(
                    definesItem->childCount()));
    }

    definesItem->setData(
        0,
        Qt::UserRole + 10,
        QStringLiteral("defines"));

    auto *typesItem =
        new QTreeWidgetItem(tree);

    typesItem->setText(
        0,
        QObject::tr("Types"));

    typesItem->setIcon(
        0,
        typeIcon);

    typesItem->setExpanded(false);

    if (symbols.types.isEmpty()) {
        addNoneItem(typesItem);
    } else {
        for (const SourceNamedSymbol &type :
             symbols.types) {
            auto *item =
                new QTreeWidgetItem(
                    typesItem);

            item->setText(
                0,
                type.name);

            item->setIcon(
                0,
                typeIcon);

            item->setData(
                0,
                Qt::UserRole,
                type.line);

            item->setToolTip(
                0,
                QObject::tr(
                    "Type — double-click to jump to line %1")
                    .arg(type.line + 1));

            item->setData(
                0,
                Qt::UserRole + 10,
                QStringLiteral("type:%1")
                    .arg(type.name));

            for (const SourceVariableSymbol &member :
                 type.members) {
                auto *memberItem =
                    new QTreeWidgetItem(item);

                memberItem->setText(
                    0,
                    member.name);

                memberItem->setIcon(
                    0,
                    localIcon);

                memberItem->setData(
                    0,
                    Qt::UserRole,
                    member.line);

                memberItem->setToolTip(
                    0,
                    QObject::tr(
                        "Member — double-click to jump to line %1")
                        .arg(member.line + 1));
            }
        }

        typesItem->setText(
            0,
            QStringLiteral("Types (%1)")
                .arg(
                    typesItem->childCount()));
    }

    typesItem->setData(
        0,
        Qt::UserRole + 10,
        QStringLiteral("types"));

    auto *globalsItem =
        new QTreeWidgetItem(tree);

    globalsItem->setText(
        0,
        QObject::tr("Globals"));

    globalsItem->setIcon(
        0,
        globalIcon);

    globalsItem->setExpanded(false);

    if (symbols.globals.isEmpty()) {
        addNoneItem(globalsItem);
    } else {
        for (const SourceVariableSymbol &global :
             symbols.globals) {
            auto *item =
                new QTreeWidgetItem(
                    globalsItem);

            item->setText(
                0,
                global.name
                    + global.arraySuffix
                    + (global.aligned ? QStringLiteral(" (aligned)") : QString()));

            item->setIcon(
                0,
                globalIcon);

            item->setData(
                0,
                Qt::UserRole,
                global.line);

            item->setToolTip(
                0,
                QObject::tr(
                    "Global — double-click to jump to line %1")
                    .arg(global.line + 1));
        }

        globalsItem->setText(
            0,
            QStringLiteral("Globals (%1)")
                .arg(
                    globalsItem->childCount()));
    }

    globalsItem->setData(
        0,
        Qt::UserRole + 10,
        QStringLiteral("globals"));

    auto *functionsItem =
        new QTreeWidgetItem(tree);

    functionsItem->setText(
        0,
        QObject::tr("Functions"));

    functionsItem->setExpanded(false);

    functionsItem->setIcon(
        0,
        functionIcon);

    functionsItem->setData(
        0,
        Qt::UserRole + 10,
        QStringLiteral("functions"));

    if (symbols.functions.isEmpty()) {
        addNoneItem(functionsItem);
    } else {
        for (const SourceFunctionSymbol &function :
             symbols.functions) {
            auto *functionItem =
                new QTreeWidgetItem(
                    functionsItem);

            functionItem->setText(
                0,
                function.signature);

            functionItem->setIcon(
                0,
                functionIcon);

            functionItem->setData(
                0,
                Qt::UserRole,
                function.line);

            functionItem->setToolTip(
                0,
                QObject::tr(
                    "Function — double-click to jump to line %1")
                    .arg(function.line + 1));

            functionItem->setData(
                0,
                Qt::UserRole + 10,
                QStringLiteral("function:%1")
                    .arg(function.signature));

            if (!function.parameters.isEmpty()) {
                auto *parametersItem =
                    new QTreeWidgetItem(
                        functionItem);

                parametersItem->setText(
                    0,
                    QObject::tr("Parameters"));

                parametersItem->setIcon(
                    0,
                    parameterIcon);

                parametersItem->setExpanded(true);

                for (const SourceVariableSymbol &parameter :
                     function.parameters) {
                    auto *item =
                        new QTreeWidgetItem(
                            parametersItem);

                    item->setText(
                        0,
                        parameter.name
                            + parameter.arraySuffix
                            + (parameter.aligned ? QStringLiteral(" (aligned)") : QString()));

                    item->setIcon(
                        0,
                        parameterIcon);

                    item->setData(
                        0,
                        Qt::UserRole,
                        parameter.line);

                    item->setToolTip(
                        0,
                        QObject::tr(
                            "Parameter — double-click to jump to function"));
                }

                parametersItem->setData(
                    0,
                    Qt::UserRole + 10,
                    QStringLiteral(
                        "function:%1:parameters")
                        .arg(function.signature));
            }

            if (!function.locals.isEmpty()) {
                auto *localsItem =
                    new QTreeWidgetItem(
                        functionItem);

                localsItem->setText(
                    0,
                    QObject::tr("Locals"));

                localsItem->setIcon(
                    0,
                    localIcon);

                localsItem->setExpanded(true);

                for (const SourceVariableSymbol &local :
                     function.locals) {
                    auto *item =
                        new QTreeWidgetItem(
                            localsItem);

                    item->setText(
                        0,
                        local.name
                            + local.arraySuffix
                            + (local.aligned ? QStringLiteral(" (aligned)") : QString()));

                    item->setIcon(
                        0,
                        localIcon);

                    item->setData(
                        0,
                        Qt::UserRole,
                        local.line);

                    item->setToolTip(
                        0,
                        QObject::tr(
                            "Local — double-click to jump to line %1")
                            .arg(local.line + 1));
                }

                localsItem->setData(
                    0,
                    Qt::UserRole + 10,
                    QStringLiteral(
                        "function:%1:locals")
                        .arg(function.signature));
            }
        }

        functionsItem->setText(
            0,
            QStringLiteral("Functions (%1)")
                .arg(
                    functionsItem->childCount()));
    }

    tree->setUpdatesEnabled(true);
    tree->viewport()->update();
}

QString sanitizedCSource(const QString &source)
{
    QString result = source;
    bool inLineComment = false;
    bool inBlockComment = false;
    bool inString = false;
    bool inChar = false;
    bool escaped = false;

    for (int i = 0; i < source.size(); ++i) {
        const QChar ch = source.at(i);
        const QChar next = i + 1 < source.size() ? source.at(i + 1) : QChar();

        if (inLineComment) {
            if (ch == QLatin1Char('\n')) {
                inLineComment = false;
            } else {
                result[i] = QLatin1Char(' ');
            }
            continue;
        }

        if (inBlockComment) {
            if (ch == QLatin1Char('*') && next == QLatin1Char('/')) {
                result[i] = QLatin1Char(' ');
                if (i + 1 < result.size()) {
                    result[i + 1] = QLatin1Char(' ');
                }
                ++i;
                inBlockComment = false;
            } else if (ch != QLatin1Char('\n')) {
                result[i] = QLatin1Char(' ');
            }
            continue;
        }

        if (inString || inChar) {
            if (ch == QLatin1Char('\n')) {
                inString = false;
                inChar = false;
                escaped = false;
                continue;
            }

            result[i] = QLatin1Char(' ');
            if (escaped) {
                escaped = false;
                continue;
            }
            if (ch == QLatin1Char('\\')) {
                escaped = true;
                continue;
            }
            if ((inString && ch == QLatin1Char('"')) || (inChar && ch == QLatin1Char('\''))) {
                inString = false;
                inChar = false;
            }
            continue;
        }

        if (ch == QLatin1Char('/') && next == QLatin1Char('/')) {
            result[i] = QLatin1Char(' ');
            if (i + 1 < result.size()) {
                result[i + 1] = QLatin1Char(' ');
            }
            ++i;
            inLineComment = true;
            continue;
        }

        if (ch == QLatin1Char('/') && next == QLatin1Char('*')) {
            result[i] = QLatin1Char(' ');
            if (i + 1 < result.size()) {
                result[i + 1] = QLatin1Char(' ');
            }
            ++i;
            inBlockComment = true;
            continue;
        }

        if (ch == QLatin1Char('"')) {
            result[i] = QLatin1Char(' ');
            inString = true;
            escaped = false;
            continue;
        }

        if (ch == QLatin1Char('\'')) {
            result[i] = QLatin1Char(' ');
            inChar = true;
            escaped = false;
            continue;
        }
    }

    return result;
}

int sourceLineForOffset(const QString &source, int offset)
{
    if (offset <= 0) {
        return 0;
    }

    /*
     * Do not allocate source.left(...) for every symbol. Large generated files
     * may contain thousands of symbols; repeatedly copying prefixes turns a
     * simple line lookup into a surprising amount of memory churn.
     */
    const int limit =
        qMin(offset, source.size());

    int line = 0;

    for (int i = 0; i < limit; ++i) {
        if (source.at(i)
            == QLatin1Char('\n')) {
            ++line;
        }
    }

    return line;
}

int matchingBracePosition(const QString &text, int openingBrace)
{
    int depth = 0;
    for (int i = openingBrace; i < text.size(); ++i) {
        if (text.at(i) == QLatin1Char('{')) {
            ++depth;
        } else if (text.at(i) == QLatin1Char('}')) {
            --depth;
            if (depth == 0) {
                return i;
            }
        }
    }
    return -1;
}

QString variableNameFromDeclarator(QString declarator)
{
    int nesting = 0;
    int equals = -1;
    for (int i = 0; i < declarator.size(); ++i) {
        const QChar ch = declarator.at(i);
        if (ch == QLatin1Char('(') || ch == QLatin1Char('[') || ch == QLatin1Char('{')) {
            ++nesting;
        } else if (ch == QLatin1Char(')') || ch == QLatin1Char(']') || ch == QLatin1Char('}')) {
            nesting = qMax(0, nesting - 1);
        } else if (ch == QLatin1Char('=') && nesting == 0) {
            equals = i;
            break;
        }
    }
    if (equals >= 0) {
        declarator = declarator.left(equals);
    }

    declarator.remove(QRegularExpression(QStringLiteral("\\[[^\\]]*\\]")));
    const QRegularExpression nameExpression(QStringLiteral("([A-Za-z_][A-Za-z0-9_]*)\\s*$"));
    const QRegularExpressionMatch match = nameExpression.match(declarator.trimmed());
    return match.hasMatch() ? match.captured(1) : QString();
}

int inferredBraceArrayElementCount(const QString &declarator)
{
    /*
     * Count elements in the outermost brace initializer only.
     *
     * Examples:
     *   { 1, 2, 3 }                  -> 3
     *   { {1,2}, {3,4} }            -> 2
     *
     * The parser calls this with sanitized C source, so comments and quoted
     * strings have already been blanked and commas inside them cannot confuse
     * the count.
     */
    const int equals = declarator.indexOf(QLatin1Char('='));
    if (equals < 0) {
        return -1;
    }

    const int openBrace = declarator.indexOf(QLatin1Char('{'), equals + 1);
    if (openBrace < 0) {
        return -1;
    }

    int depth = 0;
    int elementCount = 0;
    bool elementHasContent = false;

    for (int i = openBrace + 1; i < declarator.size(); ++i) {
        const QChar ch = declarator.at(i);

        if (ch == QLatin1Char('{')) {
            ++depth;
            elementHasContent = true;
            continue;
        }

        if (ch == QLatin1Char('}')) {
            if (depth > 0) {
                --depth;
                elementHasContent = true;
                continue;
            }

            // Closing brace of the outer initializer.
            if (elementHasContent) {
                ++elementCount;
            }
            return elementCount;
        }

        if (ch == QLatin1Char(',')
            && depth == 0) {
            if (elementHasContent) {
                ++elementCount;
                elementHasContent = false;
            }
            continue;
        }

        if (!ch.isSpace()) {
            elementHasContent = true;
        }
    }

    return -1;
}

QString arraySuffixFromDeclarator(const QString &declarator,
                                  const QString &variableName)
{
    if (variableName.isEmpty()) {
        return {};
    }

    QString beforeInitializer = declarator;

    /*
     * Find '=' only at top level. An array bound may itself contain
     * parentheses/brackets, so do not simply use indexOf('=').
     */
    int nesting = 0;
    int equals = -1;
    for (int i = 0; i < beforeInitializer.size(); ++i) {
        const QChar ch = beforeInitializer.at(i);

        if (ch == QLatin1Char('(') || ch == QLatin1Char('[')) {
            ++nesting;
        } else if (ch == QLatin1Char(')') || ch == QLatin1Char(']')) {
            nesting = qMax(0, nesting - 1);
        } else if (ch == QLatin1Char('=') && nesting == 0) {
            equals = i;
            break;
        }
    }

    if (equals >= 0) {
        beforeInitializer = beforeInitializer.left(equals);
    }

    const QRegularExpression arrayExpression(
        QStringLiteral(
            R"(\b%1\b\s*((?:\[[^\]]*\]\s*)+)$)")
            .arg(QRegularExpression::escape(variableName)));

    const QRegularExpressionMatch match =
        arrayExpression.match(beforeInitializer.trimmed());

    if (!match.hasMatch()) {
        return {};
    }

    QString suffix = match.captured(1);
    suffix.remove(QRegularExpression(QStringLiteral("\\s+")));

    /*
     * If the first dimension was left empty and this declaration has a brace
     * initializer, show the element count that C would infer.
     *
     *     const int8_t background[] = { 10, 20, 30 };
     *                               -> background[3]
     *
     * For multidimensional arrays only the first unsized dimension is inferred:
     *
     *     int map[][2] = {{1,2}, {3,4}};
     *                  -> map[2][2]
     */
    if (suffix.startsWith(QStringLiteral("[]"))) {
        const int inferredCount =
            inferredBraceArrayElementCount(declarator);

        if (inferredCount > 0) {
            suffix.replace(
                0,
                2,
                QStringLiteral("[%1]").arg(inferredCount));
        }
    }

    return suffix;
}

QStringList splitTopLevelCommas(const QString &text)
{
    QStringList parts;
    QString current;
    int depth = 0;
    for (const QChar ch : text) {
        if (ch == QLatin1Char('(') || ch == QLatin1Char('[') || ch == QLatin1Char('{')) {
            ++depth;
        } else if (ch == QLatin1Char(')') || ch == QLatin1Char(']') || ch == QLatin1Char('}')) {
            depth = qMax(0, depth - 1);
        }

        if (ch == QLatin1Char(',') && depth == 0) {
            parts.append(current.trimmed());
            current.clear();
        } else {
            current.append(ch);
        }
    }
    if (!current.trimmed().isEmpty()) {
        parts.append(current.trimmed());
    }
    return parts;
}

QString typeNameFromDeclaration(const QString &statement,
                                const QString &variableName)
{
    if (variableName.isEmpty()) {
        return {};
    }

    QString beforeInitializer = statement;
    const int equals = beforeInitializer.indexOf(QLatin1Char('='));
    if (equals >= 0) {
        beforeInitializer = beforeInitializer.left(equals);
    }

    const QRegularExpression variableExpression(
        QStringLiteral("\\b%1\\b")
            .arg(QRegularExpression::escape(variableName)));

    const int variablePos =
        beforeInitializer.indexOf(variableExpression);

    if (variablePos <= 0) {
        return {};
    }

    QString typePart =
        beforeInitializer.left(variablePos).trimmed();

    // Remove pointer stars and common declaration qualifiers/storage classes.
    typePart.remove(QLatin1Char('*'));

    static const QRegularExpression qualifierExpression(
        QStringLiteral(
            R"(\b(?:const|volatile|restrict|static|extern|register|auto|signed|unsigned|long|short)\b)"));

    typePart.remove(qualifierExpression);

    // Alignment macros decorate the variable, they are not its type.
    static const QRegularExpression alignmentExpression(
        QStringLiteral(R"(\bMEMALIGN(?:4|8|16|32)\b)"));
    typePart.remove(alignmentExpression);
    typePart = typePart.simplified();

    // "struct Foo", "union Foo" and "enum Foo" should resolve to Foo.
    static const QRegularExpression taggedTypeExpression(
        QStringLiteral(R"(^(?:struct|union|enum)\s+([A-Za-z_][A-Za-z0-9_]*)$)"));

    const QRegularExpressionMatch taggedMatch =
        taggedTypeExpression.match(typePart);

    if (taggedMatch.hasMatch()) {
        return taggedMatch.captured(1);
    }

    // For a typedef alias (Vec3, Face, etc.) the final identifier is the type.
    static const QRegularExpression finalIdentifierExpression(
        QStringLiteral(R"(([A-Za-z_][A-Za-z0-9_]*)\s*$)"));

    const QRegularExpressionMatch finalMatch =
        finalIdentifierExpression.match(typePart);

    return finalMatch.hasMatch()
        ? finalMatch.captured(1)
        : QString();
}

QList<SourceVariableSymbol> variableSymbolsFromStatement(const QString &statement,
                                                          int statementOffset,
                                                          const QString &wholeSource)
{
    QList<SourceVariableSymbol> symbols;
    QString text = statement.trimmed();
    if (text.isEmpty() || text.startsWith(QLatin1Char('#')) || text.startsWith(QStringLiteral("typedef "))) {
        return symbols;
    }

    static const QStringList rejectedStarts = {
        QStringLiteral("return"), QStringLiteral("break"), QStringLiteral("continue"),
        QStringLiteral("goto"), QStringLiteral("case"), QStringLiteral("else"),
        QStringLiteral("if"), QStringLiteral("while"), QStringLiteral("switch"),
        QStringLiteral("do")
    };

    const QString firstWord = text.section(QRegularExpression(QStringLiteral("\\s+")), 0, 0);
    if (rejectedStarts.contains(firstWord)) {
        return symbols;
    }

    // A normal variable declaration needs something before its first declarator name
    // (the type/qualifiers). This filters assignments such as "x = 4".
    const QStringList declarators = splitTopLevelCommas(text);
    if (declarators.isEmpty()) {
        return symbols;
    }

    const QString firstName = variableNameFromDeclarator(declarators.first());
    if (firstName.isEmpty()) {
        return symbols;
    }

    QString firstBeforeInitializer = declarators.first();
    const int eq = firstBeforeInitializer.indexOf(QLatin1Char('='));
    if (eq >= 0) {
        firstBeforeInitializer = firstBeforeInitializer.left(eq);
    }
    const int firstNamePos = firstBeforeInitializer.lastIndexOf(QRegularExpression(
        QStringLiteral("\\b%1\\b").arg(QRegularExpression::escape(firstName))));
    if (firstNamePos <= 0 || firstBeforeInitializer.left(firstNamePos).trimmed().isEmpty()) {
        return symbols;
    }

    /*
     * Member assignments are expressions, not declarations:
     *
     *     fish.y = 3;
     *     fish->y = 3;
     *
     * Without this check the lightweight declaration parser sees the final
     * member name (y) and mistakes the object name (fish) for a type.
     */
    const QString declarationPrefix =
        firstBeforeInitializer.left(firstNamePos).trimmed();

    if (declarationPrefix.contains(QLatin1Char('.'))
        || declarationPrefix.contains(QStringLiteral("->"))) {
        return symbols;
    }

    // Function calls/prototypes are not variables. Function-pointer declarations are
    // intentionally skipped by this light-weight browser rather than guessed wrongly.
    if (text.contains(QLatin1Char('(')) || text.contains(QLatin1Char(')'))) {
        return symbols;
    }

    const int line = sourceLineForOffset(wholeSource, statementOffset);
    const QString declarationType =
        typeNameFromDeclaration(text, firstName);

    // If there is no identifiable type before the variable name, this was an
    // expression (for example *ptr = value), not a declaration.
    if (declarationType.isEmpty()) {
        return symbols;
    }

    const bool isExternDeclaration =
        QRegularExpression(QStringLiteral(R"(\bextern\b)"))
            .match(text)
            .hasMatch();

    static const QRegularExpression alignmentExpression(
        QStringLiteral(R"(\bMEMALIGN(?:4|8|16|32)\b)"));

    for (const QString &declarator : declarators) {
        const QString name = variableNameFromDeclarator(declarator);
        if (!name.isEmpty()) {
            // Look only before the symbol itself: initializer contents must
            // not make an otherwise unaligned variable appear aligned.
            const int namePos = declarator.indexOf(
                QRegularExpression(QStringLiteral(R"(\b%1\b)")
                    .arg(QRegularExpression::escape(name))));
            const bool isAligned = namePos > 0
                && alignmentExpression.match(declarator.left(namePos)).hasMatch();

            symbols.append({
                name,
                line,
                declarationType,
                arraySuffixFromDeclarator(declarator, name),
                isExternDeclaration,
                isAligned
            });
        }
    }
    return symbols;
}

/*
 * Find C array declarations which use brace initialisers, for example:
 *
 *     const int8_t background[] = {
 *         1, 2, 3, 4
 *     };
 *
 * The normal lightweight declaration regexp deliberately stops at braces, so
 * these declarations used to disappear from the Globals/Locals tree. Scan
 * them separately and feed the complete declaration through the same
 * variable/type parser used for ordinary declarations.
 */
QList<SourceVariableSymbol> braceInitialisedArraySymbolsInRange(
    const QString &sanitized,
    const QString &wholeSource,
    int start,
    int end)
{
    QList<SourceVariableSymbol> symbols;

    if (start < 0 || end <= start || start >= sanitized.size()) {
        return symbols;
    }

    const int boundedEnd = qMin(end, sanitized.size());

    static const QRegularExpression arrayStartExpression(
        QStringLiteral(
            R"((?:^|[\n;{}])\s*((?:(?:const|volatile|static|extern|register)\s+)*(?:(?:struct|union|enum)\s+)?[A-Za-z_][A-Za-z0-9_]*(?:\s*\*)*(?:\s+MEMALIGN(?:4|8|16|32))?\s+[A-Za-z_][A-Za-z0-9_]*\s*(?:\[[^\]]*\]\s*)+\s*=\s*\{))"),
        QRegularExpression::MultilineOption);

    int searchFrom = start;

    while (searchFrom < boundedEnd) {
        const QRegularExpressionMatch match =
            arrayStartExpression.match(
                sanitized,
                searchFrom,
                QRegularExpression::NormalMatch,
                QRegularExpression::NoMatchOption);

        if (!match.hasMatch() || match.capturedStart(1) >= boundedEnd) {
            break;
        }

        const int declarationStart = match.capturedStart(1);
        const int openBrace =
            sanitized.indexOf(QLatin1Char('{'), match.capturedStart(1));

        if (openBrace < 0 || openBrace >= boundedEnd) {
            break;
        }

        const int closeBrace = matchingBracePosition(sanitized, openBrace);
        if (closeBrace < 0 || closeBrace >= boundedEnd) {
            break;
        }

        int semicolon = closeBrace + 1;
        while (semicolon < boundedEnd
               && sanitized.at(semicolon).isSpace()) {
            ++semicolon;
        }

        if (semicolon >= boundedEnd
            || sanitized.at(semicolon) != QLatin1Char(';')) {
            searchFrom = closeBrace + 1;
            continue;
        }

        const QString declaration =
            sanitized.mid(
                declarationStart,
                semicolon - declarationStart);

        const auto found =
            variableSymbolsFromStatement(
                declaration,
                declarationStart,
                wholeSource);

        for (const SourceVariableSymbol &symbol : found) {
            bool duplicate = false;
            for (const SourceVariableSymbol &existing : symbols) {
                if (existing.name == symbol.name
                    && existing.line == symbol.line) {
                    duplicate = true;
                    break;
                }
            }

            if (!duplicate) {
                symbols.append(symbol);
            }
        }

        searchFrom = semicolon + 1;
    }

    return symbols;
}

QList<SourceVariableSymbol> variableSymbolsInRange(const QString &sanitized,
                                                    const QString &wholeSource,
                                                    int start,
                                                    int end)
{
    QList<SourceVariableSymbol> symbols;
    if (start < 0 || end <= start || start >= sanitized.size()) {
        return symbols;
    }

    const int boundedEnd = qMin(end, sanitized.size());
    const QString region = sanitized.mid(start, boundedEnd - start);

    // Normal one-line declarations ending in ';'. This covers the style used by the
    // Sidbox sources while avoiding most expression statements.
    static const QRegularExpression declarationExpression(
        QStringLiteral("(?:^|[\\n{};])\\s*([^;{}\\n]+)\\s*;"),
        QRegularExpression::MultilineOption);

    QRegularExpressionMatchIterator iterator = declarationExpression.globalMatch(region);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        const int offset = start + match.capturedStart(1);
        const auto found = variableSymbolsFromStatement(match.captured(1), offset, wholeSource);
        for (const SourceVariableSymbol &symbol : found) {
            bool duplicate = false;
            for (const SourceVariableSymbol &existing : symbols) {
                if (existing.name == symbol.name && existing.line == symbol.line) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                symbols.append(symbol);
            }
        }
    }

    /*
     * Brace-initialised arrays need a separate pass because the ordinary
     * declaration regexp above intentionally excludes braces.
     */
    const auto arraySymbols =
        braceInitialisedArraySymbolsInRange(
            sanitized,
            wholeSource,
            start,
            boundedEnd);

    for (const SourceVariableSymbol &symbol : arraySymbols) {
        bool duplicate = false;
        for (const SourceVariableSymbol &existing : symbols) {
            if (existing.name == symbol.name
                && existing.line == symbol.line) {
                duplicate = true;
                break;
            }
        }

        if (!duplicate) {
            symbols.append(symbol);
        }
    }

    // Also pick up the common C99 form: for (int i = 0; ...)
    static const QRegularExpression forDeclarationExpression(
        QStringLiteral("\\bfor\\s*\\(\\s*([^;]+);"),
        QRegularExpression::MultilineOption);
    iterator = forDeclarationExpression.globalMatch(region);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        const int offset = start + match.capturedStart(1);
        const auto found = variableSymbolsFromStatement(match.captured(1), offset, wholeSource);
        for (const SourceVariableSymbol &symbol : found) {
            bool duplicate = false;
            for (const SourceVariableSymbol &existing : symbols) {
                if (existing.name == symbol.name && existing.line == symbol.line) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                symbols.append(symbol);
            }
        }
    }

    return symbols;
}

QList<SourceNamedSymbol> defineSymbolsFromSource(
    const QString &source,
    const QString &sanitized)
{
    QList<SourceNamedSymbol> symbols;

    static const QRegularExpression defineExpression(
        QStringLiteral(R"((?:^|\n)\s*#\s*define\s+([A-Za-z_][A-Za-z0-9_]*))"),
        QRegularExpression::MultilineOption);

    QRegularExpressionMatchIterator iterator = defineExpression.globalMatch(sanitized);
    while (iterator.hasNext()) {
        const QRegularExpressionMatch match = iterator.next();
        const QString name = match.captured(1).trimmed();
        if (name.isEmpty()) {
            continue;
        }

        const int line = sourceLineForOffset(source, match.capturedStart(1));
        symbols.append({name, line});
    }

    return symbols;
}

QList<SourceNamedSymbol> typeSymbolsFromSource(
    const QString &source,
    const QString &sanitized)
{
    QList<SourceNamedSymbol> symbols;

    auto appendUnique = [&symbols](const QString &name,
                                   int line,
                                   const QList<SourceVariableSymbol> &members = {}) {
        if (name.isEmpty()) {
            return;
        }

        for (SourceNamedSymbol &existing : symbols) {
            if (existing.name == name && existing.line == line) {
                if (existing.members.isEmpty() && !members.isEmpty()) {
                    existing.members = members;
                }
                return;
            }
        }

        symbols.append({name, line, members});
    };

    static const QRegularExpression typedefStartExpression(
        QStringLiteral(R"(\btypedef\b)"));

    int searchFrom = 0;
    while (searchFrom < sanitized.size()) {
        const QRegularExpressionMatch startMatch =
            typedefStartExpression.match(sanitized, searchFrom);

        if (!startMatch.hasMatch()) {
            break;
        }

        const int typedefStart = startMatch.capturedStart(0);
        int braceDepth = 0;
        int parenDepth = 0;
        int bracketDepth = 0;
        int typedefEnd = -1;

        for (int i = startMatch.capturedEnd(0); i < sanitized.size(); ++i) {
            const QChar ch = sanitized.at(i);

            if (ch == QLatin1Char('{')) {
                ++braceDepth;
            } else if (ch == QLatin1Char('}')) {
                braceDepth = qMax(0, braceDepth - 1);
            } else if (ch == QLatin1Char('(')) {
                ++parenDepth;
            } else if (ch == QLatin1Char(')')) {
                parenDepth = qMax(0, parenDepth - 1);
            } else if (ch == QLatin1Char('[')) {
                ++bracketDepth;
            } else if (ch == QLatin1Char(']')) {
                bracketDepth = qMax(0, bracketDepth - 1);
            } else if (ch == QLatin1Char(';')
                       && braceDepth == 0
                       && parenDepth == 0
                       && bracketDepth == 0) {
                typedefEnd = i;
                break;
            }
        }

        if (typedefEnd < 0) {
            break;
        }

        const QString declaration =
            sanitized.mid(typedefStart, typedefEnd - typedefStart + 1);

        QList<SourceVariableSymbol> members;
        const int relativeOpenBrace = declaration.indexOf(QLatin1Char('{'));
        if (relativeOpenBrace >= 0) {
            const int openBrace = typedefStart + relativeOpenBrace;
            const int closeBrace = matchingBracePosition(sanitized, openBrace);

            if (closeBrace > openBrace && closeBrace <= typedefEnd) {
                members = variableSymbolsInRange(
                    sanitized,
                    source,
                    openBrace + 1,
                    closeBrace);
            }
        }

        static const QRegularExpression aliasExpression(
            QStringLiteral(R"(([A-Za-z_][A-Za-z0-9_]*)\s*;$)"));

        const QRegularExpressionMatch aliasMatch =
            aliasExpression.match(declaration);

        if (aliasMatch.hasMatch()) {
            const QString alias = aliasMatch.captured(1).trimmed();
            const int aliasOffset =
                typedefStart + aliasMatch.capturedStart(1);

            appendUnique(
                alias,
                sourceLineForOffset(source, aliasOffset),
                members);
        }

        searchFrom = typedefEnd + 1;
    }

    // Named struct / enum / union types, including non-typedef declarations.
    static const QRegularExpression taggedTypeExpression(
        QStringLiteral(
            R"(\b(struct|enum|union)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:__attribute__\s*\(\([^\n]*?\)\)\s*)?(?=\{|;))"),
        QRegularExpression::MultilineOption);

    QRegularExpressionMatchIterator taggedIterator =
        taggedTypeExpression.globalMatch(sanitized);

    while (taggedIterator.hasNext()) {
        const QRegularExpressionMatch match = taggedIterator.next();
        const QString name = match.captured(2).trimmed();

        QList<SourceVariableSymbol> members;
        const int openBrace = sanitized.indexOf(
            QLatin1Char('{'),
            match.capturedEnd(0));

        if (openBrace >= 0) {
            // Do not accidentally attach a later unrelated brace to a
            // forward declaration such as "struct Foo;".
            const int semicolon = sanitized.indexOf(
                QLatin1Char(';'),
                match.capturedEnd(0));

            if (semicolon < 0 || openBrace < semicolon) {
                const int closeBrace =
                    matchingBracePosition(sanitized, openBrace);

                if (closeBrace > openBrace) {
                    members = variableSymbolsInRange(
                        sanitized,
                        source,
                        openBrace + 1,
                        closeBrace);
                }
            }
        }

        appendUnique(
            name,
            sourceLineForOffset(source, match.capturedStart(2)),
            members);
    }

    return symbols;
}

void maskTypeDeclarations(QString *text)
{
    if (!text) {
        return;
    }

    auto blankRange = [text](int start, int end) {
        if (start < 0 || end < start) {
            return;
        }

        const int boundedEnd = qMin(end, text->size() - 1);
        for (int i = start; i <= boundedEnd; ++i) {
            if (text->at(i) != QLatin1Char('\n')) {
                (*text)[i] = QLatin1Char(' ');
            }
        }
    };

    // Mask complete typedef declarations, respecting braces/parentheses so
    // member semicolons inside a struct do not terminate the declaration.
    static const QRegularExpression typedefStartExpression(
        QStringLiteral(R"(\btypedef\b)"));

    int searchFrom = 0;
    while (searchFrom < text->size()) {
        const QRegularExpressionMatch match =
            typedefStartExpression.match(*text, searchFrom);

        if (!match.hasMatch()) {
            break;
        }

        int braces = 0;
        int parens = 0;
        int brackets = 0;
        int end = -1;

        for (int i = match.capturedEnd(); i < text->size(); ++i) {
            const QChar ch = text->at(i);

            if (ch == QLatin1Char('{')) {
                ++braces;
            } else if (ch == QLatin1Char('}')) {
                braces = qMax(0, braces - 1);
            } else if (ch == QLatin1Char('(')) {
                ++parens;
            } else if (ch == QLatin1Char(')')) {
                parens = qMax(0, parens - 1);
            } else if (ch == QLatin1Char('[')) {
                ++brackets;
            } else if (ch == QLatin1Char(']')) {
                brackets = qMax(0, brackets - 1);
            } else if (ch == QLatin1Char(';')
                       && braces == 0
                       && parens == 0
                       && brackets == 0) {
                end = i;
                break;
            }
        }

        if (end < 0) {
            break;
        }

        blankRange(match.capturedStart(), end);
        searchFrom = end + 1;
    }

    // Also mask standalone named struct/enum/union bodies:
    //     struct Foo { int x; };
    static const QRegularExpression taggedBodyExpression(
        QStringLiteral(R"(\b(struct|enum|union)\s+[A-Za-z_][A-Za-z0-9_]*[^\n;{]*\{)"),
        QRegularExpression::MultilineOption);

    searchFrom = 0;
    while (searchFrom < text->size()) {
        const QRegularExpressionMatch match =
            taggedBodyExpression.match(*text, searchFrom);

        if (!match.hasMatch()) {
            break;
        }

        const int openBrace =
            text->indexOf(QLatin1Char('{'), match.capturedStart());

        if (openBrace < 0) {
            break;
        }

        const int closeBrace =
            matchingBracePosition(*text, openBrace);

        if (closeBrace < 0) {
            break;
        }

        int end = closeBrace;
        const int semicolon =
            text->indexOf(QLatin1Char(';'), closeBrace + 1);

        if (semicolon >= 0) {
            end = semicolon;
        }

        blankRange(match.capturedStart(), end);
        searchFrom = end + 1;
    }
}

QStringList functionSignaturesFromSanitizedFast(
    const QString &source,
    const QString &sanitized)
{
    /*
     * Fast completion catalogue: one linear pass, no regex backtracking.
     *
     * We only care about global function declarations/definitions here. The
     * detailed symbol browser still uses parseSourceSymbols(), but it runs in a
     * background worker. This scanner is deliberately tiny and predictable for
     * 100-200 KB generated files.
     */
    QStringList signatures;

    static const QSet<QString> ignoredNames = {
        QStringLiteral("if"),
        QStringLiteral("for"),
        QStringLiteral("while"),
        QStringLiteral("switch"),
        QStringLiteral("return"),
        QStringLiteral("sizeof"),
        QStringLiteral("__attribute__"),
        QStringLiteral("__declspec")
    };

    int braceDepth = 0;

    for (int i = 0; i < sanitized.size(); ++i) {
        const QChar ch =
            sanitized.at(i);

        if (ch == QLatin1Char('{')) {
            ++braceDepth;
            continue;
        }

        if (ch == QLatin1Char('}')) {
            braceDepth =
                qMax(0, braceDepth - 1);
            continue;
        }

        if (braceDepth != 0
            || ch != QLatin1Char('(')) {
            continue;
        }

        int nameEnd = i - 1;

        while (nameEnd >= 0
               && sanitized.at(nameEnd).isSpace()) {
            --nameEnd;
        }

        if (nameEnd < 0
            || !(sanitized.at(nameEnd).isLetterOrNumber()
                 || sanitized.at(nameEnd)
                    == QLatin1Char('_'))) {
            continue;
        }

        int nameStart = nameEnd;

        while (nameStart > 0) {
            const QChar prev =
                sanitized.at(nameStart - 1);

            if (!prev.isLetterOrNumber()
                && prev != QLatin1Char('_')) {
                break;
            }

            --nameStart;
        }

        const QString name =
            sanitized.mid(
                nameStart,
                nameEnd - nameStart + 1);

        if (name.isEmpty()
            || ignoredNames.contains(name)) {
            continue;
        }

        int parenDepth = 1;
        int closeParen = -1;

        for (int j = i + 1;
             j < sanitized.size();
             ++j) {
            const QChar inner =
                sanitized.at(j);

            if (inner == QLatin1Char('(')) {
                ++parenDepth;
            } else if (inner
                       == QLatin1Char(')')) {
                --parenDepth;

                if (parenDepth == 0) {
                    closeParen = j;
                    break;
                }
            }
        }

        if (closeParen < 0) {
            break;
        }

        int after =
            closeParen + 1;

        while (after < sanitized.size()
               && sanitized.at(after).isSpace()) {
            ++after;
        }

        if (after >= sanitized.size()
            || (sanitized.at(after)
                    != QLatin1Char(';')
                && sanitized.at(after)
                    != QLatin1Char('{'))) {
            i = closeParen;
            continue;
        }

        /*
         * A function needs a declaration/type before its name. This rejects
         * macro-ish "(...)" constructs and most accidental expression hits.
         */
        int declarationStart =
            nameStart - 1;

        while (declarationStart >= 0) {
            const QChar before =
                sanitized.at(declarationStart);

            if (before == QLatin1Char(';')
                || before == QLatin1Char('}')
                || before == QLatin1Char('{')) {
                ++declarationStart;
                break;
            }

            --declarationStart;
        }

        declarationStart =
            qMax(0, declarationStart);

        if (sanitized
                .mid(
                    declarationStart,
                    nameStart - declarationStart)
                .trimmed()
                .isEmpty()) {
            i = closeParen;
            continue;
        }

        const QString arguments =
            source.mid(
                      i + 1,
                      closeParen - i - 1)
                .simplified();

        signatures.append(
            QStringLiteral("%1(%2)")
                .arg(
                    name,
                    arguments));

        i = closeParen;
    }

    signatures.removeDuplicates();
    signatures.sort(Qt::CaseInsensitive);
    return signatures;
}


/*
 * Discover C function definitions only at file scope.
 *
 * A permissive declaration regex can interpret e.g. "else if (...) {"
 * as a function returning "else" and named "if".  This scan tracks the
 * brace nesting of sanitized C source, and rejects any candidate appearing
 * inside another function, struct or initializer.  Reuse it for BOTH the
 * Functions & Variables tree and the editor's event navigation drop-down.
 *
 * Each character is examined at most once for brace depth.  The regex
 * match list is small (one entry per real top-level function) even when a
 * generated source file contains thousands of conditional statements.
 */
QList<QRegularExpressionMatch> fileScopeCFunctionDefinitions(
    const QString &sanitized)
{
    static const QRegularExpression functionExpression(
        QStringLiteral(
            "(?:^|\\n)\\s*"
            "((?:(?:static|inline|extern|const|volatile|unsigned|signed|long|short|struct\\s+[A-Za-z_][A-Za-z0-9_]*|enum\\s+[A-Za-z_][A-Za-z0-9_]*|union\\s+[A-Za-z_][A-Za-z0-9_]*|[A-Za-z_][A-Za-z0-9_]*)\\s+|[*]+\\s*)+)"
            "([A-Za-z_][A-Za-z0-9_]*)\\s*"
            "\\(([^;{}]*)\\)\\s*\\{"),
        QRegularExpression::MultilineOption);

    static const QSet<QString> nonFunctionNames = {
        QStringLiteral("if"),
        QStringLiteral("else"),
        QStringLiteral("for"),
        QStringLiteral("while"),
        QStringLiteral("do"),
        QStringLiteral("switch"),
        QStringLiteral("case"),
        QStringLiteral("default"),
        QStringLiteral("catch"),
        QStringLiteral("return"),
        QStringLiteral("sizeof"),
        QStringLiteral("_Alignof"),
        QStringLiteral("alignof"),
        QStringLiteral("__attribute__"),
        QStringLiteral("__declspec")
    };

    QList<QRegularExpressionMatch> result;
    auto it = functionExpression.globalMatch(sanitized);
    int scanPosition = 0;
    int braceDepth = 0;
    while (it.hasNext()) {
        const QRegularExpressionMatch match = it.next();
        const int candidateStart = match.capturedStart(0);
        for (; scanPosition < candidateStart; ++scanPosition) {
            const QChar ch = sanitized.at(scanPosition);
            if (ch == QLatin1Char('{')) {
                ++braceDepth;
            } else if (ch == QLatin1Char('}')) {
                braceDepth = qMax(0, braceDepth - 1);
            }
        }

        const QString name = match.captured(2);
        if (braceDepth != 0 || nonFunctionNames.contains(name)) {
            continue;
        }

        const int openingBrace = match.capturedEnd(0) - 1;
        if (openingBrace < 0 || matchingBracePosition(sanitized, openingBrace) < 0) {
            continue;
        }
        result.append(match);
    }
    return result;
}

SourceSymbolTable parseSourceSymbolsFromSanitized(
    const QString &source,
    const QString &sanitized,
    const std::function<void(int)> &progress = {})
{
    SourceSymbolTable table;

    if (progress) {
        progress(25);
    }

    table.defines =
        defineSymbolsFromSource(
            source,
            sanitized);

    if (progress) {
        progress(35);
    }

    table.types =
        typeSymbolsFromSource(
            source,
            sanitized);

    if (progress) {
        progress(52);
    }

    QString globalsOnly = sanitized;

    // Struct/typedef members are fields of their type, not globals.
    maskTypeDeclarations(&globalsOnly);

    if (progress) {
        progress(58);
    }

    const QList<QRegularExpressionMatch> definitions =
        fileScopeCFunctionDefinitions(sanitized);
    int lastFunctionProgress = 58;

    for (const QRegularExpressionMatch &match : definitions) {

        if (progress
            && !sanitized.isEmpty()) {
            const int scanProgress =
                58
                + qBound(
                    0,
                    (match.capturedStart(0) * 24)
                        / qMax(
                            1,
                            static_cast<int>(
                                sanitized.size())),
                    24);

            if (scanProgress > lastFunctionProgress) {
                lastFunctionProgress =
                    scanProgress;

                progress(
                    scanProgress);
            }
        }
        const QString functionName = match.captured(2).trimmed();

        static const QStringList ignoredFunctionNames = {
            QStringLiteral("__attribute__"),
            QStringLiteral("__declspec")
        };
        if (functionName.isEmpty()
            || ignoredFunctionNames.contains(functionName)) {
            continue;
        }

        const int openingBrace = match.capturedEnd(0) - 1;
        const int closingBrace = matchingBracePosition(sanitized, openingBrace);
        if (closingBrace < 0) {
            continue;
        }

        SourceFunctionSymbol function;
        const QString arguments = match.captured(3).simplified();
        function.signature = QStringLiteral("%1(%2)").arg(functionName, arguments);
        function.line = sourceLineForOffset(source, match.capturedStart(2));
        function.endLine = sourceLineForOffset(source, closingBrace);

        const QStringList parameterParts = splitApiArgumentList(match.captured(3));
        for (const QString &parameter : parameterParts) {
            const QString name = readableApiArgumentName(parameter, function.parameters.size());
            QString cleanName = name;
            cleanName.remove(QLatin1Char('*'));
            cleanName = cleanName.trimmed();
            if (!cleanName.isEmpty()) {
                function.parameters.append({
                    cleanName,
                    function.line,
                    typeNameFromDeclaration(parameter, cleanName),
                    arraySuffixFromDeclarator(parameter, cleanName)
                });
            }
        }

        function.locals = variableSymbolsInRange(sanitized, source, openingBrace + 1, closingBrace);
        table.functions.append(function);

        // Remove the whole function body from the copy used for global-variable parsing,
        // but preserve newlines so source line numbers stay exact.
        for (int i = match.capturedStart(0); i <= closingBrace && i < globalsOnly.size(); ++i) {
            if (globalsOnly.at(i) != QLatin1Char('\n')) {
                globalsOnly[i] = QLatin1Char(' ');
            }
        }
    }

    if (progress) {
        progress(84);
    }

    table.globals =
        variableSymbolsInRange(
            globalsOnly,
            source,
            0,
            globalsOnly.size());

    if (progress) {
        progress(92);
    }

    return table;
}

SourceSymbolTable parseSourceSymbols(
    const QString &source)
{
    const QString sanitized =
        sanitizedCSource(source);

    return parseSourceSymbolsFromSanitized(
        source,
        sanitized);
}


QString variableTypeInTable(const SourceSymbolTable &table,
                            const QString &variableName,
                            int usageLine,
                            bool includeLocalScope)
{
    if (includeLocalScope && usageLine >= 0) {
        for (const SourceFunctionSymbol &function : table.functions) {
            if (usageLine < function.line
                || (function.endLine >= 0 && usageLine > function.endLine)) {
                continue;
            }

            // Prefer the nearest local declaration visible before this use.
            int bestLine = -1;
            QString bestType;

            for (const SourceVariableSymbol &local : function.locals) {
                if (local.name == variableName
                    && local.line <= usageLine
                    && local.line > bestLine) {
                    bestLine = local.line;
                    bestType = local.typeName;
                }
            }

            if (!bestType.isEmpty()) {
                return bestType;
            }

            for (const SourceVariableSymbol &parameter : function.parameters) {
                if (parameter.name == variableName) {
                    return parameter.typeName;
                }
            }

            break;
        }
    }

    for (const SourceVariableSymbol &global : table.globals) {
        if (global.name == variableName) {
            return global.typeName;
        }
    }

    return {};
}

QStringList membersForTypeInTable(const SourceSymbolTable &table,
                                  const QString &typeName)
{
    for (const SourceNamedSymbol &type : table.types) {
        if (type.name != typeName) {
            continue;
        }

        QStringList members;
        for (const SourceVariableSymbol &member : type.members) {
            if (!member.name.isEmpty()) {
                members.append(member.name);
            }
        }

        members.removeDuplicates();
        members.sort(Qt::CaseInsensitive);
        return members;
    }

    return {};
}

QString sourceFunctionName(const QString &signature)
{
    const int paren = signature.indexOf(QLatin1Char('('));
    return paren >= 0 ? signature.left(paren).trimmed() : signature.trimmed();
}

int definitionLineInTable(const SourceSymbolTable &table,
                          const QString &symbol,
                          int usageLine,
                          bool includeLocalScope,
                          bool includeExternGlobals = true)
{
    if (includeLocalScope && usageLine >= 0) {
        for (const SourceFunctionSymbol &function : table.functions) {
            if (usageLine < function.line
                || (function.endLine >= 0 && usageLine > function.endLine)) {
                continue;
            }

            // A local variable is the most specific definition. Prefer the
            // nearest declaration at or before the clicked use.
            int bestLocalLine = -1;
            for (const SourceVariableSymbol &local : function.locals) {
                if (local.name == symbol
                    && local.line <= usageLine
                    && local.line > bestLocalLine) {
                    bestLocalLine = local.line;
                }
            }
            if (bestLocalLine >= 0) {
                return bestLocalLine;
            }

            for (const SourceVariableSymbol &parameter : function.parameters) {
                if (parameter.name == symbol) {
                    return parameter.line;
                }
            }
            break;
        }
    }

    // Types first makes "struct Foo" / typedef aliases particularly useful.
    for (const SourceNamedSymbol &type : table.types) {
        if (type.name == symbol) {
            return type.line;
        }
    }

    for (const SourceFunctionSymbol &function : table.functions) {
        if (sourceFunctionName(function.signature) == symbol) {
            return function.line;
        }
    }

    for (const SourceVariableSymbol &global : table.globals) {
        if (global.name == symbol
            && (includeExternGlobals || !global.externDeclaration)) {
            return global.line;
        }
    }

    for (const SourceNamedSymbol &define : table.defines) {
        if (define.name == symbol) {
            return define.line;
        }
    }

    return -1;
}

class CompilerOutputPane : public QPlainTextEdit
{
public:
    explicit CompilerOutputPane(QWidget *parent = nullptr)
        : QPlainTextEdit(parent)
    {
    }

    // Keep the compiler-output widget independent of project/editor logic.
    // The owner resolves paths and performs navigation when requested.
    void setDiagnosticHandler(std::function<bool(const QString &, bool)> handler)
    {
        m_diagnosticHandler = std::move(handler);
        setMouseTracking(true);
        viewport()->setMouseTracking(true);
        connect(document(), &QTextDocument::contentsChanged, this, [this]() {
            // A new build can replace every line, even at the same block index.
            m_hoverBlockNumber = -1;
        });
    }

protected:
    void mouseDoubleClickEvent(QMouseEvent *event) override
    {
        if (event->button() == Qt::LeftButton && m_diagnosticHandler) {
            const QString line = cursorForPosition(event->pos()).block().text();
            if (m_diagnosticHandler(line, true)) {
                event->accept();
                return;
            }
        }

        QPlainTextEdit::mouseDoubleClickEvent(event);
    }

    void mousePressEvent(QMouseEvent *event) override
    {
        m_pressedInsideSelection = false;
        if (event->button() == Qt::LeftButton) {
            const QTextCursor cursor = textCursor();
            if (cursor.hasSelection()) {
                const int position = cursorForPosition(event->pos()).position();
                m_pressedInsideSelection = position >= cursor.selectionStart()
                    && position < cursor.selectionEnd();
            }
        }

        QPlainTextEdit::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event) override
    {
        if (m_pressedInsideSelection && (event->buttons() & Qt::LeftButton)) {
            event->accept();
            return;
        }

        QPlainTextEdit::mouseMoveEvent(event);

        if (event->buttons() == Qt::NoButton && m_diagnosticHandler) {
            const QTextBlock block = cursorForPosition(event->pos()).block();
            if (block.blockNumber() != m_hoverBlockNumber) {
                m_hoverBlockNumber = block.blockNumber();
                m_hoverIsNavigable = m_diagnosticHandler(block.text(), false);
            }
            viewport()->setCursor(m_hoverIsNavigable
                                      ? Qt::PointingHandCursor
                                      : Qt::IBeamCursor);
        }
    }

    void mouseReleaseEvent(QMouseEvent *event) override
    {
        QPlainTextEdit::mouseReleaseEvent(event);
        m_pressedInsideSelection = false;
    }

private:
    bool m_pressedInsideSelection = false;
    int m_hoverBlockNumber = -1;
    bool m_hoverIsNavigable = false;
    std::function<bool(const QString &, bool)> m_diagnosticHandler;
};
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_projectFiles(nullptr)
    , m_editorTabs(nullptr)
    , m_quickTipLabel(nullptr)
    , m_outputPane(nullptr)
    , m_outputToolBar(nullptr)
    , m_findReplaceDialog(nullptr)
    , m_compilerProcess(new QProcess(this))
    , m_projectAnalysisTimer(new QTimer(this))
    , m_compileProgressDelayTimer(new QTimer(this))
    , m_fileWatcher(new QFileSystemWatcher(this))
    , m_buildStep(BuildStep::None)
    , m_projectType(GuiProjectType)
    , m_modSizeKb(0)
    , m_appSizeKb(128)
    , m_v2HeapKb(16)
    , m_v2StackKb(8)
    , m_editorFontPointSize(10)
    , m_compilerOptimization(QStringLiteral("-Ofast"))
    , m_compilerSuppressWarnings(true)
    , m_compilerWall(false)
    , m_compilerWextra(false)
    , m_compilerFunctionSections(true)
    , m_compilerDataSections(true)
    , m_compilerStackUsage(true)
    , m_theme(defaultIDETheme())
{
    ui->setupUi(this);
    loadOptions();
    setupInterface();
    refreshApiCatalog();

    /*
     * Project-wide function/type discovery scans multiple source files.
     * Running it on every single keystroke makes large resource-heavy projects
     * feel frozen. Coalesce bursts of edits into one refresh shortly after the
     * user stops typing.
     */
    m_projectAnalysisTimer->setSingleShot(true);
    /*
     * Ordinary typing only restarts this idle timer. No whole-document semantic,
     * fold, minimap or typedef scan runs while characters are continuously
     * arriving. Two seconds after the LAST edit, synchronise the active tab.
     */
    m_projectAnalysisTimer->setInterval(2000);
    connect(m_projectAnalysisTimer, &QTimer::timeout, this, [this]() {
        CodeEditor *editor = activeEditor();

        if (editor) {
            /*
             * Local fold/minimap catalogues are cooperative event-loop jobs.
             * The semantic/tree catalogue is a background worker.
             */
            editor->syncDeferredEditorStateNow();
        }

        refreshActiveEditorAnalysis();
    });

    /*
     * Reload open files when another editor/tool writes them on disk.
     * A short debounce handles editors which save by writing a temporary file
     * and renaming it over the original.
     */
    connect(m_fileWatcher, &QFileSystemWatcher::fileChanged,
            this, &MainWindow::handleExternalFileChange);

    /*
     * Fast Sidbox builds often finish before a progress indicator is useful.
     * Wait briefly before showing the busy bar so sub-180 ms builds stay
     * visually clean instead of flashing a widget on and off.
     */
    m_compileProgressDelayTimer->setSingleShot(true);
    m_compileProgressDelayTimer->setInterval(180);
    connect(m_compileProgressDelayTimer, &QTimer::timeout, this, [this]() {
        if (m_buildStep != BuildStep::None && m_compileProgressBar) {
            m_compileProgressBar->show();
        }
    });

    connect(m_compilerProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        const QString text = QString::fromLocal8Bit(m_compilerProcess->readAllStandardOutput());
        // cgarm-build normally streams errors to stderr, but recognise a
        // linker RAM failure even if a tool emits it on stdout.
        if (m_buildStep == BuildStep::V2CliBuilding) {
            const qint64 excess = cgarmRamOverflowBytes(text);
            if (m_v2Linker == QStringLiteral("cgarm") && excess > 0) {
                m_v2CgarmRamExcessBytes = excess;
                m_buildLinkSizeOverflow = true;
            }
            const QString lower = text.toLower();
            if (lower.contains(QStringLiteral("v2 code + bss + reserved stack + heap exceed applet allowance")) ||
                lower.contains(QStringLiteral("applet image exceeds selected app size"))) {
                m_buildLinkSizeOverflow = true;
            }
        }
        appendOutputText(text, OutputKind::Normal);
    });
    connect(m_compilerProcess, &QProcess::readyReadStandardError, this, [this]() {
        const QString text =
            QString::fromLocal8Bit(m_compilerProcess->readAllStandardError());

        processCompilerStderrChunk(text);
    });
    connect(m_compilerProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError) {
        const QString toolName = (m_buildStep == BuildStep::V2CliBuilding ||
                                  m_buildStep == BuildStep::V2CliProbe ||
                                  m_buildStep == BuildStep::V2CliRelink)
            ? tr("cgarm-build") : m_buildStep == BuildStep::Objcopy
            ? tr("packer / objcopy") :
            m_buildStep == BuildStep::Linking && m_currentBuildIsV2 ? tr("LLVM linker") : tr("compiler");
        appendOutputLine(tr("Could not start %1. Check that the IDE's bundled toolchain exists.").arg(toolName), OutputKind::Error);
        m_buildStep = BuildStep::None;
        finishCompileProgress();
        statusBar()->showMessage(tr("Compile failed"));
    });
    connect(m_compilerProcess, &QProcess::finished, this, &MainWindow::handleCompilerFinished);

    // Crash recovery uses an app-data session directory, never a project
    // directory. QLockFile keeps another running CoderGirl instance from
    // mistaking this live session's snapshots for a crashed session.
    const QString appData =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (!appData.isEmpty()) {
        const QString recoveryRoot =
            QDir(appData).filePath(QStringLiteral("recovery"));
        m_recoverySessionPath = QDir(recoveryRoot).filePath(
            QStringLiteral("session-")
            + QUuid::createUuid().toString(QUuid::WithoutBraces));
        if (QDir().mkpath(m_recoverySessionPath)) {
            // Snapshots may contain private source text. On Linux/Unix keep
            // recovery directories accessible to the account owner only.
            const QFileDevice::Permissions privateDirectory =
                QFileDevice::ReadOwner | QFileDevice::WriteOwner
                | QFileDevice::ExeOwner;
            QFile::setPermissions(recoveryRoot, privateDirectory);
            QFile::setPermissions(m_recoverySessionPath, privateDirectory);
            m_recoveryLock = new QLockFile(
                QDir(m_recoverySessionPath).filePath(QStringLiteral(".lock")));
            m_recoveryLock->setStaleLockTime(0);
            if (!m_recoveryLock->tryLock(0)) {
                qWarning("CoderGirl: could not secure editor recovery directory");
                delete m_recoveryLock;
                m_recoveryLock = nullptr;
            }
        }
    }

    // A short idle debounce captures recent edits; the periodic safety pass
    // covers missed signals. Atomic QSaveFile writes survive sudden exits.
    m_recoveryDebounceTimer = new QTimer(this);
    m_recoveryDebounceTimer->setSingleShot(true);
    m_recoveryDebounceTimer->setInterval(1200);
    connect(m_recoveryDebounceTimer, &QTimer::timeout,
            this, [this]() { saveEditorRecoverySnapshots(); });

    m_recoveryHeartbeatTimer = new QTimer(this);
    m_recoveryHeartbeatTimer->setInterval(12000);
    connect(m_recoveryHeartbeatTimer, &QTimer::timeout,
            this, [this]() { saveEditorRecoverySnapshots(); });
    m_recoveryHeartbeatTimer->start();

    //createNewSourceFile();
    //createNewHeaderFile();

    //AutoSelectMainC();
}

MainWindow::~MainWindow()
{
    // This is also reached when the operating system closes the process
    // normally; a forced crash deliberately bypasses the destructor.
    if (m_recoveryLock) {
        m_recoveryLock->unlock();
        delete m_recoveryLock;
        m_recoveryLock = nullptr;
    }
    // A session without a manifest has no recoverable work. Remove only
    // empty session directories; unexpected leftovers remain untouched.
    if (!m_recoverySessionPath.isEmpty()
        && !QFileInfo::exists(QDir(m_recoverySessionPath).filePath(
            QStringLiteral("manifest.json")))) {
        QDir().rmdir(m_recoverySessionPath);
    }
    delete ui;
}

bool MainWindow::closeEditorTab(int index)
{
    if (!m_editorTabs
        || index < 0
        || index >= m_editorTabs->count()) {
        return false;
    }

    QWidget *widget =
        m_editorTabs->widget(index);

    if (!widget) {
        return false;
    }

    if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(widget)) {
        if (designer->isModified()) {
            QMessageBox box(this);
            box.setIcon(QMessageBox::Warning);
            box.setWindowTitle(tr("Unsaved GUI Design"));
            box.setText(tr("Save changes to %1 before closing?").arg(QFileInfo(designer->filePath()).fileName()));
            QPushButton *saveButton = box.addButton(QMessageBox::Save);
            QPushButton *discardButton = box.addButton(QMessageBox::Discard);
            box.addButton(QMessageBox::Cancel);
            box.setDefaultButton(saveButton);
            box.exec();
            if (box.clickedButton() == saveButton) {
                if (!designer->saveDesignAndGenerate()) return false;
            } else if (box.clickedButton() != discardButton) {
                return false;
            }
        }
        m_editorTabs->removeTab(index);
        widget->deleteLater();
        return true;
    }

    if (auto *game = dynamic_cast<SidboxGameDesigner *>(widget)) {
        if (game->isModified()) {
            QMessageBox box(this);
            box.setWindowTitle(tr("Unsaved Game Design"));
            box.setText(tr("Save changes to %1 before closing?").arg(game->displayName()));
            QPushButton *saveButton = box.addButton(QMessageBox::Save);
            QPushButton *discardButton = box.addButton(QMessageBox::Discard);
            box.addButton(QMessageBox::Cancel);
            box.setDefaultButton(saveButton);
            box.exec();
            if (box.clickedButton() == saveButton) {
                if (!game->saveDesign()) return false;
            } else if (box.clickedButton() != discardButton) return false;
        }
        m_editorTabs->removeTab(index);
        widget->deleteLater();
        return true;
    }

    CodeEditor *editor =
        primaryEditorForTab(widget);

    if (editor
        && editor->document()
        && editor->document()->isModified()) {
        const QMessageBox::StandardButton reply =
            QMessageBox::question(
                this,
                tr("Unsaved Changes"),
                tr("You're about to close an unsaved tab, proceed?"),
                QMessageBox::Yes | QMessageBox::No,
                QMessageBox::No);

        if (reply != QMessageBox::Yes) {
            return false;
        }
    }

    if (editor) {
        /*
         * A split pane can temporarily borrow the QTextDocument belonging to
         * another normal tab. If that borrowed tab is being closed, restore
         * the split's secondary pane to its host document before deleting the
         * tab so the split never holds a dangling document pointer.
         */
        QSplitter *splitter =
            editorSplitWidget();

        if (splitter
            && m_editorTabs->widget(index)
                != splitter) {
            CodeEditor *host =
                splitHostEditor(splitter);

            CodeEditor *secondary =
                splitSecondaryEditor(splitter);

            if (host
                && secondary
                && secondary->document()
                    == editor->document()) {
                secondary->setProperty(
                    "sidboxApiReference",
                    host->property(
                        "sidboxApiReference"));

                secondary->shareDocumentFrom(host);
                secondary->setTextCursor(
                    host->textCursor());
                secondary->setDiagnostics(
                    host->diagnostics());

                updateEditorSplitPresentation();
            }
        }

        unwatchEditorFile(editor);
    }

    m_editorTabs->removeTab(index);
    widget->deleteLater();
    // A deliberately discarded/closed tab must not come back after a crash.
    saveEditorRecoverySnapshots();

    /*
     * Closing one or many source tabs can change which in-memory source wins
     * over the on-disk copy. The timer is single-shot, so a bulk close naturally
     * coalesces into one project-analysis refresh after the menu operation.
     */
    m_projectAnalysisTimer->start();

    return true;
}


void MainWindow::closeEvent(QCloseEvent *event)
{
    if (!event) {
        return;
    }

    const auto savePaneLayout = [this]() {
        auto *splitter = findChild<QSplitter *>(QStringLiteral("mainThreePaneSplitter"));
        if (!splitter) return;
        QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
        settings.setValue(QStringLiteral("layout/projectTreeWidth"),
                          splitter->property("projectTreeWidth").toInt());
        settings.setValue(QStringLiteral("layout/editorRightWidth"),
                          splitter->property("editorRightWidth").toInt());
        if (auto *outputSplit = findChild<QSplitter *>(
                QStringLiteral("sidboxOutputMemorySplitter")))
            settings.setValue(QStringLiteral("layout/outputMemorySplitter"),
                              outputSplit->saveState());
    };

    QList<SidboxGuiDesigner *> unsavedDesigners;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(m_editorTabs->widget(i))) {
            if (designer->isModified()) unsavedDesigners.append(designer);
        }
    }

    if (!unsavedDesigners.isEmpty()) {
        QMessageBox box(this);
        box.setIcon(QMessageBox::Warning);
        box.setWindowTitle(tr("Unsaved GUI Designs"));
        box.setText(tr("There are %1 unsaved CoderGirl GUI design(s).").arg(unsavedDesigners.size()));
        box.setInformativeText(tr("Save them and regenerate their .c files before closing Sidbox IDE?"));
        QPushButton *saveButton = box.addButton(QMessageBox::Save);
        QPushButton *discardButton = box.addButton(QMessageBox::Discard);
        box.addButton(QMessageBox::Cancel);
        box.setDefaultButton(saveButton);
        box.exec();
        if (box.clickedButton() == saveButton) {
            for (SidboxGuiDesigner *designer : unsavedDesigners) {
                if (!designer->saveDesignAndGenerate()) { event->ignore(); return; }
            }
        } else if (box.clickedButton() != discardButton) {
            event->ignore();
            return;
        }
    }

    QList<SidboxGameDesigner *> unsavedGames;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->widget(i)))
            if (game->isModified()) unsavedGames.append(game);
    }
    if (!unsavedGames.isEmpty()) {
        QMessageBox box(this);
        box.setWindowTitle(tr("Unsaved Game Designs"));
        box.setText(tr("There are %1 unsaved game design(s).").arg(unsavedGames.size()));
        QPushButton *save = box.addButton(QMessageBox::Save);
        QPushButton *discard = box.addButton(QMessageBox::Discard);
        box.addButton(QMessageBox::Cancel);
        box.setDefaultButton(save);
        box.exec();
        if (box.clickedButton() == save) {
            for (auto *game : unsavedGames) if (!game->saveDesign()) { event->ignore(); return; }
        } else if (box.clickedButton() != discard) { event->ignore(); return; }
    }

    QList<CodeEditor *> unsavedEditors;
    QStringList unsavedNames;

    /*
     * Split panes can share documents, but a secondary pane can also hold
     * another independently modified document. Check every unique document,
     * so neither case loses unsaved work on a normal Close.
     */
    QSet<QTextDocument *> checkedDocuments;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        for (CodeEditor *editor : editorsForTab(m_editorTabs->widget(i))) {
            if (!editor || !editor->document()
                || checkedDocuments.contains(editor->document())) {
                continue;
            }
            checkedDocuments.insert(editor->document());

            const bool untitledHasWork =
                editor->filePath().isEmpty()
                && !editor->toPlainText().isEmpty();

            if (!editor->document()->isModified()
                && !untitledHasWork) {
                continue;
            }

            unsavedEditors.append(editor);
            QString name = editor->filePath().isEmpty()
                ? tabTitleForEditor(editor).remove(QLatin1Char('*'))
                : QFileInfo(editor->filePath()).fileName();
            if (name.isEmpty()) {
                name = tr("Untitled source");
            }
            unsavedNames.append(name);
        }
    }

    if (unsavedEditors.isEmpty()) {
        savePaneLayout();
        clearEditorRecoverySession();
        if (m_recoveryHeartbeatTimer) m_recoveryHeartbeatTimer->stop();
        event->accept();
        return;
    }

    QString details;

    const int shownCount =
        qMin(8, unsavedNames.size());

    for (int i = 0; i < shownCount; ++i) {
        details +=
            QStringLiteral("\n  • %1")
                .arg(unsavedNames.at(i));
    }

    if (unsavedNames.size() > shownCount) {
        details +=
            tr("\n  • ...and %1 more")
                .arg(
                    unsavedNames.size()
                    - shownCount);
    }

    QMessageBox box(this);
    box.setIcon(QMessageBox::Warning);
    box.setWindowTitle(tr("Unsaved Work"));
    box.setText(
        unsavedEditors.size() == 1
            ? tr("There is 1 file with unsaved work.")
            : tr("There are %1 files with unsaved work.")
                  .arg(unsavedEditors.size()));

    box.setInformativeText(
        tr("Save before closing Sidbox IDE?%1")
            .arg(details));

    QPushButton *saveButton =
        box.addButton(
            tr("Save"),
            QMessageBox::AcceptRole);

    QPushButton *discardButton =
        box.addButton(
            tr("Discard"),
            QMessageBox::DestructiveRole);

    QPushButton *cancelButton =
        box.addButton(
            QMessageBox::Cancel);

    box.setDefaultButton(saveButton);
    box.setEscapeButton(cancelButton);
    box.exec();

    QAbstractButton *clicked =
        box.clickedButton();

    if (clicked == cancelButton
        || !clicked) {
        event->ignore();
        return;
    }

    if (clicked == discardButton) {
        savePaneLayout();
        clearEditorRecoverySession();
        if (m_recoveryHeartbeatTimer) m_recoveryHeartbeatTimer->stop();
        event->accept();
        return;
    }

    if (clicked != saveButton) {
        event->ignore();
        return;
    }

    /*
     * Save only the files that actually need attention. Untitled tabs naturally
     * use the existing Save As dialog through saveEditor(). If the user cancels
     * any Save As, abort the IDE shutdown so nothing is lost accidentally.
     */
    for (CodeEditor *editor :
         std::as_const(unsavedEditors)) {
        if (!editor) {
            continue;
        }

        if (!saveEditor(editor)) {
            event->ignore();
            statusBar()->showMessage(
                tr("Close cancelled — unsaved work remains"),
                3000);
            return;
        }
    }

    /*
     * If this is a normal saved project, persist the tab/project metadata too.
     * Do not force a .proj Save As when the user is simply working from loose
     * files in an empty IDE session.
     */
    if (!m_projectFilePath.isEmpty()) {
        if (!saveProjectFile(
                m_projectFilePath)) {
            event->ignore();
            statusBar()->showMessage(
                tr("Close cancelled — project could not be saved"),
                3000);
            return;
        }
    }

    savePaneLayout();
    clearEditorRecoverySession();
    if (m_recoveryHeartbeatTimer) m_recoveryHeartbeatTimer->stop();
    event->accept();
}


// Store ONLY unsaved text buffers. No project source file is ever overwritten
// by this service, even when the user later elects to restore a snapshot.
bool MainWindow::saveEditorRecoverySnapshots()
{
    if (m_restoringRecovery || !m_recoveryLock || !m_editorTabs) {
        return false;
    }

    struct Pending {
        QString id;
        QString filename;
        QByteArray bytes;
        QJsonObject metadata;
    };
    QList<Pending> pending;
    QSet<QTextDocument *> seenDocuments;

    for (int tab = 0; tab < m_editorTabs->count(); ++tab) {
        // Split panes sometimes share a QTextDocument with another tab.
        // Save each unique document exactly once.
        for (CodeEditor *editor : editorsForTab(m_editorTabs->widget(tab))) {
            if (!editor || !editor->document() || editor->isReadOnly()
                || seenDocuments.contains(editor->document())) {
                continue;
            }
            seenDocuments.insert(editor->document());
            const bool hasUntitledText = editor->filePath().isEmpty()
                                       && !editor->toPlainText().isEmpty();
            if (!editor->document()->isModified() && !hasUntitledText) {
                continue;
            }

            QString id = editor->property("sidboxRecoveryId").toString();
            if (id.isEmpty()) {
                id = QUuid::createUuid().toString(QUuid::WithoutBraces);
                editor->setProperty("sidboxRecoveryId", id);
            }
            const QString filename = QStringLiteral("buffer_") + id
                                     + QStringLiteral(".txt");
            const QByteArray content = editor->toPlainText().toUtf8();
            const QByteArray checksum = QCryptographicHash::hash(
                content, QCryptographicHash::Sha256).toHex();
            QString label = editor->filePath().isEmpty()
                                ? m_editorTabs->tabText(tab)
                                : QFileInfo(editor->filePath()).fileName();
            label.remove(QLatin1Char('*'));
            if (label.trimmed().isEmpty()) {
                label = tr("Untitled source");
            }
            QJsonObject metadata;
            metadata.insert(QStringLiteral("id"), id);
            metadata.insert(QStringLiteral("snapshot"), filename);
            metadata.insert(QStringLiteral("path"), editor->filePath());
            if (!editor->filePath().isEmpty()) {
                const QFileInfo diskFile(editor->filePath());
                if (diskFile.exists()) {
                    metadata.insert(QStringLiteral("diskModifiedMs"),
                        static_cast<double>(diskFile.lastModified().toMSecsSinceEpoch()));
                }
            }
            metadata.insert(QStringLiteral("label"), label.trimmed());
            metadata.insert(QStringLiteral("cursor"),
                            editor->textCursor().position());
            metadata.insert(QStringLiteral("sha256"), QString::fromLatin1(checksum));
            pending.append({id, filename, content, metadata});
        }
    }

    if (pending.isEmpty()) {
        // A save (or a deliberate tab close) has cleared the unsaved state.
        // No new recovery files are necessary until there are new edits.
        clearEditorRecoverySession();
        return true;
    }

    if (!QDir().mkpath(m_recoverySessionPath)) {
        return false;
    }
    const QDir session(m_recoverySessionPath);
    QJsonArray items;
    QSet<QString> referencedFiles;
    for (const Pending &p : std::as_const(pending)) {
        const QString file = session.filePath(p.filename);
        referencedFiles.insert(p.filename);
        if (m_recoverySavedHashes.value(p.id) !=
                    p.metadata.value(QStringLiteral("sha256")).toString().toLatin1()
            || !QFileInfo::exists(file)) {
            QSaveFile snapshot(file);
            if (!snapshot.open(QIODevice::WriteOnly)
                || snapshot.write(p.bytes) != p.bytes.size()
                || !snapshot.commit()) {
                qWarning("CoderGirl: could not write editor recovery snapshot");
                return false;
            }
            m_recoverySavedHashes.insert(p.id,
                p.metadata.value(QStringLiteral("sha256")).toString().toLatin1());
        }
        items.append(p.metadata);
    }

    QJsonObject manifest;
    manifest.insert(QStringLiteral("version"), 1);
    manifest.insert(QStringLiteral("items"), items);
    const QByteArray manifestBytes =
        QJsonDocument(manifest).toJson(QJsonDocument::Indented);
    if (manifestBytes != m_recoveryManifestBytes
        || !QFileInfo::exists(session.filePath(QStringLiteral("manifest.json")))) {
        QSaveFile output(session.filePath(QStringLiteral("manifest.json")));
        if (!output.open(QIODevice::WriteOnly)
            || output.write(manifestBytes) != manifestBytes.size()
            || !output.commit()) {
            qWarning("CoderGirl: could not write editor recovery manifest");
            return false;
        }
        m_recoveryManifestBytes = manifestBytes;
    }

    // Only remove unreferenced snapshots AFTER the replacement manifest is
    // committed. Interrupted writes can never make the previous one unusable.
    for (const QString &filename : session.entryList(
             {QStringLiteral("buffer_*.txt")}, QDir::Files)) {
        if (!referencedFiles.contains(filename)) {
            QFile::remove(session.filePath(filename));
        }
    }
    return true;
}

void MainWindow::clearEditorRecoverySession()
{
    if (m_recoveryDebounceTimer) {
        m_recoveryDebounceTimer->stop();
    }
    m_recoverySavedHashes.clear();
    m_recoveryManifestBytes.clear();
    if (!m_recoverySessionPath.isEmpty()) {
        const QDir session(m_recoverySessionPath);
        // Never remove an arbitrary directory: the session name was generated
        // by this process and is under QStandardPaths::AppDataLocation.
        for (const QString &filename : session.entryList(
                 {QStringLiteral("buffer_*.txt"), QStringLiteral("manifest.json")},
                 QDir::Files)) {
            QFile::remove(session.filePath(filename));
        }
    }
}

void MainWindow::offerEditorRecovery()
{
    const QString appData =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (appData.isEmpty()) {
        return;
    }
    QDir root(QDir(appData).filePath(QStringLiteral("recovery")));
    if (!root.exists()) {
        return;
    }

    struct Recovered {
        QString path;
        QString label;
        QString contents;
        int cursor = 0;
        qint64 diskModifiedMs = -1;
    };
    QList<Recovered> recovered;
    QStringList oldSessionDirs;
    static const QRegularExpression safeSnapshot(
        QStringLiteral(R"(^buffer_[0-9a-fA-F-]+\.txt$)"));

    // Newest sessions first. A crash could have interrupted the last write;
    // QSaveFile ensures any published manifest/snapshot is complete.
    for (const QString &sessionName : root.entryList(
             {QStringLiteral("session-*")},
             QDir::Dirs | QDir::NoDotAndDotDot, QDir::Time)) {
        const QString sessionPath = root.filePath(sessionName);
        if (sessionPath == m_recoverySessionPath) {
            continue;
        }
        QLockFile checkLock(QDir(sessionPath).filePath(QStringLiteral(".lock")));
        checkLock.setStaleLockTime(0);
        if (!checkLock.tryLock(0)) {
            continue; // Another IDE instance is actively editing this session.
        }
        QFile manifestFile(QDir(sessionPath).filePath(QStringLiteral("manifest.json")));
        if (!manifestFile.open(QIODevice::ReadOnly)) {
            continue;
        }
        const QJsonDocument document =
            QJsonDocument::fromJson(manifestFile.readAll());
        if (!document.isObject()
            || document.object().value(QStringLiteral("version")).toInt() != 1) {
            continue;
        }
        const QJsonArray items =
            document.object().value(QStringLiteral("items")).toArray();
        int loadedFromSession = 0;
        for (const QJsonValue &item : items) {
            if (!item.isObject()) continue;
            const QJsonObject obj = item.toObject();
            const QString filename = obj.value(QStringLiteral("snapshot")).toString();
            if (!safeSnapshot.match(filename).hasMatch()) continue;
            QFile snapshot(QDir(sessionPath).filePath(filename));
            if (!snapshot.open(QIODevice::ReadOnly)) continue;
            const QByteArray bytes = snapshot.readAll();
            const QByteArray checksum = QCryptographicHash::hash(
                bytes, QCryptographicHash::Sha256).toHex();
            if (QString::fromLatin1(checksum)
                != obj.value(QStringLiteral("sha256")).toString()) {
                continue;
            }
            recovered.append({obj.value(QStringLiteral("path")).toString(),
                              obj.value(QStringLiteral("label")).toString(),
                              QString::fromUtf8(bytes),
                              obj.value(QStringLiteral("cursor")).toInt(),
                              static_cast<qint64>(obj.value(
                                  QStringLiteral("diskModifiedMs")).toDouble(-1))});
            ++loadedFromSession;
        }
        if (loadedFromSession > 0) {
            oldSessionDirs.append(sessionPath);
        }
    }

    if (recovered.isEmpty()) {
        return;
    }

    QStringList names;
    for (int i = 0; i < qMin(8, recovered.size()); ++i) {
        QString name = recovered.at(i).label;
        if (name.isEmpty()) name = tr("Untitled source");
        names << QStringLiteral("  • ") + name;
    }
    if (recovered.size() > 8) {
        names << tr("  • ...and %1 more").arg(recovered.size() - 8);
    }

    QMessageBox prompt(this);
    prompt.setIcon(QMessageBox::Question);
    prompt.setWindowTitle(tr("Recover Unsaved Source Files"));
    prompt.setText(tr("CoderGirl found %1 unsaved editor snapshot(s) from an earlier session.")
                   .arg(recovered.size()));
    prompt.setInformativeText(
        tr("Restore them into editor tabs? Original files will NOT be overwritten.\n\n%1")
            .arg(names.join(QLatin1Char('\n'))));
    QPushButton *restoreButton = prompt.addButton(tr("Restore"), QMessageBox::AcceptRole);
    QPushButton *discardButton = prompt.addButton(tr("Discard Recovery Copies"), QMessageBox::DestructiveRole);
    QPushButton *laterButton = prompt.addButton(tr("Later"), QMessageBox::RejectRole);
    prompt.setDefaultButton(restoreButton);
    prompt.setEscapeButton(laterButton);
    prompt.exec();

    if (prompt.clickedButton() == laterButton || !prompt.clickedButton()) {
        return; // Keep snapshots for the next launch.
    }
    if (prompt.clickedButton() == discardButton) {
        for (const QString &sessionPath : std::as_const(oldSessionDirs)) {
            QDir(sessionPath).removeRecursively();
        }
        return;
    }
    if (prompt.clickedButton() != restoreButton) {
        return;
    }

    m_restoringRecovery = true;
    int restoredCount = 0;
    for (const Recovered &item : std::as_const(recovered)) {
        CodeEditor *editor = nullptr;
        const QString path = item.path;
        // Restoring over another *unsaved* open document would destroy data.
        // In that case (or for missing paths) create an untitled recovery tab.
        const bool diskUnchanged = item.diskModifiedMs < 0
            || (QFileInfo::exists(path)
                && QFileInfo(path).lastModified().toMSecsSinceEpoch()
                   == item.diskModifiedMs);
        if (!path.isEmpty() && QFileInfo::exists(path) && diskUnchanged
            && QFileInfo(path).suffix().compare(
                   QStringLiteral("sbui"), Qt::CaseInsensitive) != 0) {
            CodeEditor *existing = nullptr;
            for (int i = 0; i < m_editorTabs->count(); ++i) {
                CodeEditor *candidate = primaryEditorForTab(m_editorTabs->widget(i));
                if (candidate && !candidate->filePath().isEmpty()
                    && QFileInfo(candidate->filePath()).absoluteFilePath()
                       == QFileInfo(path).absoluteFilePath()) {
                    existing = candidate;
                    break;
                }
            }
            if (existing && !existing->document()->isModified()
                && !existing->isReadOnly()) {
                editor = existing;
                m_editorTabs->setCurrentIndex(tabIndexForEditor(existing));
            } else if (!existing) {
                // Do not use openFile() here: that automatically adds files to
                // the active project's tree, even when a recovery belongs to
                // an entirely different project.
                CodeEditor *loaded = createEditor(path);
                if (loaded->loadFromFile(path, true)) {
                    editor = loaded;
                    const int index = m_editorTabs->addTab(
                        editor, editorTabIconForFile(path),
                        tabTitleForEditor(editor));
                    m_editorTabs->setTabToolTip(index,
                        QDir::toNativeSeparators(path));
                    m_editorTabs->setCurrentIndex(index);
                    QTimer::singleShot(20, editor, [editor]() {
                        editor->enableSyntaxHighlighting();
                    });
                    watchEditorFile(editor);
                    m_projectAnalysisTimer->start();
                } else {
                    loaded->deleteLater();
                }
            }
        }
        if (!editor) {
            editor = createEditor();
            const QString label = item.label.isEmpty() ? tr("Untitled source") : item.label;
            editor->setProperty("sidboxRecoveryDisplayName", label);
            const int index = m_editorTabs->addTab(
                editor, tabTitleForEditor(editor));
            m_editorTabs->setCurrentIndex(index);
        }
        editor->setPlainText(item.contents);
        editor->document()->setModified(true);
        QTextCursor cursor = editor->textCursor();
        cursor.setPosition(qBound(0, item.cursor,
                                 editor->document()->characterCount() - 1));
        editor->setTextCursor(cursor);
        editor->centerCursor();
        editor->setFocus();
        updateTabTitle(editor);
        ++restoredCount;
    }
    m_restoringRecovery = false;

    // Persist restored buffers into THIS session before deleting stale data.
    // If disk is full, retain the old recovery copies for another attempt.
    if (restoredCount == recovered.size() && saveEditorRecoverySnapshots()) {
        for (const QString &sessionPath : std::as_const(oldSessionDirs)) {
            QDir(sessionPath).removeRecursively();
        }
    } else {
        QMessageBox::warning(this, tr("Editor Recovery"),
            tr("Some recovery data could not be transferred. Older recovery copies were kept."));
    }
    statusBar()->showMessage(tr("Restored %1 unsaved source buffer(s)")
                             .arg(restoredCount), 5000);
}


void MainWindow::showStartupProjectChooser()
{
    // Preserve the startup entry point used by main.cpp, but show a non-modal
    // Home tab instead of blocking the editor with a QMessageBox.
    showHomePage();
}

QStringList MainWindow::recentProjectPaths() const
{
    QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
    const QStringList stored = settings.value(
        QStringLiteral("projects/recentPaths")).toStringList();
    QStringList paths;
    for (const QString &path : stored) {
        if (path.trimmed().isEmpty())
            continue;
        const QString absolute = QFileInfo(path).absoluteFilePath();
        if (!paths.contains(absolute))
            paths.append(absolute);
        if (paths.size() >= 20)
            break;
    }
    return paths;
}

void MainWindow::rememberRecentProject(const QString &projectFile)
{
    if (projectFile.isEmpty())
        return;
    const QString absolute = QFileInfo(projectFile).absoluteFilePath();
    QStringList paths = recentProjectPaths();
    paths.removeAll(absolute);
    paths.prepend(absolute);
    paths = paths.mid(0, 20);
    QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
    settings.setValue(QStringLiteral("projects/recentPaths"), paths);
    refreshRecentProjectsHome();
}

void MainWindow::forgetRecentProject(const QString &projectFile)
{
    QStringList paths = recentProjectPaths();
    paths.removeAll(QFileInfo(projectFile).absoluteFilePath());
    QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
    settings.setValue(QStringLiteral("projects/recentPaths"), paths);
    // No filesystem operations: removing a recent entry never deletes files.
    refreshRecentProjectsHome();
}

void MainWindow::refreshRecentProjectsHome()
{
    // Find only the live Home tab. A previous Home tab may still be awaiting
    // deleteLater() after a project switch.
    QTreeWidget *list = nullptr;
    QWidget *homePage = nullptr;
    for (int i = 0; m_editorTabs && i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (tab->objectName() == QStringLiteral("sidboxHomeTab")) {
            list = tab->findChild<QTreeWidget *>(
                QStringLiteral("sidboxHomeRecentProjects"));
            homePage = tab;
            break;
        }
    }
    if (!list)
        return;
    list->clear();
    const QStringList paths = recentProjectPaths();
    for (const QString &path : paths) {
        const QFileInfo info(path);
        const bool available = info.isFile();
        auto *item = new QTreeWidgetItem(list);
        item->setIcon(0, QIcon(QStringLiteral(":/icons/open_project.png")));
        item->setText(0, info.completeBaseName());
        // Give the folder its own wide column; the exact .proj path is kept
        // separately in UserRole so opening a row never depends on this text.
        item->setText(1, QDir::toNativeSeparators(info.absolutePath()));
        item->setData(0, Qt::UserRole, path);
        item->setToolTip(0, available
            ? tr("Double-click to open %1").arg(path)
            : tr("Missing project: %1\nRemove it from the recent list if you wish.")
                  .arg(path));
        item->setToolTip(1, tr("Project directory: %1\nProject file: %2")
                               .arg(QDir::toNativeSeparators(info.absolutePath()),
                                    QDir::toNativeSeparators(path)));
        item->setSizeHint(0, QSize(160, 36));
        if (!available) {
            item->setText(0, tr("%1 (missing)").arg(info.completeBaseName()));
            item->setForeground(0, m_theme.mutedText);
            item->setForeground(1, m_theme.mutedText);
        }
        auto *remove = new QPushButton(tr("Remove"), list);
        remove->setObjectName(QStringLiteral("sidboxHomeRemoveRecent"));
        remove->setToolTip(tr("Remove from Recent — project files stay on disk"));
        remove->setFixedHeight(27);
        connect(remove, &QPushButton::clicked, this,
                [this, path]() { forgetRecentProject(path); });
        list->setItemWidget(item, 2, remove);
    }
    if (auto *hint = homePage->findChild<QLabel *>(
            QStringLiteral("sidboxHomeEmptyRecent")))
        hint->setVisible(paths.isEmpty());
}

bool MainWindow::confirmProjectSwitch()
{
    bool unsaved = false;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            if (designer->isModified()) { unsaved = true; break; }
        }
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (game->isModified()) { unsaved = true; break; }
        }
        if (CodeEditor *editor = primaryEditorForTab(tab)) {
            if (editor->document()->isModified()) { unsaved = true; break; }
        }
    }
    if (!unsaved)
        return true;
    QMessageBox prompt(this);
    prompt.setIcon(QMessageBox::Warning);
    prompt.setWindowTitle(tr("Open Project"));
    prompt.setText(tr("You have unsaved changes in the current project."));
    prompt.setInformativeText(tr("Save them before switching projects?"));
    QPushButton *save = prompt.addButton(tr("Save"), QMessageBox::AcceptRole);
    QPushButton *discard = prompt.addButton(tr("Discard Changes"), QMessageBox::DestructiveRole);
    prompt.addButton(QMessageBox::Cancel);
    prompt.setDefaultButton(save);
    prompt.exec();
    if (prompt.clickedButton() == discard)
        return true;
    if (prompt.clickedButton() == save)
        return saveProject();
    return false;
}

bool MainWindow::openProjectAtPath(const QString &projectFile)
{
    const QFileInfo info(projectFile);
    if (!info.isFile()) {
        QMessageBox::warning(this, tr("Open Project"),
            tr("This project file is missing or unavailable:\n%1\n\n"
               "The recent entry can be removed without deleting anything.")
                .arg(QDir::toNativeSeparators(projectFile)));
        return false;
    }
    const QString path = info.absoluteFilePath();
    if (!m_projectFilePath.isEmpty()
        && QFileInfo(m_projectFilePath).absoluteFilePath() == path) {
        AutoSelectMainC();
        if (m_editorTabs->currentWidget()->objectName()
                == QStringLiteral("sidboxHomeTab")) {
            for (int i = 0; i < m_editorTabs->count(); ++i) {
                if (m_editorTabs->widget(i)->objectName()
                        != QStringLiteral("sidboxHomeTab")) {
                    m_editorTabs->setCurrentIndex(i);
                    break;
                }
            }
        }
        statusBar()->showMessage(tr("Project is already open: %1")
                                     .arg(info.fileName()), 3000);
        rememberRecentProject(path);
        return true;
    }
    if (!confirmProjectSwitch())
        return false;
    if (!loadProjectFile(path))
        return false;
    AutoSelectMainC();
    statusBar()->showMessage(tr("Project opened: %1")
                             .arg(QDir::toNativeSeparators(path)), 4000);
    return true;
}

void MainWindow::showHomePage()
{
    if (!m_editorTabs)
        return;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (m_editorTabs->widget(i)->objectName()
                == QStringLiteral("sidboxHomeTab")) {
            m_editorTabs->setCurrentIndex(i);
            refreshRecentProjectsHome();
            return;
        }
    }

    auto *scroll = new QScrollArea(m_editorTabs);
    scroll->setObjectName(QStringLiteral("sidboxHomeTab"));
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    auto *page = new QWidget(scroll);
    page->setObjectName(QStringLiteral("sidboxHomePage"));
    auto *outer = new QVBoxLayout(page);
    // Home fills the central editor tab: keep only a comfortable page gutter.
    outer->setContentsMargins(20, 24, 20, 20);
    outer->setSpacing(14);

    auto *content = new QWidget(page);
    content->setObjectName(QStringLiteral("sidboxHomeContent"));
    // No maximum-width constraint: let project paths use the available tab.
    content->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    auto *layout = new QVBoxLayout(content);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(14);

    auto *title = new QLabel(tr("Welcome to CoderGirl"), content);
    title->setObjectName(QStringLiteral("sidboxHomeTitle"));
    layout->addWidget(title);
    auto *subtitle = new QLabel(
        tr("SIDBOX development — start something new, or pick up where you left off."),
        content);
    subtitle->setObjectName(QStringLiteral("sidboxHomeSubtitle"));
    subtitle->setWordWrap(true);
    layout->addWidget(subtitle);
    layout->addSpacing(12);

    auto *actions = new QHBoxLayout();
    actions->setSpacing(12);
    auto *openButton = new QPushButton(
        QIcon(QStringLiteral(":/icons/open_project.png")), tr("Open Project..."), content);
    openButton->setObjectName(QStringLiteral("sidboxHomeOpenProject"));
    openButton->setMinimumHeight(46);
    auto *newButton = new QPushButton(
        QIcon(QStringLiteral(":/icons/new_project.png")), tr("New Project..."), content);
    newButton->setMinimumHeight(46);
    actions->addWidget(openButton);
    actions->addWidget(newButton);
    actions->addStretch();
    layout->addLayout(actions);
    connect(openButton, &QPushButton::clicked, this, &MainWindow::openProject);
    connect(newButton, &QPushButton::clicked, this, &MainWindow::createNewProject);

    layout->addSpacing(12);
    auto *heading = new QLabel(tr("Recent Projects"), content);
    heading->setObjectName(QStringLiteral("sidboxHomeRecentHeading"));
    layout->addWidget(heading);
    auto *instruction = new QLabel(
        tr("Double-click to open. Remove only forgets the shortcut; it never deletes the project."),
        content);
    instruction->setObjectName(QStringLiteral("sidboxHomeInstruction"));
    instruction->setWordWrap(true);
    layout->addWidget(instruction);

    auto *recent = new QTreeWidget(content);
    recent->setObjectName(QStringLiteral("sidboxHomeRecentProjects"));
    recent->setColumnCount(3);
    recent->setHeaderLabels({tr("Project"), tr("Project directory"), QString()});
    recent->setRootIsDecorated(false);
    recent->setUniformRowHeights(false);
    recent->setAlternatingRowColors(true);
    recent->setSelectionMode(QAbstractItemView::SingleSelection);
    recent->setMinimumHeight(190);
    recent->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    // Middle-elide extremely long directories, keeping the useful beginning
    // and folder name visible. Hovering shows the complete path.
    recent->setTextElideMode(Qt::ElideMiddle);
    recent->header()->setStretchLastSection(false);
    recent->header()->setSectionResizeMode(0, QHeaderView::Interactive);
    recent->header()->resizeSection(0, 210);
    recent->header()->setSectionResizeMode(1, QHeaderView::Stretch);
    recent->header()->setSectionResizeMode(2, QHeaderView::Fixed);
    recent->header()->resizeSection(2, 104);
    layout->addWidget(recent, 1);
    connect(recent, &QTreeWidget::itemDoubleClicked, this,
            [this](QTreeWidgetItem *item, int) {
                if (item) openProjectAtPath(item->data(0, Qt::UserRole).toString());
            });
    // A separate button also supports keyboard-only navigation without
    // activating a row twice on platforms that emit both item signals.
    auto *openSelected = new QPushButton(tr("Open Selected Project"), content);
    openSelected->setMinimumHeight(32);
    auto *selectionRow = new QHBoxLayout();
    selectionRow->addWidget(openSelected);
    selectionRow->addStretch();
    layout->addLayout(selectionRow);
    connect(openSelected, &QPushButton::clicked, this, [this, recent]() {
        if (QTreeWidgetItem *item = recent->currentItem())
            openProjectAtPath(item->data(0, Qt::UserRole).toString());
    });
    auto *empty = new QLabel(
        tr("No recent projects yet. Open or create a project to see it here."), content);
    empty->setObjectName(QStringLiteral("sidboxHomeEmptyRecent"));
    empty->setWordWrap(true);
    layout->addWidget(empty);
    // Do NOT centre with an alignment flag: it prevents horizontal expansion.
    outer->addWidget(content, 1);
    scroll->setWidget(page);
    QIcon homeTabIcon(QStringLiteral(":/icons/toolbar_home.png"));
    if (homeTabIcon.isNull())
        homeTabIcon = QIcon(QStringLiteral(":/icons/icon.png"));
    const int index = m_editorTabs->addTab(scroll, homeTabIcon, tr("Home"));
    m_editorTabs->setCurrentIndex(index);
    refreshRecentProjectsHome();
    updateHomePageTheme();
}

void MainWindow::updateHomePageTheme()
{
    QWidget *home = nullptr;
    for (int i = 0; m_editorTabs && i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (tab->objectName() == QStringLiteral("sidboxHomeTab")) {
            home = tab->findChild<QWidget *>(QStringLiteral("sidboxHomePage"));
            break;
        }
    }
    if (!home)
        return;
    const auto colour = [](const QColor &c) { return ideThemeColorName(c); };
    home->setStyleSheet(QStringLiteral(
        "QWidget#sidboxHomePage, QWidget#sidboxHomeContent { background:%1; }"
        "QLabel#sidboxHomeTitle { color:%2; font-size:27px; font-weight:700; }"
        "QLabel#sidboxHomeRecentHeading { color:%2; font-size:18px; font-weight:600; }"
        "QLabel#sidboxHomeSubtitle, QLabel#sidboxHomeInstruction, "
        "QLabel#sidboxHomeEmptyRecent { color:%3; font-size:12px; }"
        "QPushButton#sidboxHomeOpenProject { border:2px solid %4; "
        "background:%5; color:%2; font-weight:600; padding:9px 18px; }"
        "QPushButton#sidboxHomeOpenProject:hover { background:%6; }"
        "QTreeWidget#sidboxHomeRecentProjects { background:%7; "
        "border:1px solid %8; alternate-background-color:%9; }"
        "QTreeWidget#sidboxHomeRecentProjects::item:selected { background:%4; color:%2; }"
        "QTreeWidget#sidboxHomeRecentProjects::item:hover { background:%6; }"
        "QPushButton#sidboxHomeRemoveRecent { padding:2px 6px; }"
    ).arg(colour(m_theme.windowBackground), colour(m_theme.brightText),
          colour(m_theme.mutedText), colour(m_theme.accent),
          colour(m_theme.panelBackground), colour(m_theme.hover),
          colour(m_theme.inputBackground), colour(m_theme.treeBorder),
          colour(m_theme.alternateBackground)));
}


void MainWindow::AutoSelectMainC(){
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (m_editorTabs->tabText(i) == "main.c" || m_editorTabs->tabText(i) == "untitled.c") { // Or tabToolTip(i) / filename check
            m_editorTabs->setCurrentIndex(i);
            break;
        }
    }
}


// ---------------------------------------------------------------------------
// SIDBOX programmer calculator — a self-contained sidebar utility.
// Numeric expressions use unsigned, fixed-width arithmetic (wrap on overflow).
// The signed row is a two's-complement *view* of the same bits.
// ---------------------------------------------------------------------------
namespace {
class SidboxCalcParser
{
public:
    SidboxCalcParser(const QString &expression, int bits)
        : m_expression(expression), m_bits(bits),
          m_mask(bits == 64 ? ~quint64(0) : ((quint64(1) << bits) - 1)) {}

    bool evaluate(quint64 &result, QString &error)
    {
        m_pos = 0;
        m_error.clear();
        const quint64 value = bitOr();
        skipSpaces();
        if (m_error.isEmpty() && m_pos != m_expression.size())
            m_error = QStringLiteral("Unexpected character at position %1").arg(m_pos + 1);
        error = m_error;
        if (!error.isEmpty()) return false;
        result = value & m_mask;
        return true;
    }

private:
    void skipSpaces()
    {
        while (m_pos < m_expression.size() && m_expression.at(m_pos).isSpace()) ++m_pos;
    }

    bool take(const char *symbol)
    {
        skipSpaces();
        const QString token = QString::fromLatin1(symbol);
        if (m_expression.mid(m_pos, token.size()) != token) return false;
        m_pos += token.size();
        return true;
    }

    quint64 bitOr()
    {
        quint64 lhs = bitXor();
        while (m_error.isEmpty() && take("|")) lhs = (lhs | bitXor()) & m_mask;
        return lhs;
    }

    quint64 bitXor()
    {
        quint64 lhs = bitAnd();
        while (m_error.isEmpty() && take("^")) lhs = (lhs ^ bitAnd()) & m_mask;
        return lhs;
    }

    quint64 bitAnd()
    {
        quint64 lhs = shifts();
        while (m_error.isEmpty() && take("&")) lhs = (lhs & shifts()) & m_mask;
        return lhs;
    }

    quint64 shifts()
    {
        quint64 lhs = addSubtract();
        while (m_error.isEmpty()) {
            if (take("<<")) {
                const quint64 amount = addSubtract();
                if (amount >= quint64(m_bits)) lhs = 0;
                else lhs = (lhs << unsigned(amount)) & m_mask;
            } else if (take(">>")) {
                const quint64 amount = addSubtract();
                if (amount >= quint64(m_bits)) lhs = 0;
                else lhs = (lhs >> unsigned(amount)) & m_mask;
            } else break;
        }
        return lhs;
    }

    quint64 addSubtract()
    {
        quint64 lhs = multiplyDivide();
        while (m_error.isEmpty()) {
            if (take("+")) lhs = (lhs + multiplyDivide()) & m_mask;
            else if (take("-")) lhs = (lhs - multiplyDivide()) & m_mask;
            else break;
        }
        return lhs;
    }

    quint64 multiplyDivide()
    {
        quint64 lhs = unary();
        while (m_error.isEmpty()) {
            if (take("*")) lhs = (lhs * unary()) & m_mask;
            else if (take("/")) {
                const quint64 rhs = unary();
                if (!rhs) { m_error = QStringLiteral("Division by zero"); return 0; }
                lhs = lhs / rhs;
            } else if (take("%")) {
                const quint64 rhs = unary();
                if (!rhs) { m_error = QStringLiteral("Division by zero"); return 0; }
                lhs = lhs % rhs;
            } else break;
        }
        return lhs & m_mask;
    }

    quint64 unary()
    {
        if (take("~")) return (~unary()) & m_mask;
        if (take("+")) return unary();
        if (take("-")) return (quint64(0) - unary()) & m_mask;
        return primary();
    }

    quint64 primary()
    {
        if (!m_error.isEmpty()) return 0;
        if (take("(")) {
            const quint64 value = bitOr();
            if (!take(")") && m_error.isEmpty()) m_error = QStringLiteral("Missing closing parenthesis");
            return value;
        }
        skipSpaces();
        int base = 10;
        if (m_expression.mid(m_pos, 2).compare(QStringLiteral("0x"), Qt::CaseInsensitive) == 0) {
            base = 16; m_pos += 2;
        } else if (m_expression.mid(m_pos, 2).compare(QStringLiteral("0b"), Qt::CaseInsensitive) == 0) {
            base = 2; m_pos += 2;
        }
        const int start = m_pos;
        quint64 result = 0;
        for (; m_pos < m_expression.size(); ++m_pos) {
            const QChar ch = m_expression.at(m_pos);
            int digit = -1;
            if (ch >= QLatin1Char('0') && ch <= QLatin1Char('9')) digit = ch.unicode() - '0';
            else if (ch >= QLatin1Char('A') && ch <= QLatin1Char('F')) digit = ch.unicode() - 'A' + 10;
            else if (ch >= QLatin1Char('a') && ch <= QLatin1Char('f')) digit = ch.unicode() - 'a' + 10;
            if (digit < 0 || digit >= base) break;
            if (result > (std::numeric_limits<quint64>::max() - quint64(digit)) / quint64(base)) {
                m_error = QStringLiteral("Number exceeds 64 bits");
                return 0;
            }
            result = result * quint64(base) + quint64(digit);
        }
        if (start == m_pos) m_error = QStringLiteral("Expected a number");
        return result & m_mask;
    }

    QString m_expression;
    int m_bits = 32;
    quint64 m_mask = 0xFFFFFFFFULL;
    int m_pos = 0;
    QString m_error;
};

// Independent REAL result. The programmer readouts retain their unsigned
// bitwise semantics; this parser evaluates arithmetic without truncating /.
// Bit operations are deliberately unsupported for REAL results.
class SidboxCalcRealParser
{
public:
    explicit SidboxCalcRealParser(const QString &text) : m_text(text) {}

    bool evaluate(double &result)
    {
        m_pos = 0;
        m_ok = true;
        const double value = expression();
        skip();
        if (!m_ok || m_pos != m_text.size() || !std::isfinite(value)) return false;
        result = value;
        return true;
    }

private:
    void skip() { while (m_pos < m_text.size() && m_text[m_pos].isSpace()) ++m_pos; }
    bool take(QChar ch)
    {
        skip();
        if (m_pos < m_text.size() && m_text[m_pos] == ch) { ++m_pos; return true; }
        return false;
    }
    double expression()
    {
        double lhs = term();
        while (m_ok) {
            if (take(QLatin1Char('+'))) lhs += term();
            else if (take(QLatin1Char('-'))) lhs -= term();
            else break;
        }
        return lhs;
    }
    double term()
    {
        double lhs = unary();
        while (m_ok) {
            if (take(QLatin1Char('*'))) lhs *= unary();
            else if (take(QLatin1Char('/'))) {
                const double denominator = unary();
                if (denominator == 0.0) { m_ok = false; return 0.0; }
                lhs /= denominator;
            } else break;
        }
        return lhs;
    }
    double unary()
    {
        if (take(QLatin1Char('+'))) return unary();
        if (take(QLatin1Char('-'))) return -unary();
        if (take(QLatin1Char('('))) {
            const double value = expression();
            if (!take(QLatin1Char(')'))) m_ok = false;
            return value;
        }
        return number();
    }
    double number()
    {
        skip();
        const int start = m_pos;
        if (m_text.mid(m_pos, 2).compare(QStringLiteral("0x"), Qt::CaseInsensitive) == 0
            || m_text.mid(m_pos, 2).compare(QStringLiteral("0b"), Qt::CaseInsensitive) == 0) {
            const int base = m_text.at(m_pos + 1).toLower() == QLatin1Char('x') ? 16 : 2;
            m_pos += 2;
            const int digitsStart = m_pos;
            while (m_pos < m_text.size()) {
                const QChar ch = m_text.at(m_pos);
                const bool digit = ch >= QLatin1Char('0') && ch <= QLatin1Char('9');
                const bool hex = ch.toLower() >= QLatin1Char('a') && ch.toLower() <= QLatin1Char('f');
                if (digit || (base == 16 && hex)) ++m_pos;
                else break;
            }
            bool ok = false;
            const quint64 value = m_text.mid(digitsStart, m_pos - digitsStart)
                .toULongLong(&ok, base);
            if (!ok) m_ok = false;
            return double(value);
        }
        // Decimal values also support fractional and scientific notation.
        bool digits = false;
        while (m_pos < m_text.size() && m_text[m_pos].isDigit()) { ++m_pos; digits = true; }
        if (m_pos < m_text.size() && m_text[m_pos] == QLatin1Char('.')) {
            ++m_pos;
            while (m_pos < m_text.size() && m_text[m_pos].isDigit()) { ++m_pos; digits = true; }
        }
        if (!digits) { m_ok = false; return 0.0; }
        if (m_pos < m_text.size() && (m_text[m_pos] == QLatin1Char('e')
                                         || m_text[m_pos] == QLatin1Char('E'))) {
            ++m_pos;
            if (m_pos < m_text.size() && (m_text[m_pos] == QLatin1Char('+')
                                             || m_text[m_pos] == QLatin1Char('-'))) ++m_pos;
            const int exponentStart = m_pos;
            while (m_pos < m_text.size() && m_text[m_pos].isDigit()) ++m_pos;
            if (m_pos == exponentStart) m_ok = false;
        }
        bool ok = false;
        const double value = m_text.mid(start, m_pos - start).toDouble(&ok);
        if (!ok) m_ok = false;
        return value;
    }

    QString m_text;
    int m_pos = 0;
    bool m_ok = true;
};

class SidboxProgrammerCalculator : public QWidget
{
public:
    explicit SidboxProgrammerCalculator(QWidget *parent = nullptr) : QWidget(parent)
    {
        setObjectName(QStringLiteral("sidboxProgrammerCalculator"));
        setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);

        auto *layout = new QVBoxLayout(this);
        layout->setContentsMargins(0, 2, 0, 0);
        layout->setSpacing(3);

        auto *heading = new QHBoxLayout();
        heading->setContentsMargins(0, 0, 0, 0);
        auto *title = new QLabel(tr("Programmer Calculator"), this);
        heading->addWidget(title, 1);
        m_width = new QComboBox(this);
        m_width->setToolTip(tr("Fixed-width arithmetic. Results wrap to the selected bit width."));
        for (int bits : {8, 16, 32, 64}) m_width->addItem(tr("%1-bit").arg(bits), bits);
        m_width->setCurrentIndex(2);
        m_width->setMaximumWidth(92);
        heading->addWidget(m_width);
        layout->addLayout(heading);

        m_expression = new QLineEdit(this);
        m_expression->setObjectName(QStringLiteral("programmerCalculatorExpression"));
        m_expression->setPlaceholderText(tr("0xD0000000 + (1 << 8)"));
        m_expression->setToolTip(tr("Enter an expression. Hex: 0x..., binary: 0b...; supports + - * / % & | ^ ~ << >> and parentheses."));
        layout->addWidget(m_expression);

        auto *readouts = new QGridLayout();
        readouts->setContentsMargins(0, 0, 0, 0);
        readouts->setHorizontalSpacing(4);
        readouts->setVerticalSpacing(2);
        const QString labels[] = {tr("HEX"), tr("UDEC"), tr("SDEC")};
        for (int index = 0; index < 3; ++index) {
            auto *caption = new QLabel(labels[index], this);
            readouts->addWidget(caption, index, 0);
            m_display[index] = new QLineEdit(this);
            m_display[index]->setObjectName(QStringLiteral("programmerCalculatorValue%1").arg(index));
            m_display[index]->setReadOnly(true);
            m_display[index]->setFrame(true);
            m_display[index]->setAlignment(Qt::AlignRight);
            m_display[index]->setMinimumWidth(0);
            m_display[index]->setToolTip(tr("Select and copy this value with Ctrl+C"));
            m_display[index]->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
            readouts->addWidget(m_display[index], index, 1);
        }
        // The fourth row is informational: integer HEX/UDEC/SDEC and bit
        // toggles still use fixed-width arithmetic independently.
        auto *realCaption = new QLabel(tr("REAL"), this);
        readouts->addWidget(realCaption, 3, 0);
        m_realDisplay = new QLineEdit(this);
        m_realDisplay->setObjectName(QStringLiteral("programmerCalculatorRealValue"));
        m_realDisplay->setReadOnly(true);
        m_realDisplay->setAlignment(Qt::AlignRight);
        m_realDisplay->setMinimumWidth(0);
        m_realDisplay->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
        m_realDisplay->setToolTip(tr("Floating-point arithmetic result (for example 3/2 = 1.5). "
            "Bitwise operations are integer-only; REAL then shows a dash."));
        readouts->addWidget(m_realDisplay, 3, 1);
        readouts->setColumnStretch(1, 1);
        layout->addLayout(readouts);

        // Each row covers up to 16 bits, from most significant on the left to
        // least significant on the right. The LOWEST 16-bit chunk comes first:
        // row 0 = bits 0-15, row 1 = bits 16-31, etc.
        auto *binaryHeading = new QHBoxLayout();
        binaryHeading->setContentsMargins(0, 0, 0, 0);
        auto *binaryTitle = new QLabel(tr("BIN  (click bits to toggle)"), this);
        binaryTitle->setToolTip(tr("Each click toggles a bit and converts the current result to an editable hex literal."));
        binaryHeading->addWidget(binaryTitle, 1);
        m_copyBinary = new QToolButton(this);
        m_copyBinary->setText(tr("COPY BIN"));
        m_copyBinary->setFocusPolicy(Qt::NoFocus);
        m_copyBinary->setToolTip(tr("Copy all binary bits, most significant first, without spaces."));
        binaryHeading->addWidget(m_copyBinary);
        layout->addLayout(binaryHeading);
        m_binaryArea = new QWidget(this);
        m_binaryArea->setObjectName(QStringLiteral("programmerCalculatorBinaryBits"));
        m_binaryRows = new QVBoxLayout(m_binaryArea);
        m_binaryRows->setContentsMargins(0, 0, 0, 0);
        m_binaryRows->setSpacing(3);
        layout->addWidget(m_binaryArea);

        m_message = new QLabel(tr("Decimal input, 0x hex, 0b binary"), this);
        m_message->setObjectName(QStringLiteral("programmerCalculatorMessage"));
        m_message->setMinimumHeight(15);
        layout->addWidget(m_message);

        const QString rows[][5] = {
            {"7", "8", "9", "/", "<<"},
            {"4", "5", "6", "*", ">>"},
            {"1", "2", "3", "-", "&"},
            {"0", "A", "B", "+", "|"},
            {"C", "D", "E", "F", "^"},
            {"0x", "0b", "(", ")", "%"},
            {"~", "DEL", "CLR", "=", "COPY"}
        };
        auto *keypad = new QGridLayout();
        keypad->setContentsMargins(0, 0, 0, 0);
        keypad->setHorizontalSpacing(2);
        keypad->setVerticalSpacing(2);
        for (int row = 0; row < 7; ++row) {
            for (int col = 0; col < 5; ++col) {
                const QString buttonText = rows[row][col];
                auto *button = new QPushButton(buttonText, this);
                button->setFixedHeight(23);
                button->setMinimumWidth(0);
                button->setFocusPolicy(Qt::NoFocus); // Keep typing in the expression field.
                if (buttonText == QStringLiteral("COPY"))
                    button->setToolTip(tr("Copy the hexadecimal result"));
                if (buttonText == QStringLiteral("A") || buttonText == QStringLiteral("B")
                    || buttonText == QStringLiteral("C") || buttonText == QStringLiteral("D")
                    || buttonText == QStringLiteral("E") || buttonText == QStringLiteral("F"))
                    button->setToolTip(tr("Use 0x before hexadecimal digits"));
                keypad->addWidget(button, row, col);
                connect(button, &QPushButton::clicked, this, [this, buttonText]() {
                    if (buttonText == QStringLiteral("CLR")) m_expression->clear();
                    else if (buttonText == QStringLiteral("DEL")) m_expression->backspace();
                    else if (buttonText == QStringLiteral("COPY")) {
                        if (m_valid) QApplication::clipboard()->setText(m_display[0]->text());
                    } else if (buttonText == QStringLiteral("=")) {
                        if (m_valid) m_expression->setText(m_display[0]->text());
                    } else m_expression->insert(buttonText);
                    m_expression->setFocus();
                });
            }
        }
        for (int col = 0; col < 5; ++col) keypad->setColumnStretch(col, 1);
        layout->addLayout(keypad);
        layout->addStretch(0);

        rebuildBitRows(m_width->currentData().toInt());
        connect(m_copyBinary, &QToolButton::clicked, this, [this]() {
            if (!m_valid) return;
            const int bits = m_width->currentData().toInt();
            QApplication::clipboard()->setText(
                QString::number(m_currentValue, 2).rightJustified(bits, QLatin1Char('0')));
        });
        connect(m_expression, &QLineEdit::textChanged, this, [this](const QString &) { recalculate(); });
        connect(m_width, QOverload<int>::of(&QComboBox::currentIndexChanged),
                this, [this](int) {
            rebuildBitRows(m_width->currentData().toInt());
            recalculate();
        });
        connect(m_expression, &QLineEdit::returnPressed, this, [this]() {
            if (m_valid) m_expression->setText(m_display[0]->text());
        });
        m_expression->setText(QStringLiteral("0"));
    }

private:
    void rebuildBitRows(int bits)
    {
        // Rebuild only when the width changes, NOT when the value changes.
        // That keeps mouse clicks stable and avoids creating 64 widgets per keypress.
        for (auto *&button : m_bitButtons) button = nullptr;
        while (QLayoutItem *item = m_binaryRows->takeAt(0)) {
            delete item->widget();
            delete item;
        }

        const int rowCount = (bits + 15) / 16;
        for (int row = 0; row < rowCount; ++row) {
            const int low = row * 16;
            const int high = qMin(low + 15, bits - 1);
            auto *rowWidget = new QWidget(m_binaryArea);
            auto *line = new QHBoxLayout(rowWidget);
            line->setContentsMargins(0, 0, 0, 0);
            line->setSpacing(1);
            auto *range = new QLabel(QStringLiteral("%1-%2").arg(low).arg(high), rowWidget);
            range->setFixedWidth(39);
            range->setToolTip(tr("Bit positions %1 to %2; bit %1 is the least significant in this row.").arg(low).arg(high));
            line->addWidget(range);

            for (int bit = high; bit >= low; --bit) {
                if (bit != high && ((bit + 1) % 4) == 0) line->addSpacing(4);
                auto *button = new QToolButton(rowWidget);
                button->setObjectName(QStringLiteral("programmerCalculatorBit%1").arg(bit));
                button->setText(QStringLiteral("0"));
                button->setCheckable(true);
                button->setFixedHeight(18);
                button->setMinimumWidth(8);
                button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
                button->setFocusPolicy(Qt::NoFocus);
                QFont bitFont = QFontDatabase::systemFont(QFontDatabase::FixedFont);
                bitFont.setPointSize(8);
                button->setFont(bitFont);
                button->setStyleSheet(QStringLiteral(
                    "QToolButton { padding: 0px; border: 1px solid palette(mid); }"
                    "QToolButton:checked { background: palette(highlight); color: palette(highlighted-text); font-weight: bold; }"));
                button->setToolTip(tr("Toggle bit %1 (0x%2); result becomes a hexadecimal value.")
                                   .arg(bit).arg(QString::number(quint64(1) << bit, 16).toUpper()));
                line->addWidget(button, 1);
                m_bitButtons[bit] = button;
                connect(button, &QToolButton::clicked, this, [this, bit]() {
                    if (!m_valid) return;
                    const int width = m_width->currentData().toInt();
                    const quint64 mask = width == 64 ? ~quint64(0) : ((quint64(1) << width) - 1);
                    const quint64 newValue = (m_currentValue ^ (quint64(1) << bit)) & mask;
                    const QString hex = QStringLiteral("0x") +
                        QString::number(newValue, 16).toUpper().rightJustified(width / 4, QLatin1Char('0'));
                    // The expression may have been complex; toggling a bit intentionally
                    // commits the evaluated value as an editable hex literal.
                    m_expression->setText(hex);
                    m_expression->setFocus();
                });
            }
            m_binaryRows->addWidget(rowWidget);
        }
        // Let the layout calculate the calculator's actual height. A fixed
        // pixel estimate clipped the last keypad row on some styles/themes.
        // Qt includes the current font, control sizes, spacing and the number
        // of binary rows (8/16/32/64-bit) in its size hint automatically.
        // QSizePolicy::Fixed keeps that space reserved below the project tree.
        layout()->invalidate();
        updateGeometry();
    }

    void recalculate()
    {
        const int bits = m_width->currentData().toInt();
        QString error;
        quint64 value = 0;
        const QString expression = m_expression->text().trimmed();
        const bool empty = expression.isEmpty();
        // Evaluate REAL separately, even if the integer parser rejects a
        // decimal fraction. This does not change the fixed-width answer.
        SidboxCalcRealParser realParser(empty ? QStringLiteral("0") : expression);
        double realValue = 0.0;
        if (realParser.evaluate(realValue)) {
            m_realDisplay->setText(QString::number(realValue, 'g', 15));
        } else {
            m_realDisplay->setText(QStringLiteral("—"));
        }
        m_realDisplay->setCursorPosition(0);
        SidboxCalcParser parser(empty ? QStringLiteral("0") : expression, bits);
        m_valid = parser.evaluate(value, error);
        m_copyBinary->setEnabled(m_valid);
        if (!m_valid) {
            for (auto *display : m_display) display->clear();
            for (auto *button : m_bitButtons) {
                if (button) {
                    button->setEnabled(false);
                    button->setChecked(false);
                    button->setText(QStringLiteral("?"));
                }
            }
            m_message->setText(error);
            m_message->setToolTip(error);
            return;
        }
        m_currentValue = value;
        const int hexDigits = bits / 4;
        m_display[0]->setText(QStringLiteral("0x") +
            QString::number(value, 16).toUpper().rightJustified(hexDigits, QLatin1Char('0')));
        m_display[1]->setText(QString::number(value));
        const quint64 signBit = quint64(1) << (bits - 1);
        const quint64 mask = bits == 64 ? ~quint64(0) : ((quint64(1) << bits) - 1);
        const QString signedValue = (value & signBit)
            ? QStringLiteral("-") + QString::number((~value + 1) & mask)
            : QString::number(value);
        m_display[2]->setText(signedValue);
        for (int bit = 0; bit < bits; ++bit) {
            auto *button = m_bitButtons[bit];
            if (!button) continue;
            const bool set = (value & (quint64(1) << bit)) != 0;
            button->setEnabled(true);
            button->setChecked(set); // clicked(), not toggled(), drives edits.
            button->setText(set ? QStringLiteral("1") : QStringLiteral("0"));
        }
        for (auto *display : m_display) display->setCursorPosition(0);
        m_message->setText(tr("Unsigned %1-bit • wraps on overflow").arg(bits));
        m_message->setToolTip(tr("Division and right-shifts use unsigned arithmetic; SDEC shows the two's-complement value."));
    }

    QLineEdit *m_expression = nullptr;
    QComboBox *m_width = nullptr;
    QLineEdit *m_display[3] = {nullptr, nullptr, nullptr};
    QLineEdit *m_realDisplay = nullptr;
    QWidget *m_binaryArea = nullptr;
    QVBoxLayout *m_binaryRows = nullptr;
    QToolButton *m_bitButtons[64] = {};
    QToolButton *m_copyBinary = nullptr;
    QLabel *m_message = nullptr;
    quint64 m_currentValue = 0;
    bool m_valid = false;
};
} // namespace


// Stage 32: read the memory span actually reserved by the ARM ELF's PT_LOAD
// segments. No external `size` tool is required, so LLVM and CGARM V2 builds
// can use the same dashboard (including CGARM ELFs without a symbol table).
namespace {
quint16 armElfU16(const QByteArray &b, qsizetype i)
{
    const auto *p = reinterpret_cast<const unsigned char *>(b.constData());
    return quint16(p[i]) | (quint16(p[i + 1]) << 8);
}
quint32 armElfU32(const QByteArray &b, qsizetype i)
{
    const auto *p = reinterpret_cast<const unsigned char *>(b.constData());
    return quint32(p[i]) | (quint32(p[i + 1]) << 8) |
           (quint32(p[i + 2]) << 16) | (quint32(p[i + 3]) << 24);
}

struct SidboxElfRam {
    bool valid = false;
    quint64 spanBytes = 0;
    quint64 startAddress = 0;
};

SidboxElfRam readSidboxElfRam(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) return {};
    const QByteArray header = file.read(52);
    if (header.size() != 52 || header.at(0) != '\x7f' ||
        header.mid(1, 3) != QByteArray("ELF") ||
        quint8(header.at(4)) != 1 || // 32-bit ELF
        quint8(header.at(5)) != 1 || // little endian
        armElfU16(header, 18) != 40) // EM_ARM
        return {};

    const quint32 phOffset = armElfU32(header, 28);
    const quint16 entrySize = armElfU16(header, 42);
    const quint16 count = armElfU16(header, 44);
    if (entrySize < 32 || entrySize > 256 || count == 0 || count > 128 ||
        quint64(phOffset) + quint64(entrySize) * count > quint64(file.size()))
        return {};

    quint64 lowest = std::numeric_limits<quint64>::max();
    quint64 highest = 0;
    for (quint16 i = 0; i < count; ++i) {
        if (!file.seek(qint64(phOffset) + qint64(i) * entrySize)) return {};
        const QByteArray ph = file.read(32);
        if (ph.size() != 32) return {};
        if (armElfU32(ph, 0) != 1) continue; // PT_LOAD
        const quint64 address = armElfU32(ph, 8);
        const quint64 memorySize = armElfU32(ph, 20);
        if (memorySize == 0) continue;
        lowest = qMin(lowest, address);
        highest = qMax(highest, address + memorySize);
    }
    if (lowest == std::numeric_limits<quint64>::max() ||
        highest < lowest || highest - lowest > 32ULL * 1024 * 1024)
        return {};
    return {true, highest - lowest, lowest};
}

struct SidboxStackFrame {
    quint64 bytes = 0;
    QString function;
    QString qualifier;
};

SidboxStackFrame largestSidboxStackFrame(const QString &buildDir)
{
    SidboxStackFrame best;
    if (buildDir.isEmpty() || !QDir(buildDir).exists()) return best;
    // gcc -fstack-usage creates one .su per translation unit. This is the
    // biggest SINGLE function frame, not an estimated peak call-chain stack.
    QDirIterator iter(buildDir, {QStringLiteral("*.su")}, QDir::Files,
                      QDirIterator::Subdirectories);
    int filesSeen = 0;
    while (iter.hasNext() && filesSeen++ < 350) {
        QFile report(iter.next());
        if (report.size() <= 0 || report.size() > 2 * 1024 * 1024 ||
            !report.open(QIODevice::ReadOnly)) continue;
        const QByteArray data = report.readAll();
        for (const QByteArray &line : data.split('\n')) {
            const QList<QByteArray> fields = line.split('\t');
            if (fields.size() < 3) continue;
            bool ok = false;
            const quint64 bytes = fields.at(1).toULongLong(&ok);
            if (!ok || bytes < best.bytes) continue;
            best.bytes = bytes;
            best.function = QString::fromUtf8(fields.at(0).trimmed()).section(':', -1);
            best.qualifier = QString::fromUtf8(fields.at(2).trimmed());
        }
    }
    return best;
}

QString sidboxMemSize(quint64 bytes)
{
    if (bytes < 1024) return QStringLiteral("%1 B").arg(bytes);
    return QStringLiteral("%1 KiB").arg(QString::number(double(bytes) / 1024.0, 'f', 1));
}

QWidget *makeAppletMemoryPanel(QWidget *parent)
{
    auto *panel = new QWidget(parent);
    panel->setObjectName(QStringLiteral("sidboxAppletMemoryPanel"));
    panel->setMinimumWidth(225);
    panel->setMaximumWidth(340);
    panel->setToolTip(QObject::tr(
        "These bars show build-time RAM reservations, not measured peak use. "
        "The ELF RAM footprint includes the reserved private stack; the "
        "bounded heap is additional. Actual peak usage requires hardware "
        "instrumentation."));

    auto *layout = new QVBoxLayout(panel);
    layout->setContentsMargins(7, 3, 7, 3);
    layout->setSpacing(2);

    auto *header = new QHBoxLayout();
    header->setContentsMargins(0, 0, 0, 0);
    header->setSpacing(5);
    auto *heading = new QLabel(QObject::tr("Applet Memory"), panel);
    heading->setObjectName(QStringLiteral("sidboxMemoryHeading"));
    heading->setStyleSheet(QStringLiteral("font-weight: bold;"));
    header->addWidget(heading);

    auto *status = new QLabel(QObject::tr("Build to measure"), panel);
    status->setObjectName(QStringLiteral("sidboxMemoryStatus"));
    status->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    status->setWordWrap(false);
    header->addWidget(status, 1);
    layout->addLayout(header);

    const auto addRow = [panel, layout](const QString &key, const QString &shortLabel,
                                         const QString &description) {
        auto *row = new QHBoxLayout();
        row->setContentsMargins(0, 0, 0, 0);
        row->setSpacing(5);
        auto *name = new QLabel(shortLabel, panel);
        name->setObjectName(QStringLiteral("sidboxMemoryLabel_") + key);
        name->setFixedWidth(43);
        name->setToolTip(description);
        row->addWidget(name);
        auto *bar = new QProgressBar(panel);
        bar->setObjectName(QStringLiteral("sidboxMemoryBar_") + key);
        bar->setRange(0, 1000);
        bar->setValue(0);
        bar->setFormat(QStringLiteral("—"));
        bar->setFixedHeight(18);
        bar->setTextVisible(true);
        row->addWidget(bar, 1);
        layout->addLayout(row);
    };
    addRow(QStringLiteral("total"), QObject::tr("Total"),
           QObject::tr("Total linked image RAM plus bounded heap reservation."));
    addRow(QStringLiteral("image"), QObject::tr("ELF"),
           QObject::tr("RAM covered by the linked ELF, including private stack."));
    addRow(QStringLiteral("stack"), QObject::tr("Stack"),
           QObject::tr("Private stack reservation; not measured maximum usage."));
    addRow(QStringLiteral("heap"), QObject::tr("Heap"),
           QObject::tr("Bounded heap reservation; not currently allocated heap."));

    auto *details = new QLabel(panel);
    details->setObjectName(QStringLiteral("sidboxMemoryDetails"));
    details->setWordWrap(true);
    details->setTextInteractionFlags(Qt::TextSelectableByMouse);
    layout->addWidget(details);
    layout->addStretch(1);
    return panel;
}

void updateAppletMemoryPanel(QWidget *root, bool v2, int appKiB,
                             int stackKiB, int heapKiB,
                             bool buildSucceeded = false,
                             const QString &elfFile = QString(),
                             const QString &appFile = QString(),
                             const QString &buildDir = QString(),
                             bool v1Game = false)
{
    if (!root) return;
    auto *status = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryStatus"));
    auto *details = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryDetails"));
    if (!status || !details) return;
    if (auto *heading = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryHeading")))
        heading->setText(v2 ? QObject::tr("Applet Memory") : QObject::tr("V1 Game / App Memory"));

    const quint64 allowance = quint64(qMax(appKiB, 1)) * 1024;
    quint64 visualAllowance = allowance;
    const auto setRow = [root, &visualAllowance](const QString &key, const QString &title,
                                           quint64 bytes, bool known) {
        auto *label = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryLabel_") + key);
        auto *bar = root->findChild<QProgressBar *>(QStringLiteral("sidboxMemoryBar_") + key);
        if (!label || !bar) return;
        // The brief row label is fixed; full context and percentages live
        // in the tooltips, so the monitor stays compact even with long values.
        bar->setValue(known ? int(qMin<quint64>(1000, (bytes * 1000) / visualAllowance)) : 0);
        bar->setFormat(known ? sidboxMemSize(bytes) : QStringLiteral("—"));
        bar->setToolTip(known ? QStringLiteral("%1: %2 / %3 (%4% of allowance)")
                       .arg(title, sidboxMemSize(bytes), sidboxMemSize(visualAllowance))
                       .arg(qulonglong((bytes * 100) / visualAllowance))
                         : QObject::tr("Build to determine this value."));
    };
    setRow(QStringLiteral("total"), QObject::tr("Total RAM reserved"), 0, false);
    setRow(QStringLiteral("image"), QObject::tr("Linked ELF RAM"), 0, false);
    setRow(QStringLiteral("stack"), QObject::tr("Private stack reserved"), 0, false);
    setRow(QStringLiteral("heap"), QObject::tr("Heap reserved"), 0, false);
    details->clear();
    details->setToolTip(QString());
    if (auto *stackLabel = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryLabel_stack")))
        stackLabel->setToolTip(QObject::tr("Private stack reservation; not measured usage."));
    if (!v2) {
        status->setText(QObject::tr("V1 · %1").arg(sidboxMemSize(allowance)));
        status->setToolTip(QObject::tr("V1 / Gaming: configured memory allowance, not measured live RAM usage."));
        if (!buildSucceeded) {
            details->setText(QObject::tr("Build to measure linked image."));
            return;
        }
        const auto elf = readSidboxElfRam(elfFile);
        if (elf.valid) {
            // A V1 game uses the SDRAM from its link start up to the RAM disk.
            // App-size KB only bounds desktop GUI images, NOT V1 games.
            if (v1Game && elf.startAddress >= 0xD0000000ULL &&
                elf.startAddress < 0xD05E0000ULL)
                visualAllowance = 0xD05E0000ULL - elf.startAddress;
            // V1 ELF PT_LOAD covers linked image and NOLOAD BSS/stack. This is
            // an ESTIMATE of reserved RAM, not peak heap/stack or framebuffer RAM.
            setRow(QStringLiteral("image"), QObject::tr("V1 linked image incl. BSS/stack"),
                   elf.spanBytes, true);
            setRow(QStringLiteral("total"), QObject::tr("V1 linked reservation (minimum)"),
                   elf.spanBytes, true);
            status->setText(QObject::tr("V1 · %1").arg(sidboxMemSize(visualAllowance)));
            if (elf.spanBytes > visualAllowance)
                status->setText(QObject::tr("OVER · %1").arg(sidboxMemSize(visualAllowance)));
        }
        QStringList notes;
        notes << (elf.valid ? QObject::tr("ELF RAM: %1").arg(sidboxMemSize(elf.spanBytes))
                            : QObject::tr("ELF RAM unavailable"));
        if (QFileInfo(appFile).isFile())
            notes << QObject::tr("APP file: %1").arg(sidboxMemSize(QFileInfo(appFile).size()));
        notes << QObject::tr("V1 heap/stack peak unknown");
        details->setText(notes.join(QStringLiteral("  ·  ")));
        details->setToolTip(QObject::tr("V1 ELF is a linked memory span, not measured RAM use. "
            "Game allowance is estimated from the default 0xD05E0000 RAM-disk boundary; "
            "custom linker layouts can differ. Music buffers, framebuffers, allocator "
            "allocations and run-time heap can use additional RAM."));
        return;
    }
    status->setText(QObject::tr("V2 · %1").arg(sidboxMemSize(allowance)));
    status->setToolTip(QObject::tr("V2 RAM allowance: %1")
                           .arg(sidboxMemSize(allowance)));
    setRow(QStringLiteral("stack"), QObject::tr("Private stack reserved"),
           quint64(qMax(0, stackKiB)) * 1024, true);
    setRow(QStringLiteral("heap"), QObject::tr("Heap reserved"),
           quint64(qMax(0, heapKiB)) * 1024, true);
    if (!buildSucceeded) {
        details->setText(QObject::tr("Build to measure ELF RAM."));
        return;
    }
    const auto elf = readSidboxElfRam(elfFile);
    if (!elf.valid) {
        details->setText(QObject::tr("ELF RAM unavailable."));
        details->setToolTip(QObject::tr("No readable 32-bit ARM ELF layout; RAM total unknown."));
        return;
    }
    // V2 .stack is a NOLOAD section *inside* the linked ELF image;
    // heap is reserved AFTER the linked ELF. Don't double count stack.
    const quint64 heap = quint64(qMax(0, heapKiB)) * 1024;
    const quint64 reserved = elf.spanBytes + heap;
    setRow(QStringLiteral("image"), QObject::tr("Linked ELF RAM (incl. stack)"),
           elf.spanBytes, true);
    setRow(QStringLiteral("total"), QObject::tr("Total RAM reserved"),
           reserved, true);
    if (reserved > allowance) {
        status->setText(QObject::tr("OVER · %1").arg(sidboxMemSize(allowance)));
        status->setToolTip(QObject::tr("V2 RAM allowance exceeded: %1 / %2")
                               .arg(sidboxMemSize(reserved), sidboxMemSize(allowance)));
    }
    QStringList notes;
    notes << QObject::tr("Free: %1")
                 .arg(sidboxMemSize(reserved < allowance ? allowance - reserved : 0));
    if (QFileInfo(appFile).isFile())
        notes << QObject::tr("APP: %1")
                     .arg(sidboxMemSize(QFileInfo(appFile).size()));
    const SidboxStackFrame frame = largestSidboxStackFrame(buildDir);
    QString frameNote;
    if (frame.bytes) {
        frameNote = QObject::tr("Largest GCC function frame: %1 (%2)%3")
                        .arg(sidboxMemSize(frame.bytes), frame.function,
                             frame.qualifier.contains(QStringLiteral("dynamic"), Qt::CaseInsensitive)
                                 ? QObject::tr(" [dynamic]") : QString());
        notes << QObject::tr("Frame: %1").arg(sidboxMemSize(frame.bytes));
    }
    details->setText(notes.join(QStringLiteral("  ·  ")));
    details->setToolTip(frameNote.isEmpty() ? notes.join(QLatin1Char('\n'))
                                             : notes.join(QLatin1Char('\n'))
                                                   + QLatin1Char('\n') + frameNote);
    if (auto *stackLabel = root->findChild<QLabel *>(QStringLiteral("sidboxMemoryLabel_stack"))) {
        stackLabel->setToolTip(frameNote.isEmpty()
                                   ? QObject::tr("Private stack reservation; not measured usage.")
                                   : frameNote + QObject::tr(" — single function only, not maximum call-chain usage."));
    }
}
} // namespace

void MainWindow::setupInterface()
{
    setWindowTitle(tr("Sidbox IDE"));
    QIcon icon = QApplication::windowIcon().isNull() ? QIcon(":/icons/icon.png") : QApplication::windowIcon();
    setWindowIcon(icon);
    //resize(1600, 880);
    //maximumSize();
    showMaximized();


    setStyleSheet(R"(
        QMainWindow {
            background-color: #101010;
            color: #ffffff;
        }

        QWidget {
            background-color: #101010;
            color: #d8d8d8;
        }

        QLabel {
            background-color: #101010;
            color: #ffffff;
            border: none;
        }

        QToolBar {
            background-color: #101010;
            border: none;
            spacing: 1px;
            padding: 1px;
        }

        QToolButton {
            background-color: #101010;
            color: #ffffff;
            border: none;
            border-radius: 0px;
            padding: 3px;
        }

        QToolButton:hover {
            background-color: #202020;
        }

        QToolButton:pressed {
            background-color: #2858A8;
        }

        QPushButton {
            background-color: #101010;
            color: #dddddd;
            border: 1px solid #303030;
            border-radius: 0px;
            padding: 4px 8px;
        }

        QPushButton:hover {
            background-color: #202020;
            border: 1px solid #506090;
        }

        QPushButton:pressed {
            background-color: #2858A8;
            color: #ffffff;
        }

        QTreeWidget {
            background-color: #050505;
            color: #dddddd;
            border: 1px solid #202840;
            border-radius: 0px;
            alternate-background-color: #0b0b0b;
        }

        QTreeWidget::item {
            border-radius: 0px;
            padding: 1px;
        }

        QTreeWidget::item:selected {
            background-color: #2858A8;
            color: #ffffff;
        }

        QTreeWidget::item:hover {
            background-color: #161616;
        }

        QTabWidget::pane {
            background-color: #101010;
            border: 1px solid #202840;
            border-radius: 0px;
        }

        QTabBar::tab {
            background-color: #101010;
            color: #aaaaaa;
            border: 1px solid #282828;
            border-bottom: none;
            border-radius: 0px;
            padding: 5px 10px;
        }

        QTabBar::tab:selected {
            background-color: #2858A8;
            color: #ffffff;
        }

        QTabBar::tab:hover:!selected {
            background-color: #202020;
        }

        QStatusBar {
            background-color: #101010;
            color: #b0b0b0;
            border-top: 1px solid #202020;
        }

        QProgressBar {
            background-color: #050505;
            color: #ffffff;
            border: 1px solid #303030;
            border-radius: 0px;
            text-align: center;
        }

        QProgressBar::chunk {
            background-color: #2858A8;
            border-radius: 0px;
            margin: 0px;
        }

        QProgressBar#compileProgress::chunk {
            width: 18px;
            margin: 1px;
        }

        QSplitter::handle {
            background-color: #202020;
        }

        QSplitter::handle:hover {
            background-color: #2858A8;
        }

        QMenu {
            background-color: #080808;
            color: #dddddd;
            border: 1px solid #303030;
        }

        QMenu::item {
            padding: 5px 24px 5px 8px;
        }

        QMenu::item:selected {
            background-color: #2858A8;
            color: #ffffff;
        }

        QScrollBar:vertical {
            background: #080808;
            width: 12px;
            margin: 0px;
        }

        QScrollBar::handle:vertical {
            background: #303030;
            min-height: 20px;
            border-radius: 0px;
        }

        QScrollBar::handle:vertical:hover {
            background: #505050;
        }

        QScrollBar:add-line:vertical,
        QScrollBar:sub-line:vertical {
            height: 0px;
        }

        QScrollBar:horizontal {
            background: #080808;
            height: 12px;
            margin: 0px;
        }

        QScrollBar::handle:horizontal {
            background: #303030;
            min-width: 20px;
            border-radius: 0px;
        }

        QScrollBar::handle:horizontal:hover {
            background: #505050;
        }

        QScrollBar:add-line:horizontal,
        QScrollBar:sub-line:horizontal {
            width: 0px;
        }

        QLineEdit,
        QPlainTextEdit {
            background-color: #050505;
            color: #dddddd;
            border: 1px solid #303030;
            border-radius: 0px;
            selection-background-color: #2858A8;
            selection-color: #ffffff;
        }

        QToolTip {
            background-color: #07090d;
            color: #f2f2f2;
            border: 2px solid #2858A8;
            padding: 5px 5px;
            font-size: 12px;
            font-weight: 500;
        }
    )");


    auto *toolBar = addToolBar(tr("Project"));
    toolBar->setMovable(false);
    toolBar->setIconSize(QSize(32, 32));
    toolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);    //

    QAction *newAction = toolBar->addAction(QIcon(":/icons/new_project.png"), tr("New"));
    //auto *newMenu = new QMenu(this);
    //QAction *newProjectAction = newMenu->addAction(tr("New Project"));
    //QAction *newSourceAction = newMenu->addAction(tr("New C Source File"));
    //QAction *newHeaderAction = newMenu->addAction(tr("New H Header File"));
    toolBar->addSeparator();
    //newAction->setMenu(newMenu);

    // Prefer the user's Home toolbar artwork; keep the old icon as fallback
    // when the optional image has not yet been embedded in the resources.
    QIcon homeToolbarIcon(QStringLiteral(":/icons/toolbar_home.png"));
    if (homeToolbarIcon.isNull())
        homeToolbarIcon = QIcon(QStringLiteral(":/icons/icon.png"));
    QAction *homeAction = toolBar->addAction(homeToolbarIcon, tr("Home"));
    homeAction->setToolTip(tr("Show the Home page and recent projects"));
    QAction *openProjectAction = toolBar->addAction(QIcon(":/icons/open_project.png"), tr("Open Project..."));
    QAction *saveProjectAction = toolBar->addAction(QIcon(":/icons/save_project.png"), tr("Save Project..."));
    toolBar->addSeparator();
    QAction *projectSettingsAction = toolBar->addAction(QIcon(":/icons/project_settings.png"), tr("Project Settings"));
    QAction *guiDesignerAction = toolBar->addAction(QIcon(":/icons/toolbar_guidesigner.png"), tr("GUI Designer"));
    guiDesignerAction->setToolTip(tr("Create a visual CoderGirl 480x320 GUI design"));
    QAction *gameDesignerAction = toolBar->addAction(QIcon(":/icons/toolbar_gamedesigner.png"), tr("Game Designer"));
    gameDesignerAction->setToolTip(tr("Create a V1 game world, camera layout, and resource references"));
    QAction *optionsAction = toolBar->addAction(QIcon(":/icons/options.png"), tr("Options"));


    //QIcon findReplaceIcon = QIcon::fromTheme(QStringLiteral("edit-find-replace"));
    //if (findReplaceIcon.isNull()) {
        //findReplaceIcon = QIcon::fromTheme(QStringLiteral("edit-find"));
    //}

    QAction *findReplaceAction = toolBar->addAction(QIcon(":/icons/search_term.png"), tr("Find / Replace"));
    findReplaceAction->setShortcut(QKeySequence(QStringLiteral("Ctrl+Shift+F")));


    QAction *findCurrentWordAction = new QAction(tr("Find Current Word"), this);
    findCurrentWordAction->setShortcuts({
        QKeySequence(QStringLiteral("Ctrl+F")),
        QKeySequence(QStringLiteral("F3"))
    });
    addAction(findCurrentWordAction);

    toolBar->addSeparator();
    QAction *compileAction = toolBar->addAction(QIcon(":/icons/compile.png"), tr("Compile [F5]"));

    toolBar->addSeparator();
    QAction *apiCheatSheetAction = toolBar->addAction(QIcon(":/icons/toolbar_cheatsheet.png"), tr("Cheat Sheet [F8]"));
    apiCheatSheetAction->setShortcut(Qt::Key_F8);
    apiCheatSheetAction->setToolTip(tr("Open searchable SDK and Game Engine guides"));

    QAction *aboutIdeAction = toolBar->addAction(QIcon(":/icons/ide_icon_32x32.png"), tr("About IDE"));

    newAction->setShortcut(QKeySequence::New);
    openProjectAction->setShortcut(QKeySequence::Open);
    saveProjectAction->setShortcut(QKeySequence::Save);
    compileAction->setShortcut(Qt::Key_F5);

    //connect(newAction, &QAction::triggered, this, [toolBar, newAction, newMenu]() {
        //if (QWidget *button = toolBar->widgetForAction(newAction)) {
            //newMenu->popup(button->mapToGlobal(QPoint(0, button->height())));
        //}
    //});
    connect(newAction, &QAction::triggered, this, &MainWindow::createNewProject);
    //connect(newSourceAction, &QAction::triggered, this, &MainWindow::createNewSourceFile);
    //connect(newHeaderAction, &QAction::triggered, this, &MainWindow::createNewHeaderFile);
    connect(homeAction, &QAction::triggered, this, &MainWindow::showHomePage);
    connect(openProjectAction, &QAction::triggered, this, &MainWindow::openProject);
    connect(saveProjectAction, &QAction::triggered, this, &MainWindow::saveProject);
    connect(projectSettingsAction, &QAction::triggered, this, &MainWindow::showProjectSettings);
    connect(guiDesignerAction, &QAction::triggered, this, &MainWindow::createGuiDesigner);
    connect(gameDesignerAction, &QAction::triggered, this, &MainWindow::createGameDesigner);
    connect(optionsAction, &QAction::triggered, this, &MainWindow::showOptions);
    connect(aboutIdeAction, &QAction::triggered, this, &MainWindow::showAboutIde);
    connect(findReplaceAction, &QAction::triggered, this, &MainWindow::showFindReplace);
    connect(apiCheatSheetAction, &QAction::triggered,
            this, &MainWindow::showApiCheatSheet);
    connect(findCurrentWordAction, &QAction::triggered,
            this, &MainWindow::showFindReplaceForCurrentWord);
    connect(compileAction, &QAction::triggered, this, &MainWindow::compileActiveFile);

    /*
     * Put the infrequently used clean operation in Compile's drop-down.
     * Ordinary F5 / clicking Compile remains exactly as before. Cleaning is
     * V2-only and uses cgarm-build's narrow, validated cache-only --clean.
     */
    auto *compileMenu = new QMenu(this);
    QAction *cleanCgarmAction = compileMenu->addAction(
        tr("Clean Selected V2 Build Cache..."));
    QAction *exportLinuxBuildAction = compileMenu->addAction(
        tr("Export Linux Makefile + build.sh..."));
    if (auto *compileButton =
            qobject_cast<QToolButton *>(toolBar->widgetForAction(compileAction))) {
        compileButton->setMenu(compileMenu);
        compileButton->setPopupMode(QToolButton::MenuButtonPopup);
    }
    connect(exportLinuxBuildAction, &QAction::triggered, this, [this]() {
#ifndef Q_OS_LINUX
        QMessageBox::information(this, tr("Export Linux Build"),
            tr("Generate this Linux build script from the Linux IDE build."));
        return;
#endif
        if (m_projectFilePath.isEmpty()) {
            QMessageBox::information(this, tr("Export Linux Build"),
                tr("Save or open a project first."));
            return;
        }
        const bool isV2 = normalizedProjectType(m_projectType) == GuiProjectType
            && m_appletFormat == QStringLiteral("v2");
        if (!saveProject()) return;
        const QString projectDir = QFileInfo(m_projectFilePath).absolutePath();
        const QString makefile = QDir(projectDir).filePath(QStringLiteral("Makefile"));
        const QString script = QDir(projectDir).filePath(QStringLiteral("build.sh"));
        if ((QFileInfo::exists(makefile) || QFileInfo::exists(script))
            && QMessageBox::question(this, tr("Export Linux Build"),
                  tr("Replace existing Makefile/build.sh in this project?\n"
                     "This may overwrite build files you've edited yourself."),
                  QMessageBox::Yes | QMessageBox::Cancel,
                  QMessageBox::Cancel) != QMessageBox::Yes)
            return;
        const QString outputName = m_outputAppName.isEmpty()
            ? QFileInfo(m_projectFilePath).completeBaseName() + QStringLiteral(".app")
            : normalizedAppOutputName(m_outputAppName);
        QString error;
        bool exported = false;
        if (isV2) {
            exported = writeStandaloneLinuxBuildFiles(
                m_projectFilePath, ideLibsPath(), outputName,
                m_appSizeKb, m_v2HeapKb, m_v2StackKb, m_v2Linker, &error);
        } else {
            StandaloneV1Options options;
            options.projectFile = m_projectFilePath;
            options.sdkDirectory = ideLibsPath();
            options.linkerScript = effectiveLinkerScriptPath();
            options.outputAppName = outputName;
            options.sources = projectFilesForCompile();
            options.optimisation = m_compilerOptimization;
            options.extraFlags = m_extraCompilerFlags;
            options.suppressWarnings = m_compilerSuppressWarnings;
            options.wall = m_compilerWall;
            options.wextra = m_compilerWextra;
            options.functionSections = m_compilerFunctionSections;
            options.dataSections = m_compilerDataSections;
            options.stackUsage = m_compilerStackUsage;
            options.gaming = normalizedProjectType(m_projectType) == GameProjectType;
            exported = writeStandaloneV1LinuxBuildFiles(options, &error);
        }
        if (!exported) {
            QMessageBox::warning(this, tr("Export Linux Build"), error);
            return;
        }
        statusBar()->showMessage(tr("Exported %1 Makefile and build.sh")
                                 .arg(isV2 ? QStringLiteral("V2") : QStringLiteral("V1")), 5000);
        QMessageBox::information(this, tr("Export Linux Build"),
            tr("Created %2 Makefile and build.sh in:\n%1\n\n"
               "Run: ./build.sh\nOr: make\n\n"
               "Regenerate if the toolchain moves or project settings change. "
               "You can also override the SDK with SIDBOX_SDK=/path/to/idelibs.")
               .arg(QDir::toNativeSeparators(projectDir),
                    isV2 ? QStringLiteral("V2") : QStringLiteral("V1")));
    });
    connect(cleanCgarmAction, &QAction::triggered, this, [this]() {
        if (m_projectFilePath.isEmpty()) {
            QMessageBox::information(this, tr("Clean V2 Build"),
                                     tr("Open a project first."));
            return;
        }
        if (normalizedProjectType(m_projectType) != GuiProjectType
            || m_appletFormat != QStringLiteral("v2")) {
            QMessageBox::information(this, tr("Clean V2 Build"),
                tr("This command applies to GUI V2 projects only. "
                   "The V1 and Gaming build systems are unchanged."));
            return;
        }
        if (m_compilerProcess->state() != QProcess::NotRunning) {
            QMessageBox::information(this, tr("Clean V2 Build"),
                tr("Wait for the current build to finish before cleaning."));
            return;
        }

        // Match the linker selected in Project Settings > General. The
        // standalone builder defaults to LLVM unless --linker is explicit.
        // Keep clean behaviour consistent with the V2 F5 compile path.
        const QString selectedLinker = m_v2Linker == QStringLiteral("cgarm")
            ? QStringLiteral("cgarm") : QStringLiteral("llvm");
        const QString linkerLabel = selectedLinker == QStringLiteral("cgarm")
            ? tr("CGARM") : tr("LLVM");

        const QString baseName = QFileInfo(m_projectFilePath).completeBaseName();
        const QString appFileName = m_outputAppName.isEmpty()
            ? baseName + QStringLiteral(".app")
            : normalizedAppOutputName(m_outputAppName);
        const QString appPath = QDir(m_projectPath).filePath(appFileName);

        QString cacheStem = QFileInfo(appPath).completeBaseName();
        cacheStem.replace(QRegularExpression(QStringLiteral("[^A-Za-z0-9_-]")),
                          QStringLiteral("_"));
        if (cacheStem.isEmpty()) cacheStem = QStringLiteral("applet");
        const QString cachePath = QDir(m_projectPath).filePath(
            QStringLiteral("build/cgarm/") + cacheStem +
            (selectedLinker == QStringLiteral("cgarm")
                 ? QStringLiteral("-cgarm") : QString()));

        const auto answer = QMessageBox::question(this,
            tr("Clean V2 Build Cache"),
            tr("Remove this project's generated %1 V2 intermediate files?\n\n%2\n\n"
               "Your source files, GUI designs, and last working .app "
               "will be kept. The next F5 will recompile all sources "
               "for the selected linker.")
                .arg(linkerLabel, QDir::toNativeSeparators(cachePath)),
            QMessageBox::Yes | QMessageBox::Cancel, QMessageBox::Cancel);
        if (answer != QMessageBox::Yes) return;

#ifdef Q_OS_WIN
        const QString cliName = QStringLiteral("cgarm-build.exe");
#else
        const QString cliName = QStringLiteral("cgarm-build");
#endif
        const QString cli = QDir(ideLibsPath()).filePath(
            QStringLiteral("tools/bin/") + cliName);
        if (!QFileInfo(cli).isFile() || !QFileInfo(cli).isExecutable()) {
            QMessageBox::warning(this, tr("Clean V2 Build"),
                tr("Cannot find the CGARM builder:\n%1")
                    .arg(QDir::toNativeSeparators(cli)));
            return;
        }

        QProcess cleaner;
        cleaner.setWorkingDirectory(m_projectPath);
        cleaner.setProcessChannelMode(QProcess::MergedChannels);
        cleaner.start(cli, {m_projectFilePath,
                            QStringLiteral("-o"), appPath,
                            QStringLiteral("--linker"), selectedLinker,
                            QStringLiteral("--clean")});
        if (!cleaner.waitForStarted(3000)) {
            QMessageBox::warning(this, tr("Clean V2 Build"),
                tr("Could not launch cgarm-build:\n%1")
                    .arg(cleaner.errorString()));
            return;
        }
        if (!cleaner.waitForFinished(30000)) {
            cleaner.kill();
            cleaner.waitForFinished();
            QMessageBox::warning(this, tr("Clean V2 Build"),
                                 tr("Cleaning timed out."));
            return;
        }
        const QString report = QString::fromLocal8Bit(cleaner.readAll());
        appendOutputLine(tr("%1 V2 build cache clean:").arg(linkerLabel), OutputKind::Header);
        appendOutputText(report, cleaner.exitStatus() == QProcess::NormalExit
                                 && cleaner.exitCode() == 0
                             ? OutputKind::Success : OutputKind::Error);
        if (cleaner.exitStatus() != QProcess::NormalExit
            || cleaner.exitCode() != 0) {
            QMessageBox::warning(this, tr("Clean V2 Build"),
                tr("Cleaning failed. See the compiler output for details."));
            return;
        }
        statusBar()->showMessage(
            tr("%1 V2 build cache cleaned; next F5 rebuilds all sources.")
                .arg(linkerLabel), 8000);
    });

    auto *mainSplitter = new QSplitter(Qt::Horizontal, this);



    // --- Left Project Panel ---
    auto *projectPane = new QWidget(mainSplitter);
    projectPane->setMinimumWidth(300); // Prevents resizing the left panel smaller than 300px

    auto *projectLayout = new QVBoxLayout(projectPane);
    projectLayout->setContentsMargins(8, 8, 8, 8);
    projectLayout->setSpacing(6);

    auto *projectLabel = new QLabel(tr("Files in Project"), projectPane);

    auto *projectTree = new ProjectTreeWidget(projectPane);
    m_projectFiles = projectTree;
    m_projectFiles->setHeaderHidden(true);
    m_projectFiles->setRootIsDecorated(true);
    m_projectFiles->setItemsExpandable(true);
    m_projectFiles->setAnimated(false);

    projectTree->fileMoveRequested = [this](const QString &sourceFilePath, const QString &targetDirectory) {
        moveProjectFile(sourceFilePath, targetDirectory);
    };

    m_projectFiles->setStyleSheet(QStringLiteral(
        "QTreeWidget {"
        "   border: 1px solid #102048;"
        "   border-radius: 0px;"
        "}"
        "QTreeWidget::item {"
        "   border-radius: 0px;"
        "}"
        "QTreeWidget::item:selected {"
        "   background-color: #2858A8;"
        "   color: #ffffff;"
        "}"
        "QTreeWidget::item:selected:hover {"
        "   border: 1px solid #6C80AA;"
        "   background-color: #2858A8;"
        "}"
        ));

    m_projectFiles->setContextMenuPolicy(Qt::CustomContextMenu);
    auto *projectButtonLayout = new QHBoxLayout();
    projectButtonLayout->setContentsMargins(0, 0, 0, 0);
    projectButtonLayout->setSpacing(4);
    //auto *addFileButton = new QPushButton(tr("Add"), projectPane);
    //auto *createFileButton = new QPushButton(tr("Create"), projectPane);
    //auto *resourceFileButton = new QPushButton(tr("Add Res"), projectPane);
    //resourceFileButton->setToolTip(tr("Create a lightweight .res C resource file"));
    //auto *rescanFilesButton = new QPushButton(tr("Rescan"), projectPane);
    //rescanFilesButton->setToolTip(tr("Rescan the project directory for supported project files"));
    //auto *removeFileButton = new QPushButton(tr("Remove"), projectPane);
    //projectButtonLayout->addWidget(addFileButton);
    //projectButtonLayout->addWidget(createFileButton);
    //projectButtonLayout->addWidget(resourceFileButton);
    //projectButtonLayout->addWidget(rescanFilesButton);
    //projectButtonLayout->addWidget(removeFileButton);

    auto *renameFileAction = new QAction(tr("Rename"), m_projectFiles);
    renameFileAction->setShortcut(Qt::Key_F2);
    renameFileAction->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    m_projectFiles->addAction(renameFileAction);
    m_projectFiles->setAlternatingRowColors(true);
    projectLayout->addWidget(projectLabel);
    projectLayout->addLayout(projectButtonLayout);
    projectLayout->addWidget(m_projectFiles, 1);

    // A fixed-height programmer calculator beneath the file tree.
    // Never borrows space from the centre editor or the right-hand symbol tree.
    projectLayout->addWidget(new SidboxProgrammerCalculator(projectPane));

    connect(m_projectFiles, &QTreeWidget::itemDoubleClicked, this, &MainWindow::openProjectFile);
    connect(m_projectFiles, &QTreeWidget::itemActivated, this, &MainWindow::openProjectFile);
    //connect(addFileButton, &QPushButton::clicked, this, &MainWindow::addExistingProjectFile);
    //connect(createFileButton, &QPushButton::clicked, this, &MainWindow::createProjectFile);
    //connect(resourceFileButton, &QPushButton::clicked, this, &MainWindow::createResourceFile);
    //connect(rescanFilesButton, &QPushButton::clicked, this, &MainWindow::rescanProjectFiles);
    //connect(removeFileButton, &QPushButton::clicked, this, &MainWindow::removeSelectedProjectFile);
    connect(renameFileAction, &QAction::triggered, this, &MainWindow::renameSelectedProjectFile);
    connect(m_projectFiles, &QTreeWidget::customContextMenuRequested, this, [this](const QPoint &pos) {
        QTreeWidgetItem *item = m_projectFiles->itemAt(pos);

        if (item) {
            m_projectFiles->setCurrentItem(item);
        } else {
            m_projectFiles->clearSelection();
        }

        const QString targetDirectory = projectContextDirectory(item);

        QMenu menu(this);

        menu.addAction(tr("Create File"), this, [this, targetDirectory]() {
            createProjectFileInDirectory(targetDirectory);
        });

        menu.addAction(tr("Add Resource"), this, [this, targetDirectory]() {
            createResourceFileInDirectory(targetDirectory);
        });

        menu.addAction(tr("Create Folder"), this, [this, targetDirectory]() {
            createProjectFolderInDirectory(targetDirectory);
        });

        menu.addAction(tr("Create GUI Design"), this, &MainWindow::createGuiDesigner);
        menu.addAction(tr("Add File"), this, &MainWindow::addExistingProjectFile);
        menu.addAction(tr("Rescan Project Files"), this, &MainWindow::rescanProjectFiles);

        /*
         * Rename / Remove currently apply to files only.
         * Folder rename/delete can be added separately later.
         */
        QAction *renameAction = nullptr;
        QAction *removeAction = nullptr;
        QAction *historyAction = nullptr;
        QString historyTarget;
        if (item && !item->data(0, Qt::UserRole + 1).toBool()) {
            historyTarget = item->data(0, Qt::UserRole).toString();
            menu.addSeparator();
            if (isHistoryTextFile(historyTarget))
                historyAction = menu.addAction(tr("File History..."));
            renameAction = menu.addAction(tr("Rename"));
            removeAction = menu.addAction(tr("Remove"));
        }

        // Destructive operations rebuild the project tree. Execute them only
        // after QMenu::exec() returns, not from inside its QAction dispatcher.
        QAction *chosen = menu.exec(m_projectFiles->viewport()->mapToGlobal(pos));
        if (chosen && chosen == renameAction)
            renameSelectedProjectFile();
        else if (chosen && chosen == removeAction)
            removeSelectedProjectFile();
        else if (chosen && chosen == historyAction) {
            // Compare against the live editor buffer when this file is open;
            // otherwise use its last saved bytes from disk.
            QString currentContent;
            bool hasUnsavedEdits = false;
            bool foundOpenEditor = false;
            const QString absoluteHistoryPath = QFileInfo(historyTarget).absoluteFilePath();
            for (int tab = 0; tab < m_editorTabs->count(); ++tab) {
                auto *candidate = primaryEditorForTab(m_editorTabs->widget(tab));
                if (candidate && QFileInfo(candidate->filePath()).absoluteFilePath()
                                 == absoluteHistoryPath) {
                    currentContent = candidate->toPlainText();
                    hasUnsavedEdits = candidate->document()->isModified();
                    foundOpenEditor = true;
                    break;
                }
            }
            if (!foundOpenEditor) {
                QFile currentFile(historyTarget);
                if (!currentFile.open(QIODevice::ReadOnly)) {
                    QMessageBox::warning(this, tr("File History"),
                        tr("Cannot read current file: %1").arg(currentFile.errorString()));
                    return;
                }
                const QByteArray raw = currentFile.readAll();
                if (currentFile.error() != QFileDevice::NoError) {
                    QMessageBox::warning(this, tr("File History"),
                                         tr("Cannot read the current file completely."));
                    return;
                }
                currentContent = QString::fromUtf8(raw);
            }
            QString restored;
            if (!chooseFileHistoryRevision(this, m_projectPath, historyTarget,
                                           currentContent, hasUnsavedEdits, &restored))
                return;

            if (!openFile(historyTarget)) return;
            CodeEditor *editor = activeEditor();
            if (!editor || QFileInfo(editor->filePath()).absoluteFilePath()
                               != QFileInfo(historyTarget).absoluteFilePath())
                return;

            if (editor->document()->isModified()
                && QMessageBox::question(this, tr("Restore File History"),
                    tr("This editor contains unsaved changes. Replace its contents "
                       "with the chosen revision?\n\n"
                       "The current file on disk will NOT be overwritten until you Save."),
                    QMessageBox::Yes | QMessageBox::Cancel,
                    QMessageBox::Cancel) != QMessageBox::Yes)
                return;

            if (editor->toPlainText() == restored) {
                statusBar()->showMessage(tr("This revision already matches the editor."), 4000);
                return;
            }
            // One undoable document edit. The disk file is left alone until Save.
            QTextCursor cursor = editor->textCursor();
            cursor.beginEditBlock();
            cursor.select(QTextCursor::Document);
            cursor.insertText(restored);
            cursor.endEditBlock();
            editor->document()->setModified(true);
            updateTabTitle(editor);
            editor->setFocus();
            statusBar()->showMessage(tr("Older version loaded into editor. Save to keep it."), 7000);
        }
    });

    // --- Center Work Area ---
    auto *workAreaSplitter = new QSplitter(Qt::Vertical, mainSplitter);
    // The centre must absorb splitter width changes, rather than imposing
    // the widest editor tab's preferred size on the main window.
    workAreaSplitter->setMinimumWidth(0);
    workAreaSplitter->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Expanding);
    m_editorTabs = new QTabWidget(workAreaSplitter);
    // Tab pages retain their size hints even when hidden. Game/GUI Designer
    // controls must not enlarge the *top-level maximised window* when we
    // switch back to source code and restore the right-hand sidebar.
    m_editorTabs->setMinimumWidth(0);
    m_editorTabs->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Expanding);
    m_editorTabs->setDocumentMode(true);
    m_editorTabs->setTabsClosable(true);
    m_editorTabs->setMovable(true);
    m_editorTabs->setStyleSheet(R"(
        QTabWidget::pane {
            border: 1px solid #102048;
            border-radius: 0px;
        }
        QTabBar::tab {
            background: #1a1a2e;
            color: #c0c0c0;
            border: 1px solid #102048;
            border-bottom: none;
            border-radius: 0px;
            padding: 6px 12px;
            margin-right: -6px;
        }
        QTabBar::tab:selected {
            background: #2858A8;
            color: #ffffff;
            border-radius: 0px;
        }
        QTabBar::tab:hover:!selected {
            background: #2a2a4a;
            border-radius: 0px;
        }
        QTabBar::close-button {
                image: url(:/icons/close_tab.png);   /* optional – only if you have a custom icon */
                border-radius: 0px;
                subcontrol-position: right;
                subcontrol-origin: padding;
                width: 14px;
                height: 14px;
                background: transparent;
            }
            QTabBar::close-button:hover {
                background: #ff5555;
                border-radius: 0px;
            }
    )");

    m_editorTabs->tabBar()->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(
        m_editorTabs->tabBar(),
        &QTabBar::customContextMenuRequested,
        this,
        [this](const QPoint &pos) {
            const int index =
                m_editorTabs->tabBar()->tabAt(pos);

            if (index < 0) {
                return;
            }

            /*
             * Right-clicking a tab makes it the active tab before showing the
             * menu. This also makes "Close Others / Left / Right" unambiguous:
             * they operate relative to the tab the user actually clicked.
             */
            m_editorTabs->setCurrentIndex(index);

            QWidget *tabWidget =
                m_editorTabs->widget(index);

            CodeEditor *editor =
                primaryEditorForTab(tabWidget);

            QMenu menu(this);

            QAction *splitAction = nullptr;

            if (editor) {
                const int splitIndex =
                    editorSplitTabIndex();

                const bool thisIsSplit =
                    splitIndex == index;

                QString splitText;

                if (thisIsSplit) {
                    splitText = tr("Close Split");
                } else if (splitIndex >= 0) {
                    splitText =
                        tr("Open in Existing Split...");
                } else {
                    splitText =
                        tr("Split Editor Left / Right");
                }

                splitAction =
                    menu.addAction(splitText);

                menu.addSeparator();
            }

            QAction *closeAction =
                menu.addAction(tr("Close"));

            QAction *closeOthersAction =
                menu.addAction(tr("Close All Other Tabs"));

            QAction *closeLeftAction =
                menu.addAction(tr("Close Tabs to the Left"));

            QAction *closeRightAction =
                menu.addAction(tr("Close Tabs to the Right"));

            closeOthersAction->setEnabled(
                m_editorTabs->count() > 1);

            closeLeftAction->setEnabled(
                index > 0);

            closeRightAction->setEnabled(
                index < m_editorTabs->count() - 1);

            QAction *chosen =
                menu.exec(
                    m_editorTabs->tabBar()
                        ->mapToGlobal(pos));

            if (!chosen) {
                return;
            }

            if (splitAction
                && chosen == splitAction) {
                const int splitIndex =
                    editorSplitTabIndex();

                const bool thisIsSplit =
                    splitIndex == index;

                if (splitIndex >= 0
                    && !thisIsSplit) {
                    openCurrentTabInExistingSplit();
                } else {
                    toggleCurrentEditorSplit();
                }

                return;
            }

            if (chosen == closeAction) {
                closeEditorTab(index);
                return;
            }

            if (chosen == closeOthersAction) {
                /*
                 * Work from right to left so removing a tab never invalidates
                 * the indexes we still need to visit. If the user keeps an
                 * unsaved tab at its confirmation prompt, that one simply
                 * remains open while the others continue closing.
                 */
                for (int i = m_editorTabs->count() - 1;
                     i >= 0;
                     --i) {
                    if (i != index) {
                        closeEditorTab(i);
                    }
                }
                return;
            }

            if (chosen == closeLeftAction) {
                for (int i = index - 1;
                     i >= 0;
                     --i) {
                    closeEditorTab(i);
                }
                return;
            }

            if (chosen == closeRightAction) {
                for (int i = m_editorTabs->count() - 1;
                     i > index;
                     --i) {
                    closeEditorTab(i);
                }
            }
        });

    connect(
        m_editorTabs,
        &QTabWidget::tabCloseRequested,
        this,
        [this](int index) {
            closeEditorTab(index);
        });

    // --- Right Panel (Functions/Variables) ---
    auto *rightPane = new QWidget(mainSplitter);
    rightPane->setMinimumWidth(300);

    auto *rightLayout = new QVBoxLayout(rightPane);
    rightLayout->setContentsMargins(8, 8, 8, 8);
    rightLayout->setSpacing(6);

    auto *functionLabel = new QLabel(tr("Functions & Variables"), rightPane);
    m_functionvarList = new QTreeWidget(rightPane);
    m_functionvarList->setHeaderHidden(true);
    m_functionvarList->setRootIsDecorated(true);
    m_functionvarList->setItemsExpandable(true);
    m_functionvarList->setExpandsOnDoubleClick(false);
    m_functionvarList->setAnimated(false);
    m_functionvarList->setStyleSheet(QStringLiteral(
        "QTreeWidget {"
        "   border: 1px solid #102048;"
        "   border-radius: 0px;"
        "}"
        "QTreeWidget::item {"
        "   border-radius: 0px;"
        "}"
        "QTreeWidget::item:selected {"
        "   background-color: #2858A8;"
        "   color: #ffffff;"
        "}"
        "QTreeWidget::item:selected:hover {"
        "   border: 1px solid #6C80AA;"
        "   background-color: #2858A8;"
        "}"
        ));

    connect(m_editorTabs, &QTabWidget::currentChanged, this, [this](int) {
        updateCursorPositionStatus();

        if (m_projectAnalysisTimer) {
            m_projectAnalysisTimer->stop();
        }

        /*
         * Changing tabs is an explicit navigation action. Let the tab paint,
         * then catch up any deferred state for the newly active source.
         */
        QTimer::singleShot(0, this, [this]() {
            CodeEditor *editor = activeEditor();

            if (editor) {
                if (editor->property("sidboxNavigatorDirty").toBool())
                    refreshEventNavigator(editor);
                editor->syncDeferredEditorStateNow();
                refreshActiveEditorAnalysis();
            } else if (m_functionvarList) {
                m_functionvarList->clear();
                if (dynamic_cast<SidboxGuiDesigner *>(m_editorTabs->currentWidget())
                    || dynamic_cast<SidboxGameDesigner *>(m_editorTabs->currentWidget())) {
                    auto *item = new QTreeWidgetItem(m_functionvarList);
                    item->setText(0, dynamic_cast<SidboxGameDesigner *>(m_editorTabs->currentWidget())
                        ? tr("Game Designer — V1 game world and resources")
                        : tr("GUI Designer — visual CoderGirl layout"));
                    item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
                }
            }
        });
    });
    connect(m_functionvarList, &QTreeWidget::itemDoubleClicked,
            this, &MainWindow::jumpToSymbol);

    rightLayout->addWidget(functionLabel);
    rightLayout->addWidget(m_functionvarList, 1);

    // --- Bottom Output Panel ---
    auto *outputPanel = new QWidget(workAreaSplitter);
    auto *outputLayout = new QVBoxLayout(outputPanel);
    outputLayout->setContentsMargins(0, 0, 0, 0);
    outputLayout->setSpacing(0);

    m_quickTipLabel = new QLabel(tr("F1: quick API tip"), outputPanel);
    m_quickTipLabel->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    m_quickTipLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    m_quickTipLabel->setStyleSheet(QStringLiteral(
        "QLabel { background: #020402; color: #66ff8a; border-top: 1px solid #15351a; "
        "border-bottom: 1px solid #15351a; padding: 3px 6px; }"));

    m_outputToolBar = new QToolBar(tr("Compiler Output"), outputPanel);
    m_outputToolBar->setMovable(false);
    QAction *clearOutputAction = m_outputToolBar->addAction(tr("Clear"));
    connect(clearOutputAction, &QAction::triggered, this, [this]() {
        m_outputPane->clear();
    });

    m_outputPane = new CompilerOutputPane(outputPanel);
    m_outputPane->setReadOnly(true);
    m_outputPane->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
    m_outputPane->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    m_outputPane->setStyleSheet(QStringLiteral(
        "QPlainTextEdit { background: #000000; color: #d8e8d0; "
        "selection-background-color: #265c32; selection-color: #ffffff; }"));
    m_outputPane->setAcceptDrops(false);
    m_outputPane->viewport()->setAcceptDrops(false);
    m_outputPane->setPlaceholderText(tr("Compiler output"));
    m_outputPane->setMaximumBlockCount(1000);

    // Double-click a GCC/Clang-style diagnostic to open its exact source
    // location. Normal clicks, text selection and copying work as before.
    // Resolve full/relative paths first; a bare filename is clickable only
    // when it uniquely identifies a project file (e.g. NOT bitmapview.c
    // when two generated resource folders contain files with that name).
    static_cast<CompilerOutputPane *>(m_outputPane)->setDiagnosticHandler(
        [this](const QString &outputLine, bool activate) -> bool {
            static const QRegularExpression diagnosticLine(
                QStringLiteral(
                    R"(^\s*(.+?):([1-9]\d*)(?::([1-9]\d*))?:\s*(?:fatal error|error|warning|note):)"),
                QRegularExpression::CaseInsensitiveOption);

            const QRegularExpressionMatch match = diagnosticLine.match(outputLine);
            if (!match.hasMatch()) {
                return false;
            }

            QString reportedPath = match.captured(1).trimmed();
            if (reportedPath.size() >= 2
                && ((reportedPath.front() == QLatin1Char('"')
                     && reportedPath.back() == QLatin1Char('"'))
                    || (reportedPath.front() == QLatin1Char('\'')
                        && reportedPath.back() == QLatin1Char('\'')))) {
                reportedPath = reportedPath.mid(1, reportedPath.size() - 2);
            }
            reportedPath = QDir::fromNativeSeparators(reportedPath);

            bool validLine = false;
            const int lineNumber = match.captured(2).toInt(&validLine);
            if (!validLine || lineNumber <= 0 || reportedPath.isEmpty()) {
                return false;
            }

            const int columnNumber = match.captured(3).toInt();
            const bool isBareName = !reportedPath.contains(QLatin1Char('/'))
                && !QFileInfo(reportedPath).isAbsolute();

            QString resolvedPath;
            if (!isBareName) {
                const QString normalized = normalizedDiagnosticPath(reportedPath);
                if (QFileInfo(normalized).isFile()) {
                    resolvedPath = normalized;
                } else if (!QFileInfo(reportedPath).isAbsolute()) {
                    const QString sdkPath =
                        QDir(ideLibsPath()).filePath(reportedPath);
                    if (QFileInfo(sdkPath).isFile()) {
                        resolvedPath = QFileInfo(sdkPath).absoluteFilePath();
                    }
                }
            } else {
                // Never guess which of two same-named generated C files GCC
                // intended. Require an unambiguous match from the project.
                QStringList candidates = m_projectFilesInProject;
                candidates.append(projectFolderSourceFiles());
                if (m_editorTabs) {
                    for (int tab = 0; tab < m_editorTabs->count(); ++tab) {
                        CodeEditor *editor =
                            primaryEditorForTab(m_editorTabs->widget(tab));
                        if (editor && !editor->filePath().isEmpty()) {
                            candidates.append(editor->filePath());
                        }
                    }
                }

                QSet<QString> matches;
                for (const QString &candidate : std::as_const(candidates)) {
                    const QFileInfo info(candidate);
                    if (info.isFile() && info.fileName() == reportedPath) {
                        matches.insert(info.absoluteFilePath());
                    }
                }
                if (matches.size() == 1) {
                    resolvedPath = *matches.cbegin();
                } else if (matches.isEmpty()) {
                    const QString normalized = normalizedDiagnosticPath(reportedPath);
                    if (QFileInfo(normalized).isFile()) {
                        resolvedPath = normalized;
                    }
                }
            }

            if (resolvedPath.isEmpty()) {
                return false;
            }
            if (!activate) {
                return true; // Show pointing-hand cursor on navigable lines.
            }

            const QString sdkRoot = QFileInfo(ideLibsPath()).absoluteFilePath();
            const QString relativeToSdk =
                QDir(sdkRoot).relativeFilePath(resolvedPath);
            const bool isSdkFile = relativeToSdk != QStringLiteral("..")
                && !relativeToSdk.startsWith(QStringLiteral("../"))
                && !QDir::isAbsolutePath(relativeToSdk);

            if (isSdkFile) {
                // SDK files are references, not project sources: open them
                // read-only and never accidentally add them to the project.
                if (!openApiReference(resolvedPath, lineNumber - 1)) {
                    return false;
                }
                CodeEditor *editor = activeEditor();
                if (editor && columnNumber > 0) {
                    const QTextBlock block =
                        editor->document()->findBlockByNumber(lineNumber - 1);
                    if (block.isValid()) {
                        QTextCursor cursor(block);
                        cursor.setPosition(block.position()
                            + qMin(columnNumber - 1, block.length() - 1));
                        editor->setTextCursor(cursor);
                        editor->centerCursor();
                    }
                }
            } else {
                ProjectSearchResult location;
                location.filePath = resolvedPath;
                location.line = lineNumber - 1;
                location.column = qMax(0, columnNumber - 1);
                jumpToProjectSearchResult(location);
            }
            return true;
        });

    outputLayout->addWidget(m_quickTipLabel);
    outputLayout->addWidget(m_outputToolBar);
    auto *outputSplit = new QSplitter(Qt::Horizontal, outputPanel);
    outputSplit->setObjectName(QStringLiteral("sidboxOutputMemorySplitter"));
    outputSplit->setChildrenCollapsible(false);
    outputSplit->addWidget(m_outputPane);
    // Scrolling keeps all bars readable even if the compiler output is short.
    auto *memoryDock = new QScrollArea(outputSplit);
    memoryDock->setObjectName(QStringLiteral("sidboxMemoryDock"));
    memoryDock->setFrameShape(QFrame::NoFrame);
    memoryDock->setWidgetResizable(true);
    memoryDock->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    memoryDock->setMinimumWidth(240);
    memoryDock->setMaximumWidth(350);
    memoryDock->setWidget(makeAppletMemoryPanel(memoryDock));
    outputSplit->addWidget(memoryDock);
    outputSplit->setStretchFactor(0, 5);
    outputSplit->setStretchFactor(1, 0);
    outputSplit->setSizes({800, 255});
    // Persist the actual log/memory split (not a hard-coded pixel offset).
    // Debounce saving while the user drags the handle; also save on close.
    auto *outputSplitSaveTimer = new QTimer(outputSplit);
    outputSplitSaveTimer->setSingleShot(true);
    outputSplitSaveTimer->setInterval(250);
    connect(outputSplit, &QSplitter::splitterMoved,
            outputSplitSaveTimer, [outputSplitSaveTimer](int, int) {
        outputSplitSaveTimer->start();
    });
    connect(outputSplitSaveTimer, &QTimer::timeout,
            outputSplit, [outputSplit]() {
        QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
        settings.setValue(QStringLiteral("layout/outputMemorySplitter"),
                          outputSplit->saveState());
    });
    outputLayout->addWidget(outputSplit, 1);
    updateAppletMemoryPanel(this, false, m_appSizeKb, m_v2StackKb, m_v2HeapKb);

    workAreaSplitter->addWidget(m_editorTabs);
    workAreaSplitter->addWidget(outputPanel);
    workAreaSplitter->setStretchFactor(0, 6);
    workAreaSplitter->setStretchFactor(1, 1);
    workAreaSplitter->setCollapsible(0, false);
    workAreaSplitter->setCollapsible(1, true);

    /*
     * Start with the editor occupying most of the work area. The output pane
     * remains freely resizable afterwards, but it no longer eats most of the
     * screen on launch.
     */
    workAreaSplitter->setSizes({850, 220});

    // Assembly of main horizontal splitter
    mainSplitter->addWidget(projectPane);
    mainSplitter->addWidget(workAreaSplitter);
    mainSplitter->addWidget(rightPane);

    mainSplitter->setStretchFactor(0, 1);
    mainSplitter->setStretchFactor(1, 5);
    mainSplitter->setStretchFactor(2, 1);
    mainSplitter->setSizes({300, 1200, 300});
    mainSplitter->setObjectName(QStringLiteral("mainThreePaneSplitter"));

    // Remember widths rather than restoring the complete splitter state. A
    // hidden right pane must never change the project tree's chosen width.
    QSettings paneSettings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
    const int projectWidth = qMax(80, paneSettings.value(
        QStringLiteral("layout/projectTreeWidth"), 300).toInt());
    const int editorRightWidth = qMax(80, paneSettings.value(
        QStringLiteral("layout/editorRightWidth"), 300).toInt());
    mainSplitter->setProperty("projectTreeWidth", projectWidth);
    mainSplitter->setProperty("editorRightWidth", editorRightWidth);
    mainSplitter->setProperty("switchingTabs", false);
    mainSplitter->setStretchFactor(0, 0);
    mainSplitter->setStretchFactor(1, 1);
    mainSplitter->setStretchFactor(2, 0);
    mainSplitter->setSizes({projectWidth, 1200, editorRightWidth});

    // One fixed-by-tab-switch project width; the user can still drag its handle.
    // In designer mode the right pane disappears and the editor fills that space.
    // In code mode the previously chosen right-pane width is restored.
    connect(m_editorTabs, &QTabWidget::currentChanged, this,
            [this, mainSplitter, rightPane](int) {
        const bool designing = dynamic_cast<SidboxGuiDesigner *>(
            m_editorTabs->currentWidget()) != nullptr
            || dynamic_cast<SidboxGameDesigner *>(m_editorTabs->currentWidget()) != nullptr;
        const int left = mainSplitter->property("projectTreeWidth").toInt();
        const int right = mainSplitter->property("editorRightWidth").toInt();
        mainSplitter->setProperty("switchingTabs", true);
        if (designing) rightPane->hide();
        else rightPane->show();
        const int total = qMax(1, mainSplitter->width());
        if (designing) mainSplitter->setSizes({left, qMax(1, total - left), 0});
        else mainSplitter->setSizes({left, qMax(1, total - left - right), right});
        // Defer until Qt has processed the show/hide layout update.
        QTimer::singleShot(0, mainSplitter, [mainSplitter, rightPane]() {
            const int left = mainSplitter->property("projectTreeWidth").toInt();
            const int right = mainSplitter->property("editorRightWidth").toInt();
            const int total = qMax(1, mainSplitter->width());
            if (rightPane->isHidden())
                mainSplitter->setSizes({left, qMax(1, total - left), 0});
            else
                mainSplitter->setSizes({left, qMax(1, total - left - right), right});
            mainSplitter->setProperty("switchingTabs", false);
        });
    });
    connect(mainSplitter, &QSplitter::splitterMoved, this,
            [mainSplitter, rightPane](int, int) {
        if (mainSplitter->property("switchingTabs").toBool()) return;
        const QList<int> widths = mainSplitter->sizes();
        if (widths.size() != 3) return;
        if (widths[0] >= 80)
            mainSplitter->setProperty("projectTreeWidth", widths[0]);
        if (!rightPane->isHidden() && widths[2] >= 80)
            mainSplitter->setProperty("editorRightWidth", widths[2]);
    });

    // The main window launches maximised. Apply the stored widths after its
    // final geometry has been calculated instead of relying on initial sizes.
    QTimer::singleShot(0, mainSplitter, [mainSplitter, rightPane]() {
        const int left = mainSplitter->property("projectTreeWidth").toInt();
        const int right = mainSplitter->property("editorRightWidth").toInt();
        const int total = qMax(1, mainSplitter->width());
        if (rightPane->isHidden())
            mainSplitter->setSizes({left, qMax(1, total - left), 0});
        else
            mainSplitter->setSizes({left, qMax(1, total - left - right), right});
    });

    setCentralWidget(mainSplitter);
    applyTheme();
    // Restoring before the maximised window has been laid out can produce
    // incorrect splitter proportions, so wait until its first event loop pass.
    QTimer::singleShot(0, outputSplit, [outputSplit, outputSplitSaveTimer]() {
        QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
        const QByteArray state = settings.value(
            QStringLiteral("layout/outputMemorySplitter")).toByteArray();
        if (!state.isEmpty()) {
            QSignalBlocker blocker(outputSplit);
            outputSplitSaveTimer->stop();
            outputSplit->restoreState(state);
        }
    });

    m_compileProgressBar = new QProgressBar(statusBar());
    m_compileProgressBar->setObjectName(QStringLiteral("compileProgress"));
    m_compileProgressBar->setRange(0, 0);
    m_compileProgressBar->setTextVisible(true);
    m_compileProgressBar->setFormat(tr("Compiling..."));
    m_compileProgressBar->setFixedWidth(190);
    m_compileProgressBar->setFixedHeight(16);
    m_compileProgressBar->hide();
    statusBar()->addPermanentWidget(m_compileProgressBar);

    m_cursorPositionLabel = new QLabel(statusBar());
    m_cursorPositionLabel->setObjectName(QStringLiteral("cursorPositionStatus"));
    m_cursorPositionLabel->setMinimumWidth(120);
    m_cursorPositionLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    statusBar()->addPermanentWidget(m_cursorPositionLabel);

    updateCursorPositionStatus();
    statusBar()->showMessage(tr("Ready"));
}

void MainWindow::createNewProject()
{
    if (!saveModifiedWorkBeforeNewProject()) {
        statusBar()->showMessage(tr("New project cancelled"));
        return;
    }

    QString projectFilePath = QFileDialog::getSaveFileName(
        this,
        tr("New Project"),
        QDir::home().filePath(QStringLiteral("project.proj")),
        tr("Sidbox projects (*.proj);;All files (*)"));

    if (projectFilePath.isEmpty()) {
        statusBar()->showMessage(tr("New project cancelled"));
        return;
    }

    if (QFileInfo(projectFilePath).suffix().isEmpty()) {
        projectFilePath.append(QStringLiteral(".proj"));
    }

    QMessageBox typeBox(this);
    typeBox.setWindowTitle(tr("Project Type"));
    typeBox.setText(tr("What type of Sidbox project is this?"));
    QPushButton *guiButton = typeBox.addButton(tr("GUI"), QMessageBox::AcceptRole);
    QPushButton *gameButton = typeBox.addButton(tr("Game"), QMessageBox::AcceptRole);
    typeBox.addButton(QMessageBox::Cancel);

    if (typeBox.exec() == QMessageBox::Cancel || !typeBox.clickedButton()) {
        statusBar()->showMessage(tr("New project cancelled"));
        return;
    }

    m_projectType =
        typeBox.clickedButton() == static_cast<QAbstractButton *>(gameButton)
            ? GameProjectType
            : GuiProjectType;

    Q_UNUSED(guiButton);

    m_modSizeKb = 0;
    m_appSizeKb = 128;
    m_appletFormat = QStringLiteral("v1");
    m_v2Linker = QStringLiteral("llvm");
    m_v2HeapKb = 16;
    m_v2StackKb = 8;
    m_outputAppName.clear();
    m_linkerScriptPath.clear();

    m_compilerOptimization = QStringLiteral("-Ofast");
    m_compilerSuppressWarnings = true;
    m_compilerWall = false;
    m_compilerWextra = false;
    m_compilerFunctionSections = true;
    m_compilerDataSections = true;
    m_compilerStackUsage = true;
    m_extraCompilerFlags.clear();

    m_projectFilePath = QFileInfo(projectFilePath).absoluteFilePath();
    m_projectPath = QFileInfo(m_projectFilePath).absolutePath();
    m_projectFilesInProject.clear();
    updateAppletMemoryPanel(this, false, m_appSizeKb, m_v2StackKb, m_v2HeapKb);

    if (!QDir().mkpath(m_projectPath)) {
        QMessageBox::warning(
            this,
            tr("New Project"),
            tr("Could not create the project directory:\n%1")
                .arg(QDir::toNativeSeparators(m_projectPath)));
        return;
    }

    const QString mainCPath =
        QFileInfo(QDir(m_projectPath).filePath(QStringLiteral("main.c")))
            .absoluteFilePath();

    const QString mainHPath =
        QFileInfo(QDir(m_projectPath).filePath(QStringLiteral("main.h")))
            .absoluteFilePath();

    const QDateTime now = QDateTime::currentDateTime();
    const QString dateStr = now.toString(QStringLiteral("MMM dd yyyy"));
    const QString timeStr = now.toString(QStringLiteral("hh:mm:ss"));

    QByteArray mainCContents =
        QString(
            "/*\n"
            "   Created file: %1 %2\n"
            "*/\n"
            "#include <stdint.h>\n"
            "#include <stdlib.h>\n\n"
            "#include \"apis.h\"\n"
            "#include \"main.h\"\n\n"
            "int main(void)\n"
            "{\n"
            "    printf(\"Hello world\");\n"
            "    return 0;\n"
            "}\n")
            .arg(timeStr, dateStr)
            .toUtf8();

    // Stage 52: Gaming is V1, and its starter must have the actual graphics
    // setup/game loop. Never overwrite a game project with GUI Hello World.
    if (m_projectType == GameProjectType) {
        QFile templateFile(QDir(ideLibsPath()).filePath(QStringLiteral("templates/games/main.c")));
        if (!templateFile.open(QIODevice::ReadOnly)) {
            QMessageBox::warning(this, tr("New Game Project"),
                tr("Cannot read the bundled V1 gaming starter:\n%1\n\n"
                   "No project files were overwritten.").arg(templateFile.fileName()));
            return;
        }
        mainCContents = GamerGirlMainOwnership::withOwnerHeader(templateFile.readAll());
    }

    const QByteArray mainHContents =
        QString(
            "/*\n"
            "   Created Header file: %1 %2\n"
            "*/\n"
            "#ifndef MAIN_H\n"
            "#define MAIN_H\n\n"
            "\n"
            "#endif // MAIN_H\n")
            .arg(timeStr, dateStr)
            .toUtf8();

    auto writeDefaultFile =
        [this](const QString &path,
               const QByteArray &contents,
               const QString &displayName) -> bool {
            if (QFileInfo::exists(path)) {
                const QMessageBox::StandardButton answer =
                    QMessageBox::warning(
                        this,
                        tr("New Project"),
                        tr("%1 already exists in the selected project directory.\n\n"
                           "Overwrite it with the Sidbox default file?")
                            .arg(displayName),
                        QMessageBox::Yes | QMessageBox::No,
                        QMessageBox::No);

                if (answer != QMessageBox::Yes) {
                    return false;
                }
            }

            QFile file(path);
            if (!file.open(
                    QIODevice::WriteOnly
                    | QIODevice::Text
                    | QIODevice::Truncate)) {
                QMessageBox::warning(
                    this,
                    tr("New Project"),
                    tr("Could not create %1:\n%2")
                        .arg(displayName, QDir::toNativeSeparators(path)));
                return false;
            }

            if (file.write(contents) != contents.size()) {
                file.close();
                QMessageBox::warning(
                    this,
                    tr("New Project"),
                    tr("Could not write the complete %1 file.")
                        .arg(displayName));
                return false;
            }

            file.close();
            return true;
        };

    if (!writeDefaultFile(mainCPath, mainCContents, QStringLiteral("main.c"))
        || !writeDefaultFile(mainHPath, mainHContents, QStringLiteral("main.h"))) {
        statusBar()->showMessage(tr("New project creation cancelled"), 3000);
        return;
    }

    if (m_projectType == GameProjectType) {
        QString ownershipError;
        if (!GamerGirlMainOwnership::storeRecord(m_projectPath, QStringLiteral("IDE"),
                                                 mainCContents, &ownershipError)) {
            // Main.c is still safe: without a valid record no overwrite is allowed.
            QMessageBox::warning(this, tr("Game main.c ownership"),
                tr("Game project was created, but automatic main.c regeneration "
                   "is disabled because its ownership record could not be saved:\n%1")
                    .arg(ownershipError));
        }
    }

    clearEditorTabs();

    addProjectFile(mainCPath);
    addProjectFile(mainHPath);

    refreshProjectFiles();

    openFile(mainCPath);
    openFile(mainHPath);

    saveProjectFile(m_projectFilePath);

    AutoSelectMainC();

    statusBar()->showMessage(
        tr("New %1 project created: %2")
            .arg(projectTypeLabel(m_projectType),
                 QDir::toNativeSeparators(m_projectFilePath)),
        4000);
}


void MainWindow::createNewSourceFile()
{
    CodeEditor *editor = createEditor();

    const QDateTime now = QDateTime::currentDateTime();
    const QString dateStr = now.toString(QStringLiteral("MMM dd yyyy"));
    const QString timeStr = now.toString(QStringLiteral("hh:mm:ss"));

    editor->setPlainText(QString(
                             "/*\n"
                             "   Created file: %1 %2\n"
                             "*/\n"
                             "#include <stdint.h>\n"
                             "#include <stdlib.h>\n\n"
                             "#include \"apis.h\"\n\n"
                             "int main(void)\n"
                             "{\n"
                             "    printf(\"Hello world\");\n"
                             "    return 0;\n"
                             "}\n").arg(timeStr, dateStr));

    editor->document()->setModified(false);

    const int index = m_editorTabs->addTab(
        editor,
        editorTabIconForFile(editor->filePath(), 0),
        tabTitleForEditor(editor, 0));
    m_editorTabs->setCurrentIndex(index);
    m_projectAnalysisTimer->start();
    statusBar()->showMessage(tr("New C source file created"));
}

void MainWindow::createNewHeaderFile(){
    CodeEditor *editor = createEditor();

    const QDateTime now = QDateTime::currentDateTime();
    const QString dateStr = now.toString(QStringLiteral("MMM dd yyyy"));
    const QString timeStr = now.toString(QStringLiteral("hh:mm:ss"));

    editor->setPlainText(QString(
                             "/*\n"
                             "   Created Header file: %1 %2\n"
                             "*/\n"
                             "\n").arg(timeStr, dateStr));

    editor->document()->setModified(false);

    const int index = m_editorTabs->addTab(
        editor,
        editorTabIconForFile(editor->filePath(), 1),
        tabTitleForEditor(editor, 1));
    m_editorTabs->setCurrentIndex(index);
    m_projectAnalysisTimer->start();
    statusBar()->showMessage(tr("New H header file created"));
}


void MainWindow::createGameDesigner()
{
    if (m_projectPath.isEmpty() || m_projectFilePath.isEmpty()) {
        QMessageBox::information(this, tr("Game Designer"),
            tr("Create or open a V1 Game project first."));
        return;
    }
    if (normalizedProjectType(m_projectType) != GameProjectType) {
        QMessageBox::information(this, tr("Game Designer"),
            tr("Game Designer is available for V1 Game projects.\n"
               "GUI and CGARM V2 projects still use GUI Designer."));
        return;
    }
    bool accepted = false;
    QString name = QInputDialog::getText(this, tr("New Game Design"), tr("Design name:"),
                                         QLineEdit::Normal, QStringLiteral("gameworld"),
                                         &accepted).trimmed();
    if (!accepted || name.isEmpty()) return;
    // A design name is one filename in the project root, never a path.
    if (name.contains(QLatin1Char('/')) || name.contains(QLatin1Char('\\'))
        || name == QStringLiteral(".") || name == QStringLiteral("..")) {
        QMessageBox::warning(this, tr("Game Designer"), tr("Enter a filename without slashes."));
        return;
    }
    name = QFileInfo(name).completeBaseName();
    if (name.isEmpty()) return;
    const QString path = QDir(m_projectPath).filePath(name + QStringLiteral(".sbgm"));
    if (QFileInfo::exists(path)) {
        QMessageBox::information(this, tr("Game Designer"),
            tr("That design already exists. Open it from the project tree instead."));
        return;
    }
    if (openGameDesigner(path)) {
        auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->currentWidget());
        if (game && game->saveDesign()) {
            addProjectFile(path);
            refreshProjectFiles();
            saveProjectFile(m_projectFilePath);
        }
    }
}

bool MainWindow::openGameDesigner(const QString &filePath)
{
    const QString absolute = QFileInfo(filePath).absoluteFilePath();
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->widget(i))) {
            if (QFileInfo(game->filePath()).absoluteFilePath() == absolute) {
                m_editorTabs->setCurrentIndex(i);
                return true;
            }
        }
    }
    auto *game = new SidboxGameDesigner(absolute, m_editorTabs);
    game->setTheme(m_theme);
    if (!game->isValid()) { delete game; return false; }
    int index = m_editorTabs->addTab(game,
        QIcon(QStringLiteral(":/icons/toolbar_gamedesigner.png")), game->displayName());
    m_editorTabs->setTabToolTip(index, tr("V1 Game design\n%1").arg(QDir::toNativeSeparators(absolute)));
    game->tabTitleChanged = [this, game]() {
        const int i = m_editorTabs->indexOf(game);
        if (i >= 0) m_editorTabs->setTabText(i, game->displayName());
    };
    // New PNG/PPB/audio assets need only a file-tree refresh. A full Rescan
    // reparses all C functions and is unnecessary for binary resource imports.
    game->assetFilesChanged = [this]() { refreshProjectFiles(); };
    game->mainSourceHasUnsavedEdits = [this](const QString &mainPath) {
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            CodeEditor *open = primaryEditorForTab(m_editorTabs->widget(i));
            if (open && QFileInfo(open->filePath()).absoluteFilePath() ==
                    QFileInfo(mainPath).absoluteFilePath() && open->document()->isModified())
                return true;
        }
        return false;
    };
    addProjectFile(absolute);
    m_editorTabs->setCurrentIndex(index);
    game->setFocus();
    return true;
}

void MainWindow::createGuiDesigner()
{
    if (m_projectPath.isEmpty()) {
        QMessageBox::information(
            this,
            tr("GUI Designer"),
            tr("Save or open a project first so the .sbui design and generated .c file have a project folder."));
        return;
    }

    bool accepted = false;
    QString baseName = QInputDialog::getText(
        this,
        tr("New CoderGirl GUI"),
        tr("Design name:"),
        QLineEdit::Normal,
        QStringLiteral("mainwindow"),
        &accepted).trimmed();

    if (!accepted || baseName.isEmpty()) {
        return;
    }

    baseName = QFileInfo(baseName).completeBaseName();
    QString filePath = QDir(m_projectPath).filePath(baseName + QStringLiteral(".sbui"));
    if (QFileInfo::exists(filePath)) {
        QMessageBox::warning(this, tr("GUI Designer"), tr("%1 already exists.").arg(QDir::toNativeSeparators(filePath)));
        return;
    }

    if (!openGuiDesigner(filePath)) {
        return;
    }

    if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(m_editorTabs->currentWidget())) {
        if (designer->saveDesignAndGenerate()) {
            addProjectFile(filePath);
            addProjectFile(QFileInfo(filePath).dir().filePath(QFileInfo(filePath).completeBaseName() + QStringLiteral(".c")));
            refreshProjectFiles();
            if (!m_projectFilePath.isEmpty()) saveProjectFile(m_projectFilePath);
        }
    }
}

bool MainWindow::openGuiDesigner(const QString &filePath)
{
    const QString absolutePath = QFileInfo(filePath).absoluteFilePath();
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(m_editorTabs->widget(i))) {
            if (QFileInfo(designer->filePath()).absoluteFilePath() == absolutePath) {
                m_editorTabs->setCurrentIndex(i);
                return true;
            }
        }
    }

    // Available during the designer constructor, including initial properties.
    m_editorTabs->setProperty("sidboxProjectRoot", m_projectPath);
    auto *designer = createSidboxGuiDesigner(absolutePath, m_editorTabs);
    // Let the designer discover every .sbui in the project, including subfolders.
    designer->setProperty("sidboxProjectRoot", m_projectPath);
    const int index = m_editorTabs->addTab(designer, QIcon(QStringLiteral(":/icons/toolbar_guidesigner.png")), designer->displayName());
    m_editorTabs->setTabToolTip(index, tr("CoderGirl visual design\n%1").arg(QDir::toNativeSeparators(absolutePath)));

    designer->tabTitleChanged = [this, designer]() {
        const int index = m_editorTabs->indexOf(designer);
        if (index >= 0) m_editorTabs->setTabText(index, designer->displayName());
    };
    designer->beforeGenerate = [this](const QString &cPath) {
        const QString absoluteCPath = QFileInfo(cPath).absoluteFilePath();
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            CodeEditor *editor = primaryEditorForTab(m_editorTabs->widget(i));
            if (!editor || editor->filePath().isEmpty()) {
                continue;
            }
            if (QFileInfo(editor->filePath()).absoluteFilePath() == absoluteCPath
                && editor->document()->isModified()) {
                return saveEditor(editor);
            }
        }
        return true;
    };

    designer->generatedFilesChanged = [this](const QString &designPath, const QString &cPath) {
        addProjectFile(designPath);
        addProjectFile(cPath);
        // Generated .c windows now come with a matching public .h file.
        // Register it as a project source/header for browsing and completion,
        // but never accidentally register a programmer-owned header or a
        // binary-resource .c file that merely shares the same filename.
        const QFileInfo generatedInfo(cPath);
        if (generatedInfo.suffix().compare(QStringLiteral("c"), Qt::CaseInsensitive) == 0) {
            const QString headerPath = generatedInfo.dir().filePath(
                generatedInfo.completeBaseName() + QStringLiteral(".h"));
            QFile header(headerPath);
            if (header.open(QIODevice::ReadOnly)
                && header.read(48).startsWith("/* SIDBOX-IDE GENERATED GUI HEADER: ")) {
                addProjectFile(headerPath);
            }
        }
        refreshProjectFiles();

        /*
         * The Designer has just committed the regenerated file. If its source
         * is already open, refresh that editor now; waiting for an external
         * QFileSystemWatcher event isn't reliable (and the event navigator
         * otherwise continues to display the previous generated callbacks).
         *
         * Never discard unsaved programmer edits: beforeGenerate normally
         * saved the .c file first, but keep this guard for other resources.
         */
        const QString generatedPath = QFileInfo(cPath).absoluteFilePath();
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            CodeEditor *editor = primaryEditorForTab(m_editorTabs->widget(i));
            if (!editor || editor->filePath().isEmpty()
                || QFileInfo(editor->filePath()).absoluteFilePath() != generatedPath)
                continue;

            if (editor->document()->isModified())
                continue;

            if (reloadEditorFromDisk(editor)) {
                watchEditorFile(editor); // QSaveFile can replace the watched inode.
                editor->setProperty("sidboxNavigatorDirty", true);
                if (editor == activeEditor() && !editor->isResourceMode())
                    refreshEventNavigator(editor);
            }
        }
        statusBar()->showMessage(tr("GUI generated: %1").arg(displayPath(cPath)), 2500);
    };

    designer->sourceNavigationRequested =
        [this](const QString &cPath,
               const QString &preferredMarker,
               const QString &fallbackMarker) {
            const QString absoluteCPath =
                QFileInfo(cPath).absoluteFilePath();

            if (!openFile(absoluteCPath)) {
                return;
            }

            CodeEditor *editor =
                activeEditor();

            if (!editor
                || QFileInfo(editor->filePath()).absoluteFilePath()
                   != absoluteCPath) {
                return;
            }

            /*
             * Regeneration may replace an already-open .c file. beforeGenerate
             * saved its USER edits first, so reloading here is safe and avoids
             * waiting for the file-watcher debounce before the jump.
             */
            editor->loadFromFile(
                absoluteCPath,
                true);

            editor->enableSyntaxHighlighting();
            editor->setProperty("sidboxNavigatorDirty", true);
            refreshEventNavigator(editor);

            QTextCursor target;

            if (!preferredMarker.isEmpty()) {
                target =
                    editor->document()->find(
                        preferredMarker);
            }

            if (target.isNull()
                && !fallbackMarker.isEmpty()) {
                target =
                    editor->document()->find(
                        fallbackMarker);
            }

            if (!target.isNull()) {
                editor->setTextCursor(target);
                editor->centerCursor();
            }

            editor->setFocus();

            statusBar()->showMessage(
                target.isNull()
                    ? tr("Generated GUI source opened")
                    : tr("Jumped to GUI handler"),
                1800);
        };

    addProjectFile(absolutePath);
    m_editorTabs->setCurrentIndex(index);
    designer->setFocus();
    return true;
}

bool MainWindow::saveGuiDesignerTab(QWidget *widget)
{
    auto *designer = dynamic_cast<SidboxGuiDesigner *>(widget);
    return !designer || designer->saveDesignAndGenerate();
}

void MainWindow::openProject()
{
    const QString projectFilePath = QFileDialog::getOpenFileName(
        this,
        tr("Open Project"),
        m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath,
        tr("Sidbox projects (*.proj);;All files (*)"));

    if (projectFilePath.isEmpty()) {
        return;
    }

    openProjectAtPath(projectFilePath);
}

bool MainWindow::saveProject()
{
    // Save any pending V1 Game Designer documents before project metadata.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->widget(i))) {
            if (game->isModified() && !game->saveDesign()) return false;
        }
    }
    bool allSaved = true;

    /*
     * Save source editors FIRST. A generated GUI .c file may contain programmer
     * edits inside protected USER callback blocks; putting those edits on disk
     * before regeneration lets the designer preserve them safely.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (!editor) {
            continue;
        }

        // Project Save skips untitled tabs as before. A saved editor that
        // has not changed must not be rewritten: doing so invalidates the
        // incremental compiler's object-cache timestamps.
        if (editor->filePath().isEmpty()
            || !editor->document()
            || !editor->document()->isModified()) {
            continue;
        }

        allSaved = saveEditor(editor) && allSaved;
    }

    if (allSaved) {
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(m_editorTabs->widget(i))) {
                if (designer->isModified()) {
                    allSaved = designer->saveDesignAndGenerate() && allSaved;
                }
            }
        }
    }

    if (!allSaved) {
        statusBar()->showMessage(tr("Project save cancelled"));
        return false;
    }

    QString projectFilePath = m_projectFilePath;
    if (projectFilePath.isEmpty()) {
        projectFilePath = QFileDialog::getSaveFileName(
            this,
            tr("Save Project"),
            QDir(m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath).filePath(QStringLiteral("project.proj")),
            tr("Sidbox projects (*.proj);;All files (*)"));

        if (projectFilePath.isEmpty()) {
            statusBar()->showMessage(tr("Project save cancelled"));
            return false;
        }

        if (QFileInfo(projectFilePath).suffix().isEmpty()) {
            projectFilePath.append(QStringLiteral(".proj"));
        }
    }

    // Source/editor saves already add new files and refresh the tree when needed.
    // Saving unchanged .proj metadata must not rescan the whole directory.
    const QStringList projectFilesBeforeSave = m_projectFilesInProject;
    if (saveProjectFile(projectFilePath)) {
        if (m_projectFilesInProject != projectFilesBeforeSave)
            refreshProjectFiles();
        statusBar()->showMessage(tr("Project saved: %1").arg(QDir::toNativeSeparators(m_projectFilePath)));
        return true;
    }

    return false;
}

void MainWindow::showOptions()
{
    int newFontPointSize = m_editorFontPointSize;
    IDETheme newTheme = m_theme;

    /*
     * Keep the dialog in its own scope so it and all of its colour-picker /
     * tab children are destroyed before we replace the MainWindow stylesheet.
     */
    {
        OptionsDialog dialog(this);
        dialog.setThemeDirectory(QDir(ideLibsPath()).filePath(QStringLiteral("themes")));
        dialog.setEditorFontPointSize(m_editorFontPointSize);
        dialog.setTheme(m_theme);

        if (dialog.exec() != QDialog::Accepted) {
            return;
        }

        newFontPointSize = dialog.editorFontPointSize();
        newTheme = dialog.theme();
    }

    m_editorFontPointSize = newFontPointSize;
    m_theme = newTheme;

    saveOptions();
    applyTheme();
    applyEditorFont();

    statusBar()->showMessage(tr("Options saved"), 3000);
}

void MainWindow::showFindReplace()
{
    if (!m_findReplaceDialog) {
        m_findReplaceDialog = new FindReplaceDialog(this);
        m_findReplaceDialog->setAttribute(Qt::WA_DeleteOnClose, true);

        connect(m_findReplaceDialog, &QObject::destroyed,
                this, [this]() {
                    m_findReplaceDialog = nullptr;
                });

        connect(m_findReplaceDialog, &FindReplaceDialog::findAllRequested,
                this, [this]() {
                    if (!m_findReplaceDialog) {
                        return;
                    }

                    const QList<ProjectSearchResult> results =
                        findInProject(
                            m_findReplaceDialog->findText(),
                            m_findReplaceDialog->matchCase(),
                            m_findReplaceDialog->wholeWord());

                    m_findReplaceDialog->setResults(results);

                    statusBar()->showMessage(
                        tr("%1 match(es) found")
                            .arg(results.size()),
                        3000);
                });

        connect(m_findReplaceDialog, &FindReplaceDialog::resultActivated,
                this, [this](int index) {
                    if (!m_findReplaceDialog
                        || index < 0
                        || index >= m_findReplaceDialog->results().size()) {
                        return;
                    }

                    jumpToProjectSearchResult(
                        m_findReplaceDialog->results().at(index));
                });

        connect(m_findReplaceDialog, &FindReplaceDialog::replaceSelectedRequested,
                this, [this]() {
                    if (!m_findReplaceDialog) {
                        return;
                    }

                    QList<ProjectSearchResult> selected;
                    for (const int index :
                         m_findReplaceDialog->selectedResultIndexes()) {
                        if (index >= 0
                            && index < m_findReplaceDialog->results().size()) {
                            selected.append(
                                m_findReplaceDialog->results().at(index));
                        }
                    }

                    if (selected.isEmpty()) {
                        return;
                    }

                    if (!replaceProjectResults(
                            selected,
                            m_findReplaceDialog->replaceText())) {
                        return;
                    }

                    const QList<ProjectSearchResult> refreshed =
                        findInProject(
                            m_findReplaceDialog->findText(),
                            m_findReplaceDialog->matchCase(),
                            m_findReplaceDialog->wholeWord());

                    m_findReplaceDialog->setResults(refreshed);

                    statusBar()->showMessage(
                        tr("%1 selected replacement(s) made")
                            .arg(selected.size()),
                        3000);
                });

        connect(m_findReplaceDialog, &FindReplaceDialog::replaceAllRequested,
                this, [this]() {
                    if (!m_findReplaceDialog
                        || m_findReplaceDialog->results().isEmpty()) {
                        return;
                    }

                    const QList<ProjectSearchResult> allResults =
                        m_findReplaceDialog->results();

                    QSet<QString> files;
                    for (const ProjectSearchResult &result : allResults) {
                        files.insert(QFileInfo(result.filePath).absoluteFilePath());
                    }

                    const QMessageBox::StandardButton answer =
                        QMessageBox::question(
                            this,
                            tr("Replace All"),
                            tr("Replace %1 occurrence(s) in %2 file(s)?\n\n"
                               "Open files will remain as unsaved editor changes. "
                               "Files which are not open will be written to disk.")
                                .arg(allResults.size())
                                .arg(files.size()),
                            QMessageBox::Yes | QMessageBox::Cancel,
                            QMessageBox::Cancel);

                    if (answer != QMessageBox::Yes) {
                        return;
                    }

                    if (!replaceProjectResults(
                            allResults,
                            m_findReplaceDialog->replaceText())) {
                        return;
                    }

                    const QList<ProjectSearchResult> refreshed =
                        findInProject(
                            m_findReplaceDialog->findText(),
                            m_findReplaceDialog->matchCase(),
                            m_findReplaceDialog->wholeWord());

                    m_findReplaceDialog->setResults(refreshed);

                    statusBar()->showMessage(
                        tr("%1 replacement(s) made")
                            .arg(allResults.size()),
                        4000);
                });
    }

    m_findReplaceDialog->show();
    m_findReplaceDialog->raise();
    m_findReplaceDialog->activateWindow();
}

void MainWindow::showFindReplaceForCurrentWord()
{
    QString word;

    if (CodeEditor *editor = activeEditor()) {
        QTextCursor cursor = editor->textCursor();

        if (cursor.hasSelection()) {
            word = cursor.selectedText().trimmed();
        } else {
            cursor.select(QTextCursor::WordUnderCursor);
            word = cursor.selectedText().trimmed();
        }
    }

    showFindReplace();

    if (!m_findReplaceDialog) {
        return;
    }

    if (!word.isEmpty()) {
        m_findReplaceDialog->setFindText(word);
    } else {
        m_findReplaceDialog->focusFindText();
    }
}



namespace {

/*
 * The About page is a normal scrollable editor tab.  Draw the owner's
 * transparent portrait behind the existing selectable QLabel text rather
 * than placing an opaque picture widget into the layout.
 *
 * The PNG is optional: a fresh checkout still runs without the artwork.
 * Add icons/nagelgirl.png and reconfigure CMake to embed it later.
 */
class NagelAboutPage final : public QWidget
{
public:
    explicit NagelAboutPage(QWidget *parent = nullptr)
        : QWidget(parent),
          m_portrait(QStringLiteral(":/icons/nagelgirl.png"))
    {
    }

protected:
    void paintEvent(QPaintEvent *event) override
    {
        QWidget::paintEvent(event);
        if (m_portrait.isNull())
            return;

        // Keep the graphic in the upper-right corner, preserving aspect ratio
        // and the feathered alpha supplied by the original PNG.
        const QSize imageBounds(qMax(1, qMin(540, width() * 45 / 100)),
                                qMax(1, qMin(760, height() * 90 / 100)));
        const QPixmap scaled = m_portrait.scaled(imageBounds,
                                                Qt::KeepAspectRatio,
                                                Qt::SmoothTransformation);

        QPainter painter(this);
        painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
        painter.drawPixmap(width() - scaled.width(), 0, scaled);
    }

private:
    const QPixmap m_portrait;
};

/*
 * Theme-aware contour around Qt's rendered text. A light theme needs a light
 * halo behind its dark labels; dark themes need the reverse. The effect keeps
 * QLabel's native selection and word wrapping intact.
 */
class NagelAboutTextOutline final : public QGraphicsEffect
{
public:
    explicit NagelAboutTextOutline(const QColor &colour, QObject *parent = nullptr)
        : QGraphicsEffect(parent), m_outline(colour)
    {
    }

    void setOutlineColour(const QColor &colour)
    {
        if (m_outline == colour)
            return;
        m_outline = colour;
        update();
    }

protected:
    QRectF boundingRectFor(const QRectF &rect) const override
    {
        // Room for the two-pixel contour at every edge.
        return rect.adjusted(-2.0, -2.0, 2.0, 2.0);
    }

    void draw(QPainter *painter) override
    {
        if (!painter)
            return;

        QPoint origin;
        const QPixmap source = sourcePixmap(Qt::LogicalCoordinates, &origin,
                                              QGraphicsEffect::PadToEffectiveBoundingRect);
        if (source.isNull()) {
            drawSource(painter);
            return;
        }

        // Use the label's alpha as a stencil. The themed halo follows the
        // glyphs, preserving anti-aliasing and transparent image backgrounds.
        QPixmap silhouette(source.size());
        silhouette.setDevicePixelRatio(source.devicePixelRatio());
        silhouette.fill(Qt::transparent);
        {
            QPainter maskPainter(&silhouette);
            maskPainter.drawPixmap(QPoint(0, 0), source);
            maskPainter.setCompositionMode(QPainter::CompositionMode_SourceIn);
            maskPainter.fillRect(silhouette.rect(), m_outline);
        }

        painter->save();
        for (int dy = -2; dy <= 2; ++dy) {
            for (int dx = -2; dx <= 2; ++dx) {
                const int radius2 = dx * dx + dy * dy;
                if (radius2 == 0 || radius2 > 5)
                    continue;
                painter->drawPixmap(origin + QPoint(dx, dy), silhouette);
            }
        }
        painter->drawPixmap(origin, source);
        painter->restore();
    }

private:
    QColor m_outline;
};

// WCAG-style relative luminance lets us choose a readable outline even when
// a custom .sidtheme specifies foreground/background colours unusually close.
double aboutRelativeLuminance(const QColor &colour)
{
    const auto linear = [](double channel) {
        return channel <= 0.04045 ? channel / 12.92
                                : std::pow((channel + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * linear(colour.redF())
         + 0.7152 * linear(colour.greenF())
         + 0.0722 * linear(colour.blueF());
}

double aboutColourContrast(const QColor &first, const QColor &second)
{
    const double a = aboutRelativeLuminance(first);
    const double b = aboutRelativeLuminance(second);
    return (qMax(a, b) + 0.05) / (qMin(a, b) + 0.05);
}

QColor aboutOutlineColour(const IDETheme &theme)
{
    // The About page uses the normal themed background behind the portrait.
    // Normally that colour already contrasts very well with the label text.
    const QColor text = theme.brightText;
    const QColor background = theme.windowBackground;
    if (aboutColourContrast(text, background) >= 4.5)
        return background;

    // Respect unusual custom themes: if their background and text are nearly
    // identical, choose whichever extreme provides the strongest separation.
    const QColor dark = Qt::black;
    const QColor light = Qt::white;
    return aboutColourContrast(text, dark) >= aboutColourContrast(text, light)
               ? dark : light;
}

void outlineAboutText(QLabel *label, const IDETheme &theme)
{
    if (!label)
        return;

    label->setProperty("sidboxAboutOutlined", true);
    label->setAutoFillBackground(false);
    // Match the label colour used by MainWindow::applyTheme(), but keep the
    // background transparent so the feathered portrait shows through.
    label->setStyleSheet(QStringLiteral(
        "background: transparent; border: none; color: %1;")
        .arg(ideThemeColorName(theme.brightText)));

    const QColor outline = aboutOutlineColour(theme);
    if (auto *effect = dynamic_cast<NagelAboutTextOutline *>(label->graphicsEffect()))
        effect->setOutlineColour(outline);
    else
        label->setGraphicsEffect(new NagelAboutTextOutline(outline, label));
}

} // namespace


void MainWindow::showAboutIde()
{
    if (!m_editorTabs) {
        return;
    }

    // Reuse the existing About tab instead of opening duplicates.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *widget = m_editorTabs->widget(i);
        if (widget && widget->property("sidboxAboutIde").toBool()) {
            m_editorTabs->setCurrentIndex(i);
            return;
        }
    }

    auto *page = new NagelAboutPage;
    page->setProperty("sidboxAboutIde", true);

    auto *outerLayout = new QVBoxLayout(page);
    outerLayout->setContentsMargins(24, 24, 24, 24);
    outerLayout->setSpacing(14);

    auto *headerLayout = new QHBoxLayout;
    headerLayout->setSpacing(18);

    auto *logoLabel = new QLabel(page);
    logoLabel->setFixedSize(160, 160);
    logoLabel->setAlignment(Qt::AlignCenter);

    /*
     * ABOUT LOGO PLACEHOLDER
     *
     * Replace :/icons/icon.png below with your final About graphic resource,
     * for example:
     *
     *     QPixmap logo(QStringLiteral(":/icons/about_logo.png"));
     */
    QPixmap logo(QStringLiteral(":/icons/icon.png"));
    if (!logo.isNull()) {
        logoLabel->setPixmap(
            logo.scaled(
                logoLabel->size(),
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation));
    } else {
        logoLabel->setText(tr("SIDBOX IDE"));
    }

    // Lay out the header text directly, without an intermediate QWidget.
    // Global IDE styles can give a child QWidget an opaque theme background,
    // which would otherwise cover the right-hand portrait with a rectangle.
    auto *titleLayout = new QVBoxLayout;
    titleLayout->setContentsMargins(0, 0, 0, 0);
    titleLayout->setSpacing(5);

    auto *title = new QLabel(tr("Sidbox IDE"), page);
    QFont titleFont = title->font();
    titleFont.setPointSize(titleFont.pointSize() + 8);
    titleFont.setBold(true);
    title->setFont(titleFont);

    auto *subtitle = new QLabel(
        tr("A dedicated C development environment for the Sidbox platform."),
        page);
    subtitle->setWordWrap(true);

    auto *purpose = new QLabel(
        tr("Sidbox IDE was created to make developing Sidbox software quicker, "
           "clearer and more enjoyable. It brings the Sidbox project format, "
           "compiler toolchain, API navigation, diagnostics, source browsing, "
           "minimap, project symbols and searchable API Cheat Sheet together "
           "in one focused development environment."),
        page);
    purpose->setWordWrap(true);

    titleLayout->addWidget(title);
    titleLayout->addWidget(subtitle);
    titleLayout->addSpacing(8);
    titleLayout->addWidget(purpose);
    titleLayout->addStretch(1);

    headerLayout->addWidget(logoLabel, 0, Qt::AlignTop);
    headerLayout->addLayout(titleLayout, 1);

    auto *aboutHeading = new QLabel(tr("About the IDE"), page);
    QFont headingFont = aboutHeading->font();
    headingFont.setBold(true);
    aboutHeading->setFont(headingFont);

    auto *aboutText = new QLabel(
        tr("Although it is a capable C/C++ editor at heart, Sidbox IDE was "
           "designed specifically around Sidbox development. Its goal is not "
           "to be a huge general-purpose IDE; it is to provide the tools that "
           "are actually useful when creating Sidbox applications and games."),
        page);
    aboutText->setWordWrap(true);
    aboutText->setTextInteractionFlags(Qt::TextSelectableByMouse);

    auto *featuresHeading = new QLabel(tr("Built for Sidbox"), page);
    featuresHeading->setFont(headingFont);

    auto *features = new QLabel(
        tr("• Sidbox .proj project support\n"
           "• Integrated Sidbox compiler and linker settings\n"
           "• Error and warning diagnostics\n"
           "• API-aware syntax highlighting and completion\n"
           "• Ctrl+Click navigation into project and Sidbox API source\n"
           "• Read-only API source reference tabs\n"
           "• F1 contextual API tips\n"
           "• F8 searchable API Cheat Sheet\n"
           "• Functions / variables browser and minimap navigation\n"
           "• Project-wide find and replace"),
        page);
    features->setWordWrap(true);
    features->setTextInteractionFlags(Qt::TextSelectableByMouse);

    auto *creditsHeading = new QLabel(tr("Credits"), page);
    creditsHeading->setFont(headingFont);

    auto *credits = new QLabel(
        tr("Sidbox IDE was designed and created by Electronscape for the Sidbox platform.\n\n"
           "Qt 6 / C++ implementation assistance, debugging and code review "
           "were carried out with the assistance of ChatGPT by OpenAI."),
        page);
    credits->setWordWrap(true);
    credits->setTextInteractionFlags(Qt::TextSelectableByMouse);

    auto *note = new QLabel(
        tr("Built because Sidbox deserved an IDE of its own. :)"),
        page);
    QFont noteFont = note->font();
    noteFont.setItalic(true);
    note->setFont(noteFont);

    // Give all About text a theme-contrasting contour so it can cross the image
    // without opaque backgrounds or losing mouse text selection.
    for (QLabel *label : {title, subtitle, purpose, aboutHeading, aboutText,
                           featuresHeading, features, creditsHeading, credits,
                           note}) {
        outlineAboutText(label, m_theme);
    }

    outerLayout->addLayout(headerLayout);
    outerLayout->addSpacing(6);
    outerLayout->addWidget(aboutHeading);
    outerLayout->addWidget(aboutText);
    outerLayout->addSpacing(6);
    outerLayout->addWidget(featuresHeading);
    outerLayout->addWidget(features);
    outerLayout->addSpacing(6);
    outerLayout->addWidget(creditsHeading);
    outerLayout->addWidget(credits);
    outerLayout->addStretch(1);
    outerLayout->addWidget(note);

    auto *scroll = new QScrollArea(m_editorTabs);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setWidget(page);
    scroll->setProperty("sidboxAboutIde", true);

    const int index = m_editorTabs->addTab(scroll, tr("About IDE"));
    m_editorTabs->setTabToolTip(index, tr("About Sidbox IDE"));
    m_editorTabs->setCurrentIndex(index);
}

namespace {


QString libraryCheatSheetCategory(const QString &filePath)
{
    const QString baseName = QFileInfo(filePath).completeBaseName();
    return QStringLiteral("Libraries — %1")
        .arg(baseName.isEmpty() ? QStringLiteral("Library") : baseName);
}

QString libraryArchiveForHeader(const QString &libraryRoot,
                                const QString &headerPath)
{
    if (libraryRoot.isEmpty() || headerPath.isEmpty()) {
        return {};
    }

    QString headerBase = QFileInfo(headerPath).completeBaseName();
    if (headerBase.startsWith(QStringLiteral("lib"), Qt::CaseInsensitive)) {
        headerBase.remove(0, 3);
    }

    QDirIterator iterator(
        libraryRoot,
        {QStringLiteral("*.a")},
        QDir::Files,
        QDirIterator::Subdirectories);

    while (iterator.hasNext()) {
        const QString archivePath =
            QFileInfo(iterator.next()).absoluteFilePath();

        QString archiveBase =
            QFileInfo(archivePath).completeBaseName();

        if (archiveBase.startsWith(QStringLiteral("lib"), Qt::CaseInsensitive)) {
            archiveBase.remove(0, 3);
        }

        if (archiveBase.compare(headerBase, Qt::CaseInsensitive) == 0) {
            return archivePath;
        }
    }

    return {};
}

QString apiCheatSheetCategory(const QString &apiRoot,
                              const QString &filePath)
{
    QString relative =
        QDir(apiRoot).relativeFilePath(filePath);

    relative = QDir::fromNativeSeparators(relative);

    const int slash = relative.indexOf(QLatin1Char('/'));
    QString category =
        slash >= 0
            ? relative.left(slash)
            : QFileInfo(relative).completeBaseName();

    if (category.compare(QStringLiteral("apis"), Qt::CaseInsensitive) == 0
        || category.compare(QStringLiteral("syscalls"), Qt::CaseInsensitive) == 0
        || category.compare(QStringLiteral("applet"), Qt::CaseInsensitive) == 0) {
        category = QStringLiteral("Core");
    }

    if (!category.isEmpty()) {
        category[0] = category.at(0).toUpper();
    }

    return category.isEmpty() ? QStringLiteral("Other") : category;
}

QString cleanApiComment(QString comment)
{
    comment.replace(QStringLiteral("/**"), QString());
    comment.replace(QStringLiteral("/*"), QString());
    comment.replace(QStringLiteral("*/"), QString());

    QStringList cleaned;
    const QStringList lines = comment.split(QLatin1Char('\n'));

    for (QString line : lines) {
        line = line.trimmed();

        if (line.startsWith(QLatin1Char('*'))) {
            line.remove(0, 1);
            line = line.trimmed();
        }
        if (line.startsWith(QStringLiteral("//"))) {
            line.remove(0, 2);
            line = line.trimmed();
        }

        if (line.startsWith(QStringLiteral("@brief"))) {
            line.remove(0, 6);
            line = line.trimmed();
        }

        /*
         * Keep useful prose, but skip documentation tags that are better
         * represented by the function signature itself.
         */
        if (line.startsWith(QLatin1Char('@'))) {
            continue;
        }

        if (!line.isEmpty()) {
            cleaned.append(line);
        }
    }

    return cleaned.join(QLatin1Char(' ')).simplified();
}

QString apiCommentBeforeLine(const QString &source, int zeroBasedLine)
{
    if (zeroBasedLine < 0) {
        return {};
    }

    const QStringList lines = source.split(QLatin1Char('\n'));
    if (zeroBasedLine >= lines.size()) {
        return {};
    }

    int i = zeroBasedLine - 1;

    while (i >= 0 && lines.at(i).trimmed().isEmpty()) {
        --i;
    }

    if (i < 0) {
        return {};
    }

    QStringList commentLines;

    // Consecutive // comments directly above the declaration.
    if (lines.at(i).trimmed().startsWith(QStringLiteral("//"))) {
        while (i >= 0
               && lines.at(i).trimmed().startsWith(QStringLiteral("//"))) {
            commentLines.prepend(lines.at(i));
            --i;
        }
        return cleanApiComment(commentLines.join(QLatin1Char('\n')));
    }

    // /* ... */ or /** ... */ block immediately above the declaration.
    if (lines.at(i).contains(QStringLiteral("*/"))) {
        while (i >= 0) {
            commentLines.prepend(lines.at(i));

            if (lines.at(i).contains(QStringLiteral("/*"))) {
                break;
            }
            --i;
        }

        if (!commentLines.isEmpty()
            && commentLines.first().contains(QStringLiteral("/*"))) {
            return cleanApiComment(commentLines.join(QLatin1Char('\n')));
        }
    }

    return {};
}

QString firstDeclarationLineContaining(const QString &source,
                                       const QString &symbol,
                                       int *lineOut)
{
    if (lineOut) {
        *lineOut = -1;
    }

    const QRegularExpression symbolExpression(
        QStringLiteral(R"(\b%1\b)")
            .arg(QRegularExpression::escape(symbol)));

    const QStringList lines = source.split(QLatin1Char('\n'));

    for (int i = 0; i < lines.size(); ++i) {
        const QString trimmed = lines.at(i).trimmed();

        if (trimmed.startsWith(QStringLiteral("//"))
            || trimmed.startsWith(QLatin1Char('*'))
            || trimmed.startsWith(QStringLiteral("/*"))) {
            continue;
        }

        if (!symbolExpression.match(lines.at(i)).hasMatch()) {
            continue;
        }

        if (lineOut) {
            *lineOut = i;
        }

        /*
         * Gather a short multi-line declaration/prototype, stopping at ';' or
         * '{'. This keeps the Cheat Sheet useful for wrapped API prototypes.
         */
        QString declaration = trimmed;

        for (int j = i + 1;
             j < lines.size()
             && j <= i + 6
             && !declaration.contains(QLatin1Char(';'))
             && !declaration.contains(QLatin1Char('{'));
             ++j) {
            declaration += QLatin1Char(' ');
            declaration += lines.at(j).trimmed();
        }

        return declaration.simplified();
    }

    return {};
}

}

void MainWindow::showApiCheatSheet()
{
    if (!m_editorTabs) {
        return;
    }

    /*
     * F8 is context-sensitive: if the caret is sitting on a known Sidbox API
     * identifier, remember it before switching away from the source editor.
     */
    QString requestedSymbol;

    ensureApiCatalog();

    if (auto *editor = activeEditor()) {
        QTextCursor cursor = editor->textCursor();
        cursor.select(QTextCursor::WordUnderCursor);

        const QString candidate = cursor.selectedText().trimmed();
        if (!candidate.isEmpty()
            && apiSyntaxNames().contains(candidate)) {
            requestedSymbol = candidate;
        }
    }

    auto selectCheatSheetSymbol =
        [requestedSymbol](QWidget *page) -> bool {
            if (!page || requestedSymbol.isEmpty()) {
                return false;
            }

            auto *tree =
                page->findChild<QTreeWidget *>(
                    QStringLiteral("apiCheatTree"));
            auto *search =
                page->findChild<QLineEdit *>(
                    QStringLiteral("apiCheatSearch"));

            if (!tree) {
                return false;
            }

            /*
             * A previous search may have hidden the requested symbol. Clear it
             * before selecting the exact API entry.
             */
            if (search && !search->text().isEmpty()) {
                search->clear();
            }

            const QList<QTreeWidgetItem *> matches =
                tree->findItems(
                    requestedSymbol,
                    Qt::MatchExactly | Qt::MatchRecursive,
                    0);

            for (QTreeWidgetItem *item : matches) {
                if (!item || item->childCount() > 0) {
                    continue;
                }

                /*
                 * Keep the tree collapsed by default. Only expand the category
                 * which contains the API symbol requested by F8.
                 */
                tree->collapseAll();

                for (QTreeWidgetItem *ancestor = item->parent();
                     ancestor; ancestor = ancestor->parent()) {
                    ancestor->setExpanded(true);
                }

                tree->setCurrentItem(item);
                tree->scrollToItem(
                    item,
                    QAbstractItemView::PositionAtCenter);
                return true;
            }

            return false;
        };

    /*
     * Reuse the existing Cheat Sheet tab instead of opening duplicates.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *widget = m_editorTabs->widget(i);
        if (widget
            && widget->property("sidboxApiCheatSheet").toBool()) {
            m_editorTabs->setCurrentIndex(i);

            const bool selected =
                selectCheatSheetSymbol(widget);

            if (!selected) {
                if (QLineEdit *search =
                        widget->findChild<QLineEdit *>(
                            QStringLiteral("apiCheatSearch"))) {
                    search->setFocus();
                    search->selectAll();
                }
            }
            return;
        }
    }

    const QString libsRoot = ideLibsPath();
    const QString apiRoot =
        QDir(libsRoot).filePath(QStringLiteral("api"));
    const QString libraryRoot =
        QDir(libsRoot).filePath(QStringLiteral("libraries"));

    const QString guidesPath =
        QDir(libsRoot).filePath(QStringLiteral("docs/cheatsheet.json"));
    if (!QFileInfo::exists(apiRoot)
        && !QFileInfo::exists(libraryRoot)
        && !QFileInfo::exists(guidesPath)) {
        QMessageBox::information(
            this,
            tr("Cheat Sheet"),
            tr("SIDBOX API, libraries and guides could not be found under:\n%1")
                .arg(QDir::toNativeSeparators(libsRoot)));
        return;
    }

    QJsonObject cheatsheetDocument;
    QFile guidesFile(guidesPath);
    if (guidesFile.open(QIODevice::ReadOnly)) {
        QJsonParseError parseError;
        const QJsonDocument document = QJsonDocument::fromJson(
            guidesFile.readAll(), &parseError);
        if (parseError.error == QJsonParseError::NoError && document.isObject()) {
            cheatsheetDocument = document.object();
        }
    }

    auto *page = new QWidget(m_editorTabs);
    page->setProperty("sidboxApiCheatSheet", true);

    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(8, 8, 8, 8);
    layout->setSpacing(6);

    auto *title = new QLabel(
        tr("SIDBOX SDK & Game Engine Cheat Sheet"),
        page);

    QFont titleFont = title->font();
    titleFont.setBold(true);
    title->setFont(titleFont);

    auto *search = new QLineEdit(page);
    search->setObjectName(QStringLiteral("apiCheatSearch"));
    search->setPlaceholderText(
        tr("Search guides, platformer features, API functions and examples..."));
    search->setClearButtonEnabled(true);

    auto *splitter = new QSplitter(Qt::Horizontal, page);

    auto *tree = new QTreeWidget(splitter);
    tree->setObjectName(QStringLiteral("apiCheatTree"));
    tree->setHeaderHidden(true);
    tree->setRootIsDecorated(true);
    tree->setAlternatingRowColors(true);
    tree->setMinimumWidth(300);

    auto *detailPane = new QWidget(splitter);
    auto *detailLayout = new QVBoxLayout(detailPane);
    detailLayout->setContentsMargins(8, 0, 0, 0);
    detailLayout->setSpacing(6);

    auto *symbolLabel = new QLabel(tr("Select an API item"), detailPane);
    QFont symbolFont = symbolLabel->font();
    symbolFont.setBold(true);
    symbolLabel->setFont(symbolFont);
    symbolLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);

    auto *signatureLabel = new QLabel(detailPane);
    signatureLabel->setWordWrap(true);
    signatureLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    signatureLabel->setFont(
        QFontDatabase::systemFont(QFontDatabase::FixedFont));

    auto *description = new QTextBrowser(detailPane);
    description->setOpenExternalLinks(false);
    description->setPlaceholderText(
        tr("No API item selected."));
    description->setMinimumHeight(160);

    auto *sourceLabel = new QLabel(detailPane);
    sourceLabel->setWordWrap(true);
    sourceLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);

    auto *buttonRow = new QHBoxLayout;
    auto *openSourceButton =
        new QPushButton(tr("Open Source"), detailPane);
    auto *copyPrototypeButton =
        new QPushButton(tr("Copy Prototype"), detailPane);

    openSourceButton->setEnabled(false);
    copyPrototypeButton->setEnabled(false);

    buttonRow->addWidget(openSourceButton);
    buttonRow->addWidget(copyPrototypeButton);
    buttonRow->addStretch(1);

    detailLayout->addWidget(symbolLabel);
    detailLayout->addWidget(signatureLabel);
    detailLayout->addWidget(description, 1);
    detailLayout->addWidget(sourceLabel);
    detailLayout->addLayout(buttonRow);

    splitter->addWidget(tree);
    splitter->addWidget(detailPane);
    splitter->setStretchFactor(0, 2);
    splitter->setStretchFactor(1, 3);

    layout->addWidget(title);
    layout->addWidget(search);
    layout->addWidget(splitter, 1);

    struct ApiEntry {
        QString name;
        QString signature;
        QString description;
        QString filePath;
        QString category;
        QString libraryArchive;
        bool libraryEntry = false;
        bool guideEntry = false;
        QString example;
        int line = -1;
    };

    QList<ApiEntry> entries;
    const QStringList knownNames = apiSyntaxNames();

    QStringList catalogFiles;

    if (QFileInfo::exists(apiRoot)) {
        QDirIterator apiIterator(
            apiRoot,
            {QStringLiteral("*.h"), QStringLiteral("*.c")},
            QDir::Files,
            QDirIterator::Subdirectories);

        while (apiIterator.hasNext()) {
            catalogFiles.append(
                QFileInfo(apiIterator.next()).absoluteFilePath());
        }
    }

    if (QFileInfo::exists(libraryRoot)) {
        QDirIterator libraryIterator(
            libraryRoot,
            {QStringLiteral("*.h")},
            QDir::Files,
            QDirIterator::Subdirectories);

        while (libraryIterator.hasNext()) {
            catalogFiles.append(
                QFileInfo(libraryIterator.next()).absoluteFilePath());
        }
    }

    /*
     * Headers first: both the core API and static libraries generally expose
     * the public declaration/documentation there. API .c files remain a
     * fallback for wrappers/definitions whose documentation lives in source.
     */
    std::stable_sort(
        catalogFiles.begin(),
        catalogFiles.end(),
        [](const QString &a, const QString &b) {
            const bool aHeader =
                QFileInfo(a).suffix().compare(
                    QStringLiteral("h"),
                    Qt::CaseInsensitive) == 0;
            const bool bHeader =
                QFileInfo(b).suffix().compare(
                    QStringLiteral("h"),
                    Qt::CaseInsensitive) == 0;

            if (aHeader != bHeader) {
                return aHeader;
            }
            return a.compare(b, Qt::CaseInsensitive) < 0;
        });

    QSet<QString> addedNames;

    for (const QString &name : knownNames) {
        ApiEntry chosen;
        chosen.name = name;

        for (const QString &filePath : std::as_const(catalogFiles)) {
            QFile file(filePath);
            if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                continue;
            }

            const QString source =
                QString::fromUtf8(file.readAll());

            int line = -1;
            const QString declaration =
                firstDeclarationLineContaining(
                    source,
                    name,
                    &line);

            if (line < 0) {
                continue;
            }

            chosen.filePath = filePath;
            chosen.line = line;

            const QString absoluteLibraryRoot =
                QFileInfo(libraryRoot).absoluteFilePath();
            const QString absoluteFilePath =
                QFileInfo(filePath).absoluteFilePath();

            chosen.libraryEntry =
                QFileInfo::exists(libraryRoot)
                && (absoluteFilePath == absoluteLibraryRoot
                    || absoluteFilePath.startsWith(
                        absoluteLibraryRoot + QDir::separator()));

            if (chosen.libraryEntry) {
                chosen.category =
                    libraryCheatSheetCategory(filePath);
                chosen.libraryArchive =
                    libraryArchiveForHeader(
                        libraryRoot,
                        filePath);
            } else {
                chosen.category =
                    apiCheatSheetCategory(
                        apiRoot,
                        filePath);
            }

            const QString catalogTip =
                quickTipForSymbol(name);

            chosen.signature =
                !catalogTip.isEmpty()
                    ? catalogTip
                    : declaration;

            chosen.description =
                apiCommentBeforeLine(source, line);

            /*
             * Prefer a documented match. If the first header declaration has
             * no prose, keep looking for a source definition with a useful
             * comment before accepting the plain declaration.
             */
            if (!chosen.description.isEmpty()) {
                break;
            }
        }

        if (chosen.filePath.isEmpty()) {
            continue;
        }

        // Curated quick-reference descriptions are useful even when the
        // declaration has no doc comment. Keep the real source/prototype.
        const QJsonObject documented =
            cheatsheetDocument.value(QStringLiteral("entries"))
                .toObject().value(name).toObject();
        if (!documented.isEmpty()) {
            QStringList explanation;
            const QString summary =
                documented.value(QStringLiteral("summary")).toString();
            const QString notes =
                documented.value(QStringLiteral("notes")).toString();
            const QString example =
                documented.value(QStringLiteral("example")).toString();
            if (!summary.isEmpty()) explanation << summary;
            if (!notes.isEmpty()) explanation << notes;
            if (!example.isEmpty()) explanation << tr("Example:\n%1").arg(example);
            if (!explanation.isEmpty())
                chosen.description = explanation.join(QStringLiteral("\n\n"));
        }

        if (chosen.description.isEmpty()) {
            chosen.description =
                chosen.libraryEntry
                    ? tr("No description is written in this library header yet. "
                         "Add a /* @brief ... */ comment above the declaration "
                         "to document it in the Cheat Sheet.")
                    : tr("No description is written in the API source yet. "
                         "Use the prototype and Open Source button to inspect how it works.");
        }

        entries.append(chosen);
        addedNames.insert(name);
    }

    // The SDK has long shipped beginner guides in this JSON. Display them
    // alongside the API catalogue, plus the advanced V1 game-engine guides.
    const QJsonArray guides =
        cheatsheetDocument.value(QStringLiteral("guides")).toArray();
    for (const QJsonValue &value : guides) {
        if (!value.isObject()) continue;
        const QJsonObject guide = value.toObject();
        const QString name = guide.value(QStringLiteral("title")).toString().trimmed();
        if (name.isEmpty()) continue;

        ApiEntry item;
        item.guideEntry = true;
        item.name = name;
        item.category = guide.value(QStringLiteral("category"))
                            .toString(QStringLiteral("Getting Started"));
        item.signature = guide.value(QStringLiteral("summary")).toString();
        item.description = guide.value(QStringLiteral("notes")).toString();
        item.example = guide.value(QStringLiteral("example")).toString();
        entries.append(item);
    }

    std::sort(
        entries.begin(),
        entries.end(),
        [](const ApiEntry &a, const ApiEntry &b) {
            const int categoryCompare =
                a.category.compare(
                    b.category,
                    Qt::CaseInsensitive);

            if (categoryCompare != 0) {
                return categoryCompare < 0;
            }

            return a.name.compare(
                       b.name,
                       Qt::CaseInsensitive) < 0;
        });

    QHash<QString, QTreeWidgetItem *> categoryItems;

    for (const ApiEntry &entry : std::as_const(entries)) {
        // Slash-separated guide categories become real nested tree branches:
        // Game Engines -> Advanced Platformer -> Springers, Keys, etc.
        QTreeWidgetItem *category = nullptr;
        QString categoryPath;
        const QStringList segments = entry.category.split(
            QLatin1Char('/'), Qt::SkipEmptyParts);
        for (const QString &untrimmed : segments) {
            const QString segment = untrimmed.trimmed();
            if (segment.isEmpty()) continue;
            if (!categoryPath.isEmpty()) categoryPath += QLatin1Char('/');
            categoryPath += segment;
            QTreeWidgetItem *found = categoryItems.value(categoryPath, nullptr);
            if (!found) {
                found = category
                    ? new QTreeWidgetItem(category)
                    : new QTreeWidgetItem(tree);
                found->setText(0, segment);
                found->setExpanded(false);
                found->setData(0, Qt::UserRole + 20, QStringLiteral("category"));
                categoryItems.insert(categoryPath, found);
            }
            category = found;
        }
        if (!category) continue;

        auto *item = new QTreeWidgetItem(category);
        item->setText(0, entry.name);
        item->setToolTip(0, entry.signature);
        item->setData(0, Qt::UserRole, entry.filePath);
        item->setData(0, Qt::UserRole + 1, entry.line);
        item->setData(0, Qt::UserRole + 2, entry.signature);
        item->setData(0, Qt::UserRole + 3, entry.description);
        item->setData(0, Qt::UserRole + 4, entry.category);
        item->setData(0, Qt::UserRole + 5, entry.name);
        item->setData(0, Qt::UserRole + 6, entry.libraryArchive);
        item->setData(0, Qt::UserRole + 7, entry.libraryEntry);
        item->setData(0, Qt::UserRole + 8, entry.guideEntry);
        item->setData(0, Qt::UserRole + 9, entry.example);
    }

    auto showItem = [=](QTreeWidgetItem *item) {
        if (!item || item->childCount() > 0) {
            return;
        }

        const QString name =
            item->data(0, Qt::UserRole + 5).toString();
        const QString signature =
            item->data(0, Qt::UserRole + 2).toString();
        const QString explanation =
            item->data(0, Qt::UserRole + 3).toString();
        const QString filePath =
            item->data(0, Qt::UserRole).toString();
        const int line =
            item->data(0, Qt::UserRole + 1).toInt();

        const bool isGuide = item->data(0, Qt::UserRole + 8).toBool();
        symbolLabel->setText(name);
        if (isGuide) {
            signatureLabel->clear();
            const QString example = item->data(0, Qt::UserRole + 9).toString();
            const QString asHtml = [](const QString &content) {
                return content.toHtmlEscaped().replace(
                    QLatin1Char('\n'), QStringLiteral("<br/>"));
            }(signature);
            QString html = QStringLiteral("<h3>What this covers</h3><p>%1</p>")
                               .arg(asHtml);
            if (!explanation.isEmpty()) {
                html += QStringLiteral("<h3>Steps and notes</h3><p>%1</p>")
                            .arg(explanation.toHtmlEscaped().replace(
                                QLatin1Char('\n'), QStringLiteral("<br/>")));
            }
            if (!example.isEmpty()) {
                html += QStringLiteral("<h3>Example / reference</h3><pre>%1</pre>")
                            .arg(example.toHtmlEscaped());
            }
            description->setHtml(html);
            sourceLabel->setText(tr("Guide: %1").arg(
                item->data(0, Qt::UserRole + 4).toString().replace(
                    QLatin1Char('/'), QStringLiteral(" → "))));
            openSourceButton->setEnabled(false);
            openSourceButton->setProperty("apiFilePath", QString());
            copyPrototypeButton->setText(tr("Copy Example"));
            copyPrototypeButton->setProperty("apiPrototype", example);
            copyPrototypeButton->setEnabled(!example.isEmpty());
            description->verticalScrollBar()->setValue(0);
            return;
        }

        copyPrototypeButton->setText(tr("Copy Prototype"));
        signatureLabel->setText(signature);
        description->setPlainText(explanation);
        description->verticalScrollBar()->setValue(0);

        const bool libraryEntry =
            item->data(
                0,
                Qt::UserRole + 7).toBool();

        const QString libraryArchive =
            item->data(
                0,
                Qt::UserRole + 6).toString();

        if (libraryEntry) {
            const QString archiveText =
                libraryArchive.isEmpty()
                    ? tr("(matching .a archive not found)")
                    : QFileInfo(libraryArchive).fileName();

            sourceLabel->setText(
                tr("Library: %1\nHeader: %2:%3")
                    .arg(
                        archiveText,
                        QDir(libsRoot).relativeFilePath(filePath))
                    .arg(line + 1));
        } else {
            sourceLabel->setText(
                tr("Source: %1:%2")
                    .arg(
                        QDir(libsRoot).relativeFilePath(filePath))
                    .arg(line + 1));
        }

        openSourceButton->setProperty(
            "apiFilePath",
            filePath);
        openSourceButton->setProperty(
            "apiLine",
            line);
        copyPrototypeButton->setProperty(
            "apiPrototype",
            signature);

        openSourceButton->setEnabled(
            !filePath.isEmpty() && line >= 0);
        copyPrototypeButton->setEnabled(
            !signature.isEmpty());
    };

    connect(tree, &QTreeWidget::currentItemChanged,
            page,
            [showItem](QTreeWidgetItem *current,
                       QTreeWidgetItem *) {
                showItem(current);
            });

    connect(tree, &QTreeWidget::itemDoubleClicked,
            page,
            [this](QTreeWidgetItem *item, int) {
                if (!item || item->childCount() > 0
                    || item->data(0, Qt::UserRole + 8).toBool()) {
                    return;
                }

                const QString filePath =
                    item->data(
                        0,
                        Qt::UserRole).toString();
                const int line =
                    item->data(
                        0,
                        Qt::UserRole + 1).toInt();

                openApiReference(filePath, line);
            });

    connect(openSourceButton, &QPushButton::clicked,
            page,
            [this, openSourceButton]() {
                const QString filePath =
                    openSourceButton
                        ->property("apiFilePath")
                        .toString();
                const int line =
                    openSourceButton
                        ->property("apiLine")
                        .toInt();

                if (!filePath.isEmpty()) {
                    openApiReference(filePath, line);
                }
            });

    connect(copyPrototypeButton, &QPushButton::clicked,
            page,
            [copyPrototypeButton]() {
                const QString prototype =
                    copyPrototypeButton
                        ->property("apiPrototype")
                        .toString();

                if (!prototype.isEmpty()) {
                    QApplication::clipboard()
                        ->setText(prototype);
                }
            });

    connect(search, &QLineEdit::textChanged,
            page,
            [tree](const QString &text) {
                const QString needle = text.trimmed();
                // Recursive matching keeps both levels of category visible,
                // and lets searches match guide text, examples, and category.
                std::function<bool(QTreeWidgetItem *, bool)> filterItem =
                    [&](QTreeWidgetItem *item, bool matchingParent) -> bool {
                        const QString searchable =
                            item->text(0) + QLatin1Char(' ')
                            + item->data(0, Qt::UserRole + 2).toString()
                            + QLatin1Char(' ')
                            + item->data(0, Qt::UserRole + 3).toString()
                            + QLatin1Char(' ')
                            + item->data(0, Qt::UserRole + 4).toString()
                            + QLatin1Char(' ')
                            + item->data(0, Qt::UserRole + 9).toString();
                        const bool ownMatch = needle.isEmpty()
                            || searchable.contains(needle, Qt::CaseInsensitive);
                        const bool branchMatch = matchingParent || ownMatch;
                        bool childMatch = false;
                        for (int j = 0; j < item->childCount(); ++j)
                            childMatch |= filterItem(item->child(j), branchMatch);
                        const bool visible = branchMatch || childMatch;
                        item->setHidden(!visible);
                        if (item->childCount() > 0)
                            item->setExpanded(!needle.isEmpty() && visible);
                        return visible;
                    };
                for (int i = 0; i < tree->topLevelItemCount(); ++i)
                    filterItem(tree->topLevelItem(i), false);
            });

    const int index =
        m_editorTabs->addTab(
            page,
            tr("Cheat Sheet"));

    m_editorTabs->setTabToolTip(
        index,
        tr("F8 — searchable SIDBOX guides, game engine and API reference"));

    m_editorTabs->setCurrentIndex(index);

    tree->collapseAll();

    const bool selected =
        selectCheatSheetSymbol(page);

    if (!selected) {
        search->setFocus();
    }

    statusBar()->showMessage(
        tr("SIDBOX Cheat Sheet ready — %1 guides and API items")
            .arg(entries.size()),
        3000);
}

void MainWindow::showProjectSettings()
{
    ProjectSettingsDialog dialog(this);
    dialog.setProjectType(m_projectType);
    dialog.setAppletFormat(m_appletFormat);
    dialog.setV2Linker(m_v2Linker);
    dialog.setModSizeKb(m_modSizeKb);
    // Only inspect file sizes when Project Settings is opened, never during
    // F5, Save Project, tab restore or source intelligence indexing.
    if (!m_projectPath.isEmpty()) {
        qint64 largest = 0;
        QString largestName;
        int modules = 0;
        int visited = 0;
        QStringList directories{m_projectPath};
        while (!directories.isEmpty() && visited < 50000) {
            QDir dir(directories.takeLast());
            for (const QFileInfo &entry : dir.entryInfoList(
                     QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks,
                     QDir::Name)) {
                if (++visited > 50000) break;
                if (entry.isDir()) {
                    if (!isExcludedProjectDirectoryName(entry.fileName()))
                        directories.append(entry.absoluteFilePath());
                    continue;
                }
                const QString suffix = entry.suffix().toLower();
                if (!QStringList{QStringLiteral("mod"), QStringLiteral("med"),
                      QStringLiteral("s3m"), QStringLiteral("xm"),
                      QStringLiteral("tfmx")}.contains(suffix)) continue;
                ++modules;
                if (entry.size() > largest) {
                    largest = entry.size();
                    largestName = QDir(m_projectPath).relativeFilePath(entry.absoluteFilePath());
                }
            }
        }
        if (largest > 0)
            dialog.setSuggestedModSizeKb(int(qMin<qint64>(1024 * 1024,
                ((largest + 4095) / 4096) * 4)), largestName, modules);
    }
    dialog.setAppSizeKb(m_appSizeKb);
    dialog.setV2HeapKb(m_v2HeapKb);
    dialog.setV2StackKb(m_v2StackKb);
    dialog.setOutputAppName(m_outputAppName);
    dialog.setCustomLinkerScriptPath(m_linkerScriptPath);
    dialog.setDefaultLinkerScriptPaths(
        defaultLinkerScriptPath(GuiProjectType),
        defaultLinkerScriptPath(GameProjectType));

    dialog.setOptimizationFlag(m_compilerOptimization);
    dialog.setSuppressWarnings(m_compilerSuppressWarnings);
    dialog.setWallEnabled(m_compilerWall);
    dialog.setWextraEnabled(m_compilerWextra);
    dialog.setFunctionSectionsEnabled(m_compilerFunctionSections);
    dialog.setDataSectionsEnabled(m_compilerDataSections);
    dialog.setStackUsageEnabled(m_compilerStackUsage);
    dialog.setExtraCompilerFlags(m_extraCompilerFlags);

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    m_projectType = normalizedProjectType(dialog.projectType());
    m_appletFormat = (m_projectType == GuiProjectType) ? dialog.appletFormat() : QStringLiteral("v1");
    m_v2Linker = (m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2"))
        ? dialog.v2Linker() : QStringLiteral("llvm");
    m_modSizeKb = dialog.modSizeKb();
    m_appSizeKb = dialog.appSizeKb();
    m_v2HeapKb = dialog.v2HeapKb();
    m_v2StackKb = dialog.v2StackKb();
    m_outputAppName =
        normalizedAppOutputName(dialog.outputAppName());
    m_linkerScriptPath = dialog.customLinkerScriptPath();

    m_compilerOptimization = dialog.optimizationFlag();
    m_compilerSuppressWarnings = dialog.suppressWarnings();
    m_compilerWall = dialog.wallEnabled();
    m_compilerWextra = dialog.wextraEnabled();
    m_compilerFunctionSections = dialog.functionSectionsEnabled();
    m_compilerDataSections = dialog.dataSectionsEnabled();
    m_compilerStackUsage = dialog.stackUsageEnabled();
    m_extraCompilerFlags = dialog.extraCompilerFlags();

    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }

    updateAppletMemoryPanel(this,
        m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2"),
        m_appSizeKb, m_v2StackKb, m_v2HeapKb);
    statusBar()->showMessage(tr("Project settings saved"));
}

void MainWindow::compileActiveFile()
{
    /*
     * F5 is a PROJECT build action, not a source-tab action. GUI Designer tabs
     * are first-class project documents, so compiling from one must save source
     * editors, save/regenerate visual designs, then build the project normally.
     */
    if (m_projectFilePath.isEmpty()) {
        QMessageBox::information(this, tr("Compile"), tr("Save the project before compiling so build outputs can sit beside the .proj file."));
        return;
    }

    /*
     * Save C/C++/resource editors first so protected callback USER blocks in a
     * generated GUI .c are safely on disk before any designer regeneration.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *openEditor =
            primaryEditorForTab(
                m_editorTabs->widget(i));

        // Only save untitled or modified documents. Rewriting unchanged
        // tabs would update their timestamps and defeat incremental builds.
        // Source editors are still saved before any GUI Designer regeneration.
        if (openEditor
            && (openEditor->filePath().isEmpty()
                || (openEditor->document()
                    && openEditor->document()->isModified()))
            && !saveEditor(openEditor)) {
            QMessageBox::warning(
                this,
                tr("Compile"),
                tr("Save all project files before compiling."));
            return;
        }
    }

    /*
     * Then save/regenerate every visual design. This makes F5 work identically
     * from a .c tab, a .h tab, a .res tab, or the GUI Designer itself.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *designer =
                dynamic_cast<SidboxGuiDesigner *>(
                    m_editorTabs->widget(i))) {
            if (!designer->saveDesignAndGenerate()) {
                QMessageBox::warning(
                    this,
                    tr("Compile"),
                    tr("Could not save/regenerate a GUI design before compiling."));
                return;
            }
        }
    }

    // Save V1 game designs before F5. Once a tilemap has been exported,
    // saveDesign refreshes its C level automatically. On a new project the
    // first export may be missing, so ask rather than compile stale data.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->widget(i))) {
            if (game->isModified() && !game->saveDesign()) return;
            if (game->tilemapBuildFilesMissing()) {
                const auto answer = QMessageBox::question(this,
                    tr("Compile: Tilemap Files Missing"),
                    tr("The tilemap in %1 is missing exported C files or the tilemap helper.\n\n"
                       "Yes: Export level1.c/.h and install any missing helper files "
                       "without replacing existing helper code.\n"
                       "No: Compile without exporting.\n"
                       "Cancel: Stop compiling.")
                        .arg(QFileInfo(game->filePath()).fileName()),
                    QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel,
                    QMessageBox::Yes);
                if (answer == QMessageBox::Cancel) return;
                if (answer == QMessageBox::Yes && !game->exportTilemapForCompile()) return;
            }
        }
    }

    if (m_compilerProcess->state() != QProcess::NotRunning) {
        QMessageBox::information(this, tr("Compile"), tr("A compile is already running."));
        return;
    }

    const QStringList sourceFiles = projectFilesForCompile();
    if (sourceFiles.isEmpty()) {
        QMessageBox::information(this, tr("Compile"), tr("Add at least one .c, .cc, .cpp, or .res file to the project before compiling."));
        return;
    }

    /*
     * Preflight only what is knowable without running the linker: generated
     * embedded PCM bytes.  Compiler code, BSS, alignment, and stack are NOT
     * included in this estimate.  The linked ELF remains authoritative.
     */
    qint64 embeddedSfxBytes = 0;
    int embeddedSfxCount = 0;
    {
        QSet<QString> compiledFiles;
        for (const QString &source : sourceFiles) {
            compiledFiles.insert(QFileInfo(source).absoluteFilePath());
        }

        QDirIterator designs(m_projectPath, QStringList{QStringLiteral("*.sbui")},
                             QDir::Files, QDirIterator::Subdirectories);
        while (designs.hasNext()) {
            const QString designPath = designs.next();
            const QFileInfo designInfo(designPath);
            const QString assetSource = designInfo.dir().absoluteFilePath(
                designInfo.completeBaseName() + QStringLiteral("res/media_sfx.c"));
            const QString legacySource = designInfo.dir().absoluteFilePath(
                designInfo.completeBaseName() + QStringLiteral("_sfx.c"));
            if (!compiledFiles.contains(QFileInfo(assetSource).absoluteFilePath())
                && !compiledFiles.contains(QFileInfo(legacySource).absoluteFilePath())) {
                continue;
            }

            QFile designFile(designPath);
            if (!designFile.open(QIODevice::ReadOnly)) {
                continue;
            }
            const QJsonDocument document =
                QJsonDocument::fromJson(designFile.readAll());
            for (const QJsonValue &value :
                 document.object().value(QStringLiteral("gadgets")).toArray()) {
                const QJsonObject gadget = value.toObject();
                if (gadget.value(QStringLiteral("type")).toString() != QStringLiteral("Media")
                    || gadget.value(QStringLiteral("mediaMode")).toString() != QStringLiteral("SFX")
                    || !gadget.value(QStringLiteral("mediaEmbedSfx")).toBool()) {
                    continue;
                }
                const QByteArray pcm = QByteArray::fromBase64(
                    gadget.value(QStringLiteral("mediaEmbeddedPcmBase64"))
                        .toString().toLatin1());
                if (!pcm.isEmpty()) {
                    // Generated arrays use MEMALIGN32, plus a length constant.
                    embeddedSfxBytes += (pcm.size() + 31LL) & ~31LL;
                    embeddedSfxBytes += 4;
                    ++embeddedSfxCount;
                }
            }
        }
    }

    const qint64 reservedBytes = qint64(m_appSizeKb) * 1024;
    if (m_linkerScriptPath.isEmpty() && embeddedSfxBytes > 0 && reservedBytes > 0
        && embeddedSfxBytes * 100 >= reservedBytes * 70) {
        QMessageBox warning(this);
        warning.setIcon(QMessageBox::Warning);
        warning.setWindowTitle(tr("Applet memory preflight"));
        warning.setText(tr("Embedded sound data is using much of the applet allowance."));
        warning.setInformativeText(
            tr("%1 embedded SFX sample(s) account for approximately %2 of the "
               "configured %3 KB applet allowance.\n\n"
               "This does NOT include program code, other data, BSS or stack. "
               "Only the linker can calculate final RAM usage. Increasing the "
               "limit also changes the applet's memory reservation, so check "
               "your SIDBOX memory layout first.")
                .arg(embeddedSfxCount)
                .arg(formattedFileSize(embeddedSfxBytes))
                .arg(m_appSizeKb));
        QPushButton *settingsButton = warning.addButton(
            tr("Project Settings..."), QMessageBox::ActionRole);
        QPushButton *continueButton = warning.addButton(
            tr("Compile Anyway"), QMessageBox::AcceptRole);
        warning.addButton(QMessageBox::Cancel);
        warning.setDefaultButton(continueButton);
        warning.exec();
        if (warning.clickedButton() == settingsButton) {
            showProjectSettings();
            return; // Run Compile again after reviewing the new size.
        }
        if (warning.clickedButton() != continueButton) {
            return;
        }
    }

    const bool v2Build = normalizedProjectType(m_projectType) == GuiProjectType &&
        m_appletFormat == QStringLiteral("v2");
    if (v2Build && !m_linkerScriptPath.isEmpty()) {
        QMessageBox::warning(this, tr("CGARM (Beta) build"),
            tr("CGARM (Beta) requires the gui_v2.ld linker template. "
               "Set the Linker script field to Default, or select V1 for your custom script."));
        return;
    }
    if (v2Build && (m_v2HeapKb < 4 || (m_v2HeapKb * 1024) % 32 != 0)) {
        QMessageBox::warning(this, tr("CGARM (Beta) build"),
            tr("CGARM requires at least 4 KB of heap, aligned to 32 bytes."));
        return;
    }
    if (v2Build && (m_v2StackKb < 4 || m_v2StackKb > 128 ||
                    (m_v2StackKb * 1024) % 32 != 0)) {
        QMessageBox::warning(this, tr("CGARM (Beta) build"),
            tr("Stage 6C private callback stacks must be 4–128 KB and 32-byte aligned."));
        return;
    }
    if (v2Build && m_appSizeKb > V2MaxAppletKiB) {
        QMessageBox::warning(this, tr("CGARM (Beta) build"),
            tr("The default V2 link base permits at most 6080 KB "
               "before the SDRAM/RAM-disk boundary. Reduce the allowance or build V1."));
        return;
    }
    QString linkerError;
    if (m_linkerScriptPath.isEmpty() && !updateProjectLinkerScript(&linkerError)) {
        QMessageBox::warning(this, tr("Compile"), tr("Could not prepare the project linker script:\n%1").arg(linkerError));
        return;
    }

    const QString libsPath = ideLibsPath();
    const QDir apiDir(QDir(libsPath).filePath(QStringLiteral("api")));
    const QString selectedLinkerScript = effectiveLinkerScriptPath();
    const QString selectedCompiler = compilerPath();
    const QString selectedObjcopy = objcopyPath();
    QStringList apiSourceFiles = sidboxApiSourceFiles();
    const QStringList libraryFiles = sidboxLibraryFiles();
    const QString cgarmArchivePath = QDir(libsPath).filePath(
        QStringLiteral("tools/cgarm/lib/libcgarm.a"));
    if (v2Build) {
        // V2 uses its versioned ELF header; never link the V1 startup marker.
        apiSourceFiles.removeAll(
            QDir(apiDir.absolutePath()).filePath(QStringLiteral("applet.s"))
        );

        // CGARM is now a precompiled PIC static library. Compile only the
        // project's own sources and the shared SIDBOX API sources; ld.lld
        // extracts the required CGARM objects from libcgarm.a at link time.
        // V1 and Gaming remain unchanged.
        if (!QFileInfo(cgarmArchivePath).isFile()) {
            QMessageBox::warning(this, tr("CGARM (Beta) build"),
                tr("Precompiled CGARM library not found:\n%1\n\n"
                   "Build it from development/tools/cgarm using make.")
                    .arg(QDir::toNativeSeparators(cgarmArchivePath)));
            return;
        }
    }

    if (!QFileInfo::exists(selectedCompiler)) {
        QMessageBox::warning(this, tr("Compile"), tr("The bundled Sidbox compiler was not found:\n%1").arg(QDir::toNativeSeparators(selectedCompiler)));
        return;
    }

    if (!v2Build && !QFileInfo::exists(selectedObjcopy)) {
        QMessageBox::warning(this, tr("Compile"), tr("The bundled Sidbox objcopy was not found:\n%1").arg(QDir::toNativeSeparators(selectedObjcopy)));
        return;
    }

    if (!QFileInfo::exists(selectedLinkerScript)) {
        QMessageBox::warning(this, tr("Compile"), tr("The selected linker script does not exist:\n%1").arg(QDir::toNativeSeparators(selectedLinkerScript)));
        return;
    }

    // PIE-capable LLVM LLD is required for V2 ONLY when LLVM is selected.
    // CGARM is a separate opt-in linker with no implicit LLVM fallback.
    // Prefer a bundled executable
    // (tools/bin/ld.lld) so released IDEs do not depend on the host PATH.
    // Fedora's installed ld.lld is a development fallback only.
    QString v2LldPath;
    if (v2Build && m_v2Linker != QStringLiteral("cgarm")) {
        for (const QString &candidate : {
                 QDir(libsPath).filePath(QStringLiteral("tools/bin/ld.lld")),
                 QDir(libsPath).filePath(QStringLiteral("tools/ld.lld")),
                 QStandardPaths::findExecutable(QStringLiteral("ld.lld"))}) {
            if (!candidate.isEmpty() && QFileInfo(candidate).isExecutable()) {
                v2LldPath = candidate;
                break;
            }
        }
        if (v2LldPath.isEmpty()) {
            QMessageBox::warning(this, tr("LLVM linker missing"),
                tr("LLVM V2 mode requires ld.lld for an ARM ET_DYN executable.\n\n"
                   "Install the LLD tool for development, or place its executable at\n"
                   "%1\n\n"
                   "V1 and gaming mode are unaffected.")
                    .arg(QDir(libsPath).filePath(QStringLiteral("tools/bin/ld.lld"))));
            return;
        }
    }

    if (v2Build && m_v2Linker == QStringLiteral("cgarm")) {
        const QString cgarmLinker = QDir(libsPath).filePath(QStringLiteral("tools/bin/cgarm-ld"));
        if (!QFileInfo(cgarmLinker).isExecutable()) {
            QMessageBox::warning(this, tr("CGARM linker missing"),
                tr("The selected experimental linker is missing or not executable:\n%1\n\n"
                   "The IDE will not silently use LLVM instead.")
                    .arg(QDir::toNativeSeparators(cgarmLinker)));
            return;
        }
    }

    if (apiSourceFiles.isEmpty()) {
        QMessageBox::warning(this, tr("Compile"), tr("The IDE API sources were not found under idelibs/api."));
        return;
    }

    const QString outputBaseName =
        QFileInfo(m_projectFilePath).completeBaseName();

    const QString appFileName =
        m_outputAppName.isEmpty()
            ? outputBaseName + QStringLiteral(".app")
            : normalizedAppOutputName(m_outputAppName);

    // Keep V1 intermediate files separate from CGARM's existing build/ tree.
    // The final .app stays in the project root for both formats.
    const QString buildPath = QDir(m_projectPath).filePath(
        v2Build ? QStringLiteral("build") : QStringLiteral("buildv1"));
    if (!QDir().mkpath(buildPath)) {
        QMessageBox::warning(this, tr("Compile"), tr("Could not create build folder:\n%1").arg(QDir::toNativeSeparators(buildPath)));
        return;
    }

    const QString outputPath = QDir(buildPath).filePath(outputBaseName + QStringLiteral(".elf"));
    const QString appOutputPath = QDir(m_projectPath).filePath(appFileName);
    const QString mapOutputPath = QDir(buildPath).filePath(outputBaseName + QStringLiteral(".map"));
    const QString asmOutputPath = QDir(buildPath).filePath(outputBaseName + QStringLiteral(".asm"));

    // Stage 5: CGARM V2 is delegated to the standalone compiler. It reads
    // the same .proj that we save here (including Designer-generated files),
    // compiles the six SDK sources, links libcgarm.a and packs the applet.
    // No PATH variable is needed by the IDE; the executable is bundled.
    // V1/Gaming continue below through their ORIGINAL compiler path.
    if (v2Build) {
#ifdef Q_OS_WIN
        const QString cliName = QStringLiteral("cgarm-build.exe");
#else
        const QString cliName = QStringLiteral("cgarm-build");
#endif
        const QString cli = QDir(libsPath).filePath(
            QStringLiteral("tools/bin/") + cliName);
        if (!QFileInfo(cli).isFile() || !QFileInfo(cli).isExecutable()) {
            QMessageBox::warning(this, tr("CGARM compiler missing"),
                tr("The standalone CGARM compiler was not found or is not executable:\n%1\n\n"
                   "Build the cgarm-build CMake target (or install the CLI under idelibs/tools/bin).\n"
                   "V1 and Gaming projects are unaffected.")
                    .arg(QDir::toNativeSeparators(cli)));
            return;
        }
        if (!saveProjectFile(m_projectFilePath)) {
            return; // Never build from stale project settings.
        }

        // cgarm-build sanitises its output stem for intermediate file names.
        QString cliStem = QFileInfo(appOutputPath).completeBaseName();
        cliStem.replace(QRegularExpression(QStringLiteral("[^A-Za-z0-9_-]")),
                        QStringLiteral("_"));
        if (cliStem.isEmpty()) cliStem = QStringLiteral("applet");
        m_v2BuildDirectory = QDir(m_projectPath).filePath(
            QStringLiteral("build/cgarm/") + cliStem +
            (m_v2Linker == QStringLiteral("cgarm") ? QStringLiteral("-cgarm") : QString()));
        m_pendingElfPath = QDir(m_v2BuildDirectory).filePath(cliStem + QStringLiteral(".elf"));
        m_pendingAsmPath = asmOutputPath;
        m_pendingAppPath = appOutputPath;
        m_v2CliPath = cli;
        m_currentBuildIsV2 = true;
        m_v2AutoResizeRetried = false;
        m_buildLinkSizeOverflow = false;
        m_v2CgarmRamExcessBytes = 0;

        clearCompilerDiagnostics();
        m_outputPane->clear();
        updateAppletMemoryPanel(this, true, m_appSizeKb, m_v2StackKb, m_v2HeapKb);
        appendOutputLine(tr("Project type: %1").arg(projectTypeLabel(m_projectType)), OutputKind::Header);
        appendOutputLine(tr("Applet format: relocatable ARM ELF (V2)"), OutputKind::Header);
        appendOutputLine(tr("Build backend: standalone cgarm-build"), OutputKind::Header);
        appendOutputLine(tr("V2 linker: %1")
            .arg(m_v2Linker == QStringLiteral("cgarm")
                ? tr("CGARM (EXPERIMENTAL; NO LLVM FALLBACK)")
                : tr("LLVM LLD (default)")), OutputKind::Header);
        appendOutputLine(tr("Compiler: %1").arg(QDir::toNativeSeparators(cli)), OutputKind::Path);
        appendOutputLine(tr("Project: %1").arg(QDir::toNativeSeparators(m_projectFilePath)), OutputKind::Path);
        appendOutputLine(tr("APP: %1").arg(QDir::toNativeSeparators(appOutputPath)), OutputKind::Path);
        appendOutputLine(tr("ELF: %1").arg(QDir::toNativeSeparators(m_pendingElfPath)), OutputKind::Path);
        appendOutputLine(tr("ASM: %1").arg(QDir::toNativeSeparators(asmOutputPath)), OutputKind::Path);
        appendOutputLine(tr("V2 RAM: %1 KB allowance; %2 KB heap; %3 KB private PSP stack")
            .arg(m_appSizeKb).arg(m_v2HeapKb).arg(m_v2StackKb), OutputKind::Header);
        if (embeddedSfxBytes > 0) {
            appendOutputLine(tr("Embedded SFX: %1 sample(s), approximately %2 RAM (before code/BSS/stack)")
                .arg(embeddedSfxCount).arg(formattedFileSize(embeddedSfxBytes)),
                OutputKind::Warning);
        }
        appendOutputLine(tr("V1 and Gaming still use the original IDE compiler."), OutputKind::Muted);
        appendOutputLine(tr("Saving .sbui designs and compiling generated C resources before linking."), OutputKind::Muted);
        m_compilerStderrBuffer.clear();
        m_compilerProcess->setWorkingDirectory(m_projectPath);
        m_buildStep = BuildStep::V2CliBuilding;
        setCompileProgressStage(tr("Building V2 via cgarm-build..."));
        m_compilerProcess->start(m_v2CliPath, {
            m_projectFilePath, QStringLiteral("-o"), m_pendingAppPath,
            QStringLiteral("--sdk"), libsPath,
            QStringLiteral("--app-kb"), QString::number(m_appSizeKb),
            QStringLiteral("--heap-kb"), QString::number(m_v2HeapKb),
            QStringLiteral("--stack-kb"), QString::number(m_v2StackKb),
            QStringLiteral("--linker"), m_v2Linker
        });
        return;
    }

    // The legacy V1/Gaming build starts here (unchanged).
    QStringList arguments = {
        QStringLiteral("-mcpu=cortex-m7"),
        QStringLiteral("-mthumb"),
        QStringLiteral("-mfpu=fpv5-d16"),
        QStringLiteral("-mfloat-abi=hard"),
        QStringLiteral("-std=gnu99"),
        m_compilerOptimization,
        QStringLiteral("--specs=nano.specs"),
        QStringLiteral("-mno-unaligned-access"),
        QStringLiteral("-DSIDBOX_STARTUP_HEADER_IN_ASM"),
    };
    if (v2Build) {
        arguments << QStringLiteral("-DSIDBOX_V2_HEAP_BYTES=%1").arg(m_v2HeapKb * 1024)
                  << QStringLiteral("-DSIDBOX_APPLET_V2")
                  << QStringLiteral("-fPIE") << QStringLiteral("-fPIC")
                  << QStringLiteral("-fno-plt")
                  << QStringLiteral("-fvisibility=hidden")
                  << QStringLiteral("-ffreestanding") << QStringLiteral("-fno-builtin");
    }
    arguments << QStringList{
        QStringLiteral("-I"), apiDir.absolutePath(),
        QStringLiteral("-I"), QDir(libsPath).filePath(QStringLiteral("libraries")),
    };

    if (m_compilerFunctionSections) {
        arguments << QStringLiteral("-ffunction-sections");
    }
    if (m_compilerDataSections) {
        arguments << QStringLiteral("-fdata-sections");
    }
    if (m_compilerStackUsage) {
        arguments << QStringLiteral("-fstack-usage");
    }

    if (m_compilerSuppressWarnings) {
        arguments << QStringLiteral("-w");
    } else {
        if (m_compilerWall) {
            arguments << QStringLiteral("-Wall");
        }
        if (m_compilerWextra) {
            arguments << QStringLiteral("-Wextra");
        }
    }

    if (!m_extraCompilerFlags.trimmed().isEmpty()) {
        arguments << QProcess::splitCommand(m_extraCompilerFlags);
    }

    if (v2Build) {
        arguments << QStringLiteral("-I")
                  << QDir(libsPath).filePath(QStringLiteral("tools/cgarm/include"));
    }

    // Capture compiler-only options before project and SDK inputs or linker
    // flags are appended. V2 compiles each source to a separate PIC object.
    const QStringList v2CompileFlags = arguments;

    /*
     * .res is a Sidbox IDE resource-source extension. GCC does not infer C
     * from that suffix, so explicitly select C for that input and immediately
     * restore extension-based language detection for the files which follow.
     */
    for (const QString &sourceFile : sourceFiles) {
        if (isResourceSource(sourceFile)) {
            arguments << QStringLiteral("-x")
                      << QStringLiteral("c")
                      << sourceFile
                      << QStringLiteral("-x")
                      << QStringLiteral("none");
        } else {
            arguments << sourceFile;
        }
    }

    arguments << apiSourceFiles;
    arguments << libraryFiles;
    arguments << QStringLiteral("-T") << selectedLinkerScript;
    arguments << QStringLiteral("-Wl,-Map=%1").arg(mapOutputPath);
    arguments << QStringLiteral("-Wl,--gc-sections");
    if (v2Build) {
        // V2 never uses the GCC driver's final link. Its objects will be
        // linked explicitly by ld.lld -pie below. Never relabel ET_EXEC.

    } else {
        arguments << QStringLiteral("-static");
    }
    arguments << QStringLiteral("--specs=nosys.specs");

    arguments << QStringLiteral("-Wl,--start-group")
              << QStringLiteral("-lc")
              << QStringLiteral("-lm")
              << QStringLiteral("-Wl,--end-group")
              << QStringLiteral("-o")
              << outputPath;

    clearCompilerDiagnostics();
    m_outputPane->clear();
    updateAppletMemoryPanel(this, m_currentBuildIsV2,
                            m_appSizeKb, m_v2StackKb, m_v2HeapKb);
    appendOutputLine(tr("Compiler: %1").arg(QDir::toNativeSeparators(selectedCompiler)), OutputKind::Path);
    appendOutputLine(tr("Objcopy: %1").arg(QDir::toNativeSeparators(selectedObjcopy)), OutputKind::Path);
    appendOutputLine(tr("Project type: %1").arg(projectTypeLabel(m_projectType)), OutputKind::Header);
    appendOutputLine(v2Build
        ? tr("Applet format: relocatable ARM ELF (V2)")
        : tr("Applet format: V1 (legacy fixed-address)"), OutputKind::Header);
    if (v2Build) {
        appendOutputLine(tr("CGARM heap: %1 KB bounded; private callback PSP stack: %2 KB (Stage 6C firmware)")
            .arg(m_v2HeapKb).arg(m_v2StackKb), OutputKind::Header);
        appendOutputLine(tr("CGARM starts on MSP; window/timer callbacks use private PSP stacks. "
                            "Non-PIC GNU/Newlib archives may be rejected by the linker. "
                            "V1 and Gaming builds remain unchanged."), OutputKind::Warning);
    }
    appendOutputLine(tr("Project: %1").arg(QDir::toNativeSeparators(m_projectFilePath)), OutputKind::Path);
    appendOutputLine(tr("Build folder: %1").arg(QDir::toNativeSeparators(buildPath)), OutputKind::Path);
    appendOutputLine(tr("ELF: %1").arg(QDir::toNativeSeparators(outputPath)), OutputKind::Path);
    appendOutputLine(tr("APP: %1").arg(QDir::toNativeSeparators(appOutputPath)), OutputKind::Path);
    appendOutputLine(tr("Map: %1").arg(QDir::toNativeSeparators(mapOutputPath)), OutputKind::Path);
    appendOutputLine(tr("Asm: %1").arg(QDir::toNativeSeparators(asmOutputPath)), OutputKind::Path);
    appendOutputLine(tr("Linker script: %1").arg(QDir::toNativeSeparators(selectedLinkerScript)), OutputKind::Path);
    appendOutputLine(
        tr("Applet size: %1 KB").arg(m_appSizeKb),
        OutputKind::Header);
    if (embeddedSfxBytes > 0) {
        appendOutputLine(
            tr("Embedded SFX: %1 sample(s), approximately %2 RAM before "
               "code, BSS and stack")
                .arg(embeddedSfxCount)
                .arg(formattedFileSize(embeddedSfxBytes)),
            OutputKind::Muted);
    }
    appendOutputLine(
        tr("Optimisation: %1").arg(m_compilerOptimization),
        OutputKind::Header);

    int resourceCount = 0;
    for (const QString &sourceFile : sourceFiles) {
        if (isResourceSource(sourceFile)) {
            ++resourceCount;
        }
    }
    if (resourceCount > 0) {
        appendOutputLine(
            tr("Resource sources: %1 (.res compiled as C, IDE analysis disabled)")
                .arg(resourceCount),
            OutputKind::Muted);
    }

    QStringList enabledCompilerOptions;
    if (m_compilerFunctionSections) enabledCompilerOptions << QStringLiteral("-ffunction-sections");
    if (m_compilerDataSections) enabledCompilerOptions << QStringLiteral("-fdata-sections");
    if (m_compilerStackUsage) enabledCompilerOptions << QStringLiteral("-fstack-usage");
    if (m_compilerSuppressWarnings) {
        enabledCompilerOptions << QStringLiteral("-w");
    } else {
        if (m_compilerWall) enabledCompilerOptions << QStringLiteral("-Wall");
        if (m_compilerWextra) enabledCompilerOptions << QStringLiteral("-Wextra");
    }
    if (!m_extraCompilerFlags.trimmed().isEmpty()) {
        enabledCompilerOptions << m_extraCompilerFlags.trimmed();
    }

    appendOutputLine(
        tr("Compiler options: %1")
            .arg(enabledCompilerOptions.isEmpty()
                     ? tr("(none)")
                     : enabledCompilerOptions.join(QLatin1Char(' '))),
        OutputKind::Muted);

    if (m_modSizeKb > 0) {
        appendOutputLine(tr("MOD size: %1 KB").arg(m_modSizeKb), OutputKind::Warning);
    }
    appendOutputLine(tr("Project sources:"), OutputKind::Header);
    for (const QString &sourceFile : sourceFiles) {
        appendOutputLine(tr("  %1").arg(displayPath(sourceFile)), OutputKind::Muted);
    }
    appendOutputLine(tr("IDE API sources:"), OutputKind::Header);
    for (const QString &apiSource : apiSourceFiles) {
        appendOutputLine(tr("  %1").arg(QDir(libsPath).relativeFilePath(apiSource)), OutputKind::Muted);
    }

    m_buildLinkSizeOverflow = false;
    m_v2AutoResizeRetried = false;
    m_v2CgarmRamExcessBytes = 0;
    m_currentBuildIsV2 = v2Build;
    m_pendingElfPath = outputPath;
    m_pendingAppPath = appOutputPath;
    m_pendingAsmPath = asmOutputPath;
    m_compilerProcess->setWorkingDirectory(buildPath);

    if (v2Build) {
        // Unlike bare-metal GCC's final link (which produced ET_EXEC on the
        // tested GCC 9.3.1 toolchain), LLVM LLD explicitly produces ET_DYN.
        // Use GCC only for compiling, preserving the bundled toolchain's
        // system headers and C language compatibility.
        m_v2CompilerPath = selectedCompiler;
        m_v2LinkerPath = v2LldPath;
        m_v2BuildDirectory = buildPath;
        m_v2CompileFlags = v2CompileFlags;
        m_v2CompileSources = sourceFiles;
        m_v2CompileSources.append(apiSourceFiles);
        m_v2CompileSources.removeDuplicates();
        m_v2CompiledObjects.clear();
        for (int i = 0; i < m_v2CompileSources.size(); ++i) {
            m_v2CompiledObjects.append(QDir(buildPath).filePath(
                QStringLiteral("v2_unit_%1.o").arg(i, 3, 10, QLatin1Char('0'))));
        }
        m_v2LinkArguments = {
            QStringLiteral("-pie"),
            QStringLiteral("-Bsymbolic"),
            QStringLiteral("--no-undefined"),
            QStringLiteral("--nostdlib"),
            QStringLiteral("--gc-sections"),
            QStringLiteral("--entry=applet_entry"),
            QStringLiteral("-T"), selectedLinkerScript,
            QStringLiteral("-Map=%1").arg(mapOutputPath)
        };
        m_v2LinkArguments.append(m_v2CompiledObjects);
        // All SDK/project objects precede the archive group. Keep CGARM and
        // optional SIDBOX archives inside one group to resolve cross-library
        // references without linking GNU/Newlib's non-PIC libc.
        m_v2LinkArguments << QStringLiteral("--start-group") << cgarmArchivePath;
        m_v2LinkArguments.append(libraryFiles);
        m_v2LinkArguments << QStringLiteral("--end-group");
        m_v2LinkArguments << QStringLiteral("-o") << outputPath;
        m_v2CompileIndex = 0;
        if (m_v2CompileSources.isEmpty()) {
            appendOutputLine(tr("CGARM has no C sources to compile."), OutputKind::Error);
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
            return;
        }
        m_buildStep = BuildStep::V2Compiling;
        appendOutputLine(tr("CGARM linker: %1 (LLVM LLD, true ET_DYN)")
            .arg(QDir::toNativeSeparators(v2LldPath)), OutputKind::Path);
        appendOutputLine(tr("CGARM library: %1")
            .arg(QDir::toNativeSeparators(cgarmArchivePath)), OutputKind::Path);
        appendOutputLine(tr("CGARM runtime: precompiled PIC libc; GNU/Newlib libc is NOT linked. "
                            "Unsupported dependencies will produce a linker error."), OutputKind::Warning);
        setCompileProgressStage(tr("Compiling applet and SDK PIC objects..."));
        QStringList compileArgs = m_v2CompileFlags;
        if (isResourceSource(m_v2CompileSources.first())) {
            compileArgs << QStringLiteral("-x") << QStringLiteral("c");
        }
        compileArgs << QStringLiteral("-c") << m_v2CompileSources.first()
                    << QStringLiteral("-o") << m_v2CompiledObjects.first();
        m_compilerProcess->start(m_v2CompilerPath, compileArgs);
    } else {
        m_buildStep = BuildStep::Linking;
        setCompileProgressStage(tr("Compiling & linking..."));
        m_compilerProcess->start(selectedCompiler, arguments);
    }
}




void MainWindow::openProjectFile(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);

    if (!item) {
        return;
    }

    const bool isFolder = item->data(0, Qt::UserRole + 1).toBool();
    const QString itemPath = item->data(0, Qt::UserRole).toString();

    if (isFolder) {
        item->setExpanded(!item->isExpanded());
        return;
    }

    if (!itemPath.isEmpty()) {
        openFile(itemPath);
    }
}

QString MainWindow::projectContextDirectory(QTreeWidgetItem *item) const
{
    if (m_projectPath.isEmpty()) {
        return {};
    }

    const QString projectRoot = QFileInfo(m_projectPath).absoluteFilePath();

    if (!item) {
        return projectRoot;
    }

    const QString itemPath = item->data(0, Qt::UserRole).toString();
    const bool isFolder = item->data(0, Qt::UserRole + 1).toBool();

    if (itemPath.isEmpty()) {
        return projectRoot;
    }

    QString directoryPath = isFolder
        ? QFileInfo(itemPath).absoluteFilePath()
        : QFileInfo(itemPath).absolutePath();

    /*
     * Files which live outside the project can appear as top-level items.
     * Do not create new project files beside those external files.
     */
    if (directoryPath != projectRoot
        && !directoryPath.startsWith(projectRoot + QDir::separator())) {
        directoryPath = projectRoot;
    }

    return directoryPath;
}

void MainWindow::moveProjectFile(const QString &sourceFilePath, const QString &targetDirectory)
{
    if (m_projectPath.isEmpty() || sourceFilePath.isEmpty()) {
        return;
    }

    const QString projectRoot = QFileInfo(m_projectPath).absoluteFilePath();
    const QString sourcePath = QFileInfo(sourceFilePath).absoluteFilePath();

    /*
     * External files may appear in the project tree, but dragging should never
     * silently relocate files from elsewhere on the machine.
     */
    if (sourcePath != projectRoot
        && !sourcePath.startsWith(projectRoot + QDir::separator())) {
        QMessageBox::information(
            this,
            tr("Move File"),
            tr("Only files inside the project folder can be moved by drag and drop."));
        refreshProjectFiles();
        return;
    }

    QString destinationDirectory = targetDirectory.isEmpty()
        ? projectRoot
        : QFileInfo(targetDirectory).absoluteFilePath();

    if (destinationDirectory != projectRoot
        && !destinationDirectory.startsWith(projectRoot + QDir::separator())) {
        destinationDirectory = projectRoot;
    }

    if (!QFileInfo(destinationDirectory).isDir()) {
        QMessageBox::warning(
            this,
            tr("Move File"),
            tr("The destination folder no longer exists."));
        refreshProjectFiles();
        return;
    }

    const QFileInfo sourceInfo(sourcePath);
    const QString destinationPath =
        QFileInfo(QDir(destinationDirectory).filePath(sourceInfo.fileName())).absoluteFilePath();

    /* Dropping onto the current folder is simply a no-op. */
    if (destinationPath == sourcePath) {
        refreshProjectFiles();
        return;
    }

    if (QFileInfo::exists(destinationPath)) {
        QMessageBox::warning(
            this,
            tr("Move File"),
            tr("A file named %1 already exists in that folder.").arg(sourceInfo.fileName()));
        refreshProjectFiles();
        return;
    }

    if (!QFile::rename(sourcePath, destinationPath)) {
        QMessageBox::warning(
            this,
            tr("Move File"),
            tr("Could not move %1 to %2.")
                .arg(QDir::toNativeSeparators(sourcePath),
                     QDir::toNativeSeparators(destinationDirectory)));
        refreshProjectFiles();
        return;
    }

    /* Update the explicit project-file list, if this file is stored there. */
    m_projectFilesInProject.removeAll(sourcePath);
    addProjectFile(destinationPath);

    /*
     * A .sbui is not a CodeEditor tab. Moving it without updating the live
     * designer leaves m_filePath pointing at the old location; saving then
     * recreates the old design and triggers duplicate-window diagnostics.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (QFileInfo(game->filePath()).absoluteFilePath() == sourcePath) {
                game->setFilePath(destinationPath);
                m_editorTabs->setTabToolTip(i, tr("V1 Game design\n%1").arg(QDir::toNativeSeparators(destinationPath)));
            }
            continue;
        }
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            if (QFileInfo(designer->filePath()).absoluteFilePath() == sourcePath) {
                designer->setFilePath(destinationPath);
                m_editorTabs->setTabToolTip(i,
                    tr("CoderGirl visual design\n%1")
                        .arg(QDir::toNativeSeparators(destinationPath)));
            }
            continue;
        }

        auto *editor = primaryEditorForTab(tab);
        if (editor
            && !editor->filePath().isEmpty()
            && QFileInfo(editor->filePath()).absoluteFilePath() == sourcePath) {
            unwatchEditorFile(editor);
            editor->setFilePath(destinationPath);
            watchEditorFile(editor);
            updateTabTitle(editor);
        }
    }

    refreshProjectFiles();
    refreshFunctionCompletions();

    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }

    statusBar()->showMessage(
        tr("File moved: %1").arg(displayPath(destinationPath)),
        4000);
}

void MainWindow::addExistingProjectFile()
{
    const QString baseDirectory = m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath;
    const QStringList filePaths = QFileDialog::getOpenFileNames(
        this,
        tr("Add File"),
        baseDirectory,
        tr("Project files (*.c *.h *.inc *.res *.txt *.md);;All files (*)"));

    if (filePaths.isEmpty()) {
        return;
    }

    for (const QString &filePath : filePaths) {
        addProjectFile(filePath);
    }

    refreshProjectFiles();
    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }
    statusBar()->showMessage(tr("File added to project"));
}

void MainWindow::createProjectFile()
{
    createProjectFileInDirectory(m_projectPath);
}

void MainWindow::createProjectFileInDirectory(const QString &directoryPath)
{
    if (m_projectPath.isEmpty()) {
        QMessageBox::information(this, tr("Create File"), tr("Save or create a project first so the IDE knows which folder to use."));
        return;
    }

    QString targetDirectory = directoryPath.isEmpty()
        ? QFileInfo(m_projectPath).absoluteFilePath()
        : QFileInfo(directoryPath).absoluteFilePath();

    const QString projectRoot = QFileInfo(m_projectPath).absoluteFilePath();
    if (targetDirectory != projectRoot
        && !targetDirectory.startsWith(projectRoot + QDir::separator())) {
        targetDirectory = projectRoot;
    }

    if (!QFileInfo(targetDirectory).isDir()) {
        QMessageBox::warning(this, tr("Create File"), tr("The selected project folder no longer exists."));
        return;
    }

    bool accepted = false;
    QString fileName = QInputDialog::getText(
        this,
        tr("Create File"),
        tr("File name:"),
        QLineEdit::Normal,
        QStringLiteral("newfile.c"),
        &accepted).trimmed();

    if (!accepted || fileName.isEmpty()) {
        return;
    }

    if (QFileInfo(fileName).suffix().isEmpty()) {
        fileName.append(QStringLiteral(".c"));
    }

    if (QFileInfo(fileName).fileName() != fileName) {
        QMessageBox::warning(this, tr("Create File"), tr("Enter a file name, not a path."));
        return;
    }

    const QString filePath = QFileInfo(QDir(targetDirectory).filePath(fileName)).absoluteFilePath();

    if (!isProjectExplorerFile(filePath)) {
        QMessageBox::warning(this, tr("Create File"), tr("Use one of these extensions: .c, .h, .inc, .res, .txt, .md"));
        return;
    }

    if (QFileInfo::exists(filePath)) {
        QMessageBox::warning(this, tr("Create File"), tr("That file already exists."));
        return;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Create File"), tr("Could not create %1.").arg(QDir::toNativeSeparators(filePath)));
        return;
    }
    file.close();

    addProjectFile(filePath);
    refreshProjectFiles();
    openFile(filePath);

    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }

    statusBar()->showMessage(tr("File created: %1").arg(displayPath(filePath)));
}

void MainWindow::createResourceFile()
{
    createResourceFileInDirectory(m_projectPath);
}

void MainWindow::createResourceFileInDirectory(const QString &directoryPath)
{
    if (m_projectPath.isEmpty()) {
        QMessageBox::information(
            this,
            tr("Create Resource"),
            tr("Save or create a project first so the IDE knows which folder to use."));
        return;
    }

    QString targetDirectory = directoryPath.isEmpty()
        ? QFileInfo(m_projectPath).absoluteFilePath()
        : QFileInfo(directoryPath).absoluteFilePath();

    const QString projectRoot = QFileInfo(m_projectPath).absoluteFilePath();
    if (targetDirectory != projectRoot
        && !targetDirectory.startsWith(projectRoot + QDir::separator())) {
        targetDirectory = projectRoot;
    }

    if (!QFileInfo(targetDirectory).isDir()) {
        QMessageBox::warning(
            this, tr("Create Resource"), tr("The selected project folder no longer exists."));
        return;
    }

    bool accepted = false;
    QString fileName = QInputDialog::getText(
        this,
        tr("Create Resource"),
        tr("Resource file name:"),
        QLineEdit::Normal,
        QStringLiteral("resource.res"),
        &accepted).trimmed();

    if (!accepted || fileName.isEmpty()) {
        return;
    }

    if (QFileInfo(fileName).suffix().isEmpty()) {
        fileName.append(QStringLiteral(".res"));
    }

    if (QFileInfo(fileName).suffix().compare(
            QStringLiteral("res"), Qt::CaseInsensitive) != 0) {
        QMessageBox::warning(
            this, tr("Create Resource"), tr("Sidbox resource source files use the .res extension."));
        return;
    }

    if (QFileInfo(fileName).fileName() != fileName) {
        QMessageBox::warning(this, tr("Create Resource"), tr("Enter a file name, not a path."));
        return;
    }

    const QString filePath =
        QFileInfo(QDir(targetDirectory).filePath(fileName)).absoluteFilePath();

    if (QFileInfo::exists(filePath)) {
        QMessageBox::warning(this, tr("Create Resource"), tr("That resource file already exists."));
        return;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(
            this,
            tr("Create Resource"),
            tr("Could not create %1.").arg(QDir::toNativeSeparators(filePath)));
        return;
    }

    const QByteArray header =
        "/*\n"
        " * SIDBOX RESOURCE SOURCE\n"
        " *\n"
        " * This file contains C resource data. Sidbox IDE compiles .res\n"
        " * files as C, but deliberately excludes them from IntelliSense,\n"
        " * project symbol analysis and heavyweight syntax analysis.\n"
        " */\n\n";

    file.write(header);
    file.close();

    addProjectFile(filePath);
    refreshProjectFiles();
    openFile(filePath);

    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }

    statusBar()->showMessage(
        tr("Resource created: %1").arg(displayPath(filePath)),
        4000);
}

void MainWindow::createProjectFolderInDirectory(const QString &directoryPath)
{
    if (m_projectPath.isEmpty()) {
        QMessageBox::information(this, tr("Create Folder"), tr("Save or create a project first so the IDE knows which folder to use."));
        return;
    }

    QString targetDirectory = directoryPath.isEmpty()
        ? QFileInfo(m_projectPath).absoluteFilePath()
        : QFileInfo(directoryPath).absoluteFilePath();

    const QString projectRoot = QFileInfo(m_projectPath).absoluteFilePath();
    if (targetDirectory != projectRoot
        && !targetDirectory.startsWith(projectRoot + QDir::separator())) {
        targetDirectory = projectRoot;
    }

    if (!QFileInfo(targetDirectory).isDir()) {
        QMessageBox::warning(this, tr("Create Folder"), tr("The selected project folder no longer exists."));
        return;
    }

    bool accepted = false;
    const QString folderName = QInputDialog::getText(
        this,
        tr("Create Folder"),
        tr("Folder name:"),
        QLineEdit::Normal,
        QStringLiteral("NewFolder"),
        &accepted).trimmed();

    if (!accepted || folderName.isEmpty()) {
        return;
    }

    if (folderName == QStringLiteral(".")
        || folderName == QStringLiteral("..")
        || QFileInfo(folderName).fileName() != folderName) {
        QMessageBox::warning(this, tr("Create Folder"), tr("Enter a folder name, not a path."));
        return;
    }

    const QString folderPath = QFileInfo(QDir(targetDirectory).filePath(folderName)).absoluteFilePath();

    if (QFileInfo::exists(folderPath)) {
        QMessageBox::warning(this, tr("Create Folder"), tr("That folder already exists."));
        return;
    }

    QDir parentDirectory(targetDirectory);
    if (!parentDirectory.mkdir(folderName)) {
        QMessageBox::warning(this, tr("Create Folder"), tr("Could not create %1.").arg(QDir::toNativeSeparators(folderPath)));
        return;
    }

    refreshProjectFiles();
    statusBar()->showMessage(tr("Folder created: %1").arg(displayPath(folderPath)));
}

void MainWindow::removeSelectedProjectFile()
{
    QTreeWidgetItem *item = m_projectFiles->currentItem();
    if (!item) {
        return;
    }

    if (item->data(0, Qt::UserRole + 1).toBool()) {
        return;
    }

    const QString filePath = item->data(0, Qt::UserRole).toString();
    if (filePath.isEmpty()) {
        return;
    }

    const bool inProjectFolder = !m_projectPath.isEmpty()
        && QFileInfo(filePath).absoluteFilePath().startsWith(QFileInfo(m_projectPath).absoluteFilePath() + QDir::separator());

    QMessageBox box(this);
    box.setWindowTitle(tr("Remove File"));
    box.setText(tr("Remove %1?").arg(displayPath(filePath)));
    QPushButton *removeButton = box.addButton(inProjectFolder ? tr("Delete File") : tr("Remove From Project"), QMessageBox::DestructiveRole);
    box.addButton(QMessageBox::Cancel);
    box.exec();

    if (box.clickedButton() != removeButton) {
        return;
    }

    if (inProjectFolder && QFileInfo::exists(filePath) && !QFile::remove(filePath)) {
        QMessageBox::warning(this, tr("Remove File"), tr("Could not delete %1.").arg(QDir::toNativeSeparators(filePath)));
        return;
    }

    m_projectFilesInProject.removeAll(QFileInfo(filePath).absoluteFilePath());
    for (int i = m_editorTabs->count() - 1; i >= 0; --i) {
        QWidget *widget = m_editorTabs->widget(i);
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(widget)) {
            if (QFileInfo(game->filePath()).absoluteFilePath() == QFileInfo(filePath).absoluteFilePath()) {
                m_editorTabs->removeTab(i); widget->deleteLater(); continue;
            }
        }
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(widget)) {
            if (QFileInfo(designer->filePath()).absoluteFilePath() == QFileInfo(filePath).absoluteFilePath()) {
                m_editorTabs->removeTab(i);
                widget->deleteLater();
                continue;
            }
        }
        auto *editor = primaryEditorForTab(widget);
        if (editor && !editor->filePath().isEmpty()
            && QFileInfo(editor->filePath()).absoluteFilePath() == QFileInfo(filePath).absoluteFilePath()) {
            unwatchEditorFile(editor);
            m_editorTabs->removeTab(i);
            widget->deleteLater();
        }
    }

    // Remove can be triggered from a QMenu::exec() on the project tree.
    // Rebuilding that tree synchronously destroys the selected item while
    // QMenu/Qt may still be dispatching the originating QAction event.
    // Finish project-bookkeeping first, then rebuild after the menu unwinds.
    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }
    QTimer::singleShot(0, this, [this]() {
        refreshProjectFiles();
    });
    statusBar()->showMessage(tr("File removed"));
}

void MainWindow::renameSelectedProjectFile()
{
    QTreeWidgetItem *item = m_projectFiles->currentItem();
    if (!item) {
        return;
    }

    if (item->data(0, Qt::UserRole + 1).toBool()) {
        return;
    }

    const QString oldPath = item->data(0, Qt::UserRole).toString();
    const QFileInfo oldInfo(oldPath);
    if (!oldInfo.exists()) {
        return;
    }

    bool accepted = false;
    const QString newName = QInputDialog::getText(
        this,
        tr("Rename File"),
        tr("New name:"),
        QLineEdit::Normal,
        oldInfo.fileName(),
        &accepted).trimmed();

    if (!accepted || newName.isEmpty() || newName == oldInfo.fileName()) {
        return;
    }

    if (QFileInfo(newName).fileName() != newName) {
        QMessageBox::warning(this, tr("Rename File"), tr("Enter a file name, not a path."));
        return;
    }

    const QString newPath = QFileInfo(oldInfo.dir().filePath(newName)).absoluteFilePath();
    if (!isProjectExplorerFile(newPath)) {
        QMessageBox::warning(this, tr("Rename File"), tr("Use one of these extensions: .c, .h, .inc, .res, .txt, .md, .sbui, .sbgm, .uis"));
        return;
    }

    if (QFileInfo::exists(newPath)) {
        QMessageBox::warning(this, tr("Rename File"), tr("A file with that name already exists."));
        return;
    }

    if (!QFile::rename(oldPath, newPath)) {
        QMessageBox::warning(this, tr("Rename File"), tr("Could not rename %1.").arg(QDir::toNativeSeparators(oldPath)));
        return;
    }

    m_projectFilesInProject.removeAll(oldInfo.absoluteFilePath());
    addProjectFile(newPath);

    for (int i = m_editorTabs->count() - 1; i >= 0; --i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (QFileInfo(game->filePath()).absoluteFilePath() == oldInfo.absoluteFilePath()) {
                game->setFilePath(newPath);
                m_editorTabs->setTabToolTip(i, tr("V1 Game design\n%1").arg(QDir::toNativeSeparators(newPath)));
            }
            continue;
        }
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            if (QFileInfo(designer->filePath()).absoluteFilePath() == oldInfo.absoluteFilePath()) {
                designer->setFilePath(newPath);
                m_editorTabs->setTabToolTip(i,
                    tr("CoderGirl visual design\n%1")
                        .arg(QDir::toNativeSeparators(newPath)));
                continue;
            }
        }
        auto *editor = primaryEditorForTab(tab);
        if (editor && !editor->filePath().isEmpty()
            && QFileInfo(editor->filePath()).absoluteFilePath() == oldInfo.absoluteFilePath()) {
            unwatchEditorFile(editor);
            editor->setFilePath(newPath);
            watchEditorFile(editor);
            updateTabTitle(editor);
        }
    }

    refreshProjectFiles();
    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }
    statusBar()->showMessage(tr("File renamed: %1").arg(displayPath(newPath)));
}

void MainWindow::setCompileProgressStage(const QString &text)
{
    /*
     * The status message changes immediately so even lightning-fast builds
     * have useful feedback. The animated bar itself is delayed to avoid a
     * distracting flash when the whole build completes almost instantly.
     */
    statusBar()->showMessage(text);

    if (m_compileProgressBar) {
        m_compileProgressBar->setFormat(text);

        if (m_compileProgressBar->isVisible()) {
            return;
        }
    }

    if (m_compileProgressDelayTimer
        && !m_compileProgressDelayTimer->isActive()) {
        m_compileProgressDelayTimer->start();
    }
}

void MainWindow::finishCompileProgress()
{
    if (m_compileProgressDelayTimer) {
        m_compileProgressDelayTimer->stop();
    }

    if (m_compileProgressBar) {
        m_compileProgressBar->hide();
        m_compileProgressBar->setFormat(tr("Compiling..."));
    }
}

void MainWindow::handleCompilerFinished(int exitCode)
{
    if ((m_buildStep == BuildStep::Linking || m_buildStep == BuildStep::V2Compiling ||
         m_buildStep == BuildStep::V2CliBuilding ||
         m_buildStep == BuildStep::V2CliProbe ||
         m_buildStep == BuildStep::V2CliRelink ||
         m_buildStep == BuildStep::V2CliAsm)
        && !m_compilerStderrBuffer.isEmpty()) {
        const QString finalLine = m_compilerStderrBuffer.toLower();
        if (m_buildStep == BuildStep::V2CliBuilding &&
            m_v2Linker == QStringLiteral("cgarm")) {
            const qint64 excess = cgarmRamOverflowBytes(m_compilerStderrBuffer);
            if (excess > 0) {
                m_v2CgarmRamExcessBytes = excess;
                m_buildLinkSizeOverflow = true;
            }
        }
        if (finalLine.contains(QStringLiteral("v2 code + bss + reserved stack + heap exceed applet allowance"))
            || finalLine.contains(QStringLiteral("applet image exceeds selected app size"))
            || (finalLine.contains(QStringLiteral("applet"))
                && finalLine.contains(QStringLiteral("region"))
                && (finalLine.contains(QStringLiteral("overflowed"))
                    || finalLine.contains(QStringLiteral("will not fit"))))) {
            m_buildLinkSizeOverflow = true;
        }
        appendOutputLine(
            m_compilerStderrBuffer,
            compilerOutputKindForLine(m_compilerStderrBuffer));
        processCompilerDiagnosticLine(m_compilerStderrBuffer);
        m_compilerStderrBuffer.clear();
    }

    // CGARM V2 through the standalone cgarm-build backend. The CLI already
    // compiles, links, checks ET_DYN and packs; never pack the same ELF twice.
    if (m_buildStep == BuildStep::V2CliBuilding ||
        m_buildStep == BuildStep::V2CliRelink ||
        m_buildStep == BuildStep::V2CliProbe) {
        const BuildStep completed = m_buildStep;
        const auto failure = [this](const QString &message) {
            appendOutputLine(message, OutputKind::Error);
            m_buildStep = BuildStep::None;
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
        };
        const auto runLinkOnly = [this](int allowanceKb, bool probe) {
            m_compilerStderrBuffer.clear();
            m_compilerProcess->setWorkingDirectory(m_projectPath);
            m_buildStep = probe ? BuildStep::V2CliProbe : BuildStep::V2CliRelink;
            setCompileProgressStage(probe
                ? tr("Measuring CGARM applet RAM (6080 KB probe)...")
                : tr("Relinking resized CGARM applet..."));
            QStringList cliArgs = {
                m_projectFilePath, QStringLiteral("-o"), m_pendingAppPath,
                QStringLiteral("--sdk"), ideLibsPath(),
                QStringLiteral("--app-kb"), QString::number(allowanceKb),
                QStringLiteral("--heap-kb"), QString::number(m_v2HeapKb),
                QStringLiteral("--stack-kb"), QString::number(m_v2StackKb),
                QStringLiteral("--linker"), m_v2Linker,
                QStringLiteral("--link-only")
            };
            // The 6080 KiB probe must NOT overwrite a working .app.
            if (probe) cliArgs << QStringLiteral("--no-pack");
            m_compilerProcess->start(m_v2CliPath, cliArgs);
        };

        // Both CGARM's precise overflow diagnostic and LLVM's sizing probe
        // use the same user-approved update + link-only retry. No .app is
        // replaced until the V2 packer validates a successful new link.
        const auto offerResize = [this, &failure, &runLinkOnly](int minimumKb) {
            if (minimumKb <= m_appSizeKb || minimumKb > V2MaxAppletKiB) {
                failure(tr("Measured minimum RAM %1 KB cannot fit a larger valid allowance (maximum 6080 KB).")
                        .arg(minimumKb));
                QMessageBox::warning(this, tr("Applet RAM limit exceeded"),
                    tr("This applet needs at least %1 KB of RAM. At the default link base the available virtual SDRAM span is 6080 KB. "
                       "Reduce the applet's memory usage or change its heap/stack requirements.")
                        .arg(minimumKb));
                return;
            }
            const int marginKb = qMax(8, (minimumKb + 9) / 10);
            const int recommendedKb = qMin(V2MaxAppletKiB, ((minimumKb + marginKb + 15) / 16) * 16);
            QMessageBox suggestion(this);
            suggestion.setIcon(QMessageBox::Question);
            suggestion.setWindowTitle(tr("Resize V2 applet?"));
            suggestion.setText(tr("This applet needs at least %1 KB of RAM.").arg(minimumKb));
            suggestion.setInformativeText(
                tr("Current allowance: %1 KB\nRecommended allowance: %2 KB\n"
                   "Reserved heap: %3 KB; private callback stack: %4 KB\n\n"
                   "Update Project Settings and relink WITHOUT recompiling? "
                   "At the default link base, the 6 MiB SDRAM region permits up to 6080 KB; music buffers share this RAM.")
                    .arg(m_appSizeKb).arg(recommendedKb).arg(m_v2HeapKb).arg(m_v2StackKb));
            QPushButton *resizeButton = suggestion.addButton(
                tr("Resize to %1 KB and relink").arg(recommendedKb),
                QMessageBox::AcceptRole);
            suggestion.addButton(tr("Keep current size"), QMessageBox::RejectRole);
            suggestion.exec();
            if (suggestion.clickedButton() != resizeButton) {
                failure(tr("Applet RAM resize declined; existing .app left untouched."));
                return;
            }
            const int previousKb = m_appSizeKb;
            m_appSizeKb = recommendedKb;
            QString linkerError;
            if (!updateProjectLinkerScript(&linkerError) ||
                !saveProjectFile(m_projectFilePath)) {
                m_appSizeKb = previousKb;
                updateProjectLinkerScript(nullptr);
                saveProjectFile(m_projectFilePath);
                failure(tr("Could not save resized V2 project: %1").arg(linkerError));
                return;
            }
            appendOutputLine(tr("V2: new allowance %1 KB; re-linking existing PIC objects...")
                             .arg(recommendedKb), OutputKind::Success);
            m_v2AutoResizeRetried = true;
            runLinkOnly(recommendedKb, false);
        };

        // Our linker reports the *exact* shortage. Do not run the old
        // LLVM-oriented 6080 KB probe: CGARM's ET_DYN has no GNU .symtab,
        // so arm-none-eabi-nm cannot reliably measure it. Ask directly.
        if (completed == BuildStep::V2CliBuilding && exitCode != 0 &&
            m_v2Linker == QStringLiteral("cgarm") &&
            m_v2CgarmRamExcessBytes > 0 && !m_v2AutoResizeRetried &&
            m_linkerScriptPath.isEmpty()) {
            // Don't let corrupt/tool-generated enormous numbers overflow our
            // arithmetic. Anything above the 6080 KB SDRAM-boundary maximum is rejected.
            const qint64 availableExtra = qMax<qint64>(0, qint64(V2MaxAppletKiB - m_appSizeKb) * 1024);
            const bool aboveLimit = m_v2CgarmRamExcessBytes > availableExtra;
            const qint64 requiredBytes = aboveLimit ? qint64(V2MaxAppletKiB + 1) * 1024
                : qint64(m_appSizeKb) * 1024 + m_v2CgarmRamExcessBytes;
            const qint64 minimumKb = (requiredBytes + 1023) / 1024;
            appendOutputLine(aboveLimit
                ? tr("CGARM: current RAM allowance is short by %1 bytes; "
                     "the 6080 KB SDRAM-region limit cannot accommodate this build.")
                    .arg(m_v2CgarmRamExcessBytes)
                : tr("CGARM: current allowance is short by %1 bytes; "
                     "minimum required %2 KB.")
                    .arg(m_v2CgarmRamExcessBytes).arg(minimumKb), OutputKind::Warning);
            offerResize(int(qMin<qint64>(minimumKb, V2MaxAppletKiB + 1)));
            return;
        }

        if (completed == BuildStep::V2CliBuilding && exitCode != 0 &&
            m_v2Linker != QStringLiteral("cgarm") &&
            m_buildLinkSizeOverflow && !m_v2AutoResizeRetried &&
            m_linkerScriptPath.isEmpty() && m_appSizeKb < V2MaxAppletKiB) {
            appendOutputLine(tr("CGARM: applet too large. Re-linking existing objects against 6080 KB to measure RAM."),
                             OutputKind::Header);
            m_v2AutoResizeRetried = true;
            runLinkOnly(V2MaxAppletKiB, true);
            return;
        }
        if (completed == BuildStep::V2CliProbe) {
            if (exitCode != 0) {
                failure(tr("CGARM: even the 6080 KB sizing probe failed. No application was published."));
                return;
            }
            // Match the original Qt IDE's ELF RAM measurement: .stack is
            // included in __stack_end__, while the bounded heap is additional.
            QString nmExecutable = compilerPath();
            if (nmExecutable.endsWith(QStringLiteral("gcc"))) {
                nmExecutable.chop(3);
                nmExecutable += QStringLiteral("nm");
            } else if (nmExecutable.endsWith(QStringLiteral("gcc.exe"))) {
                nmExecutable.chop(7);
                nmExecutable += QStringLiteral("nm.exe");
            }
            QProcess nm;
            nm.start(nmExecutable, {QStringLiteral("-n"), m_pendingElfPath});
            if (!nm.waitForStarted(3000) || !nm.waitForFinished(3000) ||
                nm.exitStatus() != QProcess::NormalExit || nm.exitCode() != 0) {
                failure(tr("CGARM: could not measure probe ELF with arm-none-eabi-nm."));
                return;
            }
            const QString symbols = QString::fromLocal8Bit(nm.readAllStandardOutput());
            const QRegularExpression expr(
                QStringLiteral(R"(^([0-9a-fA-F]+)\s+[A-Za-z]\s+(_appstart|__stack_end__)\s*$)"),
                QRegularExpression::MultilineOption);
            quint64 begin = 0, end = 0;
            bool haveBegin = false, haveEnd = false;
            auto matches = expr.globalMatch(symbols);
            while (matches.hasNext()) {
                const auto match = matches.next();
                bool ok = false;
                const quint64 addr = match.captured(1).toULongLong(&ok, 16);
                if (!ok) continue;
                if (match.captured(2) == QStringLiteral("_appstart")) {
                    begin = addr; haveBegin = true;
                } else {
                    end = addr; haveEnd = true;
                }
            }
            if (!haveBegin || !haveEnd || end < begin) {
                failure(tr("CGARM: probe ELF lacks usable _appstart / __stack_end__ symbols."));
                return;
            }
            const quint64 requiredBytes = end - begin + quint64(m_v2HeapKb) * 1024ULL;
            const int minimumKb = int((requiredBytes + 1023ULL) / 1024ULL);
            offerResize(minimumKb);
            return;
        }
        if (exitCode != 0) {
            failure(tr("cgarm-build failed (exit %1). See the compiler/linker diagnostics above.")
                    .arg(exitCode));
            if (completed == BuildStep::V2CliBuilding && m_buildLinkSizeOverflow) {
                appendOutputLine(tr("Applet RAM limit exceeded. Review Project Settings (maximum 6080 KB)."),
                                 OutputKind::Warning);
            }
            return;
        }
        if (!QFileInfo(m_pendingAppPath).isFile() ||
            !QFileInfo(m_pendingElfPath).isFile()) {
            failure(tr("cgarm-build exited successfully, but its .app or .elf is missing."));
            return;
        }
        appendOutputLine(tr("CGARM V2 applet built: %1 (%2 bytes)")
            .arg(QDir::toNativeSeparators(m_pendingAppPath))
            .arg(QLocale().toString(QFileInfo(m_pendingAppPath).size())),
            OutputKind::Success);
        // Keep the RAM usage line that existed in the IDE-native V2 compiler.
        // The packer allocates the bounded heap outside the linked ELF image.
        QString nmTool = compilerPath();
        if (nmTool.endsWith(QStringLiteral("gcc"))) {
            nmTool.chop(3); nmTool += QStringLiteral("nm");
        } else if (nmTool.endsWith(QStringLiteral("gcc.exe"))) {
            nmTool.chop(7); nmTool += QStringLiteral("nm.exe");
        }
        QProcess nm;
        nm.start(nmTool, {QStringLiteral("-n"), m_pendingElfPath});
        if (nm.waitForStarted(3000) && nm.waitForFinished(3000) &&
            nm.exitStatus() == QProcess::NormalExit && nm.exitCode() == 0) {
            const QRegularExpression symbolsExpr(
                QStringLiteral(R"(^([0-9a-fA-F]+)\s+[A-Za-z]\s+(_appstart|__stack_end__)\s*$)"),
                QRegularExpression::MultilineOption);
            const QString symbols = QString::fromLocal8Bit(nm.readAllStandardOutput());
            quint64 first = 0, last = 0;
            bool haveFirst = false, haveLast = false;
            auto entries = symbolsExpr.globalMatch(symbols);
            while (entries.hasNext()) {
                const auto entry = entries.next();
                bool ok = false;
                const quint64 address = entry.captured(1).toULongLong(&ok, 16);
                if (!ok) continue;
                if (entry.captured(2) == QStringLiteral("_appstart")) {
                    first = address; haveFirst = true;
                } else {
                    last = address; haveLast = true;
                }
            }
            if (haveFirst && haveLast && last >= first) {
                const qint64 used = qint64(last - first) + qint64(m_v2HeapKb) * 1024;
                const qint64 limit = qint64(m_appSizeKb) * 1024;
                appendOutputLine(tr("Applet RAM: %1 / %2 used (%3%); %4 free (includes stack reserve and bounded heap)")
                    .arg(formattedFileSize(used)).arg(formattedFileSize(limit))
                    .arg(limit ? qRound(100.0 * used / limit) : 0)
                    .arg(formattedFileSize(qMax(qint64(0), limit - used))),
                    used * 100 >= limit * 90 ? OutputKind::Warning : OutputKind::Success);
            }
        }
        // Preserve the IDE's established build/<project>.asm output.
        QString objdumpExec = objcopyPath();
        objdumpExec.replace(QStringLiteral("objcopy"), QStringLiteral("objdump"));
        if (!QFileInfo(objdumpExec).isExecutable()) {
            failure(tr("Cannot generate .asm: missing arm-none-eabi-objdump: %1")
                    .arg(objdumpExec));
            return;
        }
        appendOutputLine(tr("Generating .asm output..."), OutputKind::Header);
        m_compilerProcess->setWorkingDirectory(m_projectPath);
        m_compilerProcess->setStandardOutputFile(m_pendingAsmPath);
        m_buildStep = BuildStep::V2CliAsm;
        setCompileProgressStage(tr("Generating assembly..."));
        m_compilerProcess->start(objdumpExec, {
            QStringLiteral("-d"), QStringLiteral("-S"), m_pendingElfPath
        });
        return;
    }

    if (m_buildStep == BuildStep::V2CliAsm) {
        m_compilerProcess->setStandardOutputFile(QString());
        if (exitCode != 0) {
            appendOutputLine(tr("CGARM .asm generation failed (exit %1); packed .app is available.")
                             .arg(exitCode), OutputKind::Warning);
        } else {
            appendOutputLine(tr("ASM generated: %1 (%2 bytes)")
                             .arg(QDir::toNativeSeparators(m_pendingAsmPath))
                             .arg(QLocale().toString(QFileInfo(m_pendingAsmPath).size())),
                             OutputKind::Success);
        }
        appendOutputLine(tr("Compile finished successfully."), OutputKind::Success);
        updateAppletMemoryPanel(this, true, m_appSizeKb, m_v2StackKb,
            m_v2HeapKb, true, m_pendingElfPath, m_pendingAppPath, m_v2BuildDirectory);
        m_buildStep = BuildStep::None;
        finishCompileProgress();
        statusBar()->showMessage(tr("Compile successful"));
        return;
    }

    if (m_buildStep == BuildStep::V2Compiling) {
        if (exitCode != 0) {
            appendOutputLine(tr("CGARM PIC compilation failed for %1 (exit %2).")
                .arg(QDir::toNativeSeparators(m_v2CompileSources.value(m_v2CompileIndex)))
                .arg(exitCode), OutputKind::Error);
            m_buildStep = BuildStep::None;
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
            return;
        }
        ++m_v2CompileIndex;
        if (m_v2CompileIndex < m_v2CompileSources.size()) {
            QStringList compileArgs = m_v2CompileFlags;
            if (isResourceSource(m_v2CompileSources.at(m_v2CompileIndex))) {
                compileArgs << QStringLiteral("-x") << QStringLiteral("c");
            }
            compileArgs << QStringLiteral("-c")
                        << m_v2CompileSources.at(m_v2CompileIndex)
                        << QStringLiteral("-o")
                        << m_v2CompiledObjects.at(m_v2CompileIndex);
            m_compilerProcess->start(m_v2CompilerPath, compileArgs);
            return;
        }
        appendOutputLine(tr("CGARM PIC objects compiled: %1")
            .arg(m_v2CompiledObjects.size()), OutputKind::Success);
        appendOutputLine(tr("Linking with LLVM LLD in PIE mode..."), OutputKind::Header);
        m_buildStep = BuildStep::Linking;
        setCompileProgressStage(tr("Linking CGARM ELF..."));
        m_compilerProcess->start(m_v2LinkerPath, m_v2LinkArguments);
        return;
    }

    if (m_buildStep == BuildStep::Linking) {
        if (exitCode != 0) {
            bool resizeDialogShown = false;

            // CGARM only: when the requested RAM is too small, link the ALREADY
            // compiled PIC objects once against a temporary 6080 KB region limit.
            // This provides a measured size without touching the project's .ld,
            // .proj, .elf, .map, or the normal V1/Gaming build paths.
            if (m_currentBuildIsV2 && m_buildLinkSizeOverflow &&
                !m_v2AutoResizeRetried && m_linkerScriptPath.isEmpty() &&
                m_appSizeKb < V2MaxAppletKiB) {
                appendOutputLine(tr("CGARM: measuring applet RAM requirement (6080 KB temporary link)..."),
                                 OutputKind::Header);
                QTemporaryDir tempDir(QDir(m_v2BuildDirectory).filePath(
                    QStringLiteral("cgarm-autosize-XXXXXX")));
                if (tempDir.isValid()) {
                    QFile sourceLinker(projectLinkerScriptPath());
                    if (sourceLinker.open(QIODevice::ReadOnly | QIODevice::Text)) {
                        QString probeScript = QString::fromUtf8(sourceLinker.readAll());
                        if (replaceLinkerAssignment(&probeScript,
                                QStringLiteral("_v2_app_limit"), hexBytes(V2MaxAppletKiB))) {
                            const QString scriptPath = tempDir.filePath(QStringLiteral("probe.ld"));
                            const QString elfPath = tempDir.filePath(QStringLiteral("probe.elf"));
                            const QString mapPath = tempDir.filePath(QStringLiteral("probe.map"));
                            QFile scriptFile(scriptPath);
                            if (scriptFile.open(QIODevice::WriteOnly | QIODevice::Text) &&
                                scriptFile.write(probeScript.toUtf8()) >= 0) {
                                scriptFile.close();
                                QStringList probeArgs = m_v2LinkArguments;
                                for (int i = 0; i < probeArgs.size(); ++i) {
                                    if (probeArgs.at(i) == QStringLiteral("-T") &&
                                        i + 1 < probeArgs.size()) {
                                        probeArgs[i + 1] = scriptPath;
                                        ++i;
                                    } else if (probeArgs.at(i) == QStringLiteral("-o") &&
                                               i + 1 < probeArgs.size()) {
                                        probeArgs[i + 1] = elfPath;
                                        ++i;
                                    } else if (probeArgs.at(i).startsWith(QStringLiteral("-Map="))) {
                                        probeArgs[i] = QStringLiteral("-Map=%1").arg(mapPath);
                                    }
                                }

                                QProcess probeLink;
                                probeLink.setWorkingDirectory(m_v2BuildDirectory);
                                probeLink.start(m_v2LinkerPath, probeArgs);
                                const bool probeOk = probeLink.waitForStarted(3000) &&
                                    probeLink.waitForFinished(15000) &&
                                    probeLink.exitStatus() == QProcess::NormalExit &&
                                    probeLink.exitCode() == 0;
                                if (probeOk) {
                                    QString nmExecutable = compilerPath();
                                    if (nmExecutable.endsWith(QStringLiteral("gcc"))) {
                                        nmExecutable.chop(3);
                                        nmExecutable += QStringLiteral("nm");
                                    } else if (nmExecutable.endsWith(QStringLiteral("gcc.exe"))) {
                                        nmExecutable.chop(7);
                                        nmExecutable += QStringLiteral("nm.exe");
                                    }
                                    QProcess nm;
                                    nm.start(nmExecutable, {QStringLiteral("-n"), elfPath});
                                    if (nm.waitForStarted(3000) && nm.waitForFinished(3000) &&
                                        nm.exitStatus() == QProcess::NormalExit && nm.exitCode() == 0) {
                                        const QString symbols = QString::fromLocal8Bit(nm.readAllStandardOutput());
                                        const QRegularExpression symbolPattern(
                                            QStringLiteral(R"(^([0-9a-fA-F]+)\s+[A-Za-z]\s+(_appstart|__stack_end__)\s*$)"),
                                            QRegularExpression::MultilineOption);
                                        quint64 start = 0, end = 0;
                                        bool haveStart = false, haveEnd = false;
                                        auto matches = symbolPattern.globalMatch(symbols);
                                        while (matches.hasNext()) {
                                            const auto match = matches.next();
                                            bool ok = false;
                                            const quint64 address = match.captured(1).toULongLong(&ok, 16);
                                            if (!ok) continue;
                                            if (match.captured(2) == QStringLiteral("_appstart")) {
                                                start = address;
                                                haveStart = true;
                                            } else {
                                                end = address;
                                                haveEnd = true;
                                            }
                                        }
                                        if (haveStart && haveEnd && end >= start) {
                                            const quint64 requiredBytes = end - start +
                                                quint64(m_v2HeapKb) * 1024ULL;
                                            const int minimumKb = int((requiredBytes + 1023ULL) / 1024ULL);
                                            if (minimumKb > m_appSizeKb && minimumKb <= V2MaxAppletKiB) {
                                                // 10% headroom (at least 8 KiB), rounded to 16 KiB.
                                                const int marginKb = qMax(8, (minimumKb + 9) / 10);
                                                const int wantedKb = minimumKb + marginKb;
                                                const int recommendedKb = qMin(V2MaxAppletKiB,
                                                    ((wantedKb + 15) / 16) * 16);
                                                resizeDialogShown = true;
                                                QMessageBox suggestion(this);
                                                suggestion.setIcon(QMessageBox::Question);
                                                suggestion.setWindowTitle(tr("Resize V2 applet?"));
                                                suggestion.setText(tr("This applet needs at least %1 KB of RAM.")
                                                    .arg(minimumKb));
                                                suggestion.setInformativeText(
                                                    tr("Current allowance: %1 KB\n"
                                                       "Recommended allowance: %2 KB\n"
                                                       "Reserved heap: %3 KB; private callback stack: %4 KB\n\n"
                                                       "Update Project Settings and relink without recompiling? "
                                                       "At the default link base, the 6 MiB SDRAM region permits up to 6080 KB; music buffers share this RAM.")
                                                        .arg(m_appSizeKb).arg(recommendedKb)
                                                        .arg(m_v2HeapKb).arg(m_v2StackKb));
                                                QPushButton *resizeButton = suggestion.addButton(
                                                    tr("Resize to %1 KB and relink").arg(recommendedKb),
                                                    QMessageBox::AcceptRole);
                                                suggestion.addButton(tr("Keep current size"), QMessageBox::RejectRole);
                                                suggestion.exec();
                                                if (suggestion.clickedButton() == resizeButton) {
                                                    const int previousKb = m_appSizeKb;
                                                    m_appSizeKb = recommendedKb;
                                                    QString scriptError;
                                                    if (updateProjectLinkerScript(&scriptError) &&
                                                        saveProjectFile(m_projectFilePath)) {
                                                        m_v2AutoResizeRetried = true;
                                                        m_buildLinkSizeOverflow = false;
                                                        appendOutputLine(tr("CGARM: applet allowance updated to %1 KB. Relinking existing PIC objects...")
                                                            .arg(recommendedKb), OutputKind::Success);
                                                        setCompileProgressStage(tr("Relinking resized CGARM applet..."));
                                                        m_compilerProcess->start(m_v2LinkerPath, m_v2LinkArguments);
                                                        return;
                                                    }
                                                    m_appSizeKb = previousKb;
                                                    updateProjectLinkerScript(nullptr);
                                                    saveProjectFile(m_projectFilePath);
                                                    appendOutputLine(tr("Could not save the new applet size: %1")
                                                        .arg(scriptError), OutputKind::Error);
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    appendOutputLine(tr("CGARM: the applet could not link even with the 6080 KB limit; automatic sizing is unavailable."),
                                                     OutputKind::Warning);
                                }
                            }
                        }
                    }
                }
            }

            appendOutputLine(tr("Link failed with exit code %1.").arg(exitCode), OutputKind::Error);
            m_buildStep = BuildStep::None;
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
            if (m_buildLinkSizeOverflow && !resizeDialogShown) {
                QMessageBox memoryWarning(this);
                memoryWarning.setIcon(QMessageBox::Warning);
                memoryWarning.setWindowTitle(tr("Applet memory limit exceeded"));
                memoryWarning.setText(
                    tr("The linker could not fit the applet into its allocated RAM."));
                memoryWarning.setInformativeText(
                    tr("Current applet allowance: %1 KB. The limit includes code, "
                       "embedded sounds, data, BSS and stack.\n\n"
                       "You can review Applet size in Project Settings. "
                       "Don't increase it beyond your reserved SDRAM layout.\n\n"
                       "The full linker error remains in the Build Output.")
                        .arg(m_appSizeKb));
                QPushButton *settingsButton = memoryWarning.addButton(
                    tr("Project Settings..."), QMessageBox::ActionRole);
                memoryWarning.addButton(QMessageBox::Close);
                memoryWarning.exec();
                if (memoryWarning.clickedButton() == settingsButton) {
                    showProjectSettings();
                }
            }
            return;
        }

        appendOutputLine(tr("Link finished successfully."), OutputKind::Success);

        // Validate the GCC-linked ELF *before* disassembly/packing.  A linker
        // that ignored PIE can emit ET_EXEC even when -fPIC compiled cleanly;
        // the V2 packer correctly refuses to reinterpret that file as ET_DYN.
        if (m_currentBuildIsV2) {
            QFile elf(m_pendingElfPath);
            if (!elf.open(QIODevice::ReadOnly)) {
                appendOutputLine(tr("V2 ELF check: cannot read the linked file: %1")
                    .arg(QDir::toNativeSeparators(m_pendingElfPath)), OutputKind::Error);
                m_buildStep = BuildStep::None;
                finishCompileProgress();
                statusBar()->showMessage(tr("Compile failed"));
                return;
            }
            const QByteArray header = elf.read(20);
            if (header.size() != 20 || !header.startsWith("\x7f" "ELF") ||
                quint8(header.at(4)) != 1 || quint8(header.at(5)) != 1) {
                appendOutputLine(tr("V2 ELF check: expected little-endian ELF32."), OutputKind::Error);
                m_buildStep = BuildStep::None;
                finishCompileProgress();
                statusBar()->showMessage(tr("Compile failed"));
                return;
            }
            const quint16 elfType = quint8(header.at(16)) |
                (quint16(quint8(header.at(17))) << 8);
            const quint16 elfMachine = quint8(header.at(18)) |
                (quint16(quint8(header.at(19))) << 8);
            const QString typeName = elfType == 3 ? QStringLiteral("ET_DYN") :
                elfType == 2 ? QStringLiteral("ET_EXEC") :
                QStringLiteral("other");
            appendOutputLine(tr("V2 ELF check: %1 (type %2), machine %3")
                .arg(typeName).arg(elfType).arg(elfMachine),
                elfType == 3 && elfMachine == 40 ? OutputKind::Success : OutputKind::Error);
            if (elfType != 3 || elfMachine != 40) {
                appendOutputLine(tr("V2 requires ARM ET_DYN. This build's linker produced "
                                    "an incompatible ELF despite the PIE request. No .app "
                                    "will be generated. The linker/toolchain configuration "
                                    "must be corrected; do not bypass the V2 packer check."),
                                 OutputKind::Error);
                m_buildStep = BuildStep::None;
                finishCompileProgress();
                statusBar()->showMessage(tr("Compile failed"));
                return;
            }
        }

        // Use linked symbols, not the on-disk .app size.  __stack_end__
        // includes the reserved stack; .app binary file size does not.
        QString nmExecutable = compilerPath();
        if (nmExecutable.endsWith(QStringLiteral("gcc"))) {
            nmExecutable.chop(3);
            nmExecutable += QStringLiteral("nm");
        } else if (nmExecutable.endsWith(QStringLiteral("gcc.exe"))) {
            nmExecutable.chop(7);
            nmExecutable += QStringLiteral("nm.exe");
        }
        if (QFileInfo::exists(nmExecutable)) {
            QProcess nm;
            nm.start(nmExecutable, {QStringLiteral("-n"), m_pendingElfPath});
            if (nm.waitForFinished(3000) && nm.exitStatus() == QProcess::NormalExit
                && nm.exitCode() == 0) {
                const QString symbols = QString::fromLocal8Bit(nm.readAllStandardOutput());
                const QRegularExpression entry(
                    QStringLiteral(R"(^([0-9a-fA-F]+)\s+[A-Za-z]\s+(_appstart|__stack_end__)\s*$)"),
                    QRegularExpression::MultilineOption);
                quint64 start = 0;
                quint64 end = 0;
                bool foundStart = false;
                bool foundEnd = false;
                auto matches = entry.globalMatch(symbols);
                while (matches.hasNext()) {
                    const QRegularExpressionMatch match = matches.next();
                    bool ok = false;
                    const quint64 address = match.captured(1).toULongLong(&ok, 16);
                    if (!ok) continue;
                    if (match.captured(2) == QStringLiteral("_appstart")) {
                        start = address;
                        foundStart = true;
                    } else {
                        end = address;
                        foundEnd = true;
                    }
                }
                if (foundStart && foundEnd && end >= start) {
                    // V2: the ELF includes reserved .stack, but the heap is an
                    // additional uninitialised allocation appended by the packer.
                    const qint64 used = qint64(end - start) +
                        (m_currentBuildIsV2 ? qint64(m_v2HeapKb) * 1024 : 0);
                    if (!m_linkerScriptPath.isEmpty()) {
                        appendOutputLine(
                            tr("Applet RAM used: %1 (including stack; custom linker controls the limit)")
                                .arg(formattedFileSize(used)),
                            OutputKind::Header);
                    } else {
                        const qint64 allowance = qint64(m_appSizeKb) * 1024;
                        appendOutputLine(
                            tr("Applet RAM: %1 / %2 used (%3%); %4 free (includes stack reserve%5)")
                                .arg(formattedFileSize(used))
                                .arg(formattedFileSize(allowance))
                                .arg(allowance > 0 ? qRound(100.0 * used / allowance) : 0)
                                .arg(formattedFileSize(qMax(qint64(0), allowance - used)))
                                .arg(m_currentBuildIsV2 ? tr(" and bounded heap") : QString()),
                            allowance > 0 && used * 100 >= allowance * 90
                                ? OutputKind::Warning : OutputKind::Success);
                    }
                }
            }
        }

        appendOutputLine(tr("Generating .asm output..."), OutputKind::Header);

        QString objdumpExec = objcopyPath();
        objdumpExec.replace(QStringLiteral("objcopy"), QStringLiteral("objdump"));

        m_buildStep = BuildStep::Asm;
        setCompileProgressStage(tr("Generating assembly..."));
        m_compilerProcess->setWorkingDirectory(m_projectPath);
        m_compilerProcess->setStandardOutputFile(m_pendingAsmPath);
        m_compilerProcess->start(objdumpExec, {
                                                  QStringLiteral("-d"),
                                                  QStringLiteral("-S"),
                                                  m_pendingElfPath
                                              });
        return;
    }

    if (m_buildStep == BuildStep::Asm) {
        m_compilerProcess->setStandardOutputFile(QString());

        if (exitCode != 0) {
            appendOutputLine(tr("ASM generation failed with exit code %1.").arg(exitCode), OutputKind::Error);
            m_buildStep = BuildStep::None;
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
            return;
        }

        const qint64 asmSize = QFileInfo(m_pendingAsmPath).size();
        appendOutputLine(tr("ASM generated: %1").arg(QDir::toNativeSeparators(m_pendingAsmPath)), OutputKind::Success);
        if (asmSize >= 0) {
            appendOutputLine(tr("ASM size: %1 bytes").arg(QLocale().toString(asmSize)), OutputKind::Success);
        }

        m_buildStep = BuildStep::Objcopy;
        setCompileProgressStage(tr("Creating applet..."));
        m_compilerProcess->setWorkingDirectory(m_projectPath);
        if (m_currentBuildIsV2) {
            appendOutputLine(tr("Packing and validating relocatable V2 ELF..."), OutputKind::Header);
            // Built from v2_packer.cpp at the IDE source root, but deployed
            // together with the other build tools under idelibs/tools/.
            // Never fall back to Python or to the legacy V1 objcopy path.
            const QString packerName =
#ifdef Q_OS_WIN
                QStringLiteral("sidbox-v2-packer.exe");
#else
                QStringLiteral("sidbox-v2-packer");
#endif
            const QString packerPath = QDir(ideLibsPath()).filePath(
                QStringLiteral("tools/") + packerName);
            const QFileInfo packerInfo(packerPath);
            if (!packerInfo.isFile() || !packerInfo.isExecutable()) {
                appendOutputLine(tr("Native V2 packer missing or not executable: %1. "
                                    "Rebuild SidboxIDE to stage it in idelibs/tools.")
                    .arg(QDir::toNativeSeparators(packerPath)), OutputKind::Error);
                m_buildStep = BuildStep::None;
                finishCompileProgress();
                statusBar()->showMessage(tr("Compile failed"));
                return;
            }
            // Passing --stack tells the Stage 6C loader to use its private
            // PSP bridge for window/timer callbacks.  The native packer checks
            // the ELF .stack reservation before marking the applet.
            m_compilerProcess->start(packerPath, {
                m_pendingElfPath, m_pendingAppPath,
                QStringLiteral("--heap"), QString::number(m_v2HeapKb * 1024),
                QStringLiteral("--stack"), QString::number(m_v2StackKb * 1024)
            });
        } else {
            appendOutputLine(tr("Generating legacy V1 .app binary..."), OutputKind::Header);
            m_compilerProcess->start(objcopyPath(), {
                QStringLiteral("-O"), QStringLiteral("binary"),
                m_pendingElfPath, m_pendingAppPath
            });
        }
        return;
    }

    if (m_buildStep == BuildStep::Objcopy) {
        if (exitCode != 0) {
            appendOutputLine(m_currentBuildIsV2
                ? tr("V2 packer rejected this ELF (exit %1). Inspect relocation errors; V1 remains available.").arg(exitCode)
                : tr("Objcopy failed with exit code %1.").arg(exitCode), OutputKind::Error);
            // Keep any previously working .app; the packer only publishes on success.
            // Do not leave an incomplete or mislabelled V2 image behind.
            m_buildStep = BuildStep::None;
            finishCompileProgress();
            statusBar()->showMessage(tr("Compile failed"));
            return;
        }

        const qint64 appSize = QFileInfo(m_pendingAppPath).size();
        appendOutputLine(tr("%1 APP generated: %2")
            .arg(m_currentBuildIsV2 ? QStringLiteral("V2") : QStringLiteral("V1"),
                 QDir::toNativeSeparators(m_pendingAppPath)), OutputKind::Success);
        if (appSize >= 0) {
            appendOutputLine(tr("APP size: %1 bytes").arg(QLocale().toString(appSize)), OutputKind::Success);
        }


        appendOutputLine(tr("Compile finished successfully."), OutputKind::Success);
        updateAppletMemoryPanel(this, m_currentBuildIsV2,
            m_appSizeKb, m_v2StackKb, m_v2HeapKb, true,
            m_pendingElfPath, m_pendingAppPath,
            QFileInfo(m_pendingElfPath).absolutePath(),
            m_projectType == GameProjectType);
        m_buildStep = BuildStep::None;
        finishCompileProgress();
        statusBar()->showMessage(tr("Compile successful"));
        return;
    }

    m_buildStep = BuildStep::None;
    finishCompileProgress();
}

QList<CodeEditor *> MainWindow::editorsForTab(QWidget *tabWidget) const
{
    QList<CodeEditor *> editors;

    if (!tabWidget) {
        return editors;
    }

    if (auto *editor = qobject_cast<CodeEditor *>(tabWidget)) {
        editors.append(editor);
        return editors;
    }

    if (auto *splitter = qobject_cast<QSplitter *>(tabWidget)) {
        for (int i = 0; i < splitter->count(); ++i) {
            if (auto *editor =
                    qobject_cast<CodeEditor *>(splitter->widget(i))) {
                editors.append(editor);
            }
        }
    }

    return editors;
}

CodeEditor *MainWindow::primaryEditorForTab(QWidget *tabWidget) const
{
    const QList<CodeEditor *> editors = editorsForTab(tabWidget);
    return editors.isEmpty() ? nullptr : editors.first();
}

int MainWindow::tabIndexForEditor(CodeEditor *editor) const
{
    if (!editor || !m_editorTabs) {
        return -1;
    }

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        const QList<CodeEditor *> editors =
            editorsForTab(m_editorTabs->widget(i));

        if (editors.contains(editor)) {
            return i;
        }
    }

    return -1;
}

CodeEditor *MainWindow::activeEditor() const
{
    if (!m_editorTabs) {
        return nullptr;
    }

    QWidget *tabWidget = m_editorTabs->currentWidget();
    const QList<CodeEditor *> editors = editorsForTab(tabWidget);

    if (editors.isEmpty()) {
        return nullptr;
    }

    /*
     * In a split tab the editor which currently owns keyboard focus is the
     * active side.  This keeps line/column, Ctrl+Click, search jumps and other
     * editor actions naturally attached to the pane the programmer is using.
     */
    for (CodeEditor *editor : editors) {
        if (editor->hasFocus()
            || (editor->viewport() && editor->viewport()->hasFocus())) {
            return editor;
        }
    }

    return editors.first();
}

int MainWindow::editorSplitTabIndex() const
{
    if (!m_editorTabs) {
        return -1;
    }

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *splitter =
            qobject_cast<QSplitter *>(m_editorTabs->widget(i));

        if (splitter
            && splitter->objectName()
                == QStringLiteral("editorSplitView")) {
            return i;
        }
    }

    return -1;
}

QSplitter *MainWindow::editorSplitWidget() const
{
    const int index = editorSplitTabIndex();
    if (index < 0) {
        return nullptr;
    }

    return qobject_cast<QSplitter *>(
        m_editorTabs->widget(index));
}

CodeEditor *MainWindow::splitHostEditor(
    QSplitter *splitter) const
{
    if (!splitter) {
        return nullptr;
    }

    const QList<CodeEditor *> editors =
        editorsForTab(splitter);

    for (CodeEditor *editor : editors) {
        if (editor->property(
                "sidboxSplitHostEditor").toBool()) {
            return editor;
        }
    }

    return editors.isEmpty()
        ? nullptr
        : editors.first();
}

CodeEditor *MainWindow::splitSecondaryEditor(
    QSplitter *splitter) const
{
    if (!splitter) {
        return nullptr;
    }

    const QList<CodeEditor *> editors =
        editorsForTab(splitter);
    CodeEditor *host =
        splitHostEditor(splitter);

    for (CodeEditor *editor : editors) {
        if (editor != host) {
            return editor;
        }
    }

    return nullptr;
}

void MainWindow::updateEditorSplitPresentation()
{
    const int index = editorSplitTabIndex();
    QSplitter *splitter = editorSplitWidget();

    if (index < 0 || !splitter) {
        return;
    }

    CodeEditor *host = splitHostEditor(splitter);
    CodeEditor *secondary =
        splitSecondaryEditor(splitter);

    if (!host) {
        return;
    }

    QString title = tabTitleForEditor(host);
    QString tooltip = host->filePath();

    if (secondary
        && secondary->document() != host->document()) {
        title += QStringLiteral("  |  ");
        title += tabTitleForEditor(secondary);

        tooltip =
            tr("Split view:\n%1\n%2")
                .arg(
                    QDir::toNativeSeparators(
                        host->filePath()),
                    QDir::toNativeSeparators(
                        secondary->filePath()));
    }

    m_editorTabs->setTabText(index, title);
    m_editorTabs->setTabIcon(
        index,
        editorTabIconForFile(host->filePath()));
    m_editorTabs->setTabToolTip(index, tooltip);
}

void MainWindow::openCurrentTabInExistingSplit()
{
    const int splitIndex = editorSplitTabIndex();
    QSplitter *splitter = editorSplitWidget();

    if (splitIndex < 0 || !splitter) {
        toggleCurrentEditorSplit();
        return;
    }

    const int sourceTabIndex =
        m_editorTabs->currentIndex();

    if (sourceTabIndex < 0
        || sourceTabIndex == splitIndex) {
        return;
    }

    CodeEditor *sourceEditor =
        primaryEditorForTab(
            m_editorTabs->widget(sourceTabIndex));

    CodeEditor *host =
        splitHostEditor(splitter);
    CodeEditor *secondary =
        splitSecondaryEditor(splitter);

    if (!sourceEditor || !host || !secondary) {
        return;
    }

    QMessageBox sideBox(this);
    sideBox.setWindowTitle(tr("Open in Split"));
    sideBox.setText(
        tr("Which side should show %1?")
            .arg(
                QFileInfo(sourceEditor->filePath())
                    .fileName()));
    sideBox.setInformativeText(
        tr("The other side will keep %1.")
            .arg(
                QFileInfo(host->filePath())
                    .fileName()));

    QPushButton *leftButton =
        sideBox.addButton(
            tr("Left"),
            QMessageBox::AcceptRole);

    QPushButton *rightButton =
        sideBox.addButton(
            tr("Right"),
            QMessageBox::AcceptRole);

    sideBox.addButton(QMessageBox::Cancel);

    if (sideBox.exec() == QMessageBox::Cancel
        || !sideBox.clickedButton()) {
        return;
    }

    const bool sourceOnLeft =
        sideBox.clickedButton()
        == static_cast<QAbstractButton *>(
            leftButton);

    Q_UNUSED(rightButton);

    secondary->setProperty(
        "sidboxApiReference",
        sourceEditor->property(
            "sidboxApiReference"));
    secondary->shareDocumentFrom(sourceEditor);
    secondary->setTextCursor(
        sourceEditor->textCursor());
    secondary->verticalScrollBar()->setValue(
        sourceEditor->verticalScrollBar()->value());
    secondary->horizontalScrollBar()->setValue(
        sourceEditor->horizontalScrollBar()->value());
    secondary->setDiagnostics(
        sourceEditor->diagnostics());

    /*
     * Keep the split host's own live document on the opposite side.
     * The selected tab's live document is borrowed by the reusable secondary
     * view, so there is still only one document/save state for each file.
     */
    if (sourceOnLeft) {
        splitter->insertWidget(0, secondary);
    } else {
        splitter->insertWidget(1, secondary);
    }

    const int available =
        qMax(
            240,
            splitter->width()
                - splitter->handleWidth());

    splitter->setSizes(
        {
            available / 2,
            available - (available / 2)
        });

    m_editorTabs->setCurrentIndex(splitIndex);
    updateEditorSplitPresentation();

    secondary->setFocus();
    updateCursorPositionStatus();

    statusBar()->showMessage(
        tr("%1 opened in the %2 split")
            .arg(
                QFileInfo(sourceEditor->filePath())
                    .fileName(),
                sourceOnLeft
                    ? tr("left")
                    : tr("right")),
        3000);
}

void MainWindow::toggleCurrentEditorSplit()
{
    if (!m_editorTabs
        || m_editorTabs->currentIndex() < 0) {
        return;
    }

    const int index =
        m_editorTabs->currentIndex();

    QWidget *tabWidget =
        m_editorTabs->widget(index);

    QList<CodeEditor *> editors =
        editorsForTab(tabWidget);

    if (editors.isEmpty()) {
        statusBar()->showMessage(
            tr("This tab cannot be split"),
            2500);
        return;
    }

    const int existingSplitIndex =
        editorSplitTabIndex();

    if (existingSplitIndex >= 0
        && existingSplitIndex != index) {
        openCurrentTabInExistingSplit();
        return;
    }

    const QString tabText =
        m_editorTabs->tabText(index);
    const QIcon tabIcon =
        m_editorTabs->tabIcon(index);
    const QString tabToolTip =
        m_editorTabs->tabToolTip(index);

    if (auto *splitter =
            qobject_cast<QSplitter *>(tabWidget)) {
        CodeEditor *primary =
            splitHostEditor(splitter);
        CodeEditor *secondary =
            splitSecondaryEditor(splitter);

        if (!primary) {
            return;
        }

        if (secondary
            && activeEditor() == secondary
            && secondary->document()
                == primary->document()) {
            primary->setTextCursor(
                secondary->textCursor());
            primary->verticalScrollBar()->setValue(
                secondary->verticalScrollBar()->value());
            primary->horizontalScrollBar()->setValue(
                secondary->horizontalScrollBar()->value());
        }

        m_editorTabs->removeTab(index);
        primary->setParent(m_editorTabs);
        primary->setProperty(
            "sidboxSplitHostEditor",
            false);

        if (secondary) {
            secondary->deleteLater();
        }

        splitter->deleteLater();

        m_editorTabs->insertTab(
            index,
            primary,
            editorTabIconForFile(
                primary->filePath()),
            tabTitleForEditor(primary));

        m_editorTabs->setTabToolTip(
            index,
            primary->filePath());

        m_editorTabs->setCurrentIndex(index);

        primary->setFocus();
        updateCursorPositionStatus();

        statusBar()->showMessage(
            tr("Editor split closed"),
            2000);
        return;
    }

    CodeEditor *primary = editors.first();
    if (!primary) {
        return;
    }

    auto *splitter =
        new QSplitter(
            Qt::Horizontal,
            m_editorTabs);

    splitter->setObjectName(
        QStringLiteral("editorSplitView"));
    splitter->setChildrenCollapsible(false);
    splitter->setHandleWidth(4);

    primary->setProperty(
        "sidboxSplitHostEditor",
        true);

    m_editorTabs->removeTab(index);
    splitter->addWidget(primary);

    CodeEditor *secondary =
        createEditor(primary->filePath());

    secondary->setProperty(
        "sidboxApiReference",
        primary->property(
            "sidboxApiReference"));

    secondary->setProperty(
        "sidboxSplitHostEditor",
        false);

    secondary->shareDocumentFrom(primary);
    secondary->setTextCursor(
        primary->textCursor());
    secondary->verticalScrollBar()->setValue(
        primary->verticalScrollBar()->value());
    secondary->horizontalScrollBar()->setValue(
        primary->horizontalScrollBar()->value());

    splitter->addWidget(secondary);
    splitter->setStretchFactor(0, 1);
    splitter->setStretchFactor(1, 1);

    m_editorTabs->insertTab(
        index,
        splitter,
        tabIcon,
        tabText);

    m_editorTabs->setTabToolTip(
        index,
        tabToolTip);

    m_editorTabs->setCurrentIndex(index);

    splitter->show();
    primary->show();
    secondary->show();

    QTimer::singleShot(
        0,
        splitter,
        [splitter, primary, secondary]() {
            const int available =
                qMax(
                    240,
                    splitter->width()
                        - splitter->handleWidth());

            const int left = available / 2;
            const int right = available - left;

            primary->setMinimumWidth(120);
            secondary->setMinimumWidth(120);
            splitter->setSizes({left, right});
        });

    updateEditorSplitPresentation();

    primary->setFocus();
    updateCursorPositionStatus();

    statusBar()->showMessage(
        tr("Split active — select another tab and choose Open in Existing Split"),
        4500);
}

void MainWindow::updateCursorPositionStatus()
{
    if (!m_cursorPositionLabel) {
        return;
    }

    CodeEditor *editor = activeEditor();
    if (!editor) {
        m_cursorPositionLabel->clear();
        return;
    }

    const QTextCursor cursor = editor->textCursor();
    m_cursorPositionLabel->setText(
        tr("[ Ln %1, Col %2 ]  ")
            .arg(cursor.blockNumber() + 1)
            .arg(cursor.positionInBlock() + 1));
}

void MainWindow::watchEditorFile(CodeEditor *editor)
{
    if (!editor || !m_fileWatcher) {
        return;
    }

    const QString path =
        QFileInfo(editor->filePath()).absoluteFilePath();

    if (path.isEmpty() || !QFileInfo::exists(path)) {
        return;
    }

    if (!m_fileWatcher->files().contains(path)) {
        m_fileWatcher->addPath(path);
    }
}

void MainWindow::unwatchEditorFile(CodeEditor *editor)
{
    if (!editor || !m_fileWatcher) {
        return;
    }

    const QString path =
        QFileInfo(editor->filePath()).absoluteFilePath();

    if (!path.isEmpty() && m_fileWatcher->files().contains(path)) {
        m_fileWatcher->removePath(path);
    }

    m_pendingExternalReloads.remove(path);
}

void MainWindow::handleExternalFileChange(const QString &filePath)
{
    if (!m_fileWatcher || filePath.isEmpty()) {
        return;
    }

    const QString path = QFileInfo(filePath).absoluteFilePath();

    /*
     * One external save can produce several filesystem events. Coalesce them
     * into one reload after the writer has finished replacing the file.
     */
    if (m_pendingExternalReloads.contains(path)) {
        return;
    }

    m_pendingExternalReloads.insert(path);

    QTimer::singleShot(180, this, [this, path]() {
        m_pendingExternalReloads.remove(path);

        CodeEditor *editor = nullptr;
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            auto *candidate =
                primaryEditorForTab(m_editorTabs->widget(i));

            if (candidate
                && QFileInfo(candidate->filePath()).absoluteFilePath() == path) {
                editor = candidate;
                break;
            }
        }

        /*
         * The tab may have been closed while the debounce timer was waiting.
         * In that case there is nothing left to watch.
         */
        if (!editor) {
            if (m_fileWatcher->files().contains(path)) {
                m_fileWatcher->removePath(path);
            }
            return;
        }

        /*
         * QFileSystemWatcher can drop a watched path when an editor performs
         * an atomic replace. By now the replacement should normally exist.
         */
        if (!QFileInfo::exists(path)) {
            statusBar()->showMessage(
                tr("%1 no longer exists on disk")
                    .arg(QFileInfo(path).fileName()),
                4000);
            return;
        }

        bool reload = true;

        if (editor->document()->isModified()) {
            const QMessageBox::StandardButton answer =
                QMessageBox::warning(
                    this,
                    tr("File Changed Outside Sidbox IDE"),
                    tr("%1 was changed outside Sidbox IDE, but this tab also "
                       "contains unsaved changes.\n\n"
                       "Reload the file and discard the unsaved IDE changes?")
                        .arg(QFileInfo(path).fileName()),
                    QMessageBox::Yes | QMessageBox::No,
                    QMessageBox::No);

            reload = (answer == QMessageBox::Yes);
        }

        if (reload) {
            reloadEditorFromDisk(editor);
        }

        /*
         * Re-arm after every external event. This is essential for applications
         * which save by replacing the file rather than modifying it in place.
         */
        watchEditorFile(editor);
    });
}

bool MainWindow::reloadEditorFromDisk(CodeEditor *editor)
{
    if (!editor || editor->filePath().isEmpty()) {
        return false;
    }

    const QString path =
        QFileInfo(editor->filePath()).absoluteFilePath();

    if (!QFileInfo::exists(path)) {
        return false;
    }

    const QTextCursor oldCursor = editor->textCursor();
    const int oldLine = oldCursor.blockNumber();
    const int oldColumn = oldCursor.positionInBlock();
    const int oldVerticalScroll = editor->verticalScrollBar()->value();
    const int oldHorizontalScroll = editor->horizontalScrollBar()->value();

    if (!editor->loadFromFile(path)) {
        statusBar()->showMessage(
            tr("Could not reload %1")
                .arg(QFileInfo(path).fileName()),
            4000);
        return false;
    }

    const QTextBlock block =
        editor->document()->findBlockByNumber(
            qBound(0, oldLine, qMax(0, editor->blockCount() - 1)));

    if (block.isValid()) {
        QTextCursor cursor(block);
        const int maxColumn = qMax(0, block.length() - 1);
        cursor.setPosition(
            block.position() + qMin(oldColumn, maxColumn));
        editor->setTextCursor(cursor);
    }

    editor->verticalScrollBar()->setValue(oldVerticalScroll);
    editor->horizontalScrollBar()->setValue(oldHorizontalScroll);
    editor->document()->setModified(false);
    updateTabTitle(editor);
    updateCursorPositionStatus();

    statusBar()->showMessage(
        tr("Reloaded %1 — changed outside Sidbox IDE")
            .arg(QFileInfo(path).fileName()),
        3000);

    return true;
}



void MainWindow::navigateEditorStructure(
    CodeEditor *editor,
    int direction)
{
    if (!editor
        || editor != activeEditor()) {
        return;
    }

    const QVariantList storedLines =
        editor->property(
            "sidboxStructureLines")
            .toList();

    QList<int> lines;
    lines.reserve(
        storedLines.size());

    for (const QVariant &value :
         storedLines) {
        const int line =
            value.toInt();

        if (line >= 0) {
            lines.append(line);
        }
    }

    std::sort(
        lines.begin(),
        lines.end());

    lines.erase(
        std::unique(
            lines.begin(),
            lines.end()),
        lines.end());

    if (lines.isEmpty()) {
        /*
         * The first catalogue for a freshly-opened/edited source may still be
         * running. Ask for it without blocking this shortcut.
         */
        if (editor->property(
                "sidboxAnalysisDirty")
                .toBool()
            || editor->property(
                "sidboxAnalysisWorkerRunning")
                .toBool()) {

            refreshActiveEditorAnalysis();

            statusBar()->showMessage(
                tr("Rebuilding catalogue: %1%")
                    .arg(
                        editor->property(
                            "sidboxCatalogueProgress")
                            .toInt()),
                1200);
        } else {
            statusBar()->showMessage(
                tr("No functions or typedef/struct types in this file"),
                1800);
        }

        return;
    }

    const int currentLine =
        editor->textCursor()
            .blockNumber();

    int targetLine = -1;

    if (direction < 0) {
        for (auto it = lines.crbegin();
             it != lines.crend();
             ++it) {
            if (*it < currentLine) {
                targetLine = *it;
                break;
            }
        }
    } else {
        for (int line :
             std::as_const(lines)) {
            if (line > currentLine) {
                targetLine = line;
                break;
            }
        }
    }

    if (targetLine < 0) {
        statusBar()->showMessage(
            direction < 0
                ? tr("Already at the first function/type")
                : tr("Already at the last function/type"),
            1200);
        return;
    }

    const QTextBlock block =
        editor->document()
            ->findBlockByNumber(
                targetLine);

    if (!block.isValid()) {
        return;
    }

    QTextCursor cursor(block);
    editor->setTextCursor(cursor);
    editor->centerCursor();
    editor->setFocus();

    updateCursorPositionStatus();
}


void MainWindow::selectNextEditorTab()
{
    if (!m_editorTabs
        || m_editorTabs->count() <= 0) {
        return;
    }

    const int current =
        m_editorTabs->currentIndex();

    const int next =
        current < 0
            ? 0
            : (current + 1)
                % m_editorTabs->count();

    m_editorTabs->setCurrentIndex(next);

    if (CodeEditor *editor =
            activeEditor()) {
        editor->setFocus();
    }
}


void MainWindow::showCatalogueProgress(
    CodeEditor *editor,
    int percent)
{
    if (!editor) {
        return;
    }

    const int boundedPercent =
        qBound(
            0,
            percent,
            100);

    editor->setProperty(
        "sidboxCatalogueProgress",
        boundedPercent);

    if (editor != activeEditor()) {
        return;
    }

    statusBar()->showMessage(
        tr("Rebuilding catalogue: %1%")
            .arg(boundedPercent),
        boundedPercent >= 100
            ? 1100
            : 0);
}


CodeEditor *MainWindow::createEditor(const QString &filePath)
{
    auto *editor = new CodeEditor(m_editorTabs);
    editor->setFilePath(filePath);
    // Include completion resolves relative to the current C file first, then
    // the project root and SDK header/library directories.  Never index a
    // whole project on every ordinary editor keystroke.
    const QString libsRoot = ideLibsPath();
    editor->setIncludeSearchPaths({
        m_projectPath,
        QDir(libsRoot).filePath(QStringLiteral("api")),
        QDir(libsRoot).filePath(QStringLiteral("tools/cgarm/include")),
        QDir(libsRoot).filePath(QStringLiteral("libraries"))
    });

    editor->setProperty(
        "sidboxAnalysisDirty",
        true);

    editor->setProperty(
        "sidboxCatalogueProgress",
        0);

    editor->setProperty(
        "sidboxStructureLines",
        QVariantList());

    const bool resourceMode = isResourceSource(filePath);
    editor->setResourceMode(resourceMode);
    editor->setTheme(m_theme);

    if (!resourceMode) {
        ensureApiCatalog();

        /*
         * Keep tab creation cheap. projectFunctionSignatures() and
         * projectTypeNames() both scan the project and used to run here before
         * the new tab could even appear. The existing project-analysis timer
         * fills those project-wide lists shortly after the UI has updated.
         *
         * API completions are already cached by refreshApiCatalog(), so they
         * are safe to install immediately.
         */
        editor->setFunctionCompletions(m_apiSignatures);
        editor->setProjectTypeNames({});
        editor->setApiSyntaxNames(apiSyntaxNames());
    } else {
        editor->setFunctionCompletions({});
        editor->setProjectTypeNames({});
        editor->setApiSyntaxNames({});
    }
    applyCompilerDiagnostics(editor);

    QFont font = QFontDatabase::systemFont(QFontDatabase::FixedFont);
    font.setPointSize(m_editorFontPointSize);
    editor->setFont(font);
    editor->setCompletionFont(font);
    editor->refreshLineNumberAreaWidth();

    /*
     * VB6-style object/event navigator. The bar belongs to the CodeEditor and
     * occupies its TOP viewport margin: visually directly beneath the tabs,
     * without wrapping tabs or changing the existing split editor machinery.
     */
    if (!resourceMode) {
        auto *bar = new QFrame(editor);
        bar->setObjectName(QStringLiteral("sidboxEventNavigatorBar"));
        bar->setStyleSheet(QStringLiteral(
            "QFrame#sidboxEventNavigatorBar { background: #15233C; "
            "border-bottom: 1px solid #2858A8; } "
            "QComboBox { background: #192D50; color: #E5EEFF; "
            "border: 1px solid #385B93; border-radius: 0px; "
            "padding: 1px 5px; min-height: 19px; } "
            "QComboBox QAbstractItemView { background: #192D50; "
            "color: #E5EEFF; selection-background-color: #2858A8; }"));
        auto *barLayout = new QHBoxLayout(bar);
        barLayout->setContentsMargins(6, 2, 6, 2);
        barLayout->setSpacing(7);

        auto *objects = new QComboBox(bar);
        objects->setObjectName(QStringLiteral("sidboxEventNavigatorObjects"));
        objects->setToolTip(tr("Object or control: choose a window, gadget, timer or other functions"));
        // Retro/VB6-style navigation: compact controls, not two half-width fields.
        objects->setFixedWidth(185);
        objects->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

        auto *events = new QComboBox(bar);
        events->setObjectName(QStringLiteral("sidboxEventNavigatorEvents"));
        events->setToolTip(tr("Event or function: jump to its definition in this source file"));
        events->setFixedWidth(195);
        events->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

        barLayout->addWidget(objects);
        barLayout->addWidget(events);
        barLayout->addStretch(1);
        editor->setNavigationBar(bar, 30);
        editor->setProperty("sidboxNavigatorDirty", true);

        connect(objects, qOverload<int>(&QComboBox::currentIndexChanged),
                this, [this, editor](int) {
            refreshEventNavigatorMethods(editor);
        });
        connect(events, qOverload<int>(&QComboBox::activated),
                this, [this, editor, events](int index) {
            if (!editor || index < 0)
                return;
            // A code edit may have moved definitions before the idle rescan.
            // Never navigate to an out-of-date line in that situation.
            const QString selectedName =
                events->itemData(index, Qt::UserRole + 1).toString();
            if (editor->property("sidboxNavigatorDirty").toBool()) {
                refreshEventNavigator(editor);
                const int freshIndex = events->findData(selectedName, Qt::UserRole + 1);
                if (freshIndex < 0)
                    return; // The handler was removed by the latest edit.
                events->setCurrentIndex(freshIndex);
            }
            const int line = events->currentData(Qt::UserRole).toInt();
            const QTextBlock block = editor->document()->findBlockByNumber(line);
            if (!block.isValid())
                return;
            QTextCursor cursor(block);
            editor->setTextCursor(cursor);
            editor->centerCursor();
            editor->setFocus();
            syncEventNavigatorToCursor(editor);
        });

        auto *navTimer = new QTimer(editor);
        navTimer->setObjectName(QStringLiteral("sidboxEventNavigatorTimer"));
        navTimer->setSingleShot(true);
        navTimer->setInterval(650);
        connect(navTimer, &QTimer::timeout, this, [this, editor]() {
            if (editor == activeEditor())
                refreshEventNavigator(editor);
        });
    }

    connect(editor, &QPlainTextEdit::cursorPositionChanged,
            this, [this, editor]() {
                if (editor == activeEditor()) {
                    updateCursorPositionStatus();
                    syncEventNavigatorToCursor(editor);
                }
            });

    connect(editor->document(), &QTextDocument::modificationChanged, this, [this, editor]() {
        updateTabTitle(editor);
        if (!m_restoringRecovery && m_recoveryDebounceTimer) {
            m_recoveryDebounceTimer->start();
        }
    });
    connect(editor->document(), &QTextDocument::contentsChanged,
            this, [this, editor]() {
        // Function lists and line numbers become stale on any document edit,
        // including GUI regeneration or external-file reloads.
        if (!editor->isResourceMode()) {
            editor->setProperty("sidboxNavigatorDirty", true);
            if (editor == activeEditor()) {
                if (auto *navTimer = editor->findChild<QTimer *>(
                        QStringLiteral("sidboxEventNavigatorTimer"))) {
                    navTimer->start(); // Debounced; no full scan per keystroke.
                }
            }
        }
        if (!m_restoringRecovery && m_recoveryDebounceTimer) {
            m_recoveryDebounceTimer->start();
        }
        /*
         * Every edit invalidates any worker result already in flight. The worker
         * is not force-killed (it is off the UI thread anyway); its stale result
         * is simply discarded when it finishes.
         */
        const int generation =
            editor->property(
                "sidboxAnalysisGeneration")
                .toInt()
            + 1;

        editor->setProperty(
            "sidboxAnalysisGeneration",
            generation);

        editor->setProperty(
            "sidboxAnalysisDirty",
            true);

        /*
         * Normal typing only pushes the guaranteed catch-up pass two seconds
         * into the future.
         */
        if (!editor->isResourceMode()
            && editor == activeEditor()
            && tabIndexForEditor(editor) >= 0) {
            m_projectAnalysisTimer->start();
        }
    });

    connect(editor, &CodeEditor::deferredAnalysisSyncRequested,
            this, [this, editor]() {
        if (editor != activeEditor()) {
            return;
        }

        /*
         * Arrow/Home/End/Page keys, Enter, and mouse caret movement are explicit
         * sync points. Cancel the pending idle timer and refresh the active tab
         * immediately. CodeEditor only emits this when edits are actually dirty,
         * so repeatedly pressing arrows does not repeatedly rescan unchanged code.
         */
        if (m_projectAnalysisTimer) {
            m_projectAnalysisTimer->stop();
        }

        /*
         * This returns immediately: heavy semantic parsing now runs in the
         * thread pool, while fold/minimap work is sliced across event-loop turns.
         */
        refreshActiveEditorAnalysis();
    });

    connect(editor, &CodeEditor::structureNavigationRequested,
            this, [this, editor](int direction) {
        navigateEditorStructure(
            editor,
            direction);
    });

    connect(editor, &CodeEditor::nextEditorTabRequested,
            this, [this]() {
        selectNextEditorTab();
    });

    connect(editor, &CodeEditor::quickTipRequested, this, &MainWindow::showQuickTip);
    connect(editor, &CodeEditor::quickTipCandidateChanged, this, &MainWindow::showPassiveQuickTip);
    connect(editor, &CodeEditor::definitionRequested,
            this, [this, editor](const QString &symbol, int sourceLine) {
                goToDefinition(editor, symbol, sourceLine);
            });
    connect(editor, &CodeEditor::includeFileRequested,
            this, [this, editor](const QString &includeName) {
                openIncludedFile(editor, includeName);
            });
    connect(editor, &CodeEditor::memberCompletionRequested,
            this, [this, editor](const QString &objectName,
                                int sourceLine,
                                const QString &prefix) {
                completeStructMembers(editor, objectName, sourceLine, prefix);
            });
    return editor;
}


/*
bool MainWindow::openFile(const QString &filePath)
{
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (editor && QFileInfo(editor->filePath()).absoluteFilePath() == QFileInfo(filePath).absoluteFilePath()) {
            m_editorTabs->setCurrentIndex(i);
            return true;
        }
    }

    CodeEditor *editor = createEditor(filePath);
    if (!editor->loadFromFile(filePath)) {
        editor->deleteLater();
        QMessageBox::warning(this, tr("Open File"), tr("Could not open %1.").arg(QDir::toNativeSeparators(filePath)));
        return false;
    }

    const int index = m_editorTabs->addTab(editor, tabTitleForEditor(editor));
    m_editorTabs->setCurrentIndex(index);
    refreshFunctionCompletions();
    return true;
}

*/

bool MainWindow::openFile(const QString &filePath)
{
    if (QFileInfo(filePath).suffix().compare(QStringLiteral("sbui"), Qt::CaseInsensitive) == 0) {
        return openGuiDesigner(filePath);
    }
    if (QFileInfo(filePath).suffix().compare(QStringLiteral("sbgm"), Qt::CaseInsensitive) == 0) {
        return openGameDesigner(filePath);
    }

    // Do not accidentally interpret binary SIDBOX game assets as UTF-8 C source.
    const QString assetSuffix = QFileInfo(filePath).suffix().toLower();
    if (QStringList{QStringLiteral("ppb"), QStringLiteral("pal"), QStringLiteral("act"),
                    QStringLiteral("png"), QStringLiteral("bmp"), QStringLiteral("jpg"),
                    QStringLiteral("jpeg"), QStringLiteral("gif"), QStringLiteral("wav"),
                    QStringLiteral("mod"), QStringLiteral("s3m"), QStringLiteral("xm"),
                    QStringLiteral("med"), QStringLiteral("tfmx"),
                    QStringLiteral("sid"), QStringLiteral("sba")}.contains(assetSuffix)) {
        QMessageBox::information(this, tr("Game Asset"),
            tr("%1 is a game resource, not source code.\n\n"
               "Open your .sbgm Game Designer to preview PPB/PNG assets and manage resources.")
               .arg(QFileInfo(filePath).fileName()));
        return false;
    }

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        //auto *editor = qobject_cast(m_editorTabs->widget(i));
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (editor && QFileInfo(editor->filePath()).absoluteFilePath() == QFileInfo(filePath).absoluteFilePath()) {
            m_editorTabs->setCurrentIndex(i);
            return true;
        }
    }

    /*
     * Sidbox IDE deliberately performs syntax highlighting, symbol discovery
     * and project IntelliSense on source files. That is useful for normal code,
     * but very large generated/resource files can still take a moment to open.
     *
     * Warn rather than silently disabling features: the user keeps full IDE
     * behaviour if they choose Open Anyway.
     */
    const QFileInfo openingFileInfo(filePath);
    const qint64 largeSourceThreshold = 2048LL * 1024LL;
    const qint64 veryLargeSourceThreshold = 4096LL * 1024LL;
    const QString suffix = openingFileInfo.suffix().toLower();

    const bool isSourceLike =
        suffix == QStringLiteral("c")
        || suffix == QStringLiteral("h")
        || suffix == QStringLiteral("cc")
        || suffix == QStringLiteral("cpp")
        || suffix == QStringLiteral("hpp")
        || suffix == QStringLiteral("inc")
        || suffix == QStringLiteral("uis");

    if (isSourceLike
        && openingFileInfo.exists()
        && openingFileInfo.size() >= largeSourceThreshold) {

        QMessageBox warning(this);
        warning.setIcon(QMessageBox::Warning);
        warning.setWindowTitle(
            openingFileInfo.size() >= veryLargeSourceThreshold
                ? tr("Very Large Source File")
                : tr("Large Source File"));

        warning.setText(
            tr("%1 is %2.")
                .arg(openingFileInfo.fileName(),
                     formattedFileSize(openingFileInfo.size())));

        warning.setInformativeText(
            openingFileInfo.size() >= veryLargeSourceThreshold
                ? tr("This is a very large source file. Syntax analysis and IntelliSense "
                     "may take a few seconds. Generated/resource data is usually easier "
                     "for the IDE to handle when split across smaller source files.")
                : tr("Large source files may take a moment to open while syntax analysis "
                     "and IntelliSense are prepared. If this is generated/resource data, "
                     "consider splitting it across smaller source files."));

        QPushButton *openAnywayButton =
            warning.addButton(tr("Open Anyway"), QMessageBox::AcceptRole);
        warning.addButton(QMessageBox::Cancel);
        warning.setDefaultButton(openAnywayButton);

        warning.exec();

        if (warning.clickedButton() != openAnywayButton) {
            return false;
        }
    }

    CodeEditor *editor = createEditor(filePath);
    if (!editor->loadFromFile(filePath, true)) {
        editor->deleteLater();
        QMessageBox::warning(this, tr("Open File"), tr("Could not open %1.").arg(QDir::toNativeSeparators(filePath)));
        return false;
    }

    const int index = m_editorTabs->addTab(
        editor,
        editorTabIconForFile(filePath),
        tabTitleForEditor(editor));
    m_editorTabs->setCurrentIndex(index);
    editor->setProperty("sidboxNavigatorDirty", true);
    QTimer::singleShot(0, editor, [this, editor]() {
        if (editor == activeEditor())
            refreshEventNavigator(editor);
    });

    /*
     * Give Qt one paint opportunity before asking QSyntaxHighlighter to walk
     * the document. Twenty milliseconds is visually instant, but it lets the
     * user see the file/tab immediately while the IDE prepares colouring and
     * the later project catalogue refresh.
     */
    QTimer::singleShot(20, editor, [editor]() {
        editor->enableSyntaxHighlighting();
    });

    watchEditorFile(editor);

    const QString absoluteProjectFile =
        QFileInfo(filePath).absoluteFilePath();
    const bool projectListChanged =
        !m_projectFilesInProject.contains(absoluteProjectFile);

    addProjectFile(filePath);

    /*
     * Merely opening an existing project file does not change the file tree.
     * Avoid recursively rebuilding that tree on every tab open.
     */
    if (projectListChanged) {
        refreshProjectFiles();
    }

    m_projectAnalysisTimer->start();
    return true;
}


bool MainWindow::openApiReference(const QString &filePath, int line)
{
    const QString absolutePath = QFileInfo(filePath).absoluteFilePath();
    if (absolutePath.isEmpty() || !QFileInfo::exists(absolutePath)) {
        return false;
    }

    /*
     * Reuse an already-open tab for the same file. If it is a project tab,
     * leave its editability alone; if it was opened by API navigation it is
     * already read-only.
     */
    CodeEditor *editor = nullptr;

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *candidate =
            primaryEditorForTab(m_editorTabs->widget(i));

        if (!candidate || candidate->filePath().isEmpty()) {
            continue;
        }

        if (QFileInfo(candidate->filePath()).absoluteFilePath()
            == absolutePath) {
            editor = candidate;
            m_editorTabs->setCurrentIndex(i);
            break;
        }
    }

    if (!editor) {
        editor = createEditor(absolutePath);

        if (!editor->loadFromFile(absolutePath, true)) {
            editor->deleteLater();
            QMessageBox::warning(
                this,
                tr("Open API Source"),
                tr("Could not open %1.")
                    .arg(QDir::toNativeSeparators(absolutePath)));
            return false;
        }

        editor->setReadOnly(true);
        editor->setProperty("sidboxApiReference", true);

        const int index =
            m_editorTabs->addTab(
                editor,
                editorTabIconForFile(absolutePath),
                tabTitleForEditor(editor));

        m_editorTabs->setTabToolTip(
            index,
            tr("Read-only Sidbox API source\n%1")
                .arg(QDir::toNativeSeparators(absolutePath)));

        m_editorTabs->setCurrentIndex(index);

        QTimer::singleShot(20, editor, [editor]() {
            editor->enableSyntaxHighlighting();
        });

        watchEditorFile(editor);
    }

    if (line >= 0) {
        const QTextBlock block =
            editor->document()->findBlockByNumber(line);

        if (block.isValid()) {
            QTextCursor cursor(block);
            editor->setTextCursor(cursor);
            editor->centerCursor();
        }
    }

    editor->setFocus();
    return true;
}




/*

bool MainWindow::saveEditor(CodeEditor *editor)
{
    if (!editor) {
        return false;
    }

    const bool wasUntitled = editor->filePath().isEmpty();
    if (wasUntitled) {
        const QString baseDirectory = m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath;
        QString filePath = QFileDialog::getSaveFileName(
            this,
            tr("Save Source File"),
            QDir(baseDirectory).filePath(QStringLiteral("main.c")),
            tr("C source/header files (*.c *.h *.cc *.cpp *.hpp);;All files (*)"));

        if (filePath.isEmpty()) {
            return false;
        }

        if (QFileInfo(filePath).suffix().isEmpty()) {
            filePath.append(QStringLiteral(".c"));
        }

        if (!editor->saveAs(filePath)) {
            QMessageBox::warning(this, tr("Save File"), tr("Could not save %1.").arg(QDir::toNativeSeparators(filePath)));
            return false;
        }
    } else if (!editor->save()) {
        QMessageBox::warning(this, tr("Save File"), tr("Could not save %1.").arg(QDir::toNativeSeparators(editor->filePath())));
        return false;
    }

    addProjectFile(editor->filePath());
    updateTabTitle(editor);
    refreshProjectFiles();
    refreshFunctionCompletions();
    return true;
}

*/

bool MainWindow::saveEditor(CodeEditor *editor)
{
    if (!editor) {
        return false;
    }

    const bool wasUntitled = editor->filePath().isEmpty();
    const QString oldPath =
        QFileInfo(editor->filePath()).absoluteFilePath();

    /*
     * Do not treat Sidbox IDE's own save as an external edit.
     * Temporarily remove the file from QFileSystemWatcher and re-arm it after
     * the save completes.
     */
    if (!oldPath.isEmpty()
        && m_fileWatcher
        && m_fileWatcher->files().contains(oldPath)) {
        m_fileWatcher->removePath(oldPath);
    }
    if (wasUntitled) {
        const QString baseDirectory = m_projectPath.isEmpty() ? QDir::homePath() : m_projectPath;
        QString filePath = QFileDialog::getSaveFileName(
            this,
            tr("Save Source File"),
            QDir(baseDirectory).filePath(tabTitleForEditor(editor).remove(QLatin1Char('*'))),
            tr("Source files (*.c *.h *.inc *.cc *.cpp *.hpp);;All files (*)"));

        if (filePath.isEmpty()) {
            return false;
        }

        if (QFileInfo(filePath).suffix().isEmpty()) {
            filePath.append(QStringLiteral(".c"));
        }

        if (!editor->saveAs(filePath)) {
            QMessageBox::warning(this, tr("Save File"), tr("Could not save %1.").arg(QDir::toNativeSeparators(filePath)));
            watchEditorFile(editor);
            return false;
        }
    } else {
        // The first programmer SAVE of generated main.c relinquishes IDE
        // ownership. Change only the OWNER line in the editor's buffer.
        // No ownership transfer happens on an unchanged Ctrl+S.
        const bool claimMain = editor->document()->isModified()
            && GamerGirlMainOwnership::matchesMainPath(editor->filePath(), m_projectPath)
            && GamerGirlMainOwnership::loadRecord(m_projectPath).owner == QStringLiteral("IDE");
        if (claimMain) {
            const QByteArray oldPrefix("// GAMERGIRL GENERATED MAIN.C\n// OWNER: IDE");
            if (editor->toPlainText().toUtf8().startsWith(oldPrefix)) {
                QTextCursor cursor = editor->document()->find(QStringLiteral("// OWNER: IDE"));
                if (!cursor.isNull()) cursor.insertText(QStringLiteral("// OWNER: user"));
            }
        }
        // Keep the OLD on-disk source before CodeEditor overwrites it.
        // Unchanged saves, non-project files and non-source files are skipped.
        QString historyError;
        if (!backupFileBeforeSave(m_projectPath, editor->filePath(),
                                  editor->toPlainText(), &historyError)) {
            const auto decision = QMessageBox::warning(
                this, tr("File History Backup Failed"),
                tr("Could not preserve the previous version of %1.\n%2\n\n"
                   "Continue saving WITHOUT a history backup?")
                    .arg(QFileInfo(editor->filePath()).fileName(), historyError),
                QMessageBox::Save | QMessageBox::Cancel,
                QMessageBox::Cancel);
            if (decision != QMessageBox::Save) {
                watchEditorFile(editor);
                return false;
            }
        }
        if (!editor->save()) {
            QMessageBox::warning(this, tr("Save File"),
                tr("Could not save %1.").arg(QDir::toNativeSeparators(editor->filePath())));
            watchEditorFile(editor);
            return false;
        }
        if (claimMain) {
            QString ownershipError;
            if (!GamerGirlMainOwnership::recordUserSave(m_projectPath, &ownershipError)) {
                QMessageBox::warning(this, tr("Game main.c ownership"),
                    tr("Your main.c was saved, but ownership metadata could not be updated:\n%1")
                        .arg(ownershipError));
                // The generated file checksum no longer matches, so it still
                // cannot be overwritten even if the metadata write failed.
            }
        }
    }

    watchEditorFile(editor);

    const QString newPath =
        QFileInfo(editor->filePath()).absoluteFilePath();

    if (!oldPath.isEmpty()
        && oldPath != newPath) {
        m_cachedFileFunctionSignatures.remove(
            oldPath);
        m_cachedFileTypeNames.remove(
            oldPath);
    }

    const bool projectListChanged =
        !m_projectFilesInProject.contains(newPath);

    addProjectFile(editor->filePath());
    updateTabTitle(editor);

    if (wasUntitled
        || projectListChanged
        || (!oldPath.isEmpty() && oldPath != newPath)) {
        refreshProjectFiles();
    }

    m_projectAnalysisTimer->start();
    // A successful manual Save clears any older unsaved recovery copy now,
    // rather than waiting for the next autosave timer tick.
    saveEditorRecoverySnapshots();
    return true;
}


bool MainWindow::saveModifiedWorkBeforeNewProject()
{
    // A Home tab isn't an unsaved source file.
    bool hasUnsavedWork = false;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            if (designer->isModified()) {
                hasUnsavedWork = true;
                break;
            }
        }
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (game->isModified()) { hasUnsavedWork = true; break; }
        }
        auto *editor = primaryEditorForTab(tab);
        if (editor && (editor->document()->isModified()
                       || (m_projectFilePath.isEmpty() && editor->filePath().isEmpty()))) {
            hasUnsavedWork = true;
            break;
        }
    }

    if (!hasUnsavedWork) {
        return true;
    }

    const QMessageBox::StandardButton answer = QMessageBox::warning(
        this,
        tr("New Project"),
        tr("Save the current project and source files before creating a new project?"),
        QMessageBox::Save | QMessageBox::Cancel | QMessageBox::Discard,
        QMessageBox::Save);


    if (answer == QMessageBox::Discard) {
        // Throw away current work and reset to the exact same clean state as startup
        m_projectFilePath.clear();
        m_projectPath.clear();
        m_projectFilesInProject.clear();
        m_linkerScriptPath.clear();
        m_outputAppName.clear();
        m_modSizeKb = 0;
        m_projectType = GuiProjectType;
        m_appletFormat = QStringLiteral("v1");
        m_v2Linker = QStringLiteral("llvm");
        m_compilerOptimization = QStringLiteral("-Ofast");
        m_compilerSuppressWarnings = true;
        m_compilerWall = false;
        m_compilerWextra = false;
        m_compilerFunctionSections = true;
        m_compilerDataSections = true;
        m_compilerStackUsage = true;
        m_extraCompilerFlags.clear();
        clearEditorTabs();
        refreshProjectFiles();
        createNewSourceFile();
        createNewHeaderFile();
        setWindowTitle(tr("Sidbox IDE"));
        statusBar()->showMessage(tr("New project started (unsaved)"));
        return false;   // stop createNewProject — we already did the reset
    }

    if (answer != QMessageBox::Save) {
        return false;
    }


    return saveProject();
}

bool MainWindow::loadProjectFile(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Open Project"), tr("Could not open %1.").arg(QDir::toNativeSeparators(filePath)));
        return false;
    }

    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(file.readAll(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        QMessageBox::warning(this, tr("Open Project"), tr("The project file is not valid JSON."));
        return false;
    }

    const QJsonObject root = document.object();
    const QJsonArray files = root.value(QStringLiteral("files")).toArray();

    // Tear down the previous project's tabs before changing the active
    // project directory. Old GUI/Game Designer instances must never run
    // their teardown against the next project's state.
    clearEditorTabs();
    m_projectFilePath = QFileInfo(filePath).absoluteFilePath();
    m_projectPath = QFileInfo(m_projectFilePath).absolutePath();
    m_projectFilesInProject.clear();
    m_projectType = normalizedProjectType(root.value(QStringLiteral("projectType")).toString(GuiProjectType));
    m_appletFormat = (m_projectType == GuiProjectType &&
        root.value(QStringLiteral("appletFormat")).toString() == QStringLiteral("v2"))
        ? QStringLiteral("v2") : QStringLiteral("v1");
    m_v2Linker = (m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2") &&
                  root.value(QStringLiteral("v2Linker")).toString() == QStringLiteral("cgarm"))
        ? QStringLiteral("cgarm") : QStringLiteral("llvm");
    m_modSizeKb = root.value(QStringLiteral("modSizeKb")).toInt(0);
    m_appSizeKb = root.value(QStringLiteral("appSizeKb")).toInt(128);
    m_v2HeapKb = qBound(0, root.value(QStringLiteral("v2HeapKb")).toInt(16), V2MaxAppletKiB);
    m_v2StackKb = qBound(1, root.value(QStringLiteral("v2StackKb")).toInt(8), 128);
    m_outputAppName =
        normalizedAppOutputName(
            root.value(QStringLiteral("outputAppName")).toString());
    if (m_appSizeKb < 16) {
        m_appSizeKb = 128;
    }

    const QJsonObject compiler =
        root.value(QStringLiteral("compiler")).toObject();

    m_compilerOptimization =
        compiler.value(QStringLiteral("optimization"))
            .toString(QStringLiteral("-Ofast"));

    const QStringList validOptimizations = {
        QStringLiteral("-O0"),
        QStringLiteral("-Og"),
        QStringLiteral("-O1"),
        QStringLiteral("-O2"),
        QStringLiteral("-O3"),
        QStringLiteral("-Os"),
        QStringLiteral("-Ofast")
    };
    if (!validOptimizations.contains(m_compilerOptimization)) {
        m_compilerOptimization = QStringLiteral("-Ofast");
    }

    m_compilerSuppressWarnings =
        compiler.value(QStringLiteral("suppressWarnings")).toBool(true);
    m_compilerWall =
        compiler.value(QStringLiteral("wall")).toBool(false);
    m_compilerWextra =
        compiler.value(QStringLiteral("wextra")).toBool(false);
    m_compilerFunctionSections =
        compiler.value(QStringLiteral("functionSections")).toBool(true);
    m_compilerDataSections =
        compiler.value(QStringLiteral("dataSections")).toBool(true);
    m_compilerStackUsage =
        compiler.value(QStringLiteral("stackUsage")).toBool(true);
    m_extraCompilerFlags =
        compiler.value(QStringLiteral("extraFlags")).toString();

    /*
     * -w means warnings are suppressed, so warning-enabling switches have no
     * effect. Keep the stored state internally consistent for older/hand-edited
     * project files.
     */
    if (m_compilerSuppressWarnings) {
        m_compilerWall = false;
        m_compilerWextra = false;
    }

    const QString linkerScript = root.value(QStringLiteral("linkerScript")).toString();
    m_linkerScriptPath = linkerScript.isEmpty() ? QString() : fromProjectRelativePath(linkerScript);

    for (const QJsonValue &value : files) {
        const QString projectFile = fromProjectRelativePath(value.toString());
        if (!projectFile.isEmpty()) {
            addProjectFile(projectFile);
        }
    }

    refreshProjectFiles();

    const QJsonArray openTabsArray = root.value(QStringLiteral("openTabs")).toArray();
    for (const QJsonValue &val : openTabsArray) {
        const QString tabPath = fromProjectRelativePath(val.toString());
        if (!tabPath.isEmpty() && QFileInfo::exists(tabPath)) {
            openFile(tabPath);
        }
    }

    /*
    for (const QString &projectFile : std::as_const(m_projectFilesInProject)) {
        // open initially the main.c only
        //openFile(projectFile);
        if (projectFile.endsWith(QStringLiteral("/main.c"), Qt::CaseInsensitive) || projectFile == QStringLiteral("main.c")) {
            openFile(projectFile);
            break; // Stop looping once main.c is found and opened
        }
    }
    */

    if (m_editorTabs->count() == 0) {
        for (const QString &projectFile : std::as_const(m_projectFilesInProject)) {
            if (projectFile.endsWith(QStringLiteral("/main.c"), Qt::CaseInsensitive) || projectFile == QStringLiteral("main.c")) {
                openFile(projectFile);
                break;
            }
        }
    }

    if (m_editorTabs->count() == 0) {
        createNewSourceFile();
    }

    /*
     * Project load is a project-level event, so build the per-file caches once.
     * Normal typing after this point only refreshes the active tab.
     */
    refreshFunctionCompletions();
    refreshSymbolTree();
    // Display existing build measurements on reopening, without compiling.
    const bool v2Project = m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2");
    const QString stem = QFileInfo(m_projectFilePath).completeBaseName();
    const QString existingElf = QDir(m_projectPath).filePath(
        QStringLiteral("%1/%2.elf").arg(v2Project ? QStringLiteral("build") : QStringLiteral("buildv1"), stem));
    const QString appName = m_outputAppName.isEmpty() ? stem + QStringLiteral(".app") : m_outputAppName;
    const QString existingApp = QDir(m_projectPath).filePath(appName);
    updateAppletMemoryPanel(this, v2Project, m_appSizeKb, m_v2StackKb, m_v2HeapKb,
        QFileInfo(existingElf).isFile() && QFileInfo(existingApp).isFile(),
        existingElf, existingApp, QFileInfo(existingElf).absolutePath(),
        m_projectType == GameProjectType);

    setWindowTitle(tr("Sidbox IDE - %1").arg(QFileInfo(m_projectFilePath).fileName()));
    rememberRecentProject(m_projectFilePath);
    return true;
}

bool MainWindow::saveProjectFile(const QString &filePath)
{
    m_projectFilePath = QFileInfo(filePath).absoluteFilePath();
    m_projectPath = QFileInfo(m_projectFilePath).absolutePath();
    for (const QString &projectFile : collectOpenProjectFiles()) {
        addProjectFile(projectFile);
    }

    QJsonArray files;
    for (const QString &projectFile : std::as_const(m_projectFilesInProject)) {
        files.append(toProjectRelativePath(projectFile));
    }

    QJsonArray openTabsArray;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            if (!designer->filePath().isEmpty()) {
                openTabsArray.append(toProjectRelativePath(designer->filePath()));
            }
            continue;
        }
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (!game->filePath().isEmpty())
                openTabsArray.append(toProjectRelativePath(game->filePath()));
            continue;
        }
        auto *editor = primaryEditorForTab(tab);
        if (editor && !editor->filePath().isEmpty()) {
            openTabsArray.append(toProjectRelativePath(editor->filePath()));
        }
    }

    QJsonObject root;
    root.insert(QStringLiteral("version"), ProjectFileVersion);
    root.insert(QStringLiteral("projectType"), normalizedProjectType(m_projectType));
    root.insert(QStringLiteral("appletFormat"),
                m_projectType == GameProjectType ? QStringLiteral("v1") : m_appletFormat);
    root.insert(QStringLiteral("v2Linker"),
                (m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2"))
                    ? m_v2Linker : QStringLiteral("llvm"));
    root.insert(QStringLiteral("files"), files);
    root.insert(QStringLiteral("openTabs"), openTabsArray);
    root.insert(QStringLiteral("linkerScript"), m_linkerScriptPath.isEmpty() ? QString() : toProjectRelativePath(m_linkerScriptPath));
    root.insert(QStringLiteral("modSizeKb"), m_modSizeKb);
    root.insert(QStringLiteral("appSizeKb"), m_appSizeKb);
    root.insert(QStringLiteral("v2HeapKb"), m_v2HeapKb);
    root.insert(QStringLiteral("v2StackKb"), m_v2StackKb);
    root.insert(QStringLiteral("outputAppName"), m_outputAppName);

    QJsonObject compiler;
    compiler.insert(QStringLiteral("optimization"), m_compilerOptimization);
    compiler.insert(QStringLiteral("suppressWarnings"), m_compilerSuppressWarnings);
    compiler.insert(QStringLiteral("wall"), m_compilerWall);
    compiler.insert(QStringLiteral("wextra"), m_compilerWextra);
    compiler.insert(QStringLiteral("functionSections"), m_compilerFunctionSections);
    compiler.insert(QStringLiteral("dataSections"), m_compilerDataSections);
    compiler.insert(QStringLiteral("stackUsage"), m_compilerStackUsage);
    compiler.insert(QStringLiteral("extraFlags"), m_extraCompilerFlags);
    root.insert(QStringLiteral("compiler"), compiler);

    QFile file(m_projectFilePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        QMessageBox::warning(this, tr("Save Project"), tr("Could not save %1.").arg(QDir::toNativeSeparators(m_projectFilePath)));
        return false;
    }

    file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
    file.close();

    if (m_linkerScriptPath.isEmpty()) {
        QString linkerError;
        if (!updateProjectLinkerScript(&linkerError)) {
            QMessageBox::warning(this, tr("Save Project"), tr("Project saved, but the linker script could not be prepared:\n%1").arg(linkerError));
            return false;
        }
    }

    // Do NOT rebuild the entire C function/type catalogue on each Save Project.
    // File edits are already analyzed by the editor's debounced worker; a
    // deliberate Rescan or project load explicitly refreshes the catalogue.
    const bool v2Project = m_projectType == GuiProjectType && m_appletFormat == QStringLiteral("v2");
    const QString stem = QFileInfo(m_projectFilePath).completeBaseName();
    const QString existingElf = QDir(m_projectPath).filePath(
        QStringLiteral("%1/%2.elf").arg(v2Project ? QStringLiteral("build") : QStringLiteral("buildv1"), stem));
    const QString appName = m_outputAppName.isEmpty() ? stem + QStringLiteral(".app") : m_outputAppName;
    const QString existingApp = QDir(m_projectPath).filePath(appName);
    updateAppletMemoryPanel(this, v2Project, m_appSizeKb, m_v2StackKb, m_v2HeapKb,
        QFileInfo(existingElf).isFile() && QFileInfo(existingApp).isFile(),
        existingElf, existingApp, QFileInfo(existingElf).absolutePath(),
        m_projectType == GameProjectType);
    setWindowTitle(tr("Sidbox IDE - %1").arg(QFileInfo(m_projectFilePath).fileName()));
    rememberRecentProject(m_projectFilePath);
    return true;
}

void MainWindow::addProjectFile(const QString &filePath)
{
    if (filePath.isEmpty()) {
        return;
    }

    const QString absolutePath = QFileInfo(filePath).absoluteFilePath();
    if (!m_projectFilesInProject.contains(absolutePath)) {
        m_projectFilesInProject.append(absolutePath);
        m_projectFilesInProject.sort(Qt::CaseInsensitive);
    }
}

void MainWindow::clearEditorTabs()
{
    // A pending analysis callback must not run while a different project is
    // being installed. Other per-editor callbacks are destroyed with the tabs.
    if (m_projectAnalysisTimer)
        m_projectAnalysisTimer->stop();
    if (m_fileWatcher) {
        const QStringList watchedFiles = m_fileWatcher->files();
        if (!watchedFiles.isEmpty())
            m_fileWatcher->removePaths(watchedFiles);
    }
    m_pendingExternalReloads.clear();
    m_cachedFileFunctionSignatures.clear();
    m_cachedFileTypeNames.clear();

    // The reusable split pane can borrow a QTextDocument owned by another
    // tab. Return it to its own host before that document can be destroyed.
    if (QSplitter *splitter = editorSplitWidget()) {
        CodeEditor *host = splitHostEditor(splitter);
        CodeEditor *secondary = splitSecondaryEditor(splitter);
        if (host && secondary && secondary->document() != host->document()) {
            secondary->setProperty("sidboxApiReference",
                                   host->property("sidboxApiReference"));
            secondary->shareDocumentFrom(host);
        }
    }

    // A project switch can be initiated by a button on the Home tab itself.
    // Do NOT synchronously delete a widget while its own clicked handler is
    // executing. Detach the old tabs from the IDE object tree immediately,
    // then let Qt destroy them when the current event has unwound.
    // This also prevents findChildren() from seeing stale project editors.
    QSignalBlocker blockTabSignals(m_editorTabs);
    while (m_editorTabs->count() > 0) {
        QWidget *widget = m_editorTabs->widget(0);
        m_editorTabs->removeTab(0);
        widget->setParent(nullptr);
        widget->deleteLater();
    }
}

void MainWindow::rescanProjectFiles()
{
    if (m_projectPath.isEmpty()
        || !QFileInfo(m_projectPath).isDir()) {
        statusBar()->showMessage(
            tr("No project directory to rescan"),
            3000);
        return;
    }

    /*
     * projectFolderSourceFiles() is deliberately the single source of truth
     * for what belongs in the Files in Project tree.  At present that means:
     *
     *   .c  .h  .inc  .res  .txt  .md
     *
     * It scans subdirectories recursively and skips generated build/ and
     * buildv1/ directories.  Linker scripts (.ld) stay out of the file tree because they
     * are managed separately in Project Settings.
     */
    const QStringList discoveredFiles =
        projectFolderSourceFiles();

    int addedCount = 0;

    for (const QString &filePath : discoveredFiles) {
        const QString absolutePath =
            QFileInfo(filePath).absoluteFilePath();

        if (!m_projectFilesInProject.contains(absolutePath)) {
            m_projectFilesInProject.append(absolutePath);
            ++addedCount;
        }
    }

    m_projectFilesInProject.removeDuplicates();
    m_projectFilesInProject.sort(Qt::CaseInsensitive);

    refreshProjectFiles();
    refreshFunctionCompletions();
    refreshSymbolTree();

    /*
     * Persist the newly discovered file list immediately when a real .proj
     * file is already open. This keeps Rescan behaving like "add these files
     * to my project", not merely "show them until I restart".
     */
    if (!m_projectFilePath.isEmpty()) {
        saveProjectFile(m_projectFilePath);
    }

    statusBar()->showMessage(
        addedCount == 1
            ? tr("Rescan complete — 1 new project file added")
            : tr("Rescan complete — %1 new project files added")
                  .arg(addedCount),
        3500);
}


void MainWindow::refreshProjectFiles()
{
    // Default: collapsed. If the user manually expanded folders, do not snap
    // them closed every time a file is generated or the tree is refreshed.
    QSet<QString> previouslyExpanded;
    for (QTreeWidgetItemIterator it(m_projectFiles); *it; ++it) {
        const QTreeWidgetItem *item = *it;
        if (item->data(0, Qt::UserRole + 1).toBool() && item->isExpanded())
            previouslyExpanded.insert(item->data(0, Qt::UserRole).toString());
    }
    m_projectFiles->clear();

    QHash<QString, QTreeWidgetItem *> folderItems;

    /*
     * Create / find a folder item from a path relative to the project root.
     * Folder items store their real directory path in Qt::UserRole and are
     * marked as folders in Qt::UserRole + 1.
     */
    auto ensureFolderItem = [this, &folderItems](const QString &relativeFolderPath) -> QTreeWidgetItem * {
        const QString cleanPath = QDir::cleanPath(relativeFolderPath);
        if (cleanPath.isEmpty() || cleanPath == QStringLiteral(".")) {
            return nullptr;
        }

        const QStringList parts = cleanPath.split(QLatin1Char('/'), Qt::SkipEmptyParts);
        QTreeWidgetItem *parentItem = nullptr;
        QString currentFolder;

        for (const QString &part : parts) {
            if (!currentFolder.isEmpty()) {
                currentFolder += QLatin1Char('/');
            }
            currentFolder += part;

            QTreeWidgetItem *folderItem = folderItems.value(currentFolder, nullptr);
            if (!folderItem) {
                folderItem = new QTreeWidgetItem();
                folderItem->setText(0, part);
                folderItem->setIcon(0, QIcon(QStringLiteral(":/icons/tree_folder.png")));

                const QString absoluteFolderPath =
                    QFileInfo(QDir(m_projectPath).filePath(currentFolder)).absoluteFilePath();

                folderItem->setData(0, Qt::UserRole, absoluteFolderPath);
                folderItem->setData(0, Qt::UserRole + 1, true);
                folderItem->setToolTip(0, QDir::toNativeSeparators(absoluteFolderPath));

                if (parentItem) {
                    parentItem->addChild(folderItem);
                } else {
                    m_projectFiles->addTopLevelItem(folderItem);
                }

                folderItems.insert(currentFolder, folderItem);
            }

            parentItem = folderItem;
        }

        return parentItem;
    };

    /*
     * Show empty folders as well as populated ones, but DON'T descend into
     * build directories or history. A recursive QDirIterator visits those
     * directories even if we ignore their results after the fact.
     */
    if (!m_projectPath.isEmpty() && QFileInfo(m_projectPath).isDir()) {
        std::function<void(const QDir &)> addVisibleFolders;
        addVisibleFolders = [&](const QDir &parent) {
            const QFileInfoList subdirs = parent.entryInfoList(
                QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks,
                QDir::Name | QDir::IgnoreCase);
            for (const QFileInfo &subdir : subdirs) {
                if (isExcludedProjectDirectoryName(subdir.fileName())) continue;
                ensureFolderItem(QDir(m_projectPath).relativeFilePath(subdir.absoluteFilePath()));
                addVisibleFolders(QDir(subdir.absoluteFilePath()));
            }
        };
        addVisibleFolders(QDir(m_projectPath));
    }

    QStringList files = m_projectFilesInProject;

    for (const QString &projectFile : projectFolderSourceFiles()) {
        const QString absolutePath = QFileInfo(projectFile).absoluteFilePath();
        if (!files.contains(absolutePath)) {
            files.append(absolutePath);
        }
    }

    files.removeDuplicates();
    files.sort(Qt::CaseInsensitive);

    for (const QString &filePath : std::as_const(files)) {
        if (!isProjectExplorerFile(filePath) || !QFileInfo::exists(filePath)) {
            continue;
        }

        const QFileInfo fileInfo(filePath);
        QString relativePath;

        if (!m_projectPath.isEmpty()) {
            relativePath = QDir(m_projectPath).relativeFilePath(fileInfo.absoluteFilePath());
        } else {
            relativePath = fileInfo.fileName();
        }
        // Never display old .proj manifest entries from generated folders.
        if (isExcludedProjectRelativePath(relativePath))
            continue;

        relativePath = QDir::cleanPath(relativePath);

        QIcon fileIcon;
        const QString suffix = fileInfo.suffix().toLower();

        if (suffix == QStringLiteral("c") || suffix == QStringLiteral("cc")
            || suffix == QStringLiteral("cpp")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_c.png"));
        } else if (suffix == QStringLiteral("h") || suffix == QStringLiteral("hpp")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_h.png"));
        } else if (suffix == QStringLiteral("inc")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_inc.png"));
        } else if (suffix == QStringLiteral("res")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_res.png"));
        } else if (suffix == QStringLiteral("txt")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_txt.png"));
        } else if (suffix == QStringLiteral("uis")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_c.png"));
        } else if (suffix == QStringLiteral("sbui")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_guidesigner.png"));
        } else if (suffix == QStringLiteral("sbgm")) {
            fileIcon = QIcon(QStringLiteral(":/icons/toolbar_gamedesigner.png"));
        } else if (suffix == QStringLiteral("md")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_md.png"));
        } else if (suffix == QStringLiteral("ppb") || suffix == QStringLiteral("png")
                   || suffix == QStringLiteral("bmp") || suffix == QStringLiteral("jpg")
                   || suffix == QStringLiteral("jpeg") || suffix == QStringLiteral("gif")
                   || suffix == QStringLiteral("pal") || suffix == QStringLiteral("act")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_res.png"));
        } else if (suffix == QStringLiteral("wav") || suffix == QStringLiteral("mod")
                   || suffix == QStringLiteral("s3m") || suffix == QStringLiteral("xm")
                   || suffix == QStringLiteral("med") || suffix == QStringLiteral("tfmx")
                   || suffix == QStringLiteral("sid") || suffix == QStringLiteral("sba")) {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_unknown.png"));
        } else {
            fileIcon = QIcon(QStringLiteral(":/icons/tree_file_unknown.png"));
        }

        const QString absoluteFilePath =
            fileInfo.absoluteFilePath();

        bool hasCompilerError = false;

        const auto diagnosticIt =
            m_compilerDiagnostics.constFind(
                absoluteFilePath);

        if (diagnosticIt
            != m_compilerDiagnostics.constEnd()) {
            for (const EditorDiagnostic &diagnostic :
                 diagnosticIt.value()) {
                if (diagnostic.severity
                    == EditorDiagnostic::Severity::Error) {
                    hasCompilerError = true;
                    break;
                }
            }
        }

        if (hasCompilerError) {
            fileIcon =
                projectFileIconWithErrorBadge(
                    fileIcon,
                    m_theme.diagnosticError);
        }

        /* Files outside the project directory remain top-level entries. */
        if (relativePath == QStringLiteral("..")
            || relativePath.startsWith(QStringLiteral("../"))) {

            auto *fileItem = new QTreeWidgetItem(m_projectFiles);
            fileItem->setText(0, projectFileDisplayText(filePath));
            fileItem->setIcon(0, fileIcon);
            fileItem->setData(0, Qt::UserRole, fileInfo.absoluteFilePath());
            fileItem->setData(0, Qt::UserRole + 1, false);
            fileItem->setToolTip(0, QDir::toNativeSeparators(fileInfo.absoluteFilePath()));
            continue;
        }

        const QString parentFolderPath = QFileInfo(relativePath).path();
        QTreeWidgetItem *parentItem = nullptr;

        if (!parentFolderPath.isEmpty() && parentFolderPath != QStringLiteral(".")) {
            parentItem = ensureFolderItem(parentFolderPath);
        }

        auto *fileItem = new QTreeWidgetItem();
        fileItem->setText(0, QStringLiteral("%1 (%2)")
                                 .arg(fileInfo.fileName(), formattedFileSize(fileInfo.size())));
        fileItem->setIcon(0, fileIcon);
        fileItem->setData(0, Qt::UserRole, fileInfo.absoluteFilePath());
        fileItem->setData(0, Qt::UserRole + 1, false);
        fileItem->setToolTip(0, QDir::toNativeSeparators(fileInfo.absoluteFilePath()));

        if (parentItem) {
            parentItem->addChild(fileItem);
        } else {
            m_projectFiles->addTopLevelItem(fileItem);
        }
    }

    // Restore only folders the user chose to open. The initial view remains
    // collapsed; compiler-error folders are expanded explicitly below.
    for (auto it = folderItems.cbegin(); it != folderItems.cend(); ++it) {
        QTreeWidgetItem *folder = it.value();
        if (previouslyExpanded.contains(folder->data(0, Qt::UserRole).toString()))
            folder->setExpanded(true);
    }
    for (QTreeWidgetItemIterator it(m_projectFiles); *it; ++it) {
        QTreeWidgetItem *item = *it;
        if (item->data(0, Qt::UserRole + 1).toBool()) continue;
        const QString path = item->data(0, Qt::UserRole).toString();
        const auto diagnosticIt = m_compilerDiagnostics.constFind(path);
        if (diagnosticIt == m_compilerDiagnostics.constEnd()) continue;
        bool hasError = false;
        for (const EditorDiagnostic &diagnostic : diagnosticIt.value()) {
            if (diagnostic.severity == EditorDiagnostic::Severity::Error) {
                hasError = true;
                break;
            }
        }
        if (hasError) {
            for (QTreeWidgetItem *parent = item->parent(); parent; parent = parent->parent())
                parent->setExpanded(true);
        }
    }
}


void MainWindow::updateProjectDiagnosticMarkers()
{
    if (!m_projectFiles) {
        return;
    }

    auto fileHasError =
        [this](const QString &path) {
            const QString absolutePath =
                QFileInfo(path)
                    .absoluteFilePath();

            const auto it =
                m_compilerDiagnostics
                    .constFind(
                        absolutePath);

            if (it
                == m_compilerDiagnostics
                       .constEnd()) {
                return false;
            }

            for (const EditorDiagnostic &diagnostic :
                 it.value()) {
                if (diagnostic.severity
                    == EditorDiagnostic::Severity::Error) {
                    return true;
                }
            }

            return false;
        };

    std::function<void(QTreeWidgetItem *)>
        updateItem;

    updateItem =
        [this,
         &fileHasError,
         &updateItem](QTreeWidgetItem *item) {
            if (!item) {
                return;
            }

            const bool isFolder =
                item->data(
                        0,
                        Qt::UserRole + 1)
                    .toBool();

            if (!isFolder) {
                const QString filePath =
                    item->data(
                            0,
                            Qt::UserRole)
                        .toString();

                if (!filePath.isEmpty()) {
                    QIcon icon =
                        editorTabIconForFile(
                            filePath);

                    const bool hasError =
                        fileHasError(
                            filePath);

                    if (hasError) {
                        icon =
                            projectFileIconWithErrorBadge(
                                icon,
                                m_theme.diagnosticError);
                    }

                    item->setIcon(
                        0,
                        icon);

                    // Compilation errors reveal only the relevant folder path;
                    // ordinary folders stay collapsed unless opened by user.
                    if (hasError) {
                        for (QTreeWidgetItem *parent = item->parent(); parent;
                             parent = parent->parent())
                            parent->setExpanded(true);
                    }

                    QString tooltip =
                        QDir::toNativeSeparators(
                            QFileInfo(filePath)
                                .absoluteFilePath());

                    if (hasError) {
                        tooltip +=
                            tr("\nCompiler error in this file");
                    }

                    item->setToolTip(
                        0,
                        tooltip);
                }
            }

            for (int i = 0;
                 i < item->childCount();
                 ++i) {
                updateItem(
                    item->child(i));
            }
        };

    for (int i = 0;
         i < m_projectFiles
                 ->topLevelItemCount();
         ++i) {
        updateItem(
            m_projectFiles
                ->topLevelItem(i));
    }
}


void MainWindow::saveSymbolTreeExpansionState(CodeEditor *editor)
{
    if (!editor || !m_functionvarList) {
        return;
    }

    QSet<QString> expanded;

    std::function<void(QTreeWidgetItem *)> scan;
    scan = [&](QTreeWidgetItem *item) {
        if (!item) {
            return;
        }

        const QString key = item->data(0, Qt::UserRole + 10).toString();

        if (!key.isEmpty() && item->isExpanded()) {
            expanded.insert(key);
        }

        for (int i = 0; i < item->childCount(); ++i) {
            scan(item->child(i));
        }
    };

    for (int i = 0; i < m_functionvarList->topLevelItemCount(); ++i) {
        scan(m_functionvarList->topLevelItem(i));
    }

    m_symbolTreeExpanded[editor] = expanded;
}

void MainWindow::restoreSymbolTreeExpansionState(CodeEditor *editor)
{
    if (!editor || !m_functionvarList) {
        return;
    }

    const QSet<QString> expanded = m_symbolTreeExpanded.value(editor);

    std::function<void(QTreeWidgetItem *)> restore;
    restore = [&](QTreeWidgetItem *item) {
        if (!item) {
            return;
        }

        const QString key = item->data(0, Qt::UserRole + 10).toString();

        if (!key.isEmpty()) {
            item->setExpanded(expanded.contains(key));
        }

        for (int i = 0; i < item->childCount(); ++i) {
            restore(item->child(i));
        }
    };

    for (int i = 0; i < m_functionvarList->topLevelItemCount(); ++i) {
        restore(m_functionvarList->topLevelItem(i));
    }
}


/*
 * VB6-style event navigator. These are navigation-only views of the open
 * editor's current source text. They do not create or modify any handlers.
 */
void MainWindow::refreshEventNavigator(CodeEditor *editor)
{
    if (!editor || editor->isResourceMode())
        return;

    auto *objects = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorObjects"));
    auto *events = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorEvents"));
    if (!objects || !events)
        return;

    const QString previousGroup = objects->currentData().toString();
    const QString previousFunction =
        events->currentData(Qt::UserRole + 1).toString();

    // Reuse the IDE's C comment/string sanitizer and function-definition
    // pattern, but NOT its expensive locals/globals/type analysis. The two
    // drop-downs should remain lightweight, even for sizeable generated C.
    const QString source = editor->toPlainText();
    const QString sanitized = sanitizedCSource(source);
    const QList<QRegularExpressionMatch> definitions =
        fileScopeCFunctionDefinitions(sanitized);
    QVariantList entries;
    QSet<QString> groups;
    for (const QRegularExpressionMatch &match : definitions) {
        const QString name = match.captured(2).trimmed();
        if (name.isEmpty()
            || name == QStringLiteral("__attribute__")
            || name == QStringLiteral("__declspec"))
            continue;

        const int closingBrace = matchingBracePosition(
            sanitized, match.capturedEnd(0) - 1);
        if (closingBrace < 0)
            continue;
        const int startLine = editor->document()
            ->findBlock(match.capturedStart(2)).blockNumber();
        const int endLine = editor->document()
            ->findBlock(closingBrace).blockNumber();

        QString group = QStringLiteral("(Other functions)");
        QString eventName = name;

        // CoderGirl generated callbacks: On_btn1_Activate, On_timer1_Tick,
        // On_messageBox1_Result. Split at the FINAL underscore so gadget
        // names containing underscores remain intact.
        if (name.startsWith(QStringLiteral("On_"))) {
            const int separator = name.lastIndexOf(QLatin1Char('_'));
            if (separator > 3 && separator + 1 < name.size()) {
                group = name.mid(3, separator - 3);
                eventName = QStringLiteral("On_") + name.mid(separator + 1);
            }
        } else if (name == QStringLiteral("CloseWindow")) {
            group = QStringLiteral("window");
            eventName = QStringLiteral("CloseWindow");
        } else if (name.endsWith(QStringLiteral("_Create"))) {
            group = QStringLiteral("window");
            eventName = QStringLiteral("Create");
        } else if (name.endsWith(QStringLiteral("_WndProc"))
                   || name.endsWith(QStringLiteral("_WindowProc"))) {
            group = QStringLiteral("window");
            eventName = QStringLiteral("WindowProc");
        }

        QVariantMap item;
        item.insert(QStringLiteral("group"), group);
        item.insert(QStringLiteral("event"), eventName);
        item.insert(QStringLiteral("name"), name);
        item.insert(QStringLiteral("line"), startLine);
        item.insert(QStringLiteral("endLine"), endLine);
        entries.append(item);
        groups.insert(group);
    }

    // Window event handlers are switch cases in the generated WindowProc,
    // not always separate functions. Navigate directly to cases that ACTUALLY
    // exist in the file; never pretend that an OnOpen/OnMinimise handler was
    // generated if it wasn't.
    static const QRegularExpression windowEventExpression(
        QStringLiteral(R"(\bcase\s+(CGEVT_WIN_CLOSE_REQUEST|CGEVT_WIN_MINIMISE|CGEVT_WIN_GOTFOCUS|CGEVT_WIN_LOSTFOCUS|CGEVT_WIN_MOVED|CGEVT_WIN_RESIZED)\s*:)"));
    auto windowIt = windowEventExpression.globalMatch(sanitized);
    while (windowIt.hasNext()) {
        const QRegularExpressionMatch match = windowIt.next();
        const QString eventClass = match.captured(1);
        QString label;
        if (eventClass == QStringLiteral("CGEVT_WIN_CLOSE_REQUEST"))
            label = QStringLiteral("OnClose");
        else if (eventClass == QStringLiteral("CGEVT_WIN_MINIMISE"))
            label = QStringLiteral("OnMinimise");
        else if (eventClass == QStringLiteral("CGEVT_WIN_GOTFOCUS"))
            label = QStringLiteral("OnFocus");
        else if (eventClass == QStringLiteral("CGEVT_WIN_LOSTFOCUS"))
            label = QStringLiteral("OnLostFocus");
        else if (eventClass == QStringLiteral("CGEVT_WIN_MOVED"))
            label = QStringLiteral("OnMoved");
        else if (eventClass == QStringLiteral("CGEVT_WIN_RESIZED"))
            label = QStringLiteral("OnResized");
        if (label.isEmpty())
            continue;
        const int line = editor->document()
            ->findBlock(match.capturedStart()).blockNumber();
        QVariantMap item;
        item.insert(QStringLiteral("group"), QStringLiteral("window"));
        item.insert(QStringLiteral("event"), label);
        item.insert(QStringLiteral("name"), QStringLiteral("window:") + label);
        item.insert(QStringLiteral("line"), line);
        item.insert(QStringLiteral("endLine"), line);
        entries.append(item);
        groups.insert(QStringLiteral("window"));
    }

    editor->setProperty("sidboxNavigatorItems", entries);
    editor->setProperty("sidboxNavigatorDirty", false);

    QStringList names = groups.values();
    names.sort(Qt::CaseInsensitive);
    names.removeAll(QStringLiteral("window"));
    names.removeAll(QStringLiteral("(Other functions)"));

    QStringList orderedGroups;
    if (groups.contains(QStringLiteral("window")))
        orderedGroups.append(QStringLiteral("window"));
    orderedGroups.append(names);
    if (groups.contains(QStringLiteral("(Other functions)")))
        orderedGroups.append(QStringLiteral("(Other functions)"));

    {
        QSignalBlocker blockObjects(objects);
        objects->clear();
        if (orderedGroups.isEmpty()) {
            objects->addItem(tr("(No functions)"));
            objects->setEnabled(false);
        } else {
            objects->setEnabled(true);
            for (const QString &name : orderedGroups)
                objects->addItem(name, name);
        }
        int index = objects->findData(previousGroup);
        if (index < 0)
            index = 0;
        objects->setCurrentIndex(index);
    }

    refreshEventNavigatorMethods(editor);
    const int eventIndex = events->findData(previousFunction, Qt::UserRole + 1);
    if (eventIndex >= 0) {
        const QSignalBlocker blockEvents(events);
        events->setCurrentIndex(eventIndex);
    } else {
        syncEventNavigatorToCursor(editor);
    }
}

void MainWindow::refreshEventNavigatorMethods(CodeEditor *editor)
{
    if (!editor)
        return;
    auto *objects = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorObjects"));
    auto *events = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorEvents"));
    if (!objects || !events)
        return;

    const QString selectedGroup = objects->currentData().toString();
    const QString previousFunction =
        events->currentData(Qt::UserRole + 1).toString();

    QSignalBlocker blockEvents(events);
    events->clear();
    const QVariantList entries =
        editor->property("sidboxNavigatorItems").toList();
    for (const QVariant &value : entries) {
        const QVariantMap item = value.toMap();
        if (item.value(QStringLiteral("group")).toString() != selectedGroup)
            continue;
        events->addItem(item.value(QStringLiteral("event")).toString(),
                        item.value(QStringLiteral("line")));
        const int row = events->count() - 1;
        events->setItemData(row, item.value(QStringLiteral("name")),
                            Qt::UserRole + 1);
    }
    events->setEnabled(events->count() > 0);
    int index = events->findData(previousFunction, Qt::UserRole + 1);
    if (index < 0)
        index = 0;
    events->setCurrentIndex(index);
}

void MainWindow::syncEventNavigatorToCursor(CodeEditor *editor)
{
    if (!editor || editor->isResourceMode())
        return;
    auto *objects = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorObjects"));
    auto *events = editor->findChild<QComboBox *>(
        QStringLiteral("sidboxEventNavigatorEvents"));
    if (!objects || !events)
        return;

    const int line = editor->textCursor().blockNumber();
    const QVariantList entries =
        editor->property("sidboxNavigatorItems").toList();
    QVariantMap best;
    int shortest = std::numeric_limits<int>::max();
    for (const QVariant &value : entries) {
        const QVariantMap item = value.toMap();
        const int start = item.value(QStringLiteral("line")).toInt();
        const int end = item.value(QStringLiteral("endLine")).toInt();
        if (line >= start && line <= end && end - start < shortest) {
            shortest = end - start;
            best = item;
        }
    }
    if (best.isEmpty())
        return;

    const int objectIndex = objects->findData(
        best.value(QStringLiteral("group")));
    if (objectIndex < 0)
        return;
    if (objects->currentIndex() != objectIndex) {
        const QSignalBlocker blockObjects(objects);
        objects->setCurrentIndex(objectIndex);
        refreshEventNavigatorMethods(editor);
    }
    const int eventIndex = events->findData(
        best.value(QStringLiteral("name")), Qt::UserRole + 1);
    if (eventIndex >= 0) {
        const QSignalBlocker blockEvents(events);
        events->setCurrentIndex(eventIndex);
    }
}

void MainWindow::refreshSymbolTree()
{
    if (!m_functionvarList) {
        return;
    }

    if (m_symbolTreeEditor) {
        saveSymbolTreeExpansionState(
            m_symbolTreeEditor);
    }

    CodeEditor *editor =
        activeEditor();

    m_functionvarList->clear();

    if (!editor) {
        m_symbolTreeEditor = nullptr;
        return;
    }

    if (editor->isResourceMode()) {
        auto *resourceItem =
            new QTreeWidgetItem(
                m_functionvarList);

        resourceItem->setText(
            0,
            tr("Resource file — analysis disabled"));

        resourceItem->setFlags(
            resourceItem->flags()
            & ~Qt::ItemIsSelectable);

        m_symbolTreeEditor = editor;
        return;
    }

    /*
     * This synchronous version is retained for explicit project-level actions.
     * Normal editing uses refreshActiveEditorAnalysis(), which parses off the UI
     * thread and feeds the resulting table straight into this same tree builder.
     */
    const SourceSymbolTable symbols =
        parseSourceSymbols(
            editor->toPlainText());

    populateSourceSymbolTree(
        m_functionvarList,
        symbols);

    editor->setProperty(
        "sidboxStructureLines",
        structureNavigationLines(
            symbols));

    restoreSymbolTreeExpansionState(
        editor);

    m_symbolTreeEditor =
        editor;
}

void MainWindow::completeStructMembers(CodeEditor *sourceEditor,
                                       const QString &objectName,
                                       int sourceLine,
                                       const QString &prefix)
{
    if (!sourceEditor || objectName.isEmpty()) {
        return;
    }

    const SourceSymbolTable currentSymbols =
        parseSourceSymbols(sourceEditor->toPlainText());

    const QString typeName =
        variableTypeInTable(
            currentSymbols,
            objectName,
            sourceLine,
            true);

    if (typeName.isEmpty()) {
        sourceEditor->showMemberCompletions({}, prefix);
        return;
    }

    // The type may be declared in the same file.
    QStringList members =
        membersForTypeInTable(currentSymbols, typeName);

    if (!members.isEmpty()) {
        sourceEditor->showMemberCompletions(members, prefix);
        return;
    }

    const QString sourcePath =
        sourceEditor->filePath().isEmpty()
            ? QString()
            : QFileInfo(sourceEditor->filePath()).absoluteFilePath();

    QSet<QString> scannedPaths;
    if (!sourcePath.isEmpty()) {
        scannedPaths.insert(sourcePath);
    }

    // Then search other open tabs, using their unsaved in-memory text.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor =
            primaryEditorForTab(m_editorTabs->widget(i));

        if (!editor || editor == sourceEditor || editor->isResourceMode()) {
            continue;
        }

        if (!editor->filePath().isEmpty()) {
            scannedPaths.insert(
                QFileInfo(editor->filePath()).absoluteFilePath());
        }

        const SourceSymbolTable table =
            parseSourceSymbols(editor->toPlainText());

        members = membersForTypeInTable(table, typeName);
        if (!members.isEmpty()) {
            sourceEditor->showMemberCompletions(members, prefix);
            return;
        }
    }

    // Finally search the remaining project files on disk.
    QStringList projectFiles = m_projectFilesInProject;
    projectFiles.append(projectFolderSourceFiles());
    projectFiles.removeDuplicates();

    for (const QString &filePath : std::as_const(projectFiles)) {
        const QString absolutePath =
            QFileInfo(filePath).absoluteFilePath();

        if (absolutePath.isEmpty()
            || scannedPaths.contains(absolutePath)
            || !QFileInfo::exists(absolutePath)
            || !canContainFunctionSignatures(absolutePath)) {
            continue;
        }

        QFile file(absolutePath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        const SourceSymbolTable table =
            parseSourceSymbols(QString::fromUtf8(file.readAll()));

        members = membersForTypeInTable(table, typeName);
        if (!members.isEmpty()) {
            sourceEditor->showMemberCompletions(members, prefix);
            return;
        }
    }

    sourceEditor->showMemberCompletions({}, prefix);
}


void MainWindow::openIncludedFile(
    CodeEditor *sourceEditor,
    const QString &includeName)
{
    if (!sourceEditor || includeName.trimmed().isEmpty()) {
        return;
    }

    const QString cleanInclude =
        QDir::cleanPath(includeName.trimmed());

    QStringList candidates;

    auto addCandidate =
        [&candidates](const QString &path) {
            if (path.isEmpty()) {
                return;
            }

            const QString absolute =
                QFileInfo(path).absoluteFilePath();

            if (!candidates.contains(absolute)) {
                candidates.append(absolute);
            }
        };

    /*
     * Match the same practical search order a C programmer expects:
     * current source directory first, then project root, then the Sidbox API
     * and library include roots.
     */
    const QFileInfo includeInfo(cleanInclude);
    if (includeInfo.isAbsolute()) {
        addCandidate(cleanInclude);
    } else {
        if (!sourceEditor->filePath().isEmpty()) {
            addCandidate(
                QDir(QFileInfo(sourceEditor->filePath()).absolutePath())
                    .filePath(cleanInclude));
        }

        if (!m_projectPath.isEmpty()) {
            addCandidate(
                QDir(m_projectPath)
                    .filePath(cleanInclude));
        }

        const QString libsRoot = ideLibsPath();
        addCandidate(
            QDir(QDir(libsRoot).filePath(QStringLiteral("api")))
                .filePath(cleanInclude));
        addCandidate(
            QDir(QDir(libsRoot).filePath(QStringLiteral("libraries")))
                .filePath(cleanInclude));
    }

    /*
     * Also consider known project files by relative path or basename. This is
     * useful for older projects whose file list contains a header outside the
     * immediate source directory.
     */
    QStringList projectFiles = m_projectFilesInProject;
    projectFiles.append(projectFolderSourceFiles());
    projectFiles.removeDuplicates();

    for (const QString &projectFile : std::as_const(projectFiles)) {
        const QFileInfo info(projectFile);

        if (info.fileName().compare(
                QFileInfo(cleanInclude).fileName(),
                Qt::CaseInsensitive) == 0) {
            addCandidate(info.absoluteFilePath());
        }

        if (!m_projectPath.isEmpty()) {
            const QString relative =
                QDir(m_projectPath)
                    .relativeFilePath(info.absoluteFilePath());

            if (QDir::cleanPath(relative).compare(
                    cleanInclude,
                    Qt::CaseInsensitive) == 0) {
                addCandidate(info.absoluteFilePath());
            }
        }
    }

    QString resolvedPath;
    for (const QString &candidate : std::as_const(candidates)) {
        const QFileInfo info(candidate);
        if (info.exists() && info.isFile()) {
            resolvedPath = info.absoluteFilePath();
            break;
        }
    }

    if (resolvedPath.isEmpty()) {
        statusBar()->showMessage(
            tr("Include not found: %1").arg(cleanInclude),
            3000);
        return;
    }

    /*
     * Sidbox's own API/library headers are references supplied by the IDE, so
     * keep those read-only. Project/local headers open as normal editable tabs.
     */
    const QString libsRoot =
        QFileInfo(ideLibsPath()).absoluteFilePath();

    const QString relativeToLibs =
        QDir(libsRoot).relativeFilePath(resolvedPath);

    const bool isIdeLibraryFile =
        !relativeToLibs.startsWith(QStringLiteral("../"))
        && relativeToLibs != QStringLiteral("..")
        && !QDir::isAbsolutePath(relativeToLibs);

    const bool opened =
        isIdeLibraryFile
            ? openApiReference(resolvedPath, 0)
            : openFile(resolvedPath);

    if (opened) {
        statusBar()->showMessage(
            tr("Opened include: %1")
                .arg(QDir::toNativeSeparators(resolvedPath)),
            2500);
    }
}


void MainWindow::goToDefinition(CodeEditor *sourceEditor,
                                const QString &symbol,
                                int sourceLine)
{
    if (!sourceEditor || symbol.isEmpty()) {
        return;
    }

    auto jumpToLine = [this](CodeEditor *editor, int line) {
        if (!editor || line < 0) {
            return false;
        }

        const QTextBlock block = editor->document()->findBlockByNumber(line);
        if (!block.isValid()) {
            return false;
        }

        const int tabIndex = tabIndexForEditor(editor);
        if (tabIndex >= 0) {
            m_editorTabs->setCurrentIndex(tabIndex);
        }

        QTextCursor cursor(block);
        editor->setTextCursor(cursor);
        editor->centerCursor();
        editor->setFocus();
        return true;
    };

    /*
     * Keep the first extern declaration as a fallback. We search every open
     * tab/project file for a real definition first. If none exists, Ctrl+Click
     * can still take the user to the declaration rather than doing nothing.
     */
    CodeEditor *externFallbackEditor = nullptr;
    int externFallbackLine = -1;
    QString externFallbackPath;

    // 1. Current file first. This also resolves locals and parameters using
    //    the function containing the Ctrl+Clicked use.
    const SourceSymbolTable currentSymbols =
        parseSourceSymbols(sourceEditor->toPlainText());

    for (const SourceVariableSymbol &global : currentSymbols.globals) {
        if (global.name == symbol && global.externDeclaration) {
            externFallbackEditor = sourceEditor;
            externFallbackLine = global.line;
            externFallbackPath = sourceEditor->filePath();
            break;
        }
    }

    const int currentLine =
        definitionLineInTable(currentSymbols, symbol, sourceLine, true, false);

    if (currentLine >= 0) {
        jumpToLine(sourceEditor, currentLine);
        statusBar()->showMessage(
            tr("%1 — definition in %2:%3")
                .arg(symbol,
                     sourceEditor->filePath().isEmpty()
                         ? tr("current tab")
                         : QFileInfo(sourceEditor->filePath()).fileName())
                .arg(currentLine + 1),
            2500);
        return;
    }

    const QString sourcePath = sourceEditor->filePath().isEmpty()
        ? QString()
        : QFileInfo(sourceEditor->filePath()).absoluteFilePath();

    QSet<QString> scannedPaths;
    if (!sourcePath.isEmpty()) {
        scannedPaths.insert(sourcePath);
    }

    // 2. Other open tabs. Use their in-memory contents so unsaved edits still
    //    participate in Ctrl+Click navigation.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (!editor || editor == sourceEditor || editor->isResourceMode()) {
            continue;
        }

        const QString editorPath = editor->filePath().isEmpty()
            ? QString()
            : QFileInfo(editor->filePath()).absoluteFilePath();

        if (!editorPath.isEmpty()) {
            scannedPaths.insert(editorPath);
        }

        const SourceSymbolTable symbols =
            parseSourceSymbols(editor->toPlainText());

        if (externFallbackLine < 0) {
            for (const SourceVariableSymbol &global : symbols.globals) {
                if (global.name == symbol && global.externDeclaration) {
                    externFallbackEditor = editor;
                    externFallbackLine = global.line;
                    externFallbackPath = editorPath;
                    break;
                }
            }
        }

        const int line = definitionLineInTable(symbols, symbol, -1, false, false);
        if (line >= 0) {
            jumpToLine(editor, line);
            statusBar()->showMessage(
                tr("%1 — definition in %2:%3")
                    .arg(symbol,
                         editorPath.isEmpty()
                             ? tr("open tab")
                             : QFileInfo(editorPath).fileName())
                    .arg(line + 1),
                2500);
            return;
        }
    }

    // 3. Remaining files in the project. This includes headers and .inc files,
    //    not just compilable .c/.cpp sources.
    QStringList projectFiles = m_projectFilesInProject;
    projectFiles.append(projectFolderSourceFiles());
    projectFiles.removeDuplicates();

    for (const QString &filePath : std::as_const(projectFiles)) {
        const QString absolutePath = QFileInfo(filePath).absoluteFilePath();

        if (absolutePath.isEmpty()
            || scannedPaths.contains(absolutePath)
            || !QFileInfo::exists(absolutePath)
            || !canContainFunctionSignatures(absolutePath)) {
            continue;
        }

        QFile file(absolutePath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        const QString source = QString::fromUtf8(file.readAll());
        const SourceSymbolTable symbols = parseSourceSymbols(source);

        if (externFallbackLine < 0) {
            for (const SourceVariableSymbol &global : symbols.globals) {
                if (global.name == symbol && global.externDeclaration) {
                    externFallbackEditor = nullptr;
                    externFallbackLine = global.line;
                    externFallbackPath = absolutePath;
                    break;
                }
            }
        }

        const int line = definitionLineInTable(symbols, symbol, -1, false, false);

        if (line < 0) {
            continue;
        }

        if (!openFile(absolutePath)) {
            return;
        }

        CodeEditor *targetEditor = activeEditor();
        if (targetEditor && jumpToLine(targetEditor, line)) {
            statusBar()->showMessage(
                tr("%1 — definition in %2:%3")
                    .arg(symbol, QFileInfo(absolutePath).fileName())
                    .arg(line + 1),
                2500);
        }
        return;
    }

    /*
     * 4. Sidbox API source/header lookup.
     *
     * Only do this for names that are actually in the API catalogue, so a
     * failed Ctrl+Click on an ordinary project identifier does not recursively
     * scan the SDK.
     */
    ensureApiCatalog();

    const QStringList knownApiNames = apiSyntaxNames();
    if (knownApiNames.contains(symbol)) {
        const QString libsRoot = ideLibsPath();
        const QString apiPath =
            QDir(libsRoot).filePath(QStringLiteral("api"));
        const QString libraryPath =
            QDir(libsRoot).filePath(QStringLiteral("libraries"));

        QStringList apiSourceFiles;
        QStringList apiHeaderFiles;
        QStringList libraryHeaderFiles;

        if (QFileInfo::exists(apiPath)) {
            QDirIterator apiIterator(
                apiPath,
                {QStringLiteral("*.c"), QStringLiteral("*.h")},
                QDir::Files,
                QDirIterator::Subdirectories);

            while (apiIterator.hasNext()) {
                const QString path =
                    QFileInfo(apiIterator.next()).absoluteFilePath();

                if (QFileInfo(path).suffix().compare(
                        QStringLiteral("c"),
                        Qt::CaseInsensitive) == 0) {
                    apiSourceFiles.append(path);
                } else {
                    apiHeaderFiles.append(path);
                }
            }
        }

        if (QFileInfo::exists(libraryPath)) {
            QDirIterator libraryIterator(
                libraryPath,
                {QStringLiteral("*.h")},
                QDir::Files,
                QDirIterator::Subdirectories);

            while (libraryIterator.hasNext()) {
                libraryHeaderFiles.append(
                    QFileInfo(
                        libraryIterator.next())
                        .absoluteFilePath());
            }
        }

        /*
         * Prefer API .c implementations first, then API headers, then static
         * library headers. A .a archive is binary, so its accompanying .h is
         * the useful read-only reference target for Ctrl+Click.
         */
        apiSourceFiles.sort(Qt::CaseInsensitive);
        apiHeaderFiles.sort(Qt::CaseInsensitive);
        libraryHeaderFiles.sort(Qt::CaseInsensitive);

        QStringList sdkFiles = apiSourceFiles;
        sdkFiles.append(apiHeaderFiles);
        sdkFiles.append(libraryHeaderFiles);

        for (const QString &apiFilePath : std::as_const(sdkFiles)) {
            QFile apiFile(apiFilePath);
            if (!apiFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                continue;
            }

            const QString apiSource =
                QString::fromUtf8(apiFile.readAll());

            const SourceSymbolTable apiSymbols =
                parseSourceSymbols(apiSource);

            const int apiLine =
                definitionLineInTable(
                    apiSymbols,
                    symbol,
                    -1,
                    false,
                    false);

            if (apiLine < 0) {
                continue;
            }

            if (openApiReference(apiFilePath, apiLine)) {
                const QString absoluteLibraryRoot =
                    QFileInfo(libraryPath).absoluteFilePath();
                const QString absoluteReferencePath =
                    QFileInfo(apiFilePath).absoluteFilePath();

                const bool libraryReference =
                    QFileInfo::exists(libraryPath)
                    && absoluteReferencePath.startsWith(
                        absoluteLibraryRoot + QDir::separator());

                statusBar()->showMessage(
                    libraryReference
                        ? tr("%1 — Sidbox library header in %2:%3 (read-only)")
                              .arg(
                                  symbol,
                                  QFileInfo(apiFilePath).fileName())
                              .arg(apiLine + 1)
                        : tr("%1 — Sidbox API source in %2:%3 (read-only)")
                              .arg(
                                  symbol,
                                  QFileInfo(apiFilePath).fileName())
                              .arg(apiLine + 1),
                    3500);
            }
            return;
        }
    }

    /*
     * No storage definition was found. Fall back to the extern declaration,
     * if there was one.
     */
    if (externFallbackLine >= 0) {
        if (externFallbackEditor) {
            jumpToLine(externFallbackEditor, externFallbackLine);
            statusBar()->showMessage(
                tr("%1 — extern declaration in %2:%3")
                    .arg(symbol,
                         externFallbackPath.isEmpty()
                             ? tr("open tab")
                             : QFileInfo(externFallbackPath).fileName())
                    .arg(externFallbackLine + 1),
                2500);
            return;
        }

        if (!externFallbackPath.isEmpty()
            && openFile(externFallbackPath)) {
            CodeEditor *targetEditor = activeEditor();
            if (targetEditor
                && jumpToLine(targetEditor, externFallbackLine)) {
                statusBar()->showMessage(
                    tr("%1 — extern declaration in %2:%3")
                        .arg(symbol,
                             QFileInfo(externFallbackPath).fileName())
                        .arg(externFallbackLine + 1),
                    2500);
            }
            return;
        }
    }

    statusBar()->showMessage(
        tr("No definition found for %1").arg(symbol),
        3000);
}


void MainWindow::jumpToSymbol(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);

    if (!item) {
        return;
    }

    bool ok = false;
    const int line = item->data(0, Qt::UserRole).toInt(&ok);
    if (!ok || line < 0) {
        return;
    }

    CodeEditor *editor = activeEditor();
    if (!editor) {
        return;
    }

    const QTextBlock block = editor->document()->findBlockByNumber(line);
    if (!block.isValid()) {
        return;
    }

    QTextCursor cursor(block);
    editor->setTextCursor(cursor);
    editor->centerCursor();
    editor->setFocus();
}

QStringList MainWindow::apiSyntaxNames() const
{
    QStringList names = m_apiTips.keys();

    /*
     * Some functions are discovered as signatures without a separate quick-tip
     * entry. Pull their identifier out as well so every catalogued API symbol
     * receives the API syntax colour.
     */
    for (const QString &signature : m_apiSignatures) {
        const int paren = signature.indexOf(QLatin1Char('('));
        const QString name =
            (paren >= 0 ? signature.left(paren) : signature).trimmed();

        if (!name.isEmpty()) {
            names.append(name);
        }
    }

    names.removeDuplicates();
    names.sort(Qt::CaseSensitive);
    return names;
}

void MainWindow::refreshFunctionCompletions()
{
    ensureApiCatalog();

    m_cachedFileFunctionSignatures.clear();
    m_cachedFileTypeNames.clear();

    QHash<QString, CodeEditor *> openEditors;

    /*
     * Open tabs win over disk so a deliberate full refresh still sees unsaved
     * source correctly. Build a path -> editor map once rather than walking all
     * tabs repeatedly for every project file.
     */
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        CodeEditor *editor =
            primaryEditorForTab(
                m_editorTabs->widget(i));

        if (!editor
            || editor->isResourceMode()
            || editor->filePath().isEmpty()) {
            continue;
        }

        const QString path =
            QFileInfo(editor->filePath())
                .absoluteFilePath();

        openEditors.insert(path, editor);
    }

    QStringList projectFiles =
        m_projectFilesInProject;

    projectFiles.append(
        projectFolderSourceFiles());

    for (auto it = openEditors.constBegin();
         it != openEditors.constEnd();
         ++it) {
        if (!projectFiles.contains(it.key())) {
            projectFiles.append(it.key());
        }
    }

    projectFiles.removeDuplicates();

    for (const QString &rawPath :
         std::as_const(projectFiles)) {
        const QString path =
            QFileInfo(rawPath)
                .absoluteFilePath();

        if (path.isEmpty()
            || !canContainFunctionSignatures(path)) {
            continue;
        }

        QString source;

        if (CodeEditor *editor =
                openEditors.value(path, nullptr)) {
            source = editor->toPlainText();
        } else {
            QFile file(path);

            if (!file.exists()
                || !file.open(
                    QIODevice::ReadOnly
                    | QIODevice::Text)) {
                continue;
            }

            source =
                QString::fromUtf8(
                    file.readAll());
        }

        const QString sanitized =
            sanitizedCSource(source);

        QStringList functions =
            functionSignaturesFromSanitizedFast(
                source,
                sanitized);

        QStringList types;

        const SourceSymbolTable symbols =
            parseSourceSymbolsFromSanitized(
                source,
                sanitized);

        for (const SourceNamedSymbol &type :
             symbols.types) {
            if (!type.name.isEmpty()) {
                types.append(type.name);
            }
        }

        functions.removeDuplicates();
        types.removeDuplicates();

        m_cachedFileFunctionSignatures.insert(
            path,
            functions);

        m_cachedFileTypeNames.insert(
            path,
            types);
    }

    QStringList completions =
        m_apiSignatures;

    QStringList typeNames;

    for (auto it =
             m_cachedFileFunctionSignatures.constBegin();
         it !=
             m_cachedFileFunctionSignatures.constEnd();
         ++it) {
        completions.append(it.value());
    }

    for (auto it =
             m_cachedFileTypeNames.constBegin();
         it !=
             m_cachedFileTypeNames.constEnd();
         ++it) {
        typeNames.append(it.value());
    }

    typeNames.removeDuplicates();
    typeNames.sort(Qt::CaseInsensitive);

    completions.append(typeNames);
    completions.removeDuplicates();
    completions.sort(Qt::CaseInsensitive);

    const QStringList apiNames =
        apiSyntaxNames();

    for (int i = 0;
         i < m_editorTabs->count();
         ++i) {
        const QList<CodeEditor *> editors =
            editorsForTab(
                m_editorTabs->widget(i));

        for (CodeEditor *editor :
             editors) {
            if (!editor) {
                continue;
            }

            if (editor->isResourceMode()) {
                editor->setFunctionCompletions({});
                editor->setProjectTypeNames({});
                editor->setApiSyntaxNames({});
                continue;
            }

            editor->setFunctionCompletions(
                completions);

            editor->setProjectTypeNames(
                typeNames);

            editor->setApiSyntaxNames(
                apiNames);
        }
    }
}


void MainWindow::refreshActiveEditorAnalysis()
{
    CodeEditor *editor =
        activeEditor();

    if (!editor) {
        return;
    }

    if (editor->isResourceMode()) {
        editor->setFunctionCompletions({});
        editor->setProjectTypeNames({});
        editor->setApiSyntaxNames({});
        return;
    }

    ensureApiCatalog();

    /*
     * If a worker is already cataloguing this tab, do not queue an army of
     * expensive copies/parses behind it. Remember that another pass is wanted;
     * the completed worker will either apply its still-current result or launch
     * one fresh pass if edits made it stale.
     */
    if (editor->property(
            "sidboxAnalysisWorkerRunning")
            .toBool()) {
        editor->setProperty(
            "sidboxAnalysisRerun",
            true);

        showCatalogueProgress(
            editor,
            editor->property(
                "sidboxCatalogueProgress")
                .toInt());

        return;
    }

    /*
     * Copying ~100-200 KB once is cheap compared with parsing it repeatedly on
     * the GUI thread. From this point onward the heavy work happens in a
     * QThreadPool worker.
     */
    const QString source =
        editor->toPlainText();

    const int generation =
        editor->property(
            "sidboxAnalysisGeneration")
            .toInt();

    const QString editorPath =
        editor->filePath().isEmpty()
            ? QString()
            : QFileInfo(editor->filePath())
                  .absoluteFilePath();

    editor->setProperty(
        "sidboxAnalysisWorkerRunning",
        true);

    editor->setProperty(
        "sidboxAnalysisRerun",
        false);

    showCatalogueProgress(
        editor,
        0);

    QPointer<MainWindow> self(this);
    QPointer<CodeEditor> guardedEditor(editor);

    QThreadPool::globalInstance()->start(
        QRunnable::create(
            [self,
             guardedEditor,
             source,
             generation,
             editorPath]() mutable {

                int lastProgress = 0;

                auto reportProgress =
                    [self,
                     guardedEditor,
                     generation,
                     &lastProgress](int percent) {
                        if (!self
                            || !guardedEditor) {
                            return;
                        }

                        const int bounded =
                            qBound(
                                0,
                                percent,
                                100);

                        /*
                         * Avoid filling the GUI event queue with duplicate
                         * percentages when a source contains many functions.
                         */
                        if (bounded <= lastProgress) {
                            return;
                        }

                        lastProgress =
                            bounded;

                        QMetaObject::invokeMethod(
                            self.data(),
                            [self,
                             guardedEditor,
                             generation,
                             bounded]() {
                                if (!self
                                    || !guardedEditor) {
                                    return;
                                }

                                CodeEditor *editor =
                                    guardedEditor.data();

                                if (self->activeEditor()
                                        != editor
                                    || editor->property(
                                           "sidboxAnalysisGeneration")
                                           .toInt()
                                           != generation) {
                                    return;
                                }

                                self->showCatalogueProgress(
                                    editor,
                                    bounded);
                            },
                            Qt::QueuedConnection);
                    };

                /*
                 * Sanitize ONCE, then reuse that copy for both the detailed
                 * symbol catalogue and the ultra-light function signature pass.
                 */
                const QString sanitized =
                    sanitizedCSource(source);

                reportProgress(18);

                SourceSymbolTable symbols =
                    parseSourceSymbolsFromSanitized(
                        source,
                        sanitized,
                        reportProgress);

                QStringList localFunctions =
                    functionSignaturesFromSanitizedFast(
                        source,
                        sanitized);

                reportProgress(96);

                QStringList localTypes;

                for (const SourceNamedSymbol &type :
                     symbols.types) {
                    if (!type.name.isEmpty()) {
                        localTypes.append(
                            type.name);
                    }
                }

                localFunctions.removeDuplicates();
                localTypes.removeDuplicates();

                QVariantList structureLines =
                    structureNavigationLines(
                        symbols);

                if (!self) {
                    return;
                }

                QMetaObject::invokeMethod(
                    self.data(),
                    [self,
                     guardedEditor,
                     generation,
                     editorPath,
                     symbols = std::move(symbols),
                     localFunctions =
                         std::move(localFunctions),
                     localTypes =
                         std::move(localTypes),
                     structureLines =
                         std::move(structureLines)]() mutable {

                        if (!self
                            || !guardedEditor) {
                            return;
                        }

                        CodeEditor *editor =
                            guardedEditor.data();

                        editor->setProperty(
                            "sidboxAnalysisWorkerRunning",
                            false);

                        const bool rerunRequested =
                            editor->property(
                                "sidboxAnalysisRerun")
                                .toBool();

                        editor->setProperty(
                            "sidboxAnalysisRerun",
                            false);

                        /*
                         * Any edit increments the generation. A stale worker is
                         * simply ignored — no half-old catalogue is ever applied.
                         */
                        const bool stillCurrent =
                            editor->property(
                                "sidboxAnalysisGeneration")
                                .toInt()
                                == generation;

                        if (!stillCurrent
                            || self->activeEditor()
                                != editor) {

                            if (self->activeEditor()
                                    == editor) {
                                self->statusBar()
                                    ->showMessage(
                                        self->tr(
                                            "Catalogue changed — waiting for the next sync"),
                                        900);
                            }

                            if (rerunRequested
                                && self->activeEditor()
                                    == editor) {
                                QTimer::singleShot(
                                    0,
                                    self.data(),
                                    [self]() {
                                        if (self) {
                                            self
                                                ->refreshActiveEditorAnalysis();
                                        }
                                    });
                            }

                            return;
                        }

                        if (!editorPath.isEmpty()) {
                            self
                                ->m_cachedFileFunctionSignatures
                                .insert(
                                    editorPath,
                                    localFunctions);

                            self
                                ->m_cachedFileTypeNames
                                .insert(
                                    editorPath,
                                    localTypes);
                        }

                        QStringList completions =
                            self->m_apiSignatures;

                        QStringList typeNames;

                        for (auto it =
                                 self
                                     ->m_cachedFileFunctionSignatures
                                     .constBegin();
                             it !=
                                 self
                                     ->m_cachedFileFunctionSignatures
                                     .constEnd();
                             ++it) {
                            completions.append(
                                it.value());
                        }

                        for (auto it =
                                 self
                                     ->m_cachedFileTypeNames
                                     .constBegin();
                             it !=
                                 self
                                     ->m_cachedFileTypeNames
                                     .constEnd();
                             ++it) {
                            typeNames.append(
                                it.value());
                        }

                        if (editorPath.isEmpty()) {
                            completions.append(
                                localFunctions);

                            typeNames.append(
                                localTypes);
                        }

                        typeNames.removeDuplicates();
                        typeNames.sort(
                            Qt::CaseInsensitive);

                        completions.append(
                            typeNames);

                        completions.removeDuplicates();
                        completions.sort(
                            Qt::CaseInsensitive);

                        const QStringList apiNames =
                            self->apiSyntaxNames();

                        QWidget *currentTab =
                            self->m_editorTabs
                                ? self
                                      ->m_editorTabs
                                      ->currentWidget()
                                : nullptr;

                        if (currentTab) {
                            const QList<CodeEditor *>
                                currentEditors =
                                    self->editorsForTab(
                                        currentTab);

                            for (CodeEditor *current :
                                 currentEditors) {
                                if (!current
                                    || current
                                        ->isResourceMode()) {
                                    continue;
                                }

                                current
                                    ->setFunctionCompletions(
                                        completions);

                                current
                                    ->setProjectTypeNames(
                                        typeNames);

                                current
                                    ->setApiSyntaxNames(
                                        apiNames);
                            }
                        }

                        editor->setProperty(
                            "sidboxStructureLines",
                            structureLines);

                        /*
                         * Reuse the already-parsed worker result for the tree.
                         * Previously the tree called parseSourceSymbols() AGAIN
                         * immediately after active-tab completion analysis.
                         */
                        if (self->m_functionvarList) {
                            if (self
                                    ->m_symbolTreeEditor) {
                                self
                                    ->saveSymbolTreeExpansionState(
                                        self
                                            ->m_symbolTreeEditor);
                            }

                            self
                                ->m_functionvarList
                                ->clear();

                            populateSourceSymbolTree(
                                self
                                    ->m_functionvarList,
                                symbols);

                            self
                                ->restoreSymbolTreeExpansionState(
                                    editor);

                            self->m_symbolTreeEditor =
                                editor;
                        }

                        editor->setProperty(
                            "sidboxAnalysisDirty",
                            false);

                        self->showCatalogueProgress(
                            editor,
                            100);

                        /*
                         * A navigation event may have requested one newer pass
                         * while this worker was running. Do that pass now, but
                         * still off the UI thread.
                         */
                        if (rerunRequested) {
                            QTimer::singleShot(
                                0,
                                self.data(),
                                [self]() {
                                    if (self) {
                                        self
                                            ->refreshActiveEditorAnalysis();
                                    }
                                });
                        }
                    },
                    Qt::QueuedConnection);
            }));
}


void MainWindow::ensureApiCatalog()
{
    if (m_apiTips.isEmpty() || m_apiSignatures.isEmpty()) {
        refreshApiCatalog();
    }
}


void MainWindow::refreshApiCatalog()
{
    m_apiTips.clear();
    m_apiSignatures.clear();

    const QString libsRoot = ideLibsPath();
    const QString apiPath =
        QDir(libsRoot).filePath(QStringLiteral("api"));
    const QString libraryPath =
        QDir(libsRoot).filePath(QStringLiteral("libraries"));

    QStringList catalogTexts;
    int scannedFileCount = 0;

    auto appendCatalogFiles =
        [&catalogTexts, &scannedFileCount](
            const QString &rootPath,
            const QStringList &filters) {
            if (!QFileInfo::exists(rootPath)) {
                return;
            }

            QDirIterator iterator(
                rootPath,
                filters,
                QDir::Files,
                QDirIterator::Subdirectories);

            while (iterator.hasNext()) {
                QFile file(iterator.next());
                if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                    continue;
                }

                catalogTexts.append(
                    uncommentedApiText(
                        QString::fromUtf8(file.readAll())));
                ++scannedFileCount;
            }
        };

    // Core Sidbox API: declarations plus source-side wrappers/types.
    appendCatalogFiles(
        apiPath,
        {QStringLiteral("*.h"), QStringLiteral("*.c")});

    /*
     * Static libraries expose their public interface through the accompanying
     * headers.  The .a archive itself is binary and cannot be meaningfully
     * parsed for Cheat Sheet descriptions/signatures, so catalogue the .h
     * files and let the build system continue linking every .a as before.
     */
    appendCatalogFiles(
        libraryPath,
        {QStringLiteral("*.h")});

    if (catalogTexts.isEmpty()) {
        if (m_quickTipLabel) {
            m_quickTipLabel->setText(
                tr("F1: API/library catalogue not found under %1")
                    .arg(QDir::toNativeSeparators(libsRoot)));
        }
        return;
    }

    QHash<QString, QString> functionPointers;
    for (const QString &text : std::as_const(catalogTexts)) {
        collectApiFunctionPointers(text, &functionPointers);
    }

    for (const QString &text : std::as_const(catalogTexts)) {
        collectApiMacros(
            text,
            functionPointers,
            &m_apiTips,
            &m_apiSignatures);
        collectApiDefines(
            text,
            &m_apiTips,
            &m_apiSignatures);
        collectApiTypes(
            text,
            &m_apiTips,
            &m_apiSignatures);
        collectApiLineSymbols(
            text,
            &m_apiTips,
            &m_apiSignatures);
        m_apiSignatures.append(
            functionSignaturesFromText(text));
    }

    m_apiSignatures.removeDuplicates();
    m_apiSignatures.sort(Qt::CaseInsensitive);

    if (m_quickTipLabel) {
        m_quickTipLabel->setText(
            tr("F1: SDK ready: %1 tips from %2 API/library files")
                .arg(m_apiTips.count())
                .arg(scannedFileCount));
    }
}

QString MainWindow::quickTipForSymbol(const QString &symbol) const
{
    const QString name = symbol.trimmed();
    if (name.isEmpty()) {
        return {};
    }

    const auto exactMatch = m_apiTips.constFind(name);
    if (exactMatch != m_apiTips.constEnd()) {
        return exactMatch.value();
    }

    for (auto it = m_apiTips.constBegin(); it != m_apiTips.constEnd(); ++it) {
        if (it.key().compare(name, Qt::CaseInsensitive) == 0) {
            return it.value();
        }
    }

    /*
     * This function is used by passive cursor tips. Cursor movement happens on
     * normal typing too, so never launch a whole-project scan here.
     */
    for (auto it =
             m_cachedFileFunctionSignatures.constBegin();
         it !=
             m_cachedFileFunctionSignatures.constEnd();
         ++it) {
        for (const QString &signature : it.value()) {
            const int parenIndex =
                signature.indexOf(QLatin1Char('('));

            const QString functionName =
                parenIndex > 0
                    ? signature.left(parenIndex)
                    : signature;

            if (functionName.compare(
                    name,
                    Qt::CaseInsensitive) == 0) {
                return signature;
            }
        }
    }

    return {};
}

void MainWindow::showPassiveQuickTip(const QString &symbol)
{
    if (!m_quickTipLabel) {
        return;
    }

    ensureApiCatalog();
    const QString tip = quickTipForSymbol(symbol);
    if (!tip.isEmpty()) {
        m_quickTipLabel->setText(tip);
    }
}


void MainWindow::showQuickTip(const QString &symbol)
{
    if (!m_quickTipLabel) {
        return;
    }

    ensureApiCatalog();
    const QString name = symbol.trimmed();
    if (name.isEmpty()) {
        m_quickTipLabel->setText(tr("F1: move the cursor onto an API call first"));
        return;
    }

    const QString tip = quickTipForSymbol(name);
    if (tip.isEmpty()) {
        m_quickTipLabel->setText(tr("F1: no API tip for %1").arg(name));
        return;
    }

    m_quickTipLabel->setText(tip);
    statusBar()->showMessage(tip, 4000);
}


void MainWindow::updateTabTitle(CodeEditor *editor)
{
    const int index = tabIndexForEditor(editor);
    if (index >= 0) {
        m_editorTabs->setTabText(
            index,
            tabTitleForEditor(editor));

        m_editorTabs->setTabIcon(
            index,
            editorTabIconForFile(
                editor->filePath()));
    }

    updateEditorSplitPresentation();
}

/*
QString MainWindow::tabTitleForEditor(CodeEditor *editor) const
{
    QString title = editor->filePath().isEmpty()
        ? tr("untitled.c")
        : QFileInfo(editor->filePath()).fileName();

    if (editor->document()->isModified()) {
        title.prepend(QLatin1Char('*'));
    }

    return title;
}
*/

QString MainWindow::tabTitleForEditor(CodeEditor *editor, int defaultType) const
{
    QString title;
    if (editor->filePath().isEmpty()) {
        const QString recoveredName = editor->property(
            "sidboxRecoveryDisplayName").toString();
        if (!recoveredName.isEmpty()) {
            title = tr("Recovered %1").arg(recoveredName);
        } else if (defaultType == 1) {
            title = tr("untitled.h");
        } else if (defaultType == 2) {
            title = tr("untitled.inc");
        } else {
            title = tr("untitled.c");
        }
    } else {
        title = QFileInfo(editor->filePath()).fileName();

        if (editor->property("sidboxApiReference").toBool()) {
            title += tr(" [API]");
        }
    }

    if (editor->document()->isModified()) {
        title.prepend(QLatin1Char('*'));
    }

    return title;
}

QString MainWindow::displayPath(const QString &filePath) const
{
    if (m_projectPath.isEmpty()) {
        return QFileInfo(filePath).fileName();
    }

    return QDir(m_projectPath).relativeFilePath(filePath);
}

QString MainWindow::projectFileDisplayText(const QString &filePath) const
{
    const QFileInfo info(filePath);
    return QStringLiteral("%1 (%2)").arg(displayPath(filePath), formattedFileSize(info.size()));
}

QStringList MainWindow::projectFolderSourceFiles() const
{
    QStringList files;
    if (m_projectPath.isEmpty() || !QFileInfo(m_projectPath).isDir()) {
        return files;
    }

    // File discovery is separate from C parsing: all these resources should
    // appear in the explorer, but only C-family text goes to IntelliSense.
    const QStringList filters = {
        QStringLiteral("*.c"), QStringLiteral("*.h"), QStringLiteral("*.inc"),
        QStringLiteral("*.cc"), QStringLiteral("*.cpp"), QStringLiteral("*.hpp"),
        QStringLiteral("*.res"), QStringLiteral("*.txt"), QStringLiteral("*.md"),
        QStringLiteral("*.sbui"), QStringLiteral("*.sbgm"), QStringLiteral("*.uis"),
        QStringLiteral("*.ppb"), QStringLiteral("*.pal"), QStringLiteral("*.act"),
        QStringLiteral("*.png"), QStringLiteral("*.bmp"), QStringLiteral("*.jpg"),
        QStringLiteral("*.jpeg"), QStringLiteral("*.gif"),
        QStringLiteral("*.wav"), QStringLiteral("*.mod"), QStringLiteral("*.s3m"),
        QStringLiteral("*.xm"), QStringLiteral("*.med"), QStringLiteral("*.tfmx"),
        QStringLiteral("*.sid"), QStringLiteral("*.sba")
    };

    std::function<void(const QDir &)> visit;
    visit = [&](const QDir &directory) {
        const QFileInfoList entries = directory.entryInfoList(
            filters, QDir::Files | QDir::NoDotAndDotDot,
            QDir::Name | QDir::IgnoreCase);
        for (const QFileInfo &file : entries)
            files.append(file.absoluteFilePath());

        const QFileInfoList subdirs = directory.entryInfoList(
            QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks,
            QDir::Name | QDir::IgnoreCase);
        for (const QFileInfo &subdir : subdirs) {
            if (!isExcludedProjectDirectoryName(subdir.fileName()))
                visit(QDir(subdir.absoluteFilePath()));
        }
    };
    visit(QDir(m_projectPath));

    files.removeDuplicates();
    files.sort(Qt::CaseInsensitive);
    return files;
}

bool MainWindow::isProjectExplorerFile(const QString &filePath) const
{
    return isProjectExplorerSuffix(QFileInfo(filePath).suffix());
}

QStringList MainWindow::collectOpenProjectFiles() const
{
    QStringList files;
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        QWidget *tab = m_editorTabs->widget(i);
        if (auto *game = dynamic_cast<SidboxGameDesigner *>(tab)) {
            if (!game->filePath().isEmpty()) files.append(QFileInfo(game->filePath()).absoluteFilePath());
            continue;
        }
        if (auto *designer = dynamic_cast<SidboxGuiDesigner *>(tab)) {
            const QString designPath = QFileInfo(designer->filePath()).absoluteFilePath();
            if (!designPath.isEmpty() && !files.contains(designPath)) files.append(designPath);
            const QString cPath = QFileInfo(designPath).dir().filePath(QFileInfo(designPath).completeBaseName() + QStringLiteral(".c"));
            if (QFileInfo::exists(cPath) && !files.contains(QFileInfo(cPath).absoluteFilePath())) files.append(QFileInfo(cPath).absoluteFilePath());
            continue;
        }
        auto *editor = primaryEditorForTab(tab);
        if (!editor || editor->filePath().isEmpty()) continue;
        const QString filePath = QFileInfo(editor->filePath()).absoluteFilePath();
        if (!files.contains(filePath)) files.append(filePath);
    }
    files.sort(Qt::CaseInsensitive);
    return files;
}

QStringList MainWindow::projectFilesForCompile() const
{
    QStringList files;
    QStringList candidates = m_projectFilesInProject;
    candidates.append(projectFolderSourceFiles());
    candidates.removeDuplicates();

    for (const QString &filePath : std::as_const(candidates)) {
        // Never compile a history file, even if it was accidentally listed
        // explicitly in an older hand-edited project manifest.
        const QString relativePath = m_projectPath.isEmpty()
            ? QString() : QDir(m_projectPath).relativeFilePath(filePath);
        if (relativePath.startsWith(QStringLiteral(".history/"))
            || relativePath.startsWith(QStringLiteral("build/"))
            || relativePath.startsWith(QStringLiteral("buildv1/")))
            continue;
        if (isCompilableSource(filePath)) {
            files.append(filePath);
        }
    }
    files.removeDuplicates();
    files.sort(Qt::CaseInsensitive);
    return files;
}

QStringList MainWindow::projectFunctionSignatures() const
{
    QStringList signatures;
    signatures.append(m_apiSignatures);
    QStringList scannedOpenFiles;

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (!editor || editor->isResourceMode()) {
            continue;
        }

        signatures.append(functionSignaturesFromText(editor->toPlainText()));
        if (!editor->filePath().isEmpty()) {
            scannedOpenFiles.append(QFileInfo(editor->filePath()).absoluteFilePath());
        }
    }

    QStringList projectFiles = m_projectFilesInProject;
    projectFiles.append(projectFolderSourceFiles());
    projectFiles.removeDuplicates();

    for (const QString &filePath : std::as_const(projectFiles)) {
        const QString absolutePath = QFileInfo(filePath).absoluteFilePath();
        if (scannedOpenFiles.contains(absolutePath)
            || !QFileInfo::exists(absolutePath)
            || !canContainFunctionSignatures(absolutePath)) {
            continue;
        }

        QFile file(absolutePath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        signatures.append(functionSignaturesFromText(QString::fromUtf8(file.readAll())));
    }

    signatures.removeDuplicates();
    signatures.sort(Qt::CaseInsensitive);
    return signatures;
}

QStringList MainWindow::projectTypeNames() const
{
    QStringList names;
    QSet<QString> scannedPaths;

    auto appendTypes = [&names](const QString &source) {
        const SourceSymbolTable symbols = parseSourceSymbols(source);

        for (const SourceNamedSymbol &type : symbols.types) {
            if (!type.name.isEmpty()) {
                names.append(type.name);
            }
        }
    };

    // Open tabs win: use the live in-memory text, including unsaved changes.
    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
        if (!editor || editor->isResourceMode()) {
            continue;
        }

        appendTypes(editor->toPlainText());

        if (!editor->filePath().isEmpty()) {
            scannedPaths.insert(
                QFileInfo(editor->filePath()).absoluteFilePath());
        }
    }

    // Then scan all remaining project files on disk, including subfolders,
    // headers and .inc files.
    QStringList projectFiles = m_projectFilesInProject;
    projectFiles.append(projectFolderSourceFiles());
    projectFiles.removeDuplicates();

    for (const QString &filePath : std::as_const(projectFiles)) {
        const QString absolutePath =
            QFileInfo(filePath).absoluteFilePath();

        if (absolutePath.isEmpty()
            || scannedPaths.contains(absolutePath)
            || !QFileInfo::exists(absolutePath)
            || !canContainFunctionSignatures(absolutePath)) {
            continue;
        }

        QFile file(absolutePath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        appendTypes(QString::fromUtf8(file.readAll()));
    }

    names.removeDuplicates();
    names.sort(Qt::CaseInsensitive);
    return names;
}

QStringList MainWindow::functionSignaturesFromText(
    const QString &text) const
{
    /*
     * The old implementation used a global QRegularExpression over the whole
     * file. For Sidbox's catalogue use-case a tiny linear C scanner is both
     * cheaper and more predictable on 100-200 KB sources.
     */
    const QString sanitized =
        sanitizedCSource(text);

    return functionSignaturesFromSanitizedFast(
        text,
        sanitized);
}


QList<ProjectSearchResult> MainWindow::findInProject(
    const QString &needle,
    bool matchCase,
    bool wholeWord) const
{
    QList<ProjectSearchResult> results;

    if (needle.isEmpty()) {
        return results;
    }

    /*
     * Build one list of project files. An open editor always wins over the
     * on-disk copy so unsaved edits are searched live.
     */
    QStringList candidates = m_projectFilesInProject;
    candidates.append(projectFolderSourceFiles());

    QHash<QString, CodeEditor *> openEditors;

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *editor =
            primaryEditorForTab(m_editorTabs->widget(i));

        if (!editor || editor->filePath().isEmpty()) {
            continue;
        }

        const QString path =
            QFileInfo(editor->filePath()).absoluteFilePath();

        openEditors.insert(path, editor);

        if (!candidates.contains(path)) {
            candidates.append(path);
        }
    }

    candidates.removeDuplicates();
    candidates.sort(Qt::CaseInsensitive);

    const Qt::CaseSensitivity sensitivity =
        matchCase ? Qt::CaseSensitive : Qt::CaseInsensitive;

    QRegularExpression wholeWordExpression;

    if (wholeWord) {
        QRegularExpression::PatternOptions options =
            QRegularExpression::NoPatternOption;

        if (!matchCase) {
            options |= QRegularExpression::CaseInsensitiveOption;
        }

        wholeWordExpression =
            QRegularExpression(
                QStringLiteral("\\b%1\\b")
                    .arg(QRegularExpression::escape(needle)),
                options);
    }

    for (const QString &rawPath : std::as_const(candidates)) {
        const QString filePath =
            QFileInfo(rawPath).absoluteFilePath();

        // Project searches and Replace must never interpret .mod/.med/.ppb
        // (or any other binary resource) as mutable UTF-8 text.
        if (!canSearchProjectText(filePath)) continue;
        if (!m_projectPath.isEmpty()
            && isExcludedProjectRelativePath(QDir(m_projectPath).relativeFilePath(filePath)))
            continue;

        QString text;

        if (CodeEditor *editor =
                openEditors.value(filePath, nullptr)) {
            text = editor->toPlainText();
        } else {
            QFile file(filePath);

            if (!file.open(
                    QIODevice::ReadOnly | QIODevice::Text)) {
                continue;
            }

            text = QString::fromUtf8(file.readAll());
        }

        QList<QPair<int, int>> matches;

        if (wholeWord) {
            QRegularExpressionMatchIterator iterator =
                wholeWordExpression.globalMatch(text);

            while (iterator.hasNext()) {
                const QRegularExpressionMatch match = iterator.next();

                if (match.capturedLength() > 0) {
                    matches.append({
                        match.capturedStart(),
                        match.capturedLength()
                    });
                }
            }
        } else {
            int from = 0;

            while (from <= text.size()) {
                const int found =
                    text.indexOf(needle, from, sensitivity);

                if (found < 0) {
                    break;
                }

                matches.append({found, needle.size()});
                from = found + qMax(1, needle.size());
            }
        }

        for (const auto &match : matches) {
            const int start = match.first;
            const int length = match.second;

            const int line =
                text.left(start).count(QLatin1Char('\n'));

            const int lineStart =
                text.lastIndexOf(QLatin1Char('\n'), start - 1) + 1;

            int lineEnd =
                text.indexOf(QLatin1Char('\n'), start);

            if (lineEnd < 0) {
                lineEnd = text.size();
            }

            const int column = start - lineStart;

            QString preview =
                text.mid(lineStart, lineEnd - lineStart).trimmed();

            if (preview.size() > 180) {
                preview = preview.left(177)
                    + QStringLiteral("...");
            }

            results.append({
                filePath,
                line,
                column,
                start,
                length,
                preview
            });
        }
    }

    return results;
}

bool MainWindow::replaceProjectResults(
    const QList<ProjectSearchResult> &results,
    const QString &replacement)
{
    if (results.isEmpty()) {
        return true;
    }

    QHash<QString, QList<ProjectSearchResult>> byFile;

    for (const ProjectSearchResult &result : results) {
        if (result.filePath.isEmpty()
            || result.start < 0
            || result.length < 0) {
            continue;
        }

        byFile[QFileInfo(result.filePath).absoluteFilePath()]
            .append(result);
    }

    for (auto it = byFile.begin();
         it != byFile.end();
         ++it) {

        QList<ProjectSearchResult> fileResults = it.value();

        std::sort(
            fileResults.begin(),
            fileResults.end(),
            [](const ProjectSearchResult &a,
               const ProjectSearchResult &b) {
                return a.start > b.start;
            });

        CodeEditor *openEditor = nullptr;

        for (int i = 0; i < m_editorTabs->count(); ++i) {
            auto *editor =
                qobject_cast<CodeEditor *>(
                    m_editorTabs->widget(i));

            if (editor
                && !editor->filePath().isEmpty()
                && QFileInfo(editor->filePath()).absoluteFilePath()
                    == it.key()) {
                openEditor = editor;
                break;
            }
        }

        if (openEditor) {
            QTextCursor cursor(openEditor->document());
            cursor.beginEditBlock();

            for (const ProjectSearchResult &result :
                 fileResults) {
                if (result.start + result.length
                    > openEditor->document()->characterCount()) {
                    continue;
                }

                cursor.setPosition(result.start);
                cursor.setPosition(
                    result.start + result.length,
                    QTextCursor::KeepAnchor);
                cursor.insertText(replacement);
            }

            cursor.endEditBlock();

            openEditor->document()->setModified(true);
            updateTabTitle(openEditor);
            continue;
        }

        QFile file(it.key());

        if (!file.open(
                QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::warning(
                this,
                tr("Replace"),
                tr("Could not read %1.")
                    .arg(QDir::toNativeSeparators(it.key())));
            return false;
        }

        QString text = QString::fromUtf8(file.readAll());
        file.close();

        for (const ProjectSearchResult &result :
             fileResults) {
            if (result.start < 0
                || result.start + result.length > text.size()) {
                continue;
            }

            text.replace(
                result.start,
                result.length,
                replacement);
        }

        QSaveFile output(it.key());

        if (!output.open(
                QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::warning(
                this,
                tr("Replace"),
                tr("Could not write %1.")
                    .arg(QDir::toNativeSeparators(it.key())));
            return false;
        }

        output.write(text.toUtf8());

        if (!output.commit()) {
            QMessageBox::warning(
                this,
                tr("Replace"),
                tr("Could not finish writing %1.")
                    .arg(QDir::toNativeSeparators(it.key())));
            return false;
        }
    }

    refreshFunctionCompletions();
    refreshSymbolTree();
    return true;
}

void MainWindow::jumpToProjectSearchResult(
    const ProjectSearchResult &result)
{
    if (result.filePath.isEmpty()) {
        return;
    }

    CodeEditor *editor = nullptr;
    const QString target =
        QFileInfo(result.filePath).absoluteFilePath();

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        auto *candidate =
            primaryEditorForTab(m_editorTabs->widget(i));

        if (candidate
            && !candidate->filePath().isEmpty()
            && QFileInfo(candidate->filePath()).absoluteFilePath()
                == target) {
            editor = candidate;
            m_editorTabs->setCurrentIndex(i);
            break;
        }
    }

    if (!editor) {
        if (!openFile(target)) {
            return;
        }

        editor = activeEditor();
    }

    if (!editor) {
        return;
    }

    QTextBlock block =
        editor->document()->findBlockByNumber(
            qMax(0, result.line));

    if (!block.isValid()) {
        return;
    }

    QTextCursor cursor(block);

    if (result.column > 0) {
        cursor.movePosition(
            QTextCursor::NextCharacter,
            QTextCursor::MoveAnchor,
            result.column);
    }

    if (result.length > 0) {
        cursor.movePosition(
            QTextCursor::NextCharacter,
            QTextCursor::KeepAnchor,
            result.length);
    }

    editor->setTextCursor(cursor);
    editor->centerCursor();
    editor->setFocus();
}

QString MainWindow::toProjectRelativePath(const QString &filePath) const
{
    if (filePath.isEmpty() || m_projectPath.isEmpty()) {
        return filePath;
    }

    return QDir(m_projectPath).relativeFilePath(filePath);
}

QString MainWindow::fromProjectRelativePath(const QString &filePath) const
{
    if (filePath.isEmpty()) {
        return {};
    }

    QFileInfo info(filePath);
    if (info.isAbsolute()) {
        return info.absoluteFilePath();
    }

    return QFileInfo(QDir(m_projectPath).filePath(filePath)).absoluteFilePath();
}

QString MainWindow::ideLibsPath() const
{
    const QDir appDir(QCoreApplication::applicationDirPath());
    const QStringList candidates = {
        appDir.filePath(QStringLiteral("idelibs")),
        appDir.filePath(QStringLiteral("../idelibs")),
        appDir.filePath(QStringLiteral("../../idelibs")),
        appDir.filePath(QStringLiteral("../SidboxIDE/idelibs")),
        QDir::current().filePath(QStringLiteral("idelibs")),
        QDir::current().filePath(QStringLiteral("SidboxIDE/idelibs"))
    };

    for (const QString &candidate : candidates) {
        const QFileInfo info(candidate);
        if (info.exists() && info.isDir()) {
            return info.absoluteFilePath();
        }
    }

    return QFileInfo(appDir.filePath(QStringLiteral("../../idelibs"))).absoluteFilePath();
}

QString MainWindow::defaultLinkerScriptPath(const QString &projectType) const
{
    const QString type = normalizedProjectType(projectType.isEmpty() ? m_projectType : projectType);
    return QDir(ideLibsPath()).filePath(type == GameProjectType ? QStringLiteral("gaming.ld") : QStringLiteral("gui.ld"));
}

QString MainWindow::projectLinkerScriptPath() const
{
    if (m_projectFilePath.isEmpty()) {
        return {};
    }

    const QString fileName = QFileInfo(m_projectFilePath).completeBaseName() + QStringLiteral(".ld");
    return QDir(m_projectPath).filePath(fileName);
}

QString MainWindow::effectiveLinkerScriptPath() const
{
    if (!m_linkerScriptPath.isEmpty()) {
        return m_linkerScriptPath;
    }

    const QString projectLinker = projectLinkerScriptPath();
    return projectLinker.isEmpty() ? defaultLinkerScriptPath() : projectLinker;
}

bool MainWindow::updateProjectLinkerScript(QString *errorMessage) const
{
    if (m_projectFilePath.isEmpty() || m_projectPath.isEmpty()) {
        if (errorMessage) {
            *errorMessage = tr("Save the project first so the linker script has a project folder.");
        }
        return false;
    }

    const QString sourcePath = (normalizedProjectType(m_projectType) == GuiProjectType &&
        m_appletFormat == QStringLiteral("v2"))
        ? QDir(ideLibsPath()).filePath(QStringLiteral("gui_v2.ld"))
        : defaultLinkerScriptPath();
    QFile sourceFile(sourcePath);
    if (!sourceFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = tr("Could not read %1.").arg(QDir::toNativeSeparators(sourcePath));
        }
        return false;
    }

    QString scriptText = QString::fromUtf8(sourceFile.readAll());
    const QString profileValue = normalizedProjectType(m_projectType) == GameProjectType
        ? QStringLiteral("0")
        : QStringLiteral("1");

    const bool linkerV2 = normalizedProjectType(m_projectType) == GuiProjectType &&
        m_appletFormat == QStringLiteral("v2");
    const bool linkedSettingsOk = linkerV2
        ? (replaceLinkerAssignment(&scriptText, QStringLiteral("_v2_app_limit"), hexBytes(m_appSizeKb))
           && replaceLinkerAssignment(&scriptText, QStringLiteral("_v2_stack_bytes"), hexBytes(m_v2StackKb))
           && replaceLinkerAssignment(&scriptText, QStringLiteral("_v2_heap_bytes"), hexBytes(m_v2HeapKb)))
        : (replaceLinkerAssignment(&scriptText, QStringLiteral("_profile_is_desktop"), profileValue)
           && replaceLinkerAssignment(&scriptText, QStringLiteral("_requested_app_size"), hexBytes(m_appSizeKb))
           && replaceLinkerAssignment(&scriptText, QStringLiteral("_largest_modfile"), hexBytes(m_modSizeKb)));
    if (!linkedSettingsOk) {
        if (errorMessage) {
            *errorMessage = tr("The template linker script is missing an expected Sidbox setting.");
        }
        return false;
    }

    /*
     * The template's wizard comment contains the template app-size value.
     * Keep that human-readable line synchronized too, otherwise somebody can
     * quite reasonably see one value in Project Settings and another in the
     * generated .ld even though the assignment itself is correct.
     */
    const QString appSizeHex = hexBytes(m_appSizeKb);
    scriptText.replace(
        QRegularExpression(
            QStringLiteral(
                R"((Applet allowance:\s*)\d+\s*KB\s*/\s*0x[0-9A-Fa-f]+)")),
        QStringLiteral("\\1%1 KB / %2")
            .arg(m_appSizeKb)
            .arg(appSizeHex));

    scriptText.prepend(tr("/* Generated by Sidbox IDE from %1. Edit the project settings to regenerate. */\n")
        .arg(QDir::toNativeSeparators(sourcePath)));

    const QString destinationPath = projectLinkerScriptPath();
    QSaveFile destinationFile(destinationPath);
    if (!destinationFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = tr("Could not write %1.").arg(QDir::toNativeSeparators(destinationPath));
        }
        return false;
    }

    destinationFile.write(scriptText.toUtf8());
    if (!destinationFile.commit()) {
        if (errorMessage) {
            *errorMessage = tr("Could not finish writing %1.").arg(QDir::toNativeSeparators(destinationPath));
        }
        return false;
    }

    return true;
}

QString MainWindow::compilerPath() const
{
    return QDir(ideLibsPath()).filePath(QStringLiteral("tools/bin/arm-none-eabi-gcc"));
}

QString MainWindow::objcopyPath() const
{
    return QDir(ideLibsPath()).filePath(QStringLiteral("tools/bin/arm-none-eabi-objcopy"));
}

QStringList MainWindow::sidboxApiSourceFiles() const
{
    // realistically this should scan the folders, and search for the .c / .h for function calls, type defs
    const QDir apiDir(QDir(ideLibsPath()).filePath(QStringLiteral("api")));
    const QStringList relativePaths = {
        QStringLiteral("applet.s"),
        QStringLiteral("apis.c"),
        QStringLiteral("syscalls.c"),
        QStringLiteral("crt/crt.c"),
        QStringLiteral("graphics/graphics.c"),
        QStringLiteral("audio/audio.c"),
        QStringLiteral("touch/touch.c")
    };

    QStringList files;
    for (const QString &relativePath : relativePaths) {
        const QString absolutePath = apiDir.filePath(relativePath);
        if (QFileInfo::exists(absolutePath)) {
            files.append(absolutePath);
        }
    }
    return files;
}

QStringList MainWindow::sidboxLibraryFiles() const
{
    QStringList files;
    const QString libraryPath = QDir(ideLibsPath()).filePath(QStringLiteral("libraries"));
    if (!QFileInfo::exists(libraryPath)) {
        return files;
    }

    QDirIterator iterator(libraryPath, {QStringLiteral("*.a")}, QDir::Files, QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        files.append(iterator.next());
    }
    return files;
}

void MainWindow::applyEditorFont()
{
    QFont font = QFontDatabase::systemFont(QFontDatabase::FixedFont);
    font.setPointSize(m_editorFontPointSize);

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        const QList<CodeEditor *> editors =
            editorsForTab(m_editorTabs->widget(i));

        for (CodeEditor *editor : editors) {
            editor->setFont(font);
            editor->setTabStopDistance(
                editor->fontMetrics().horizontalAdvance(QLatin1Char(' ')) * 4);
            editor->setCompletionFont(font);
            editor->refreshLineNumberAreaWidth();
        }
    }
}


void MainWindow::applyTheme()
{
    const auto C = [](const QColor &colour) {
        return ideThemeColorName(colour);
    };

    const QString normalStyle = QStringLiteral(
        "QMainWindow, QWidget { background-color:%1; color:%2; }"
        "QLabel { background-color:%1; color:%3; border:none; }"

        "QToolBar { background-color:%1; border:none; spacing:1px; padding:1px; }"
        "QToolButton { background-color:%1; color:%3; border:none; border-radius:0px; padding:3px; }"
        "QToolButton:hover { background-color:%4; }"
        "QToolButton:pressed { background-color:%5; }"

        "QPushButton { background-color:%1; color:%2; border:1px solid %6; border-radius:0px; padding:4px 8px; }"
        "QPushButton:hover { background-color:%4; border:1px solid %5; }"
        "QPushButton:pressed { background-color:%5; color:%3; }"

        "QTreeWidget { background-color:%7; color:%2; border:1px solid %8; "
        " alternate-background-color:%9; border-radius:0px; }"
        "QTreeWidget::item { border-radius:0px; padding:1px; }"
        "QTreeWidget::item:selected { background-color:%5; color:%3; }"
        "QTreeWidget::item:hover { background-color:%4; }"

        "QTabWidget::pane { background-color:%1; border:1px solid %8; border-radius:0px; }"
        "QTabBar::tab { background-color:%1; color:%10; border:1px solid %6; "
        " border-bottom:none; border-radius:0px; padding:5px 10px; }"
        "QTabBar::tab:selected { background-color:%5; color:%3; }"
        "QTabBar::tab:hover:!selected { background-color:%4; }"

        "QStatusBar { background-color:%1; color:%10; border-top:1px solid %6; }"
        "QProgressBar { background-color:%7; color:%3; border:1px solid %6; "
        " border-radius:0px; text-align:center; }"
        "QProgressBar::chunk { background-color:%5; border-radius:0px; margin:0px; }"
        "QProgressBar#compileProgress::chunk { width:18px; margin:1px; }"
        "QSplitter::handle { background-color:%4; }"
        "QSplitter::handle:hover { background-color:%5; }"

        "QMenu { background-color:%11; color:%2; border:1px solid %6; }"
        "QMenu::item { padding:5px 24px 5px 8px; }"
        "QMenu::item:selected { background-color:%5; color:%3; }"

        "QScrollBar:vertical { background:%11; width:12px; margin:0px; }"
        "QScrollBar:horizontal { background:%11; height:12px; margin:0px; }"
        "QScrollBar::handle:vertical { background:%12; min-height:20px; border-radius:0px; }"
        "QScrollBar::handle:horizontal { background:%12; min-width:20px; border-radius:0px; }"
        "QScrollBar::handle:vertical:hover, QScrollBar::handle:horizontal:hover { background:%13; }"
        "QScrollBar:add-line, QScrollBar:sub-line { width:0px; height:0px; }"

        "QLineEdit, QPlainTextEdit, QSpinBox { background-color:%7; color:%2; "
        " border:1px solid %6; border-radius:0px; "
        " selection-background-color:%5; selection-color:%3; }"

        "QToolTip { background-color:%14; color:%15; border:2px solid %5; "
        " padding:5px 5px; font-size:12px; font-weight:500; }")
        .arg(C(m_theme.windowBackground))      // 1
        .arg(C(m_theme.text))                  // 2
        .arg(C(m_theme.brightText))            // 3
        .arg(C(m_theme.hover))                 // 4
        .arg(C(m_theme.accent))                // 5
        .arg(C(m_theme.border))                // 6
        .arg(C(m_theme.inputBackground))       // 7
        .arg(C(m_theme.treeBorder))            // 8
        .arg(C(m_theme.alternateBackground))   // 9
        .arg(C(m_theme.mutedText))             // 10
        .arg(C(m_theme.menuBackground))        // 11
        .arg(C(m_theme.scrollHandle))          // 12
        .arg(C(m_theme.scrollHandleHover))     // 13
        .arg(C(m_theme.tooltipBackground))     // 14
        .arg(C(m_theme.tooltipText));          // 15

    // Disabled widgets were still using their full-strength enabled colours.
    // Apply explicit theme-derived disabled colours throughout the IDE, not
    // merely to the Game Object Properties dialog. No rounded corners.
    const QColor disabledText = QColor::fromRgbF(
        m_theme.mutedText.redF() * 0.7 + m_theme.panelBackground.redF() * 0.3,
        m_theme.mutedText.greenF() * 0.7 + m_theme.panelBackground.greenF() * 0.3,
        m_theme.mutedText.blueF() * 0.7 + m_theme.panelBackground.blueF() * 0.3);
    const QString disabledStyle = QStringLiteral(
        "QPushButton:disabled, QToolButton:disabled, QComboBox:disabled, "
        "QSpinBox:disabled, QDoubleSpinBox:disabled, QLineEdit:disabled { "
        "background-color:%1; color:%2; border:1px solid %3; "
        "border-radius:0px; } "
        "QComboBox::drop-down:disabled { background-color:%1; border-left:1px solid %3; } "
        "QCheckBox:disabled, QRadioButton:disabled, QLabel:disabled, "
        "QGroupBox:disabled { color:%2; } "
        "QMenu::item:disabled { color:%2; } "
        "QTabBar::tab:disabled { background-color:%1; color:%2; } "
        "QComboBox QAbstractItemView:disabled { background:%1; color:%2; }")
        .arg(C(m_theme.panelBackground), C(disabledText), C(m_theme.panelBackground));
    setStyleSheet(normalStyle + disabledStyle);

    // The memory bars get the active IDE theme (including user colour edits).
    // These use a continuous fill, without the global build-progress stripes.
    if (auto *memoryPanel = findChild<QWidget *>(
            QStringLiteral("sidboxAppletMemoryPanel"))) {
        const QString barStyle = QStringLiteral(
            "QProgressBar { background-color:%1; color:%2; border:1px solid %3; "
            "border-radius:0px; text-align:center; } "
            "QProgressBar::chunk { background-color:%4; border-radius:0px; "
            "margin:0px; }")
            .arg(C(m_theme.inputBackground), C(m_theme.brightText),
                 C(m_theme.border), C(m_theme.accent));
        for (QProgressBar *bar : memoryPanel->findChildren<QProgressBar *>())
            bar->setStyleSheet(barStyle);
        if (auto *details = memoryPanel->findChild<QLabel *>(
                QStringLiteral("sidboxMemoryDetails")))
            details->setStyleSheet(QStringLiteral("color:%1; font-size:10px;")
                                   .arg(C(m_theme.mutedText)));
    }

    if (m_projectFiles) {
        m_projectFiles->setStyleSheet(QStringLiteral(
            "QTreeWidget { border:1px solid %1; border-radius:0px; }"
            "QTreeWidget::item { border-radius:0px; }"
            "QTreeWidget::item:selected { background-color:%2; color:%3; }"
            "QTreeWidget::item:selected:hover { border:1px solid %4; background-color:%2; }")
            .arg(C(m_theme.treeBorder),
                 C(m_theme.accent),
                 C(m_theme.brightText),
                 C(m_theme.border)));
    }

    if (m_functionvarList) {
        m_functionvarList->setStyleSheet(QStringLiteral(
            "QTreeWidget { border:1px solid %1; border-radius:0px; }"
            "QTreeWidget::item { border-radius:0px; }"
            "QTreeWidget::item:selected { background-color:%2; color:%3; }"
            "QTreeWidget::item:selected:hover { border:1px solid %4; background-color:%2; }")
            .arg(C(m_theme.treeBorder),
                 C(m_theme.accent),
                 C(m_theme.brightText),
                 C(m_theme.border)));
    }

    if (m_editorTabs) {
        m_editorTabs->setStyleSheet(QStringLiteral(
            "QTabWidget::pane { border:1px solid %1; border-radius:0px; }"
            "QTabBar::tab { background:%2; color:%3; border:1px solid %1; "
            " border-bottom:none; border-radius:0px; padding:6px 12px; margin-right:-6px; }"
            "QTabBar::tab:selected { background:%4; color:%5; border-radius:0px; }"
            "QTabBar::tab:hover:!selected { background:%6; border-radius:0px; }"
            "QTabBar::close-button { image:url(:/icons/close_tab.png); border-radius:0px; "
            " subcontrol-position:right; subcontrol-origin:padding; width:14px; height:14px; background:transparent; }"
            "QTabBar::close-button:hover { background:%7; border-radius:0px; }")
            .arg(C(m_theme.treeBorder),
                 C(m_theme.panelBackground),
                 C(m_theme.mutedText),
                 C(m_theme.accent),
                 C(m_theme.brightText),
                 C(m_theme.hover),
                 C(m_theme.outputError)));
    }

    updateHomePageTheme();

    // Theme changes must also update an About tab that is already open.
    // The labels carry locally transparent styles, so reapply their new text
    // colour and the matching contrasting outline after the global QSS update.
    if (m_editorTabs) {
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            QWidget *tab = m_editorTabs->widget(i);
            if (!tab || !tab->property("sidboxAboutIde").toBool())
                continue;
            for (QLabel *label : tab->findChildren<QLabel *>()) {
                if (label->property("sidboxAboutOutlined").toBool())
                    outlineAboutText(label, m_theme);
            }
        }
    }

    if (m_quickTipLabel) {
        m_quickTipLabel->setStyleSheet(QStringLiteral(
            "QLabel { background:%1; color:%2; border-top:1px solid %3; "
            " border-bottom:1px solid %3; padding:3px 6px; }")
            .arg(C(m_theme.quickTipBackground),
                 C(m_theme.quickTipText),
                 C(m_theme.quickTipBorder)));
    }

    if (m_outputPane) {
        m_outputPane->setStyleSheet(QStringLiteral(
            "QPlainTextEdit { background:%1; color:%2; "
            " selection-background-color:%3; selection-color:%4; }")
            .arg(C(m_theme.outputBackground),
                 C(m_theme.outputNormal),
                 C(m_theme.selectionBackground),
                 C(m_theme.selectionText)));
    }

    if (m_editorTabs) {
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            const QList<CodeEditor *> editors =
                editorsForTab(m_editorTabs->widget(i));
            for (CodeEditor *editor : editors) {
                editor->setTheme(m_theme);
            }
            if (auto *game = dynamic_cast<SidboxGameDesigner *>(m_editorTabs->widget(i))) {
                game->setTheme(m_theme);
            }
        }
    }
}

void MainWindow::clearCompilerDiagnostics()
{
    m_compilerStderrBuffer.clear();
    m_compilerDiagnostics.clear();

    updateProjectDiagnosticMarkers();

    if (!m_editorTabs) {
        return;
    }

    for (int i = 0; i < m_editorTabs->count(); ++i) {
        const QList<CodeEditor *> editors =
            editorsForTab(m_editorTabs->widget(i));

        for (CodeEditor *editor : editors) {
            editor->clearDiagnostics();
        }
    }
}


QString MainWindow::normalizedDiagnosticPath(const QString &compilerPath) const
{
    QString path = compilerPath.trimmed();
    if (path.isEmpty()) {
        return {};
    }

    QFileInfo info(path);
    if (info.isAbsolute()) {
        return info.absoluteFilePath();
    }

    if (m_compilerProcess && !m_compilerProcess->workingDirectory().isEmpty()) {
        const QString fromWorkingDirectory =
            QFileInfo(QDir(m_compilerProcess->workingDirectory()).filePath(path))
                .absoluteFilePath();

        if (QFileInfo::exists(fromWorkingDirectory)) {
            return fromWorkingDirectory;
        }
    }

    if (!m_projectPath.isEmpty()) {
        const QString fromProject =
            QFileInfo(QDir(m_projectPath).filePath(path)).absoluteFilePath();

        if (QFileInfo::exists(fromProject)) {
            return fromProject;
        }
    }

    return QFileInfo(path).absoluteFilePath();
}

MainWindow::OutputKind MainWindow::compilerOutputKindForLine(
    const QString &line) const
{
    const QString lower = line.toLower();

    if (lower.contains(QStringLiteral("warning:"))) {
        return OutputKind::Warning;
    }

    if (lower.contains(QStringLiteral("fatal error:"))
        || lower.contains(QStringLiteral("error:"))
        || lower.contains(QStringLiteral("undefined reference"))
        || lower.contains(QStringLiteral("ld returned"))) {
        return OutputKind::Error;
    }

    return OutputKind::Normal;
}

void MainWindow::processCompilerStderrChunk(const QString &text)
{
    if (text.isEmpty()) {
        return;
    }

    m_compilerStderrBuffer += text;

    int newlineIndex = -1;
    while ((newlineIndex = m_compilerStderrBuffer.indexOf(QLatin1Char('\n'))) >= 0) {
        QString line = m_compilerStderrBuffer.left(newlineIndex);
        m_compilerStderrBuffer.remove(0, newlineIndex + 1);

        if (line.endsWith(QLatin1Char('\r'))) {
            line.chop(1);
        }

        const QString lowerLine = line.toLower();
        if (m_buildStep == BuildStep::V2CliBuilding &&
            m_v2Linker == QStringLiteral("cgarm")) {
            const qint64 excess = cgarmRamOverflowBytes(line);
            if (excess > 0) {
                m_v2CgarmRamExcessBytes = excess;
                m_buildLinkSizeOverflow = true;
            }
        }
        if ((m_buildStep == BuildStep::Linking || m_buildStep == BuildStep::V2CliBuilding)
            && (lowerLine.contains(QStringLiteral("v2 code + bss + reserved stack + heap exceed applet allowance"))
                || lowerLine.contains(QStringLiteral("applet image exceeds selected app size"))
                || ((lowerLine.contains(QStringLiteral("region"))
                     && lowerLine.contains(QStringLiteral("applet")))
                    && (lowerLine.contains(QStringLiteral("overflowed"))
                        || lowerLine.contains(QStringLiteral("will not fit")))))) {
            m_buildLinkSizeOverflow = true;
        }
        appendOutputLine(line, compilerOutputKindForLine(line));
        processCompilerDiagnosticLine(line);
    }
}

void MainWindow::processCompilerDiagnosticLine(const QString &line)
{
    // cgarm-ld can identify the object and missing symbol, but not a source
    // line. Resolve the object via its GCC .d file and scan only that source.
    // The resulting normal GCC-style diagnostic drives existing red markers,
    // tab/project badges and double-click navigation without new UI machinery.
    if (m_v2Linker == QStringLiteral("cgarm")
        && (m_buildStep == BuildStep::V2CliBuilding
            || m_buildStep == BuildStep::V2CliProbe
            || m_buildStep == BuildStep::V2CliRelink)) {
        static const QRegularExpression undefinedSymbolExpression(
            QStringLiteral(R"(^\s*cgarm-ld:\s*ERROR:\s*(.+?v2_unit_\d+\.o):\s*undefined symbol\s+['"]([^'"]+)['"]\s*$)"),
            QRegularExpression::CaseInsensitiveOption);
        const QRegularExpressionMatch linkerMatch = undefinedSymbolExpression.match(line);
        if (linkerMatch.hasMatch()) {
            const QString objectFile = normalizedDiagnosticPath(linkerMatch.captured(1));
            const QString symbol = linkerMatch.captured(2);
            const QString sourcePath = cgarmSourceFromDependencyFile(objectFile);
            if (!sourcePath.isEmpty()) {
                QFile sourceFile(sourcePath);
                if (sourceFile.open(QIODevice::ReadOnly)
                    && sourceFile.size() <= 16 * 1024 * 1024) {
                    const QString source = QString::fromUtf8(sourceFile.readAll());
                    const QList<int> positions = cgarmSymbolOccurrences(source, symbol);
                    for (int offset : positions) {
                        const QString preceding = source.left(offset);
                        const int lineNumber = preceding.count(QLatin1Char('\n')) + 1;
                        const int lastNewline = preceding.lastIndexOf(QLatin1Char('\n'));
                        const int columnNumber = offset - lastNewline;
                        const QString localized = QStringLiteral("%1:%2:%3: error: undefined symbol '%4' (CGARM link)")
                                                      .arg(sourcePath)
                                                      .arg(lineNumber)
                                                      .arg(columnNumber)
                                                      .arg(symbol);
                        appendOutputLine(localized, OutputKind::Error);
                        processCompilerDiagnosticLine(localized);
                    }
                    if (positions.isEmpty()) {
                        appendOutputLine(
                            tr("CGARM: missing symbol '%1' originates from %2, but its source location could not be established.")
                                .arg(symbol, QDir::toNativeSeparators(sourcePath)),
                            OutputKind::Warning);
                    }
                }
            }
            return;
        }
    }

    static const QRegularExpression diagnosticExpression(
        QStringLiteral(R"(^(.+?):(\d+)(?::(\d+))?:\s*(fatal error|error|warning):\s*(.*)$)"),
        QRegularExpression::CaseInsensitiveOption);

    const QRegularExpressionMatch match = diagnosticExpression.match(line);
    if (!match.hasMatch()) {
        return;
    }

    QString filePath = normalizedDiagnosticPath(match.captured(1));

    bool lineOk = false;
    const int oneBasedLine = match.captured(2).toInt(&lineOk);
    if (!lineOk || oneBasedLine <= 0 || filePath.isEmpty()) {
        return;
    }

    bool columnOk = false;
    const int oneBasedColumn = match.captured(3).toInt(&columnOk);

    const QString severityText = match.captured(4).toLower();
    const EditorDiagnostic::Severity severity =
        severityText == QStringLiteral("warning")
            ? EditorDiagnostic::Severity::Warning
            : EditorDiagnostic::Severity::Error;

    EditorDiagnostic diagnostic;
    diagnostic.line = oneBasedLine - 1;
    diagnostic.column = columnOk && oneBasedColumn > 0 ? oneBasedColumn - 1 : -1;
    diagnostic.severity = severity;
    diagnostic.message = match.captured(5).trimmed();

    CodeEditor *matchedEditor = nullptr;

    if (m_editorTabs) {
        // Prefer an exact absolute-path match.
        for (int i = 0; i < m_editorTabs->count(); ++i) {
            auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
            if (!editor || editor->filePath().isEmpty()) {
                continue;
            }

            const QString editorPath =
                QFileInfo(editor->filePath()).absoluteFilePath();

            if (editorPath == filePath) {
                matchedEditor = editor;
                filePath = editorPath;
                break;
            }
        }

        // Some toolchains print only a bare file name. Fall back only when
        // that name uniquely identifies one open editor.
        if (!matchedEditor) {
            const QString diagnosticName = QFileInfo(filePath).fileName();
            CodeEditor *nameMatch = nullptr;

            for (int i = 0; i < m_editorTabs->count(); ++i) {
                auto *editor = primaryEditorForTab(m_editorTabs->widget(i));
                if (!editor || editor->filePath().isEmpty()) {
                    continue;
                }

                if (QFileInfo(editor->filePath()).fileName() == diagnosticName) {
                    if (nameMatch) {
                        nameMatch = nullptr; // ambiguous
                        break;
                    }
                    nameMatch = editor;
                }
            }

            if (nameMatch) {
                matchedEditor = nameMatch;
                filePath = QFileInfo(nameMatch->filePath()).absoluteFilePath();
            }
        }
    }

    QList<EditorDiagnostic> &diagnostics = m_compilerDiagnostics[filePath];

    const bool duplicate = std::any_of(
        diagnostics.cbegin(),
        diagnostics.cend(),
        [&](const EditorDiagnostic &existing) {
            return existing.line == diagnostic.line
                && existing.column == diagnostic.column
                && existing.severity == diagnostic.severity
                && existing.message == diagnostic.message;
        });

    if (!duplicate) {
        diagnostics.append(diagnostic);
    }

    if (severity
        == EditorDiagnostic::Severity::Error) {
        updateProjectDiagnosticMarkers();
    }

    if (matchedEditor) {
        applyCompilerDiagnostics(matchedEditor);
    }
}

void MainWindow::applyCompilerDiagnostics(CodeEditor *editor)
{
    if (!editor || editor->filePath().isEmpty()) {
        return;
    }

    const QString path =
        QFileInfo(editor->filePath()).absoluteFilePath();
    const QList<EditorDiagnostic> diagnostics =
        m_compilerDiagnostics.value(path);

    const int tabIndex = tabIndexForEditor(editor);
    if (tabIndex >= 0) {
        const QList<CodeEditor *> editors =
            editorsForTab(m_editorTabs->widget(tabIndex));
        for (CodeEditor *view : editors) {
            view->setDiagnostics(diagnostics);
        }
        return;
    }

    editor->setDiagnostics(diagnostics);
}


void MainWindow::appendOutputText(const QString &text, OutputKind kind)
{
    if (!m_outputPane || text.isEmpty()) {
        return;
    }

    QColor color;
    switch (kind) {
    case OutputKind::Header:
        color = m_theme.outputHeader;
        break;
    case OutputKind::Path:
        color = m_theme.outputPath;
        break;
    case OutputKind::Success:
        color = m_theme.outputSuccess;
        break;
    case OutputKind::Error:
        color = m_theme.outputError;
        break;
    case OutputKind::Warning:
        color = m_theme.outputWarning;
        break;
    case OutputKind::Muted:
        color = m_theme.outputMuted;
        break;
    case OutputKind::Normal:
        color = m_theme.outputNormal;
        break;
    }

    QTextCharFormat format;
    format.setForeground(color);

    QTextCursor cursor = m_outputPane->textCursor();
    cursor.movePosition(QTextCursor::End);
    cursor.insertText(text, format);
    m_outputPane->setTextCursor(cursor);
    m_outputPane->ensureCursorVisible();
}

void MainWindow::appendOutputLine(const QString &text, OutputKind kind)
{
    appendOutputText(text + QLatin1Char('\n'), kind);
}

void MainWindow::loadOptions()
{
    QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));

    m_editorFontPointSize =
        qBound(6,
               settings.value(QStringLiteral("editor/fontPointSize"), 10).toInt(),
               36);

    m_theme = defaultIDETheme();

    for (const IDEThemeColorField &field : ideThemeColorFields()) {
        const QString key =
            QStringLiteral("theme/") + QLatin1String(field.key);

        if (!settings.contains(key)) {
            continue;
        }

        const QColor colour(settings.value(key).toString());
        if (colour.isValid()) {
            m_theme.*(field.member) = colour;
        }
    }
}

void MainWindow::saveOptions() const
{
    QSettings settings(QStringLiteral("Sidbox"), QStringLiteral("SidboxIDE"));
    settings.setValue(
        QStringLiteral("editor/fontPointSize"),
        m_editorFontPointSize);

    for (const IDEThemeColorField &field : ideThemeColorFields()) {
        settings.setValue(
            QStringLiteral("theme/") + QLatin1String(field.key),
            ideThemeColorName(m_theme.*(field.member)));
    }
}
