#ifndef CODEEDITOR_H
#define CODEEDITOR_H

#include <QPlainTextEdit>
#include <QList>
#include <QMetaObject>
#include <QPair>
#include <QRegularExpression>
#include <QTextCursor>
#include <QString>
#include <QStringList>
#include <QTextBlock>
#include "idetheme.h"

class CSyntaxHighlighter;
class QCompleter;
class QFont;
class QContextMenuEvent;
class QPaintEvent;
class QResizeEvent;
class QStringListModel;
class QTimer;
class QWidget;

struct EditorDiagnostic
{
    enum class Severity {
        Error,
        Warning
    };

    int line = -1;        // zero-based source line
    int column = -1;      // zero-based column, or -1 when the compiler omitted it
    Severity severity = Severity::Error;
    QString message;
};

class CodeEditor : public QPlainTextEdit
{
    Q_OBJECT

public:
    explicit CodeEditor(QWidget *parent = nullptr);
    ~CodeEditor() override;

    QString filePath() const;
    void setFilePath(const QString &path);
    void setFunctionCompletions(const QStringList &signatures);
    void setIncludeSearchPaths(const QStringList &searchPaths);
    void setProjectTypeNames(const QStringList &typeNames);
    void setApiSyntaxNames(const QStringList &apiNames);
    void setResourceMode(bool enabled);
    void setNavigationBar(QWidget *bar, int height = 30);
    bool isResourceMode() const;
    void showMemberCompletions(const QStringList &members, const QString &prefix);
    void refreshMemberCompletion();
    void setCompletionFont(const QFont &font);
    void setTheme(const IDETheme &theme);
    const IDETheme &theme() const;

    // Existing case-sensitive whole-word selections, reused by the minimap
    // without an additional scan over the document.
    const QList<QTextCursor> &selectedWordOccurrences() const;
    const QList<EditorDiagnostic> &diagnostics() const;
    void setDiagnostics(const QList<EditorDiagnostic> &diagnostics);
    void clearDiagnostics();
    QString diagnosticToolTipAtY(int y) const;

    bool loadFromFile(const QString &path, bool deferSyntaxHighlighting = false);
    void enableSyntaxHighlighting();
    bool save();
    bool saveAs(const QString &path);
    void shareDocumentFrom(CodeEditor *sourceEditor);

    int lineNumberAreaWidth() const;
    void refreshLineNumberAreaWidth();
    void lineNumberAreaPaintEvent(QPaintEvent *event);
    bool foldMarkerAtY(int y) const;
    void toggleFoldAtY(int y, bool recursiveChildren = false);
    void collapseAllFolds();
    void expandAllFolds();
    int firstVisibleSourceBlockNumber() const;
    void recalculateFoldScrollBarRange();
    void syncDeferredEditorStateNow();
    void formatSourcecode();
    void formatSourcecodeLineBy();

signals:
    void deferredAnalysisSyncRequested();
    void structureNavigationRequested(int direction);
    void nextEditorTabRequested();
    void quickTipRequested(const QString &symbol);
    void quickTipCandidateChanged(const QString &symbol);
    void definitionRequested(const QString &symbol, int sourceLine);
    void includeFileRequested(const QString &includeName);
    void memberCompletionRequested(const QString &objectName,
                                   int sourceLine,
                                   const QString &prefix);

protected:
    void focusInEvent(QFocusEvent *event) override;
    void changeEvent(QEvent *event) override;
    void contextMenuEvent(QContextMenuEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    bool eventFilter(QObject *watched, QEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    /*
     * Keep the theme before the child widgets in declaration order.
     * LineNumberArea asks CodeEditor for its theme from inside its constructor,
     * so m_theme must already be fully constructed at that point.
     */
    IDETheme m_theme;

    void updateLineNumberAreaWidth(int newBlockCount);
    void updateLineNumberArea(const QRect &rect, int dy);
    void highlightCurrentLine();
    void updateOccurrenceSelection(bool documentChanged = false);
    void showCompletionPopup(const QRect &caretRect);
    void showDelayedCompletion();
    void dismissCompletionForNavigation();
    void navigateCompletion(int direction);
    void acceptCurrentCompletion();
    void beginOccurrenceScan();
    void continueOccurrenceScan();
    QString textUnderCursor() const;
    void insertFunctionCompletion(const QString &signature);
    void insertIncludeCompletion(const QString &path);
    bool showIncludeCompletionAtCursor();
    void refreshIncludeCandidates();
    void restoreIncludeCompletionModel();
    void insertMemberCompletion(const QString &member);
    bool requestMemberCompletionAtCursor();
    void restoreFunctionCompletionModel();
    void selectArgument(int index);
    int indentWidthColumns() const;
    QString leadingWhitespace(const QString &text) const;
    void insertAutoIndent();
    bool handleAutoPairKey(QKeyEvent *event);
    bool handlePairedBackspace(QKeyEvent *event);
    void indentSelection();
    void unindentSelection();
    void drawIndentGuides(QPaintEvent *event);
    void attachFoldTracking();
    void rebuildFoldRegions();
    void startQueuedFoldRegionScan();
    void continueQueuedFoldRegionScan();
    void finishQueuedFoldRegionScan();
    void requestDeferredAnalysisSync();
    void applyFoldVisibility(int preferredScrollValue = -1);
    int visibleBlockNumberAtY(int y) const;
    int foldEndForStart(int startBlock) const;
    bool isFolded(int startBlock) const;
    QTextBlock nextVisibleBlockFast(const QTextBlock &block) const;

    QWidget *m_lineNumberArea;
    QWidget *m_minimap;
    QWidget *m_navigationBar = nullptr;
    int m_navigationHeight = 0;
    QString m_filePath;
    CSyntaxHighlighter *m_highlighter;
    QCompleter *m_completer;
    QStringListModel *m_completionModel;
    QList<QPair<int, int>> m_foldRegions;
    QTimer *m_foldScanTimer = nullptr;
    // Selection-based whole-identifier occurrence highlights. Scans are
    // deferred and batched so huge source files stay responsive.
    QTimer *m_occurrenceDelayTimer = nullptr;
    QTimer *m_occurrenceScanTimer = nullptr;
    QTimer *m_completionDelayTimer = nullptr;
    // Only genuine typing, not navigation or programmatic edits, may arm IntelliSense.
    bool m_completionTypingEdit = false;
    QString m_occurrenceWord;
    QRegularExpression m_occurrenceExpression;
    QTextBlock m_occurrenceScanBlock;
    QList<QTextCursor> m_occurrences;
    QList<QTextCursor> m_pendingOccurrences;
    QTextBlock m_foldScanBlock;
    QList<QPair<int, int>> m_pendingFoldRegions;
    QList<QPair<int, int>> m_pendingFoldStack;
    bool m_foldScanInBlockComment = false;
    int m_foldScanPreviousCodeBlock = -1;
    int m_deferredScanGeneration = 0;
    int m_foldScanRunningGeneration = 0;
    bool m_deferredEditorStateDirty = true;
    QMetaObject::Connection m_foldDocumentChangedConnection;
    QStringList m_functionCompletions;
    QStringList m_includeSearchPaths;
    QStringList m_includeCandidates;
    QString m_includePrefix;
    qint64 m_includeScanMs = 0;
    bool m_includeCompletionActive = false;
    QStringList m_projectTypeNames;
    QStringList m_apiSyntaxNames;
    QString m_memberCompletionPrefix;
    bool m_memberCompletionActive = false;
    bool m_resourceMode = false;
    QList<QPair<int, int>> m_argumentRanges;
    QList<EditorDiagnostic> m_diagnostics;
    int m_selectedArgument;
};

#endif // CODEEDITOR_H
