#ifndef SIDBOX_GAME_VISUAL_GRAPH_LOGIC_H
#define SIDBOX_GAME_VISUAL_GRAPH_LOGIC_H

// Stage 5.166.60: real, independent, typed Boolean logic nodes.
// This data belongs to .sbgm object logic, never to the .vsgm layout.
// A node is evaluated once per activation, after the owner's ordinary actions.
// Node-to-node edges form a DAG; cycles and dangling inputs are rejected.
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QHash>
#include <QSet>
#include <QString>
#include <QStringList>
#include <QVector>
#include <functional>

namespace SidboxVisualLogic {

struct Input {
    QString kind;            // "object", "node", or one-frame "event"
    QString id;              // stable resource ID or logic node ID
    bool invert = false;     // a FALSE output means NOT the upstream result
    QString command;         // TIMER: start, stop, continue, reset (gold event only)
};
struct Node {
    QString id;
    QString op;              // boolean/not/and/or, stat_compare, quest_done
    QString statName, compareOp, questId;
int targetCount = 3;
    int runtimeCounterSlot = -1; // Generated world-local index, never written to .sbgm.
    int durationFrames = 250;   // TIMER, 5 seconds at the default 50Hz game clock.
    int runtimeTimerSlot = -1;   // Generated world-local index, never saved in .sbgm.
    int threshold = 0;
    QVector<Input> inputs;
    QJsonArray trueActions, falseActions;
    QStringList resultTargets; // RESULT directly drives each Game Object active state.
    int trueDialogue = -1, falseDialogue = -1;
};

inline bool read(const QJsonArray &raw, QVector<Node> *nodes, QString *error) {
    if (raw.size()>64) { if(error)*error=QStringLiteral("Maximum 64 logic nodes per Game Object.");return false; }
    QSet<QString> ids;
    QVector<Node> parsed;
    for (const QJsonValue &item:raw) {
        if (!item.isObject()) {if(error)*error=QStringLiteral("Logic node must be an object.");return false;}
        const QJsonObject o=item.toObject();
        Node n;
        n.id=o.value(QStringLiteral("id")).toString();
        n.op=o.value(QStringLiteral("op")).toString();
        if(n.id.isEmpty() || n.id.size()>64 || ids.contains(n.id)) {
            if(error)*error=QStringLiteral("Duplicate, missing or overly long logic node ID: %1").arg(n.id);
            return false;
        }
        for (const QChar c:n.id) if(!c.isLetterOrNumber() && c!=QLatin1Char('_') && c!=QLatin1Char('-')) {
            if(error)*error=QStringLiteral("Invalid logic node ID: %1").arg(n.id);return false;
        }
        ids.insert(n.id);
        if(n.op!=QStringLiteral("boolean") && n.op!=QStringLiteral("not") &&
           n.op!=QStringLiteral("and") && n.op!=QStringLiteral("or") &&
           n.op!=QStringLiteral("stat_compare") && n.op!=QStringLiteral("quest_done") &&
           n.op!=QStringLiteral("counter") && n.op!=QStringLiteral("timer")) {
            if(error)*error=QStringLiteral("Unknown operator on logic node %1.").arg(n.id);
            return false;
        }
        const QJsonArray rawInputs=o.value(QStringLiteral("inputs")).toArray();
        const bool sourceCondition=n.op==QStringLiteral("stat_compare") || n.op==QStringLiteral("quest_done");
        const bool counter=n.op==QStringLiteral("counter");
        const bool timer=n.op==QStringLiteral("timer");
        if(rawInputs.size()>(counter?17:16) || (counter ? (rawInputs.size()<1 || rawInputs.size()>17) : timer ? rawInputs.size()>4 : sourceCondition ? rawInputs.size()>1 :
            (n.op==QStringLiteral("boolean") || n.op==QStringLiteral("not")
              ? rawInputs.size()!=1 : n.op==QStringLiteral("or") ? (rawInputs.size()<2 || rawInputs.size()>8) : rawInputs.size()<2))) {
            if(error)*error=QStringLiteral("Logic node %1 has an invalid number of inputs.").arg(n.id);
            return false;
        }
        if(counter) {
            n.targetCount=o.value(QStringLiteral("targetCount")).toInt(3);
            if(n.targetCount<1 || n.targetCount>65535) {
                if(error)*error=QStringLiteral("Counter %1 requires a target between 1 and 65535.").arg(n.id);
                return false;
            }
        }
        if(timer) {
            n.durationFrames=o.value(QStringLiteral("durationFrames")).toInt(250);
            if(n.durationFrames<1 || n.durationFrames>30000) {
                if(error)*error=QStringLiteral("Timer %1 must have 1 to 30000 game frames.").arg(n.id);
                return false;
            }
        }
        if(n.op==QStringLiteral("stat_compare")) {
            n.statName=o.value(QStringLiteral("statName")).toString().trimmed();
            n.compareOp=o.value(QStringLiteral("compareOp")).toString();
            n.threshold=o.value(QStringLiteral("threshold")).toInt();
            if(n.statName.isEmpty() || n.statName.size()>64 ||
               !QStringList{QStringLiteral("<"),QStringLiteral("<="),QStringLiteral("=="),
                   QStringLiteral("!="),QStringLiteral(">="),QStringLiteral(">")} .contains(n.compareOp)) {
                if(error)*error=QStringLiteral("Logic node %1 has an invalid statistic/comparison.").arg(n.id);
                return false;
            }
            for(const QChar ch:n.statName)
                if(n.statName!=QStringLiteral("@health") && !ch.isLetterOrNumber() && ch!=QLatin1Char(' ') && ch!=QLatin1Char('_') && ch!=QLatin1Char('-')) {
                    if(error)*error=QStringLiteral("Logic node %1 has an invalid statistic name.").arg(n.id);
                    return false;
                }
        }
        if(n.op==QStringLiteral("quest_done")) {
            n.questId=o.value(QStringLiteral("questId")).toString().trimmed();
            if(n.questId.isEmpty() || n.questId.size()>128) {
                if(error)*error=QStringLiteral("Logic node %1 has no quest ID.").arg(n.id);
                return false;
            }
            for(const QChar ch:n.questId)
                if(!ch.isLetterOrNumber() && ch!=QLatin1Char('_') && ch!=QLatin1Char('-')) {
                    if(error)*error=QStringLiteral("Logic node %1 has an invalid quest ID.").arg(n.id);
                    return false;
                }
        }
        QSet<QString> unique;
        QSet<QString> timerCommands;
        bool counterResetSeen=false;
        for(int inputIndex=0;inputIndex<rawInputs.size();++inputIndex) {
            const QJsonObject input=rawInputs.at(inputIndex).toObject();
            Input in{input.value(QStringLiteral("kind")).toString(),
                     input.value(QStringLiteral("id")).toString(),
                     input.value(QStringLiteral("invert")).toBool(false)};
            const QString eventKind=in.id.section(QLatin1Char(':'),1,1);
            const bool eventIdValid=in.id.startsWith(QStringLiteral("@event:")) &&
                (eventKind==QStringLiteral("arrival") || eventKind==QStringLiteral("hit") ||
                 eventKind==QStringLiteral("destroy") || eventKind==QStringLiteral("pickup") ||
                 eventKind==QStringLiteral("player_hit") || eventKind==QStringLiteral("enter") ||
                 eventKind==QStringLiteral("save") || eventKind==QStringLiteral("defeat") ||
                 eventKind==QStringLiteral("trigger"));
            if ((in.kind!=QStringLiteral("object") && in.kind!=QStringLiteral("node") &&
                 in.kind!=QStringLiteral("event")) || in.id.isEmpty() ||
                (in.kind==QStringLiteral("event") &&
                 (!eventIdValid || in.id.section(QLatin1Char(':'),2).isEmpty()))) {
                // State exactly which saved input is wrong. Older, mixed-version
                // installations accepted arrival events but not breakable events.
                if(error)*error=QStringLiteral("Logic node %1 INPUT %2 is invalid: kind='%3', id='%4'.")
                    .arg(n.id).arg(inputIndex+1).arg(in.kind).arg(in.id);
                return false;
            }
            const QString identity=in.kind+QLatin1Char(':')+in.id+(in.invert?QStringLiteral(":not"):QString());
            if(unique.contains(identity)) {
                if(error)*error=QStringLiteral("Logic node %1 contains a duplicate input.").arg(n.id);
                return false;
            }
            if(timer) {
                const QString command=input.value(QStringLiteral("command")).toString();
                if(in.kind!=QStringLiteral("event") ||
                   !QStringList{QStringLiteral("start"),QStringLiteral("stop"),
                                QStringLiteral("continue"),QStringLiteral("reset")}.contains(command) ||
                   timerCommands.contains(command)) {
                    if(error)*error=QStringLiteral("Timer %1 requires unique EVENT controls: START/STOP/CONTINUE/RESET.").arg(n.id);
                    return false;
                }
                timerCommands.insert(command);
                in.command=command;
            }
            if(counter && input.value(QStringLiteral("command")).toString()==QStringLiteral("reset")) {
                if(in.kind!=QStringLiteral("event") || counterResetSeen) {
                    if(error)*error=QStringLiteral("Counter %1 requires one unique gold RESET event.").arg(n.id);
                    return false;
                }
                counterResetSeen=true;
                in.command=QStringLiteral("reset");
            }
            if(counter && in.kind!=QStringLiteral("event")) {
                if(error)*error=QStringLiteral("Counter %1 accepts EVENT pulses only, not held STATE or LOGIC values.").arg(n.id);
                return false;
            }
            unique.insert(identity);
            n.inputs.append(in);
        }
        const QJsonArray rawResultTargets=o.value(QStringLiteral("resultTargets")).toArray();
        if(rawResultTargets.size()>64) {
            if(error)*error=QStringLiteral("Logic node %1 exceeds 64 RESULT targets.").arg(n.id);
            return false;
        }
        QSet<QString> bound;
        for(const QJsonValue &v:rawResultTargets) {
            if(!v.isString() || v.toString().isEmpty() || bound.contains(v.toString())) {
                if(error)*error=QStringLiteral("Logic node %1 has an invalid or duplicate RESULT target.").arg(n.id);
                return false;
            }
            bound.insert(v.toString());n.resultTargets.append(v.toString());
        }
        n.trueActions=o.value(QStringLiteral("trueActions")).toArray();
        n.falseActions=o.value(QStringLiteral("falseActions")).toArray();
        n.trueDialogue=o.value(QStringLiteral("trueDialogueNode")).toInt(-1);
        n.falseDialogue=o.value(QStringLiteral("falseDialogueNode")).toInt(-1);
        if(n.trueActions.size()>64 || n.falseActions.size()>64) {
            if(error)*error=QStringLiteral("Logic node %1 exceeds 64 actions per branch.").arg(n.id);
            return false;
        }
        parsed.append(n);
    }
    if(nodes)*nodes=parsed;
    return true;
}

// Build a topological schedule. Independently validates missing objects,
// dangling logic links and cycles. No graph is partially generated on error.
inline bool order(const QVector<Node> &nodes,const QSet<QString> &objects,
                  QVector<int> *sorted,QString *error) {
    QHash<QString,int> byId;
    for(int i=0;i<nodes.size();++i)byId.insert(nodes[i].id,i);
    QVector<int> states(nodes.size(),0),result;
    std::function<bool(int)> visit=[&](int i) -> bool {
        if(states[i]==2)return true;
        if(states[i]==1) {
            if(error)*error=QStringLiteral("Logic cycle involving node %1.").arg(nodes[i].id);
            return false;
        }
        states[i]=1;
        for(const QString &target:nodes[i].resultTargets)
            if(target.startsWith(QStringLiteral("@event:")) ||
               target.startsWith(QStringLiteral("@triggerstate:")) || !objects.contains(target)) {
                if(error)*error=QStringLiteral("Logic node %1 drives missing Game Object %2.")
                    .arg(nodes[i].id,target);
                return false;
            }
        for(const Input &input:nodes[i].inputs) {
            if(input.kind==QStringLiteral("object") && !objects.contains(input.id)) {
                if(error)*error=QStringLiteral("Logic node %1 reads missing Game Object %2.")
                    .arg(nodes[i].id,input.id);
                return false;
            }
            if(input.kind==QStringLiteral("event")) {
                // Event sockets are pulses belonging to real Game Objects, not
                // separately saved resources. Accept the source object's UUID
                // even when the caller supplies only ordinary object IDs.
                // The exporter additionally checks the event kind and owner.
                const QString sourceId=input.id.section(QLatin1Char(':'),2);
                if(!objects.contains(sourceId) && !objects.contains(input.id)) {
                    if(error)*error=QStringLiteral("Logic node %1 reads a missing event %2 (source Game Object %3 is missing).")
                        .arg(nodes[i].id).arg(input.id).arg(sourceId);
                    return false;
                }
            }
            if(input.kind==QStringLiteral("node")) {
                if(!byId.contains(input.id)) {
                    if(error)*error=QStringLiteral("Logic node %1 references missing node %2.")
                        .arg(nodes[i].id,input.id);
                    return false;
                }
                if(!visit(byId.value(input.id)))return false;
            }
        }
        states[i]=2;result.append(i);return true;
    };
    for(int i=0;i<nodes.size();++i)if(!visit(i))return false;
    if(sorted)*sorted=result;
    return true;
}

inline QString expression(const Node &node,const QHash<QString,QString> &objects,
                          const QHash<QString,QString> &values) {
    // Only safe alphanumeric/spaces IDs can reach these C string literals;
    // read() rejects malformed IDs before the exporter calls expression().
    QStringList parts;
    for(const Input &input:node.inputs) {
        // Trigger virtual latch resolves to cg_trigger_state[index].active
        // (a scalar field of cg_trigger_virtual_t); ordinary placed Game
        // Objects also have .active, but require the suffix here.
        QString x=input.kind==QStringLiteral("object")
            ? (input.id.startsWith(QStringLiteral("@triggerstate:"))
                ? objects.value(input.id)
                : objects.value(input.id)+QStringLiteral(".active"))
            : input.kind==QStringLiteral("event") ? objects.value(input.id) : values.value(input.id);
        if(input.invert)x=QStringLiteral("!(%1)").arg(x);
        parts.append(QStringLiteral("(%1)").arg(x));
    }
    if(node.op==QStringLiteral("timer"))
        return QStringLiteral("(cg_logic_timer_mode[%1u] == 3u)").arg(node.runtimeTimerSlot);
    if(node.op==QStringLiteral("counter"))
        return QStringLiteral("(cg_logic_counter_value[%1u] >= %2u)")
            .arg(node.runtimeCounterSlot).arg(node.targetCount);
    // COMPARE and QUEST STATE are live condition sources, optionally guarded
    // by a single WHEN input. With no input they preserve their original
    // independent, revision-driven behaviour. A gold event WHEN gates the
    // condition to that one pulse; a teal state WHEN is held.
    if(node.op==QStringLiteral("stat_compare") || node.op==QStringLiteral("quest_done")) {
        const QString condition=node.op==QStringLiteral("stat_compare")
            ?QStringLiteral("cg_logic_stat_compare(\"%1\", \"%2\", %3)")
                .arg(node.statName,node.compareOp).arg(node.threshold)
            :QStringLiteral("cg_logic_quest_done(\"%1\")").arg(node.questId);
        return parts.isEmpty()?condition:
            QStringLiteral("((%1) && (%2))").arg(parts.first(),condition);
    }
    QString joined=parts.join(node.op==QStringLiteral("or")?QStringLiteral(" || "):
                              QStringLiteral(" && "));
    if(node.op==QStringLiteral("not"))joined=QStringLiteral("!(%1)").arg(joined);
    return joined;
}
}
#endif
