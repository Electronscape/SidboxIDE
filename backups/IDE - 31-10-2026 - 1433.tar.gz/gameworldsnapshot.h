#ifndef CODERGIRL_GAME_WORLD_SNAPSHOT_H
#define CODERGIRL_GAME_WORLD_SNAPSHOT_H

// Stage 5.1: each .sbgm has BOTH a private .codergirl snapshot and a visible
// worlds/<name>/ build tree. The tree compiles simultaneously with other
// worlds; public per-world C identifiers are renamed by a generated header.
// Map output is staged privately in .codergirl/tilemap-staging/<world>/.
// Project-root gamelevels/ is obsolete and is never compiled.
#include <cstdint>
#include <QDateTime>
#include <QColor>
#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QRegularExpression>
#include <QSet>
#include <QStringList>
#include <QUuid>
#include "gametilemap.h"
#include "ppbcodec.h"
#include "gamehelpertemplates.h"
#include "gametitleruntime.h"
#include "gameplayerprofile.h"
#include "gamequestgen.h"

namespace GameWorldSnapshot {

inline QString activeFile(const QString &designPath)
{
    return QFileInfo(designPath).absoluteDir().filePath(
        QStringLiteral(".codergirl/active-world.json"));
}

inline bool isActive(const QString &designPath)
{
    QFile file(activeFile(designPath));
    if (!file.open(QIODevice::ReadOnly)) return false;
    const auto doc = QJsonDocument::fromJson(file.readAll());
    if (!doc.isObject()) return false;
    return QFileInfo(doc.object().value(QStringLiteral("designFile")).toString()).absoluteFilePath()
        == QFileInfo(designPath).absoluteFilePath();
}

inline bool hasActiveSelection(const QString &designPath)
{
    return QFileInfo::exists(activeFile(designPath));
}

// Two different filenames can sanitise to the same C symbol (e.g.
// "Cave 2.sbgm" and "Cave-2.sbgm"). Never let them share a world bundle.
inline bool validateUniqueName(const QString &designPath, QString *error)
{
    const QFileInfo design(designPath);
    const QDir folder(design.absolutePath());
    const QString worldName = sidboxTilemapWorldBaseName(designPath);
    for (const QFileInfo &candidate : folder.entryInfoList(QDir::Files | QDir::NoDotAndDotDot)) {
        if (candidate.suffix().compare(QStringLiteral("sbgm"), Qt::CaseInsensitive) != 0
            || candidate.absoluteFilePath() == design.absoluteFilePath()) continue;
        if (sidboxTilemapWorldBaseName(candidate.absoluteFilePath())
                .compare(worldName, Qt::CaseInsensitive) == 0) {
            if (error) *error = QStringLiteral(
                "Two .sbgm worlds would export the same C/file name '%1': %2 and %3. "
                "Rename one design before generating either world.")
                    .arg(worldName, design.fileName(), candidate.fileName());
            return false;
        }
    }
    return true;
}

// Build the C namespace from the *actual rendered public declarations*, not
// resource-name guesses. This includes each world's named sprites, draw calls,
// PPB atlas lookup, sounds, music, NPC callbacks and exported spline arrays.
// The macro header is included BEFORE every generated world translation unit;
// the C compiler therefore emits genuinely distinct linker symbols.
inline QSet<QString> exportedIdentifiers(const QString &bundleDirectory)
{
    QSet<QString> names;
    const QStringList headers = {
        QStringLiteral("gameassets/gameassets.h"),
        QStringLiteral("gamehelpers/gameworlditems.h"),
        QStringLiteral("gamehelpers/gameadventure.h"),
        QStringLiteral("gamehelpers/splinepaths.h")
    };
    const QRegularExpression functionRe(QStringLiteral(
        R"((?m)^\s*(?:extern\s+)?[A-Za-z_][A-Za-z_0-9 \t\*]*?\s*\*?\s*([A-Za-z_][A-Za-z_0-9]*)\s*\()"));
    const QRegularExpression externRe(QStringLiteral(
        R"((?m)^\s*extern\s+[^;\n]*?\b([A-Za-z_][A-Za-z_0-9]*)\s*(?:\[[^;\n]*\])?\s*;)"));
    for (const QString &relative : headers) {
        QFile input(QDir(bundleDirectory).filePath(relative));
        if (!input.open(QIODevice::ReadOnly)) continue;
        const QString content = QString::fromUtf8(input.readAll());
        auto functions = functionRe.globalMatch(content);
        while (functions.hasNext()) {
            const QString name = functions.next().captured(1);
            if (!name.isEmpty()) names.insert(name);
        }
        auto externs = externRe.globalMatch(content);
        while (externs.hasNext()) {
            const QString name = externs.next().captured(1);
            if (!name.isEmpty()) names.insert(name);
        }
    }
    // Mandatory public functions also cover pointer-return types without
    // whitespace before the asterisk, and empty-world rule stubs.
    for (const char *name : {"gameassets_init", "gameassets_shutdown",
            "gameassets_front_palette", "gameassets_back_palette",
            "gameassets_find_ppb", "gameassets_draw_foreground",
            "gameassets_draw_background", "gameassets_draw_layers",
            "gameassets_show_background", "drawworld",
            "gameworlditems_init", "gameworlditems_update",
            "gameworlditems_update_gameplay", "gameworlditems_update_particles", "gameworlditems_draw",
            "gameworlditems_draw_behind", "gameworlditems_draw_overlay", "gameworlditems_check",
            "gameworlditems_before", "gameworlditems_after", "gameworlditems_player_attack",
            "gameworlditems_set_active", "gameworlditems_trigger",
            "gameadventure_setup", "gameadventure_on_event",
            "gameworlditems_save_state", "gameworlditems_restore_state", "gameworlditems_sync_logic",
            "gameworlditems_checkpoint_saved", "gameworlditems_quest_completed",
            "gameworlditems_event_overflow_count", "gameworlditems_action_overflow_count",
            "game_adventure_dialogue_overflow_count",
            "gameworlditems_disk_export", "gameworlditems_disk_import",
            "gameadventure_disk_export", "gameadventure_disk_import",
            "gameworlditems_remote_action", "gameworlditems_remote_reset",
            "gameworlditems_apply_remote", "gameadventure_save_progress", "gameadventure_restore_progress",
            "gameadventure_npc_action", "gameadventure_npc_remote_action", "gameadventure_npc_remote_reset"}) {
        names.insert(QLatin1String(name));
    }
    return names;
}

inline bool publishBuildTree(const QString &bundleDirectory, const QDir &project,
                             const QString &worldName, const QStringList &files,
                             bool hasMap, QString *error)
{
    const QString worlds = project.filePath(QStringLiteral("worlds"));
    if (!QDir().mkpath(worlds)) {
        if (error) *error = QStringLiteral("Cannot create worlds directory: %1").arg(worlds);
        return false;
    }
    const QString uuid = QUuid::createUuid().toString(QUuid::WithoutBraces);
    const QString staging = QDir(worlds).filePath(QStringLiteral(".staging-") + uuid);
    const QString destination = QDir(worlds).filePath(worldName);
    const QString previous = QDir(worlds).filePath(QStringLiteral(".previous-") + uuid);
    if (!QDir().mkpath(staging)) {
        if (error) *error = QStringLiteral("Cannot stage buildable world: %1").arg(worldName);
        return false;
    }
    auto abort = [&](const QString &reason) {
        QDir(staging).removeRecursively();
        if (error) *error = reason;
        return false;
    };
    const QStringList symbols = exportedIdentifiers(bundleDirectory).values();
    QStringList sorted = symbols;
    sorted.sort(Qt::CaseSensitive);
    QByteArray mappings = "/* CoderGirl generated; public C symbols belong to this world. */\n"
                          "/* Included by world C modules before their own headers. */\n";
    for (const QString &name : sorted) {
        static const QRegularExpression valid(QStringLiteral("^[A-Za-z_][A-Za-z_0-9]*$"));
        if (!valid.match(name).hasMatch())
            return abort(QStringLiteral("Invalid world C export: %1").arg(name));
        mappings += "#define " + name.toUtf8() + " " + worldName.toUtf8()
                    + "_" + name.toUtf8() + "\n";
    }
    for (const QString &relative : files) {
        // maingame is documentation/starter code, not an additional entry point.
        if (relative == QStringLiteral("maingame.c.txt")) continue;
        const QString inputPath = QDir(bundleDirectory).filePath(relative);
        QFile source(inputPath);
        if (!source.open(QIODevice::ReadOnly))
            return abort(QStringLiteral("Cannot read world file: %1").arg(inputPath));
        QByteArray bytes = source.readAll();
        if (relative.endsWith(QStringLiteral(".c")))
            bytes.prepend("#include \"../world_symbols.h\"\n");
        // The tilemap header's normal ../gamehelpers include is correct in
        // project/gamelevels/, but this mirror is three directories deeper.
        if (relative.startsWith(QStringLiteral("gamelevels/"))
            && relative.endsWith(QStringLiteral(".h")))
            bytes.replace("\"../gamehelpers/gametilemap.h\"",
                          "\"../../../gamehelpers/gametilemap.h\"");
        const QString output = QDir(staging).filePath(relative);
        if (!QDir().mkpath(QFileInfo(output).absolutePath()))
            return abort(QStringLiteral("Cannot create world output: %1").arg(output));
        QSaveFile target(output);
        if (!target.open(QIODevice::WriteOnly) || target.write(bytes) != bytes.size()
            || !target.commit())
            return abort(QStringLiteral("Cannot write world module: %1").arg(output));
    }
    auto writeFile = [&](const QString &relative, const QByteArray &bytes) {
        QSaveFile out(QDir(staging).filePath(relative));
        return out.open(QIODevice::WriteOnly) && out.write(bytes) == bytes.size() && out.commit();
    };
    if (!writeFile(QStringLiteral("world_symbols.h"), mappings))
        return abort(QStringLiteral("Cannot write world namespace header."));

    // This public header is safe to include alongside other world_api.h files.
    // No preprocessor alias leaks into main.c or other world headers.
    const QByteArray id = worldName.toUtf8();
    QByteArray api = "/* Public Stage 5.2 world-module entry points (used by gameworlds.c). */\n"
                     "#ifndef CODERGIRL_WORLD_API_" + id.toUpper() + "_H\n"
                     "#define CODERGIRL_WORLD_API_" + id.toUpper() + "_H\n"
                     "#include <stdint.h>\n"
                     "#include \"../../gamehelpers/gameworlds.h\"\n"
                     "int " + id + "_gameassets_init(void);\n"
                     "void " + id + "_gameassets_shutdown(void);\n"
                     "const uint32_t *" + id + "_gameassets_front_palette(void);\n"
                     "const uint32_t *" + id + "_gameassets_back_palette(void);\n"
                     "void " + id + "_gameassets_draw_foreground(void);\n"
                     "void " + id + "_gameassets_draw_background(void);\n"
                     "void " + id + "_drawworld(void);\n"
                     "uint8_t " + id + "_gameworlditems_init(void);\n"
                     "void " + id + "_gameworlditems_save_state(void);\n"
                     "void " + id + "_gameworlditems_restore_state(void);\n"
                     "void " + id + "_gameworlditems_sync_logic(void);\n"
                     "void " + id + "_gameworlditems_checkpoint_saved(void);\n"
                     "void " + id + "_gameworlditems_quest_completed(const char *);\n"
                     // Stage 5.164.3: registry save callbacks MUST be declared
                     // in each world's PUBLIC API, not only its private header.
                     "void " + id + "_gameworlditems_disk_export(void (*)(const void *, uint32_t, void *), void *);\n"
                     "uint8_t " + id + "_gameworlditems_disk_import(uint8_t (*)(void *, uint32_t, void *), void *);\n"
                     "void " + id + "_gameworlditems_set_active(uint16_t,uint8_t);\n"
                     "void " + id + "_gameworlditems_remote_action(uint16_t,uint8_t);\n"
                     "void " + id + "_gameworlditems_remote_reset(void);\n"
                     "void " + id + "_gameworlditems_apply_remote(void);\n"
                     "void " + id + "_gameworlditems_update(uint16_t frames);\n"
                     "void " + id + "_gameworlditems_draw(int32_t x, int32_t y);\n"
                     "void " + id + "_gameadventure_setup(void);\n"
                     "void " + id + "_gameadventure_save_progress(void);\n"
                     "void " + id + "_gameadventure_restore_progress(void);\n"
                     "void " + id + "_gameadventure_disk_export(void (*)(const void *, uint32_t, void *), void *);\n"
                     "uint8_t " + id + "_gameadventure_disk_import(uint8_t (*)(void *, uint32_t, void *), void *);\n"
                     "void " + id + "_gameadventure_npc_action(uint16_t,uint8_t);\n"
                     "void " + id + "_gameadventure_npc_remote_action(uint16_t,uint8_t);\n"
                     "void " + id + "_gameadventure_npc_remote_reset(void);\n"
                     "void " + id + "_gameadventure_store_inventory(gameworlds_inventory_put_t,void *);\n"
                     "void " + id + "_gameadventure_load_inventory(gameworlds_inventory_get_t,void *);\n"
                     "void " + id + "_gameassets_show_background(void);\n";
    {
        QFile objectsHeader(QDir(bundleDirectory).filePath(QStringLiteral("gamehelpers/gameworlditems.h")));
        const QByteArray exported = objectsHeader.open(QIODevice::ReadOnly)
            ? objectsHeader.readAll() : QByteArray();
        if (exported.contains("gameworlditems_update_gameplay"))
            api += "void " + id + "_gameworlditems_update_gameplay(uint16_t);\n";
        if (exported.contains("gameworlditems_update_particles"))
            api += "void " + id + "_gameworlditems_update_particles(uint16_t);\n";
        if (exported.contains("gameworlditems_draw_behind"))
            api += "void " + id + "_gameworlditems_draw_behind(int32_t,int32_t);\n";
        if (exported.contains("gameworlditems_draw_overlay"))
            api += "void " + id + "_gameworlditems_draw_overlay(int32_t,int32_t);\n";
        if (exported.contains("gameworlditems_before")) {
            api += "void " + id + "_gameworlditems_before(game_world_player_t*);\n";
            api += "void " + id + "_gameworlditems_after(game_world_player_t*);\n";
            if (exported.contains("gameworlditems_player_attack"))
                api += "uint8_t " + id + "_gameworlditems_player_attack(int32_t,int32_t,uint16_t,uint16_t,uint8_t);\n";
        }
        if (exported.contains("gameworlditems_check"))
            api += "uint16_t " + id + "_gameworlditems_check(int32_t,int32_t,uint16_t,uint16_t,game_pickup_callback_t,void*);\n";
    }
    if (hasMap) {
        api += "#include \"../../gamehelpers/gametilemap.h\"\n"
               "#include \"gamelevels/" + id + ".h\"\n";
    }
    api += "#endif\n";
    if (!writeFile(QStringLiteral("world_api.h"), api))
        return abort(QStringLiteral("Cannot write public world API header."));

    // Never replace a user's existing folder unless it was already created
    // by this exact world exporter. A previous .sbgm test or ordinary custom
    // sources must not be destroyed as a side effect of regeneration.
    const bool hadOld = QDir(destination).exists();
    if (hadOld) {
        QFile prior(QDir(destination).filePath(QStringLiteral("world-build.json")));
        const auto priorManifest = prior.open(QIODevice::ReadOnly)
            ? QJsonDocument::fromJson(prior.readAll()) : QJsonDocument();
        if (!priorManifest.isObject()
            || priorManifest.object().value(QStringLiteral("format")).toString()
                   != QStringLiteral("CODERGIRL-V1-COMPILED-WORLD")
            || priorManifest.object().value(QStringLiteral("worldName")).toString() != worldName)
            return abort(QStringLiteral("Refusing to overwrite user folder worlds/%1. "
                "Move it aside or use a different world name.").arg(worldName));
        // A programmer may add custom files to the visible folder after
        // generation. Never delete those during a later world export.
        QSet<QString> ownedFiles;
        for (const QJsonValue &value : priorManifest.object().value(QStringLiteral("files")).toArray())
            ownedFiles.insert(value.toString());
        QDirIterator iterator(destination, QDir::Files | QDir::NoDotAndDotDot,
                              QDirIterator::Subdirectories);
        while (iterator.hasNext()) {
            const QString existing = QDir(destination).relativeFilePath(iterator.next());
            // Stage 5.36.2: Stage 5.36.1 accidentally generated a TFCard
            // checklist *outside* world-build.json's owned file set. Do not
            // block regeneration on our own abandoned artifact. The staging
            // swap discards it only after publication succeeds; every other
            // unowned file remains protected as before. Require our header so
            // a user-written file with the same name is not silently deleted.
            if (existing == QStringLiteral("TFCard-REQUIRED-FILES.txt")) {
                QFile generatedChecklist(QDir(destination).filePath(existing));
                if (generatedChecklist.open(QIODevice::ReadOnly) &&
                    generatedChecklist.readLine().trimmed() ==
                        QByteArray("# CoderGirl TFCard dependency checklist (generated, do not edit)"))
                    continue;
            }
            if (!ownedFiles.contains(existing))
                return abort(QStringLiteral("World %1 contains an additional file '%2'. "
                    "Move custom code outside the generated world folder before updating.")
                    .arg(worldName, existing));
        }
    }
    QJsonArray buildFiles;
    for (const QString &relative : files)
        if (relative != QStringLiteral("maingame.c.txt")) buildFiles.append(relative);
    buildFiles.append(QStringLiteral("world_symbols.h"));
    buildFiles.append(QStringLiteral("world_api.h"));
    buildFiles.append(QStringLiteral("world-build.json"));
    QJsonObject buildManifest;
    buildManifest.insert(QStringLiteral("files"), buildFiles);
    buildManifest.insert(QStringLiteral("format"), QStringLiteral("CODERGIRL-V1-COMPILED-WORLD"));
    buildManifest.insert(QStringLiteral("version"), 1);
    buildManifest.insert(QStringLiteral("worldName"), worldName);
    buildManifest.insert(QStringLiteral("generatedAt"),
        QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs));
    if (!writeFile(QStringLiteral("world-build.json"),
                   QJsonDocument(buildManifest).toJson(QJsonDocument::Indented)))
        return abort(QStringLiteral("Cannot write world build manifest."));
    if (hadOld && !QDir().rename(destination, previous))
        return abort(QStringLiteral("Cannot preserve previous buildable world."));
    if (!QDir().rename(staging, destination)) {
        if (hadOld) QDir().rename(previous, destination);
        return abort(QStringLiteral("Cannot publish buildable world: %1").arg(worldName));
    }
    if (hadOld) QDir(previous).removeRecursively();
    return true;
}

// Stage 5.2: regenerate ONE shared dispatcher from ALL published worlds.
// These are C symbol addresses and validated filenames, never C gameplay logic.
// Runtime behaviour belongs to gameworlds.rulec/.ruleh.
inline bool publishWorldRegistry(const QDir &project, const QDir &templates,
                                QString *error)
{
    const QDir worlds(project.filePath(QStringLiteral("worlds")));
    const QRegularExpression identifier(QStringLiteral("^[A-Za-z_][A-Za-z0-9_]*$"));
    QStringList names = worlds.entryList(QDir::Dirs | QDir::NoDotAndDotDot,
                                         QDir::Name | QDir::IgnoreCase);
    QStringList published, declarations, records;
    QHash<QString, QString> publishedSaveLayouts;
    QJsonObject sharedPlayer;
    const bool hasSharedPlayer = QFileInfo::exists(GamePlayerProfile::profilePath(project));
    if (hasSharedPlayer && !GamePlayerProfile::read(project, &sharedPlayer, error)) return false;
    QSet<int> availableProfiles;
    for (const QJsonValue &value : GamePlayerProfile::physicsProfiles(sharedPlayer))
        availableProfiles.insert(value.toObject().value(QStringLiteral("id")).toInt(-1));
    QStringList beforeFns, afterFns, attackFns, checkFns, spawnFields, namedStartFields;
    QStringList spawnDeclarations, defaultTransitionIn, defaultTransitionOut, defaultTransitionFrames, defaultCircleOrigin;
    QStringList defaultSpotlightEnabled, defaultSpotlightRadius, defaultSpotlightFeather;
    QStringList defaultSpotlightCenter, defaultSpotlightOffsetX, defaultSpotlightOffsetY;
    QStringList defaultSpotlightMaskIndex, defaultSpotlightMaskColour;
    QStringList defaultSpotlightFlipX, defaultSpotlightFlipY, defaultSpotlightOpacity;
    QStringList defaultSpotlightStable, defaultSpotlightAnimMode, defaultSpotlightAnimMin;
    QStringList defaultSpotlightAnimMax, defaultSpotlightRandomMin, defaultSpotlightRandomMax;
    QStringList defaultSpotlightPulseDelay;
    bool anyMap = false;
    QStringList defaultWeatherMode, defaultWeatherDensity, defaultWeatherWind;
    QStringList defaultWeatherSize, defaultWeatherTile;
    QStringList weatherBitmapSymbols, weatherBitmapSizes, weatherBitmapDeclarations;
    QStringList defaultWeatherColour, defaultWeatherInterval, defaultWeatherStrength, defaultWeatherPaletteStrength;
    QStringList defaultWeatherCurve;
    QStringList defaultWeatherOverlay;
    QStringList defaultWeatherSuspendSpotlight;
    QStringList defaultDayNightMode, defaultDayNightColour, defaultDayNightStrength;
    QStringList defaultDayNightDayFrames, defaultDayNightNightFrames, defaultDayNightFadeFrames, defaultDayNightStartNight;
    QStringList timeEventData, timeDayPtrs, timeNightPtrs, timeDayCounts, timeNightCounts;
    QStringList frontPaletteFns, backPaletteFns;
    bool anyAdventure = false, anyWorldPhysics = false, anyPickups = false;
    for (const QString &name : names) {
        if (name.startsWith(QLatin1Char('.'))) continue;
        const QString directory = worlds.filePath(name);
        // A user may keep their own world folders. Only published GamerGirl
        // directories, identified by our manifest, are registry members.
        if (!QFileInfo::exists(QDir(directory).filePath(QStringLiteral("world-build.json"))))
            continue;
        QFile build(QDir(directory).filePath(QStringLiteral("world-build.json")));
        QFile bundle(project.filePath(QStringLiteral(".codergirl/worlds/") + name
                                      + QStringLiteral("/world.json")));
        if (!build.open(QIODevice::ReadOnly) || !bundle.open(QIODevice::ReadOnly)) {
            if (error) *error = QStringLiteral("Missing world build/bundle manifest for '%1'.").arg(name);
            return false;
        }
        const auto b = QJsonDocument::fromJson(build.readAll()).object();
        const auto meta = QJsonDocument::fromJson(bundle.readAll()).object();
        if (b.value(QStringLiteral("format")).toString() != QStringLiteral("CODERGIRL-V1-COMPILED-WORLD")
            || b.value(QStringLiteral("worldName")).toString() != name
            || meta.value(QStringLiteral("worldName")).toString() != name
            || !identifier.match(name).hasMatch()) {
            if (error) *error = QStringLiteral("Invalid or conflicting published world '%1'.").arg(name);
            return false;
        }
        // This comes from the exact .sbgm that was compiled into the
        // published world. A later unsaved/unexported edit MUST NOT silently
        // change the fingerprint of the existing generated object arrays.
        const QString layoutDigest = meta.value(QStringLiteral("saveLayoutDigest")).toString();
        static const QRegularExpression layoutDigestRe(QStringLiteral("^[0-9a-f]{64}$"));
        if (!layoutDigestRe.match(layoutDigest).hasMatch()) {
            if (error) *error = QStringLiteral(
                "World '%1' was exported before save identity protection. "
                "Open and re-export that world, then regenerate the project. "
                "No existing save files will be modified.").arg(name);
            return false;
        }
        publishedSaveLayouts.insert(name, layoutDigest);
        published << name;
        const QString stem = name + QStringLiteral("_");
        const bool hasMap = QFileInfo::exists(QDir(directory).filePath(
            QStringLiteral("gamelevels/") + name + QStringLiteral(".c")));
        anyMap |= hasMap;
        QFile publicApi(QDir(directory).filePath(QStringLiteral("world_api.h")));
        const QByteArray exposed = publicApi.open(QIODevice::ReadOnly)
            ? publicApi.readAll() : QByteArray();
        const bool splitGameplay = exposed.contains("gameworlditems_update_gameplay");
        const bool splitParticles = exposed.contains("gameworlditems_update_particles");
        const bool behind = exposed.contains("gameworlditems_draw_behind");
        const bool overlay = exposed.contains("gameworlditems_draw_overlay");
        const bool inventoryApi = exposed.contains("gameadventure_store_inventory");
        const bool showBackground = exposed.contains("gameassets_show_background");
        // Old published worlds might still be Stage 5.45 while the user
        // regenerates them one by one. Never reference absent new symbols.
        frontPaletteFns << (exposed.contains("gameassets_front_palette")
            ? name + QStringLiteral("_gameassets_front_palette") : QStringLiteral("0"));
        backPaletteFns << (exposed.contains("gameassets_back_palette")
            ? name + QStringLiteral("_gameassets_back_palette") : QStringLiteral("0"));
        const bool hasWorldPhysics = exposed.contains("gameworlditems_before");
        const bool hasPickup = exposed.contains("gameworlditems_check");
        anyWorldPhysics |= hasWorldPhysics;
        anyPickups |= hasPickup;
        beforeFns << (hasWorldPhysics ? name + QStringLiteral("_gameworlditems_before") : QStringLiteral("0"));
        afterFns << (hasWorldPhysics ? name + QStringLiteral("_gameworlditems_after") : QStringLiteral("0"));
        attackFns << (exposed.contains("gameworlditems_player_attack")
            ? name + QStringLiteral("_gameworlditems_player_attack") : QStringLiteral("0"));
        checkFns << (hasPickup ? name + QStringLiteral("_gameworlditems_check") : QStringLiteral("0"));
        anyAdventure |= meta.value(QStringLiteral("hasAdventure")).toBool();
        declarations << QStringLiteral("#include \"../worlds/%1/world_api.h\"").arg(name);
        const QString zero = QStringLiteral("0");
        const QString objectsGameplay = splitGameplay ? stem + QStringLiteral("gameworlditems_update_gameplay") : zero;
        const QString objectsParticles = splitParticles ? stem + QStringLiteral("gameworlditems_update_particles") : zero;
        const QString objectsBehind = behind ? stem + QStringLiteral("gameworlditems_draw_behind") : zero;
        const QString objectsOverlay = overlay ? stem + QStringLiteral("gameworlditems_draw_overlay") : zero;
        const QString inventoryStore = inventoryApi
            ? stem + QStringLiteral("gameadventure_store_inventory") : zero;
        const QString inventoryLoad = inventoryApi
            ? stem + QStringLiteral("gameadventure_load_inventory") : zero;
        const QString showDirect = showBackground
            ? stem + QStringLiteral("gameassets_show_background") : zero;
        const QString mapVar = hasMap ? QStringLiteral("&game_") + name : zero;
        const QString mapLoad = hasMap ? QStringLiteral("game_") + name + QStringLiteral("_load_map") : zero;
        const QString mapUnload = hasMap ? QStringLiteral("game_") + name + QStringLiteral("_unload_map") : zero;
        const QString atlasLoad = hasMap ? QStringLiteral("game_") + name + QStringLiteral("_load_atlas") : zero;
        const QString atlasUnload = hasMap ? QStringLiteral("game_") + name + QStringLiteral("_unload_atlas") : zero;
        const QString mapPath = meta.value(QStringLiteral("externalMap")).toBool() && hasMap
            ? QStringLiteral("\"gamelevels/") + name + QStringLiteral(".map\"") : zero;
        // Stage 5.4: Player Start is WORLD metadata, not another player object.
        // Read the SAVED .sbgm, not whichever designer tab happens to be open.
        QJsonObject design;
        QFile designFile(meta.value(QStringLiteral("designFile")).toString());
        if (designFile.open(QIODevice::ReadOnly))
            design = QJsonDocument::fromJson(designFile.readAll()).object();
        const QJsonObject start = design.value(QStringLiteral("playerStart")).toObject();
        const QJsonObject weather = design.value(QStringLiteral("weather")).toObject();
        defaultWeatherMode << QString::number(qBound(0, weather.value(QStringLiteral("mode")).toInt(0), 3));
        defaultWeatherDensity << QString::number(qBound(1, weather.value(QStringLiteral("density")).toInt(48), 64));
        defaultWeatherWind << QString::number(qBound(-8, weather.value(QStringLiteral("wind")).toInt(0), 8));
        defaultWeatherSize << QString::number(qBound(2, weather.value(QStringLiteral("particleSize")).toInt(5), 32));
        defaultWeatherTile << QString::number(qBound(0, weather.value(QStringLiteral("particleTileId")).toInt(0), 65535));
        // Embed ONLY the selected tile (not an entire PPB) from a named Game
        // Resource. This also works in worlds without a .map tile atlas.
        // Legacy records without a selected resource still use the map atlas.
        QString bitmapSymbol = QStringLiteral("0"), bitmapSize = QStringLiteral("0");
        const QString chosenResource = weather.value(QStringLiteral("particleAtlasId")).toString();
        const int chosenCell = weather.value(QStringLiteral("particleTileId")).toInt();
        const int cellSize = weather.value(QStringLiteral("particleTileSize")).toInt(8);
        if (!chosenResource.isEmpty() && chosenCell > 0 &&
            weather.value(QStringLiteral("mode")).toInt() == 2) {
            if (cellSize != 8 && cellSize != 16 && cellSize != 32) {
                if (error) *error = QStringLiteral("World '%1': invalid snow atlas tile size.").arg(name);
                return false;
            }
            QString imagePath;
            for (const QJsonValue &value : design.value(QStringLiteral("resources")).toArray()) {
                const QJsonObject resource = value.toObject();
                if (resource.value(QStringLiteral("id")).toString() == chosenResource) {
                    const QString kind = resource.value(QStringLiteral("kind")).toString();
                    if (kind == QStringLiteral("tileatlas") || kind == QStringLiteral("sprite"))
                        imagePath = resource.value(QStringLiteral("path")).toString();
                    break;
                }
            }
            if (imagePath.isEmpty()) {
                if (error) *error = QStringLiteral("World '%1': selected snow atlas is missing from Game Resources.").arg(name);
                return false;
            }
            SidboxPpb::Picture picture;
            QString readError;
            if (!SidboxPpb::read(QDir(QFileInfo(meta.value(QStringLiteral("designFile")).toString())
                            .absolutePath()).filePath(imagePath), &picture, &readError)) {
                if (error) *error = QStringLiteral("World '%1': snow atlas %2 could not be read: %3")
                    .arg(name, imagePath, readError);
                return false;
            }
            const QImage &sheet = picture.indexed;
            if (sheet.width() % cellSize || sheet.height() % cellSize ||
                chosenCell > (sheet.width() / cellSize) * (sheet.height() / cellSize)) {
                if (error) *error = QStringLiteral("World '%1': selected snow atlas tile is outside the %2 px atlas.")
                    .arg(name).arg(cellSize);
                return false;
            }
            const int columns = sheet.width() / cellSize;
            const int index = chosenCell - 1;
            QStringList pixels;
            pixels.reserve(cellSize * cellSize);
            for (int row = 0; row < cellSize; ++row) {
                const uchar *source = sheet.constScanLine((index / columns) * cellSize + row) +
                    (index % columns) * cellSize;
                for (int col = 0; col < cellSize; ++col)
                    pixels << QString::number(source[col]);
            }
            bitmapSymbol = QStringLiteral("cg_weather_snow_%1").arg(name);
            bitmapSize = QString::number(cellSize);
            weatherBitmapDeclarations << QStringLiteral("static const uint8_t %1[%2] = {%3};")
                .arg(bitmapSymbol).arg(cellSize * cellSize).arg(pixels.join(QLatin1Char(',')));
        }
        weatherBitmapSymbols << bitmapSymbol;
        weatherBitmapSizes << bitmapSize;
        defaultWeatherColour << QString::number(qBound(1, weather.value(QStringLiteral("paletteIndex")).toInt(15), 254));
        defaultWeatherInterval << QString::number(qBound(100, weather.value(QStringLiteral("lightningInterval")).toInt(350), 2000));
        defaultWeatherStrength << QString::number(qBound(10, weather.value(QStringLiteral("lightningStrength")).toInt(75), 100));
        defaultWeatherCurve << QString::number(qBound(0, weather.value(QStringLiteral("lightningCurve")).toInt(25), 100) + 1);
        defaultWeatherOverlay << (weather.value(QStringLiteral("lightningOverlayEnabled")).toBool(true)
            ? QStringLiteral("1") : QStringLiteral("0"));
        defaultWeatherPaletteStrength << QString::number(qBound(0, weather.value(QStringLiteral("paletteFlashStrength")).toInt(0), 100));
        defaultWeatherSuspendSpotlight << (weather.value(QStringLiteral("suspendSpotlightOnLightning")).toBool(false)
            ? QStringLiteral("1") : QStringLiteral("0"));
        const QJsonObject dayNight = design.value(QStringLiteral("dayNight")).toObject();
        defaultDayNightMode << QString::number(qBound(0, dayNight.value(QStringLiteral("mode")).toInt(0), 2));
        QColor targetTint(dayNight.value(QStringLiteral("targetColour")).toString(QStringLiteral("#233b68")));
        if (!targetTint.isValid()) targetTint = QColor(QStringLiteral("#233b68"));
        defaultDayNightColour << QStringLiteral("0x%1u").arg(targetTint.rgb() & 0xffffffu, 6, 16, QLatin1Char('0'));
        defaultDayNightStrength << QString::number(qBound(0, dayNight.value(QStringLiteral("strength")).toInt(65), 100));
        defaultDayNightDayFrames << QString::number(qBound(50, dayNight.value(QStringLiteral("dayFrames")).toInt(3000), 30000));
        defaultDayNightNightFrames << QString::number(qBound(50, dayNight.value(QStringLiteral("nightFrames")).toInt(3000), 30000));
        defaultDayNightFadeFrames << QString::number(qBound(25, dayNight.value(QStringLiteral("fadeFrames")).toInt(500), 10000));
        defaultDayNightStartNight << (dayNight.value(QStringLiteral("startAtNight")).toBool(false)
            ? QStringLiteral("1") : QStringLiteral("0"));
        // Resolve stable resource IDs to the *actual generated per-world slots*.
        // This mirrors Game Designer's exported worldObjects ordering.
        QHash<QString,int> objectSlots, npcSlots;
        int objectSlot=0;
        for(const QJsonValue &v:design.value(QStringLiteral("resources")).toArray()) {
            const QJsonObject resource=v.toObject();
            if(resource.value(QStringLiteral("kind")).toString()!=QStringLiteral("sprite"))continue;
            const QString type=resource.value(QStringLiteral("gameObject")).toObject()
                .value(QStringLiteral("type")).toString(QStringLiteral("decoration"));
            if(type!=QStringLiteral("decoration") && type!=QStringLiteral("collectable"))
                objectSlots.insert(resource.value(QStringLiteral("id")).toString(),objectSlot++);
        }
        const QJsonArray npcs=design.value(QStringLiteral("adventure")).toObject()
            .value(QStringLiteral("npcs")).toArray();
        for(int n=0;n<npcs.size();++n)
            npcSlots.insert(npcs[n].toObject().value(QStringLiteral("spriteId")).toString(),n);
        auto compileTimeActions=[&](const QJsonArray &list,const QString &suffix,
                                    QStringList &pointers,QStringList &counts)->bool {
            QStringList rows;
            for(const QJsonValue &v:list) {
                const QJsonObject a=v.toObject();
                const QString target=a.value(QStringLiteral("target")).toString();
                const bool npc=target.startsWith(QStringLiteral("npc:"));
                const QString id=target.mid(npc?4:7);
                // Qt defines `slots` as a keyword macro. Never use it as a
                // local identifier in a Qt translation unit.
                const auto &resolvedSlots=npc?npcSlots:objectSlots;
                if(!(npc||target.startsWith(QStringLiteral("object:")))||!resolvedSlots.contains(id)) {
                    if(error)*error=QStringLiteral("Day/night %1 action targets a missing %2 in world %3. Edit World Settings.")
                        .arg(suffix,target,name);
                    return false;
                }
                const int action=qBound(0,a.value(QStringLiteral("action")).toInt(1),2);
                rows<<QStringLiteral("{%1u,%2u,%3u}").arg(resolvedSlots.value(id)).arg(npc?1:0).arg(action);
            }
            if(rows.isEmpty()){pointers<<QStringLiteral("0");counts<<QStringLiteral("0");return true;}
            const QString symbol=QStringLiteral("gw_time_%1_%2").arg(name,suffix);
            timeEventData<<QStringLiteral("static const gw_time_action_t %1[] = {%2};")
                .arg(symbol,rows.join(QLatin1Char(',')));
            pointers<<symbol;
            counts<<QString::number(rows.size());
            return true;
        };
        if(!compileTimeActions(dayNight.value(QStringLiteral("dayActions")).toArray(),
                               QStringLiteral("day"),timeDayPtrs,timeDayCounts) ||
           !compileTimeActions(dayNight.value(QStringLiteral("nightActions")).toArray(),
                               QStringLiteral("night"),timeNightPtrs,timeNightCounts))return false;
        int spawnX = start.value(QStringLiteral("x")).toInt(0);
        int spawnY = start.value(QStringLiteral("y")).toInt(0);
        if (start.isEmpty()) { // Backwards compatible with pre-5.4 player placement.
            for (const QJsonValue &value : design.value(QStringLiteral("resources")).toArray()) {
                const QJsonObject resource=value.toObject();
                if (resource.value(QStringLiteral("kind")).toString()==QStringLiteral("sprite")
                    && resource.value(QStringLiteral("name")).toString().compare(
                        QStringLiteral("player"),Qt::CaseInsensitive)==0) {
                    spawnX=resource.value(QStringLiteral("x")).toInt();
                    spawnY=resource.value(QStringLiteral("y")).toInt();
                    break;
                }
            }
        }
        const int facing=qBound(0,start.value(QStringLiteral("facing")).toInt(1),1);
        const int worldPhysicsId = hasSharedPlayer
            ? GamePlayerProfile::physicsForWorld(sharedPlayer, name) : 0;
        if (hasSharedPlayer && !availableProfiles.contains(worldPhysicsId)) {
            if (error) *error = QStringLiteral("World '%1' references missing physics profile ID %2.")
                .arg(name).arg(worldPhysicsId);
            return false;
        }
        const auto transitionMode = [](const QString &key) {
            static const QStringList modes = {QStringLiteral("none"), QStringLiteral("fade"),
                QStringLiteral("left"), QStringLiteral("right"), QStringLiteral("up"),
                QStringLiteral("down"), QStringLiteral("circle")};
            return qMax(0, modes.indexOf(key));
        };
        const int outMode = transitionMode(start.value(QStringLiteral("transitionOut")).toString());
        const int inMode = transitionMode(start.value(QStringLiteral("transitionIn")).toString());
        const int transitionFrames = qBound(1, start.value(QStringLiteral("transitionFrames")).toInt(30), 150);
        defaultTransitionIn << QString::number(inMode);
        defaultTransitionOut << QString::number(outMode);
        defaultTransitionFrames << QString::number(transitionFrames);
        defaultCircleOrigin << (start.value(QStringLiteral("circleOrigin")).toString() == QStringLiteral("location")
            ? QStringLiteral("1") : QStringLiteral("0"));
        defaultSpotlightEnabled << (start.value(QStringLiteral("spotlightEnabled")).toBool(false)
            ? QStringLiteral("1") : QStringLiteral("0"));
        defaultSpotlightRadius << QString::number(qBound(16, start.value(QStringLiteral("spotlightRadius")).toInt(96), 240));
        defaultSpotlightFeather << QString::number(qBound(0, start.value(QStringLiteral("spotlightFeather")).toInt(24), 96));
        defaultSpotlightCenter << (start.value(QStringLiteral("spotlightCenter")).toBool(true)
            ? QStringLiteral("1") : QStringLiteral("0"));
        defaultSpotlightOffsetX << QString::number(qBound(-240, start.value(QStringLiteral("spotlightOffsetX")).toInt(0), 240));
        defaultSpotlightOffsetY << QString::number(qBound(-240, start.value(QStringLiteral("spotlightOffsetY")).toInt(0), 240));
        defaultSpotlightFlipX << (start.value(QStringLiteral("spotlightFlipX")).toBool(false) ? QStringLiteral("1") : QStringLiteral("0"));
        defaultSpotlightFlipY << (start.value(QStringLiteral("spotlightFlipY")).toBool(false) ? QStringLiteral("1") : QStringLiteral("0"));
        /* The runtime uses 0 for old generated rows (100% opacity). New values
         * encode percent+1, so 1 means genuine zero-opacity darkness. */
        defaultSpotlightOpacity << QString::number(qBound(0, start.value(QStringLiteral("spotlightOpacity")).toInt(100), 100) + 1);
        defaultSpotlightStable << (start.value(QStringLiteral("spotlightStableDither")).toBool(true) ? QStringLiteral("1") : QStringLiteral("0"));
        defaultSpotlightAnimMode << QString::number(qBound(0, start.value(QStringLiteral("spotlightAnimMode")).toInt(0), 2));
        const int amin = qBound(0, start.value(QStringLiteral("spotlightAnimMin")).toInt(12), 96);
        defaultSpotlightAnimMin << QString::number(amin);
        defaultSpotlightAnimMax << QString::number(qBound(amin, start.value(QStringLiteral("spotlightAnimMax")).toInt(32), 96));
        const int dmin = qBound(1, start.value(QStringLiteral("spotlightAnimDelayMin")).toInt(3), 600);
        defaultSpotlightRandomMin << QString::number(dmin);
        defaultSpotlightRandomMax << QString::number(qBound(dmin, start.value(QStringLiteral("spotlightAnimDelayMax")).toInt(12), 600));
        defaultSpotlightPulseDelay << QString::number(qBound(1, start.value(QStringLiteral("spotlightAnimPulseDelay")).toInt(3), 600));
        defaultSpotlightMaskIndex << QString::number(qBound(1, start.value(QStringLiteral("spotlightMaskIndex")).toInt(255), 255));
        {
            QColor mask(start.value(QStringLiteral("spotlightMaskColour")).toString(QStringLiteral("#000000")));
            if (!mask.isValid()) mask = QColor(Qt::black);
            defaultSpotlightMaskColour << QStringLiteral("0xff%1u")
                .arg(qulonglong(mask.rgb() & 0xffffffu), 6, 16, QLatin1Char('0'));
        }
        spawnFields << QStringLiteral(", %1, %2, %3, %4")
            .arg(spawnX).arg(spawnY).arg(facing).arg(worldPhysicsId);
        QStringList entries;
        QSet<QString> knownIds{QStringLiteral("default")};
        const QRegularExpression startIdPattern(QStringLiteral("^[a-zA-Z0-9_-]{1,63}$"));
        for (const QJsonValue &v : design.value(QStringLiteral("playerStarts")).toArray()) {
            const QJsonObject entry = v.toObject();
            const QString id = entry.value(QStringLiteral("id")).toString();
            if (!startIdPattern.match(id).hasMatch() || knownIds.contains(id)) {
                if (error) *error = QStringLiteral("Invalid or duplicate Player Start ID in '%1'.").arg(name);
                return false;
            }
            knownIds.insert(id);
            entries << QStringLiteral("{\"%1\", %2, %3, %4, %5, %6, %7, %8}")
                .arg(id)
                .arg(qBound(0, entry.value(QStringLiteral("x")).toInt(), 32767))
                .arg(qBound(0, entry.value(QStringLiteral("y")).toInt(), 32767))
                .arg(qBound(0, entry.value(QStringLiteral("facing")).toInt(1), 1))
                .arg(transitionMode(entry.value(QStringLiteral("transitionIn")).toString()))
                .arg(transitionMode(entry.value(QStringLiteral("transitionOut")).toString()))
                .arg(qBound(1, entry.value(QStringLiteral("transitionFrames")).toInt(30), 150))
                .arg(entry.value(QStringLiteral("circleOrigin")).toString() == QStringLiteral("location") ? 1 : 0);
        }
        if (entries.isEmpty()) namedStartFields << QStringLiteral(", 0, 0");
        else {
            const QString symbol = name + QStringLiteral("_player_starts");
            spawnDeclarations << QStringLiteral("static const gameworlds_named_spawn_t %1[] = { %2 };")
                .arg(symbol, entries.join(QStringLiteral(", ")));
            namedStartFields << QStringLiteral(", %1, sizeof(%1) / sizeof(%1[0])").arg(symbol);
        }
        QString row = QStringLiteral("    {\"%1\", %2gameassets_init, %2gameassets_shutdown,\n"
            "     %2gameworlditems_init, %2gameworlditems_update, %3, %4, %2gameworlditems_draw, %5, %6,\n"
            "     %2gameassets_draw_foreground, %2gameassets_draw_background, %7,\n"
            "     %2gameadventure_setup, %8, %9,\n"
            "     %10, %11, %12, %13, %14, %15}");
        const QStringList values = {name, stem, objectsGameplay, objectsParticles, objectsBehind, objectsOverlay, showDirect,
            inventoryStore, inventoryLoad, mapVar, mapLoad, mapUnload,
            atlasLoad, atlasUnload, mapPath};
        for (int i = values.size(); i >= 1; --i)
            row.replace(QStringLiteral("%") + QString::number(i), values.at(i - 1));
        records << row;
    }
    if (published.isEmpty()) {
        if (error) *error = QStringLiteral("No published worlds exist to create a world registry.");
        return false;
    }
    for (int i = 0; i < records.size(); ++i) {
        QString &entry = records[i];
        entry.chop(1); // old final '}'
        if (anyWorldPhysics)
            entry += QStringLiteral(", ") + beforeFns.at(i) + QStringLiteral(", ") + afterFns.at(i);
        if (anyPickups)
            entry += QStringLiteral(", ") + checkFns.at(i);
        entry += spawnFields.at(i);
        entry += namedStartFields.at(i);
        // Transition defaults belong to the saved world's default entrance.
        // Each named entrance overrides them in its own generated row.
        entry += QStringLiteral(", %1, %2, %3, %4").arg(defaultTransitionIn.at(i))
            .arg(defaultTransitionOut.at(i)).arg(defaultTransitionFrames.at(i)).arg(defaultCircleOrigin.at(i));
        entry += QStringLiteral(", %1, %2, %3, %4, %5, %6").arg(defaultSpotlightEnabled.at(i))
            .arg(defaultSpotlightRadius.at(i)).arg(defaultSpotlightFeather.at(i))
            .arg(defaultSpotlightCenter.at(i)).arg(defaultSpotlightOffsetX.at(i))
            .arg(defaultSpotlightOffsetY.at(i));
        entry += QStringLiteral(", %1, %2").arg(defaultSpotlightMaskIndex.at(i), defaultSpotlightMaskColour.at(i));
        entry += QStringLiteral(", %1, %2, %3").arg(defaultSpotlightFlipX.at(i))
            .arg(defaultSpotlightFlipY.at(i)).arg(defaultSpotlightOpacity.at(i));
        entry += QStringLiteral(", %1, %2, %3, %4, %5, %6, %7").arg(defaultSpotlightStable.at(i))
            .arg(defaultSpotlightAnimMode.at(i)).arg(defaultSpotlightAnimMin.at(i))
            .arg(defaultSpotlightAnimMax.at(i)).arg(defaultSpotlightRandomMin.at(i))
            .arg(defaultSpotlightRandomMax.at(i)).arg(defaultSpotlightPulseDelay.at(i));
        entry += QStringLiteral(", %1, %2")
            .arg(frontPaletteFns.at(i), backPaletteFns.at(i));
        const QString id = published.at(i);
        entry += QStringLiteral(", %1_gameworlditems_save_state, %1_gameworlditems_restore_state, "
                                "%1_gameadventure_save_progress, %1_gameadventure_restore_progress, "
                                "%1_gameworlditems_set_active, %1_gameworlditems_remote_action, "
                                "%1_gameworlditems_remote_reset, %1_gameworlditems_apply_remote, "
                                "%1_gameadventure_npc_action, %1_gameadventure_npc_remote_action, "
                                "%1_gameadventure_npc_remote_reset")
            .arg(id);
        entry += QStringLiteral(", %1, %2, %3, %4, %5, %6, %7, %8, %9")
            .arg(defaultWeatherMode.at(i)).arg(defaultWeatherDensity.at(i))
            .arg(defaultWeatherWind.at(i)).arg(defaultWeatherColour.at(i))
            .arg(defaultWeatherInterval.at(i)).arg(defaultWeatherStrength.at(i))
            .arg(defaultWeatherPaletteStrength.at(i)).arg(defaultWeatherSuspendSpotlight.at(i))
            .arg(defaultWeatherOverlay.at(i));
        entry += QStringLiteral(", %1, %2, %3, %4, %5, %6, %7")
            .arg(defaultDayNightMode.at(i)).arg(defaultDayNightColour.at(i))
            .arg(defaultDayNightStrength.at(i)).arg(defaultDayNightDayFrames.at(i))
            .arg(defaultDayNightNightFrames.at(i)).arg(defaultDayNightFadeFrames.at(i))
            .arg(defaultDayNightStartNight.at(i));
        /* Trailing encoded field keeps previously generated world rows valid. */
        entry += QStringLiteral(", %1").arg(defaultWeatherCurve.at(i));
        entry += QStringLiteral(", %1_gameworlditems_disk_export, %1_gameworlditems_disk_import, "
                                "%1_gameadventure_disk_export, %1_gameadventure_disk_import").arg(id);
        entry += QStringLiteral(", %1, %2, %3, %4")
            .arg(timeDayPtrs.at(i),timeNightPtrs.at(i),timeDayCounts.at(i),timeNightCounts.at(i));
        entry += QStringLiteral(", %1_gameworlditems_sync_logic").arg(id);
        entry += QStringLiteral(", %1, %2, %3, %4")
            .arg(defaultWeatherSize.at(i), defaultWeatherTile.at(i),
                 weatherBitmapSymbols.at(i), weatherBitmapSizes.at(i));
        entry += QStringLiteral(", %1_gameworlditems_checkpoint_saved").arg(id);
        entry += QStringLiteral(", %1_gameworlditems_quest_completed").arg(id);
        // Trailing nullable callback: older worlds lacking the attack API are safe.
        entry += QStringLiteral(", ") + attackFns.at(i);
        entry += QLatin1Char('}');
    }
    // Use active selection as initial world. This does NOT force main.c to
    // load anything; it only chooses the default for gameworlds_start(NULL).
    QFile active(project.filePath(QStringLiteral(".codergirl/active-world.json")));
    if (active.open(QIODevice::ReadOnly)) {
        const QString first = QJsonDocument::fromJson(active.readAll()).object()
            .value(QStringLiteral("worldName")).toString();
        if (published.contains(first)) {
            published.removeAll(first);
            published.prepend(first);
        }
    }
    // Reorder C records to keep the same default order as published names.
    // Each record begins with the escaped, validated name literal.
    QStringList ordered;
    for (const QString &name : published)
        for (const QString &record : records)
            if (record.startsWith(QStringLiteral("    {\"") + name + QStringLiteral("\",")))
                ordered << record;
    QFile source(templates.filePath(QStringLiteral("gameworlds.rulec")));
    QFile header(templates.filePath(QStringLiteral("gameworlds.ruleh")));
    if (!source.open(QIODevice::ReadOnly) || !header.open(QIODevice::ReadOnly)) {
        if (error) *error = QStringLiteral("Missing SDK gameworlds.rulec/.ruleh templates.");
        return false;
    }
    QByteArray generated = source.readAll();
    generated.replace("@IDE{WORLD_DECLARATIONS}",
        (declarations + spawnDeclarations + timeEventData + weatherBitmapDeclarations)
            .join(QLatin1Char('\n')).toUtf8());
    generated.replace("@IDE{WORLD_RECORDS}", ordered.join(QStringLiteral(",\n")).toUtf8());
    /* Stable per-project TFCard namespace. Do not use randomised qHash(). */
    uint32_t saveKey=2166136261u;
    QStringList stableWorldNames=published;
    stableWorldNames.sort();
    const QByteArray fingerprintSource = project.dirName().toUtf8() + '/' +
        stableWorldNames.join(QLatin1Char('/')).toUtf8();
    for (const char ch : fingerprintSource) {
        saveKey ^= (uint8_t)ch;
        saveKey *= 16777619u;
    }
    generated.replace("@IDE{SAVE_KEY}", QByteArray::number(saveKey));
    // Stage 5.166.109: bind a save to the exact ordered identity of every
    // published world's serialized objects and story, plus quest indices.
    // A SHA-256-derived 64-bit key is embedded in the new v3 save header.
    // Cosmetic changes to unrelated resources do not affect this identity.
    QJsonArray saveWorlds;
    for (const QString &name : published) {
        QJsonObject entry;
        entry.insert(QStringLiteral("world"), name);
        entry.insert(QStringLiteral("digest"), publishedSaveLayouts.value(name));
        saveWorlds.append(entry);
    }
    QJsonArray projectQuests;
    if (!GameQuestGen::read(project,&projectQuests,error)) return false;
    QJsonArray saveQuests;
    for (const QJsonValue &v : projectQuests) {
        const QJsonObject quest=v.toObject();
        QJsonObject entry;
        entry.insert(QStringLiteral("id"),quest.value(QStringLiteral("id")));
        QJsonArray steps;
        for (const QJsonValue &sv : quest.value(QStringLiteral("objectives")).toArray()) {
            const QJsonObject step=sv.toObject();
            QJsonArray identity;
            identity.append(step.value(QStringLiteral("id")));
            identity.append(step.value(QStringLiteral("kind")));
            identity.append(step.value(QStringLiteral("target")));
            steps.append(identity);
        }
        entry.insert(QStringLiteral("steps"),steps);
        saveQuests.append(entry);
    }
    QJsonObject saveLayout;
    saveLayout.insert(QStringLiteral("schema"),QStringLiteral("CG-SAVE-V3-LAYOUT-1"));
    saveLayout.insert(QStringLiteral("worlds"),saveWorlds);
    saveLayout.insert(QStringLiteral("quests"),saveQuests);
    const QByteArray identityBytes = QCryptographicHash::hash(
        QJsonDocument(saveLayout).toJson(QJsonDocument::Compact),QCryptographicHash::Sha256);
    // Hex preserves the hash byte order without relying on host endianness.
    const QByteArray identityLiteral = "0x" + identityBytes.left(8).toHex();
    if (!generated.contains("@IDE{SAVE_IDENTITY}")) {
        if (error) *error=QStringLiteral("SDK gameworlds.rulec is missing the save-identity marker.");
        return false;
    }
    generated.replace("@IDE{SAVE_IDENTITY}",identityLiteral);
    if (!generated.contains("@IDE{QUEST_DATA}")) {
        if(error)*error=QStringLiteral("SDK gameworlds.rulec is missing the Stage 5.165 quest data marker.");
        return false;
    }
    generated.replace("@IDE{QUEST_DATA}",GameQuestGen::generateData(projectQuests));
    // Stage 5.163: the world manager must use the SAME nested condition
    // renderer as every other rule-owned helper. The previous substring-based
    // expander stopped at the first @IDE_END, even when it closed an inner
    // block (notably HAS_PICKUPS / HAS_ADVENTURE_RUNTIME / HAS_SHARED_PLAYER).
    // That could emit malformed C or leave stray directives in valid worlds.
    const QMap<QString, QString> conditionFlags = {
        {QStringLiteral("HAS_TITLE"), GameTitleRuntime::enabled(project.absolutePath()) ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_ADVENTURE_RUNTIME"), anyAdventure ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_WORLD_PHYSICS"), anyWorldPhysics ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_PICKUPS"), anyPickups ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_PLAYER_VISIBILITY"), (anyAdventure && hasSharedPlayer) ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_SHARED_PLAYER"), hasSharedPlayer ? QStringLiteral("1") : QStringLiteral("0")},
        {QStringLiteral("HAS_MAP"), anyMap ? QStringLiteral("1") : QStringLiteral("0")}
    };
    QByteArray renderedSource;
    if (!GameHelperTemplates::renderConditionals(generated, conditionFlags,
                                                  QStringLiteral("gameworlds.rulec"),
                                                  &renderedSource, error)) return false;
    if (renderedSource.contains("@IDE{") || renderedSource.contains("@IDE_IF{") ||
        renderedSource.contains("@IDE_ELSE") || renderedSource.contains("@IDE_END")) {
        if (error) *error = QStringLiteral("Unresolved world registry rule token in gameworlds.rulec.");
        return false;
    }
    const QString root = project.filePath(QStringLiteral("gamehelpers"));
    if (!QDir().mkpath(root)) {
        if (error) *error = QStringLiteral("Could not create gamehelpers for world manager.");
        return false;
    }
    const QStringList dests = {QDir(root).filePath(QStringLiteral("gameworlds.h")),
                               QDir(root).filePath(QStringLiteral("gameworlds.c"))};
    QByteArray renderedHeader;
    if (!GameHelperTemplates::renderConditionals(header.readAll(), conditionFlags,
                                                  QStringLiteral("gameworlds.ruleh"),
                                                  &renderedHeader, error)) return false;
    if (renderedHeader.contains("@IDE{") || renderedHeader.contains("@IDE_IF{") ||
        renderedHeader.contains("@IDE_ELSE") || renderedHeader.contains("@IDE_END")) {
        if (error) *error = QStringLiteral("Unresolved world registry rule token in gameworlds.ruleh.");
        return false;
    }
    const QList<QByteArray> bytes = {renderedHeader, renderedSource};
    // Check BOTH destinations before writing EITHER: a user-owned .c must
    // not leave a newly updated .h behind on a failed publication.
    for (const QString &destination : dests) {
        QFile check(destination);
        if (check.exists() && (!check.open(QIODevice::ReadOnly)
             || !check.read(200).contains("GamerGirl Stage 5.2"))) {
            if (error) *error = QStringLiteral("Refusing to overwrite user-owned file: %1").arg(destination);
            return false;
        }
    }
    for (int i = 0; i < dests.size(); ++i) {
        QSaveFile out(dests.at(i));
        if (!out.open(QIODevice::WriteOnly) || out.write(bytes.at(i)) != bytes.at(i).size() || !out.commit()) {
            if (error) *error = QStringLiteral("Could not write generated multi-world runtime: %1").arg(dests.at(i));
            return false;
        }
    }
    const QString guide = QDir(root).filePath(QStringLiteral("gameworlds-guide.txt"));
    if (!QFileInfo::exists(guide)) {
        QFile templateGuide(templates.filePath(QStringLiteral("gameworlds.ruletxt")));
        if (!templateGuide.open(QIODevice::ReadOnly)) {
            if (error) *error = QStringLiteral("Missing SDK multi-world guide template.");
            return false;
        }
        QSaveFile output(guide);
        const QByteArray guideBytes = templateGuide.readAll();
        if (!output.open(QIODevice::WriteOnly)
            || output.write(guideBytes) != guideBytes.size() || !output.commit()) {
            if (error) *error = QStringLiteral("Could not install generated multi-world guide.");
            return false;
        }
    }
    return true;
}

inline bool publish(const QString &designPath, const QString &worldName,
                    bool hasMap, bool externalMap, bool hasSpline,
                    bool hasAdventure, bool embedPixels, const QString &rulesDirectory, QString *error)
{
    const QDir project(QFileInfo(designPath).absolutePath());
    // Fingerprint the saved design that the world exporter just compiled.
    // Collectables and all other world objects occupy DIFFERENT serialized
    // arrays, each in the original resource order. Use stable UUIDs, not
    // names, positions or the live object's current state.
    QFile savedDesign(designPath);
    QJsonParseError parseError;
    if (!savedDesign.open(QIODevice::ReadOnly)) {
        if (error) *error=QStringLiteral("Cannot read saved world for save identity: %1").arg(designPath);
        return false;
    }
    const QJsonDocument document=QJsonDocument::fromJson(savedDesign.readAll(),&parseError);
    if (parseError.error!=QJsonParseError::NoError || !document.isObject()) {
        if (error) *error=QStringLiteral("Cannot parse saved world for save identity: %1").arg(designPath);
        return false;
    }
    const QJsonObject savedWorld=document.object();
    QJsonArray pickups, objects;
    QSet<QString> seenIds;
    for (const QJsonValue &v : savedWorld.value(QStringLiteral("resources")).toArray()) {
        const QJsonObject r=v.toObject();
        if (r.value(QStringLiteral("kind")).toString()!=QStringLiteral("sprite")) continue;
        const QString type=r.value(QStringLiteral("gameObject")).toObject()
            .value(QStringLiteral("type")).toString(QStringLiteral("decoration"));
        if (type==QStringLiteral("decoration")) continue;
        const QString id=r.value(QStringLiteral("id")).toString();
        if (id.isEmpty() || seenIds.contains(id)) {
            if (error) *error=QStringLiteral(
                "World '%1' has a missing or duplicate Game Object UUID. "
                "Save the world and repair the resource before exporting.").arg(worldName);
            return false;
        }
        seenIds.insert(id);
        QJsonArray identity;
        identity.append(id);
        identity.append(type);
        if (type==QStringLiteral("collectable")) pickups.append(identity);
        else objects.append(identity);
    }
    // Adventure saves store NPCs, used dialogue-choice bits and item/exchange
    // progress by index. Dialogue nodes currently lack stable UUIDs, so keep
    // their ordered definitions in the fingerprint (conservative by design).
    const QJsonObject adventure=savedWorld.value(QStringLiteral("adventure")).toObject();
    QJsonArray npcIdentity;
    for (const QJsonValue &v : adventure.value(QStringLiteral("npcs")).toArray()) {
        const QJsonObject npc=v.toObject();
        QJsonArray identity;
        identity.append(npc.value(QStringLiteral("spriteId")));
        identity.append(npc.value(QStringLiteral("node")));
        identity.append(npc.value(QStringLiteral("doneNode")));
        npcIdentity.append(identity);
    }
    QJsonArray itemIdentity;
    for (const QJsonValue &v : adventure.value(QStringLiteral("items")).toArray()) {
        const QJsonObject item=v.toObject();
        QJsonArray identity;
        identity.append(item.value(QStringLiteral("name")));
        identity.append(item.value(QStringLiteral("pickupKind")));
        itemIdentity.append(identity);
    }
    QJsonObject layout;
    layout.insert(QStringLiteral("schema"),QStringLiteral("CG-WORLD-STATE-V1"));
    layout.insert(QStringLiteral("pickups"),pickups);
    layout.insert(QStringLiteral("objects"),objects);
    layout.insert(QStringLiteral("npcs"),npcIdentity);
    layout.insert(QStringLiteral("nodes"),adventure.value(QStringLiteral("nodes")).toArray());
    layout.insert(QStringLiteral("items"),itemIdentity);
    layout.insert(QStringLiteral("pickupTypes"),adventure.value(QStringLiteral("pickupTypes")).toArray());
    const QString saveLayoutDigest=QString::fromLatin1(QCryptographicHash::hash(
        QJsonDocument(layout).toJson(QJsonDocument::Compact),QCryptographicHash::Sha256).toHex());
    const QString worldParent = project.filePath(QStringLiteral(".codergirl/worlds"));
    if (!QDir().mkpath(worldParent)) {
        if (error) *error = QStringLiteral("Cannot create world snapshot directory: %1").arg(worldParent);
        return false;
    }
    const QString suffix = QUuid::createUuid().toString(QUuid::WithoutBraces);
    const QString staging = QDir(worldParent).filePath(QStringLiteral(".staging-") + suffix);
    const QString destination = QDir(worldParent).filePath(worldName);
    const QString displaced = QDir(worldParent).filePath(QStringLiteral(".previous-") + suffix);
    if (!QDir().mkpath(staging)) {
        if (error) *error = QStringLiteral("Cannot create world snapshot staging directory.");
        return false;
    }
    auto abort = [&](const QString &message) {
        QDir(staging).removeRecursively();
        if (error) *error = message;
        return false;
    };

    QStringList files = {
        QStringLiteral("gameassets/gameassets.c"),
        QStringLiteral("gameassets/gameassets.h"),
        QStringLiteral("gamehelpers/gameworlditems.c"),
        QStringLiteral("gamehelpers/gameworlditems.h"),
        QStringLiteral("gamehelpers/gameworlditems.txt"),
        QStringLiteral("maingame.c.txt")
    };
    // No-story designs also generate a harmless rule-owned Adventure stub.
    files << QStringLiteral("gamehelpers/gameadventure.c")
          << QStringLiteral("gamehelpers/gameadventure.h");
    if (hasSpline)
        files << QStringLiteral("gamehelpers/splinepaths.c")
              << QStringLiteral("gamehelpers/splinepaths.h");
    if (hasMap) {
        const QString base = QStringLiteral("gamelevels/") + worldName;
        files << base + QStringLiteral(".c") << base + QStringLiteral(".h");
        if (externalMap) files << base + QStringLiteral(".map");
    }
    const QDir mapStaging(project.filePath(
        QStringLiteral(".codergirl/tilemap-staging/") + worldName));
    QJsonArray copied;
    for (const QString &relative : files) {
        const QString src = relative.startsWith(QStringLiteral("gamelevels/"))
            ? mapStaging.filePath(relative) : project.filePath(relative);
        if (!QFileInfo(src).isFile()) {
            // World-items stubs and a first-time starter may be absent in
            // legacy projects. Never accidentally archive another world's
            // old generated files to fill that gap.
            return abort(QStringLiteral("Missing generated world file: %1").arg(src));
        }
        const QString dst = QDir(staging).filePath(relative);
        if (!QDir().mkpath(QFileInfo(dst).absolutePath()) || !QFile::copy(src, dst))
            return abort(QStringLiteral("Could not snapshot world file: %1").arg(relative));
        copied.append(relative);
    }
    QJsonObject manifest;
    manifest.insert(QStringLiteral("format"), QStringLiteral("CODERGIRL-V1-WORLD-BUNDLE"));
    manifest.insert(QStringLiteral("version"), 2);
    manifest.insert(QStringLiteral("worldName"), worldName);
    manifest.insert(QStringLiteral("saveLayoutDigest"), saveLayoutDigest);
    manifest.insert(QStringLiteral("designFile"), QFileInfo(designPath).absoluteFilePath());
    manifest.insert(QStringLiteral("generatedAt"), QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs));
    manifest.insert(QStringLiteral("externalMap"), externalMap);
    manifest.insert(QStringLiteral("embedPixels"), embedPixels);
    manifest.insert(QStringLiteral("hasAdventure"), hasAdventure);
    manifest.insert(QStringLiteral("hasSplines"), hasSpline);
    manifest.insert(QStringLiteral("files"), copied);
    {
        QSaveFile output(QDir(staging).filePath(QStringLiteral("world.json")));
        const QByteArray bytes = QJsonDocument(manifest).toJson(QJsonDocument::Indented);
        if (!output.open(QIODevice::WriteOnly) || output.write(bytes) != bytes.size() || !output.commit())
            return abort(QStringLiteral("Could not write world bundle manifest."));
    }
    // A previous world bundle remains intact until the replacement is ready.
    const bool hadPrevious = QDir(destination).exists();
    if (hadPrevious && !QDir().rename(destination, displaced))
        return abort(QStringLiteral("Could not preserve previous world bundle: %1").arg(worldName));
    if (!QDir().rename(staging, destination)) {
        if (hadPrevious) QDir().rename(displaced, destination);
        return abort(QStringLiteral("Could not publish world bundle: %1").arg(worldName));
    }
    if (hadPrevious) QDir(displaced).removeRecursively();

    // Stage 5.1: emit the *compilable* mirror AFTER the private archive has
    // been committed. Never expose a half-written world in Files in Project.
    if (!publishBuildTree(destination, project, worldName, files, hasMap, error))
        return false;

    // Only mark a world active once its entire generated bundle is committed.
    // QSaveFile ensures an interrupted update cannot leave partial JSON.
    const QString activePath = activeFile(designPath);
    QSaveFile active(activePath);
    manifest.remove(QStringLiteral("files"));
    manifest.insert(QStringLiteral("snapshotDirectory"),
                    QStringLiteral(".codergirl/worlds/") + worldName);
    const QByteArray activeBytes = QJsonDocument(manifest).toJson(QJsonDocument::Indented);
    if (!active.open(QIODevice::WriteOnly)
        || active.write(activeBytes) != activeBytes.size() || !active.commit()) {
        active.cancelWriting();
        if (error) *error = QStringLiteral("World bundle saved, but could not update active-world marker: %1").arg(activePath);
        return false;
    }
    // Update the shared registry after the committed world is active.
    if (!publishWorldRegistry(project, QDir(rulesDirectory), error))
        return false;
    QDir(mapStaging).removeRecursively();
    // Stage 5.11: gameworlditems, gameadventure and splinepaths are WORLD
    // modules, not project-wide helpers. Their canonical generation still
    // takes place in project/gamehelpers/ until the world bundle is built,
    // but no duplicate is needed afterwards. Remove ONLY exact copies of
    // published world files. Keep actual shared engine helpers untouched,
    // and preserve an edited root file which differs from every world.
    {
        const QDir rootHelpers(project.filePath(QStringLiteral("gamehelpers")));
        const QDir publishedWorlds(project.filePath(QStringLiteral("worlds")));
        const QStringList generatedNames = {
            QStringLiteral("gameworlditems.c"),
            QStringLiteral("gameworlditems.h"),
            QStringLiteral("gameworlditems.txt"),
            QStringLiteral("gameadventure.c"),
            QStringLiteral("gameadventure.h"),
            QStringLiteral("splinepaths.c"),
            QStringLiteral("splinepaths.h")
        };
        const QByteArray namespaceInclude = "#include \"../world_symbols.h\"\n";
        const QStringList names = publishedWorlds.entryList(
            QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
        for (const QString &filename : generatedNames) {
            const QString rootFile = rootHelpers.filePath(filename);
            QFile original(rootFile);
            if (!original.open(QIODevice::ReadOnly)) continue;
            const QByteArray rootBytes = original.readAll();
            original.close();
            for (const QString &name : names) {
                if (name.startsWith(QLatin1Char('.'))) continue;
                const QDir world(publishedWorlds.filePath(name));
                if (!QFileInfo::exists(world.filePath(QStringLiteral("world-build.json"))))
                    continue;
                QFile published(world.filePath(QStringLiteral("gamehelpers/") + filename));
                if (!published.open(QIODevice::ReadOnly)) continue;
                QByteArray worldBytes = published.readAll();
                if (filename.endsWith(QStringLiteral(".c"))) {
                    // Namespaced world .c modules have precisely one added
                    // include at the beginning, inserted by publishBuildTree.
                    if (!worldBytes.startsWith(namespaceInclude)) continue;
                    worldBytes.remove(0, namespaceInclude.size());
                }
                if (rootBytes == worldBytes) {
                    QFile::remove(rootFile);
                    break;
                }
            }
        }
    }
    // Stage 5.12: gameassets.c/.h are generated for ONE world and already
    // published at worlds/<world>/gameassets/. Never keep a redundant root
    // export after successful publication. Compare bytes against ANY valid
    // published world before removing them, so regeneration of Forest does
    // not depend on which world was generated last. The buildable .c adds
    // exactly one namespace include; generated .h is unchanged.
    {
        const QDir rootAssets(project.filePath(QStringLiteral("gameassets")));
        const QDir publishedWorlds(project.filePath(QStringLiteral("worlds")));
        const QByteArray namespaceInclude = "#include \"../world_symbols.h\"\n";
        const QStringList names = publishedWorlds.entryList(
            QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
        for (const QString &filename : {QStringLiteral("gameassets.c"),
                                        QStringLiteral("gameassets.h")}) {
            const QString rootFile = rootAssets.filePath(filename);
            QFile original(rootFile);
            if (!original.open(QIODevice::ReadOnly)) continue;
            const QByteArray rootBytes = original.readAll();
            original.close();
            for (const QString &name : names) {
                if (name.startsWith(QLatin1Char('.'))) continue;
                const QDir world(publishedWorlds.filePath(name));
                if (!QFileInfo::exists(world.filePath(QStringLiteral("world-build.json"))))
                    continue;
                QFile published(world.filePath(QStringLiteral("gameassets/") + filename));
                if (!published.open(QIODevice::ReadOnly)) continue;
                QByteArray worldBytes = published.readAll();
                if (filename.endsWith(QStringLiteral(".c"))) {
                    if (!worldBytes.startsWith(namespaceInclude)) continue;
                    worldBytes.remove(0, namespaceInclude.size());
                }
                if (rootBytes == worldBytes) {
                    QFile::remove(rootFile);
                    break;
                }
            }
        }
        // Never delete unrelated files that users placed in gameassets/.
        project.rmdir(QStringLiteral("gameassets")); // Only when empty.
    }
    // Clean only recognisable legacy tilemap exports after successful
    // publication. Preserve non-generated files in a user's gamelevels/.
    {
        const QDir root(project.filePath(QStringLiteral("gamelevels")));
        if (root.exists()) {
            const QStringList designs = project.entryList(
                {QStringLiteral("*.sbgm")}, QDir::Files, QDir::Name);
            for (const QString &design : designs) {
                const QString name = sidboxTilemapWorldBaseName(project.filePath(design));
                const QString worldLevels = project.filePath(
                    QStringLiteral("worlds/") + name + QStringLiteral("/gamelevels/"));
                if (!QFileInfo::exists(QDir(worldLevels).filePath(name + QStringLiteral(".c")))
                    || !QFileInfo::exists(QDir(worldLevels).filePath(name + QStringLiteral(".h"))))
                    continue;
                for (const QString &ext : {QStringLiteral(".c"), QStringLiteral(".h"), QStringLiteral(".map")}) {
                    const QString legacy = root.filePath(name + ext);
                    QFile check(legacy);
                    if (!check.open(QIODevice::ReadOnly)) continue;
                    const QByteArray prefix = check.read(4096);
                    const bool generated = ext == QStringLiteral(".c")
                        ? prefix.startsWith(QByteArray("#include \"") + name.toUtf8() + QByteArray(".h\""))
                        : ext == QStringLiteral(".h")
                            ? prefix.contains("Generated from Tilemap Editor")
                            : prefix.startsWith("SBMP");
                    check.close();
                    if (generated) QFile::remove(legacy);
                }
            }
            project.rmdir(QStringLiteral("gamelevels")); // Succeeds only if empty.
        }
    }
    return true;
}

} // namespace GameWorldSnapshot
#endif
