#pragma once
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct Pair {
    int left;
    int right;
} Pair;
Pair make_pair(int left, int right);
Pair update_pair(Pair original, int addition);
int push_node(Node **head, int value);
int sum_nodes(Node *head);
