# Private heap, double pointers, records by value

Copy all three source/header files to the same directory on the TF card.

```
compiler -i tfcard:/pointer-heap-value/main.c tfcard:/pointer-heap-value/operations.c -o tfcard:/pointer-heap-value/demo.app
launch tfcard:/pointer-heap-value/demo.app
```

Expected hardware return value: **174**.

- `Node **handle` changes the head of a linked list across function calls.
- `malloc` and `free` use the generated applet's own 16 KiB arena; freed blocks
  can be reused.
- `Pair` is passed and returned by value; updates must not change `first`.
- No system malloc, libc, `stdlib.h`, or GCC compilation of the sample is
  needed on the SIDBOX.
