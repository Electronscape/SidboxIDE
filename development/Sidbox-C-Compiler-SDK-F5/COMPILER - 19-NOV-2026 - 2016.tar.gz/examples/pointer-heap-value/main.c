#include "types.h"
int main(void)
{
    Node *head = 0;
    Node **handle = &head;
    if (!push_node(handle, 11)) return -1;
    if (!push_node(handle, 22)) return -2;
    Pair first = {4, 6};
    Pair changed = update_pair(first, 8);
    Pair copied = make_pair(30, 40);
    changed = copied;
    int total = sum_nodes(head) + changed.left + changed.right + first.left + first.right;
    Node *old = head;
    head = head->next;
    free(old);
    Node *reused = malloc(sizeof(Node));
    if (reused == 0) return -3;
    reused->value = 50;
    reused->next = head;
    head = reused;
    total += sum_nodes(head);
    free(head->next);
    free(reused);
    return total;
}
