#include "types.h"
Pair make_pair(int left, int right)
{
    Pair result = {0};
    result.left = left;
    result.right = right;
    return result;
}
Pair update_pair(Pair original, int addition)
{
    original.left += addition;
    original.right += 3;
    return original;
}
int push_node(Node **head, int value)
{
    Node *item = malloc(sizeof(Node));
    if (item == 0)
        return 0;
    item->value = value;
    item->next = *head;
    *head = item;
    return 1;
}
int sum_nodes(Node *head)
{
    int total = 0;
    while (head != 0) {
        total += head->value;
        head = head->next;
    }
    return total;
}
