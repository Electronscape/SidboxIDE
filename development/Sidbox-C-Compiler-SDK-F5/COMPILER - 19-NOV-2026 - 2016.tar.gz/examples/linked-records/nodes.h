#pragma once

typedef struct Node {
    int value;
    struct Node *next;
} Node;

typedef struct Scene {
    Node *head;
    Node *tail;
    int count;
    int *score;
} Scene;

int connect_nodes(Node *first, Node *middle, Node *last);
int sum_scene(Scene *scene);
