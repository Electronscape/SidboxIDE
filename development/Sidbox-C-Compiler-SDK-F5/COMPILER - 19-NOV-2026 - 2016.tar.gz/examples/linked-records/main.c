#include "nodes.h"

static Node nodes[3] = {0};

int main(void)
{
    Scene scene = {0};
    int points = 9;
    nodes[0].value = 12;
    nodes[1].value = 23;
    nodes[2].value = 34;

    scene.head = &nodes[0];
    scene.tail = &nodes[2];
    scene.count = 3;
    scene.score = &points;

    int result = connect_nodes(scene.head, &nodes[1], scene.tail);
    result += sum_scene(&scene);
    result += sizeof(Node) + sizeof(Scene);
    result += scene.tail->value;
    result += *scene.score;
    return result;
}
