#include "nodes.h"

int connect_nodes(Node *first, Node *middle, Node *last)
{
    first->next = middle;
    middle->next = last;
    last->next = 0;
    return first->next->value;
}

int sum_scene(Scene *scene)
{
    Node *current = scene->head;
    int total = 0;
    while (current != 0) {
        total += current->value;
        current = current->next;
    }
    return total + scene->count;
}
