#ifndef SIDC_FLAGS_H
#define SIDC_FLAGS_H

enum Flags {
    FLAG_A = 1 << 0,
    FLAG_B = 1 << 3,
    FLAG_C = FLAG_A | FLAG_B
};

typedef enum Mode {
    MODE_IDLE = 0,
    MODE_ACTIVE = 1 << 1
} Mode;

int heap_check(void);
#endif
