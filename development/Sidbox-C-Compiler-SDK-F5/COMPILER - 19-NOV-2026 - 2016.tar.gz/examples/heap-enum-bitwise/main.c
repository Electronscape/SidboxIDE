#include "flags.h"
static const int gain = 7;
int main(void)
{
    const int local = 5;
    enum Flags state = FLAG_C;
    Mode mode = MODE_ACTIVE;
    int x = 1;
    x <<= 5;
    x |= FLAG_B;
    x ^= FLAG_A;
    x &= 63;
    x >>= 2;
    int y = ~0;
    y &= 15;
    y ^= 4;
    int z = (state | FLAG_A) ^ FLAG_A;
    int w = (-16) >> 2;
    int t = 3 << 4;
    return x + y + z + w + t + local + gain + mode + heap_check();
}
