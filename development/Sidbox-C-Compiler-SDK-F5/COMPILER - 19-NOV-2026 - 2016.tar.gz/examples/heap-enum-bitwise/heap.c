#include "flags.h"
int heap_check(void)
{
    int *a = malloc(4096);
    int *b = malloc(4096);
    int *c = malloc(4096);
    if (a == 0 || b == 0 || c == 0) return -1;
    *a = 13;
    *b = 22;
    *c = 39;
    free(b);
    free(a);
    int *joined = malloc(7000);
    if (joined != a) return -2;
    free(joined + 2);
    int *small = malloc(64);
    if (small == joined) return -3;
    free(small);
    free(joined);
    free(joined);
    free(c);
    int *large = malloc(24000);
    if (large == 0) return -4;
    *large = 77;
    int value = *large;
    free(large);
    return value;
}
